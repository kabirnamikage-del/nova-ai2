# NOVA AI Firestore Security Specification

## 1. Data Invariants
1. **Strict Private Ownership**: Every user private profile (`/users/{userId}/private/profile`), conversation (`/users/{userId}/conversations/{conversationId}`), and message (`/users/{userId}/conversations/{conversationId}/messages/{messageId}`) is readable, writable, and listable ONLY by the verified authenticated owner (`request.auth.uid == userId && request.auth.token.email_verified == true`). Even the Super Admin cannot read another user's private conversations.
2. **Single Authorized Super Admin RBAC**: `isSuperAdmin()` requires `request.auth != null && request.auth.token.email_verified == true && request.auth.token.email == 'kabirnamikage@gmail.com'`. No user can self-assign `tier == 'admin'` or access admin audit logs or user directory listings unless matching that exact verified email.
3. **User Directory Isolation**: `/users/{userId}` stores only account status (`active | blocked | suspended`), tier (`free | premium | admin`), display name, email, and non-sensitive activity counts. Users can create their own directory entry strictly as `status: 'active'` and `tier: 'free'` (unless Super Admin), and cannot self-modify `status` or `tier`. Only Super Admin can list all users, change `status`/`tier`, or delete another user's directory entry (never deleting or blocking the Super Admin account itself).
4. **Immutable Audit Logs**: `/admin_audit_logs/{logId}` is readable, listable, and creatable strictly by the Super Admin (`actorUid == request.auth.uid`, `actorEmail == 'kabirnamikage@gmail.com'`, `createdAt == request.time`), and `update`/`delete` are permanently denied.
5. **Immutable Ownership & Timestamps**: `uid`, `ownerId`, `id`, and `createdAt` cannot be modified after creation; `createdAt` and `updatedAt`/`lastActiveAt` must equal `request.time`.

## 2. Dirty Dozen Attack Payloads (All Must Return `PERMISSION_DENIED`)
1. Unauthenticated read of `/users/uid1/conversations/conv1` or `/users/uid1`
2. Unverified email user (`email_verified == false`) creating `/users/uid1/private/profile` or `/users/uid1`
3. Cross-user read: `uid2` attempting `get` or `list` on `/users/uid1/conversations` or `/users/uid1`
4. Super Admin attempting to read `/users/uid2/conversations` (private conversations remain strictly owner-only)
5. Privilege escalation on directory create: normal user creating `/users/uid2` with `tier: "admin"` or `tier: "premium"`
6. Self-unblock or tier tampering: `uid2` updating `status: "active"` or `tier: "premium"` on `/users/uid2`
7. Normal user listing `/users` or `/admin_audit_logs`
8. Normal user creating or tampering with `/admin_audit_logs/log1`
9. Super Admin attempting to update or delete an existing `/admin_audit_logs/log1`
10. Super Admin accidentally blocking or deleting their own `/users/{adminUid}` directory document
11. Oversized path ID poisoning or shadow field injection (`isAdmin: true`)
12. Unvalidated timestamp on create (`createdAt != request.time`)
