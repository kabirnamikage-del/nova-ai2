package com.novaai.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class StreamEvent {
    data class Chunk(val textDelta: String) : StreamEvent()
    data class Error(val message: String) : StreamEvent()
    data object Done : StreamEvent()
}

data class NanoBananaResponse(
    val imageBase64: String? = null,
    val mimeType: String = "image/png",
    val text: String? = null,
    val modelUsed: String? = null,
    val errorMessage: String? = null
)

class NovaApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun normalizeBaseUrl(raw: String): String {
        return raw.trim().trimEnd('/')
    }

    suspend fun fetchModels(baseUrl: String): Result<List<GeminiModelInfo>> = withContext(Dispatchers.IO) {
        try {
            val url = "${normalizeBaseUrl(baseUrl)}/api/models"
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val json = if (body.isNotBlank()) JSONObject(body) else JSONObject()
                if (!response.isSuccessful) {
                    val errMsg = json.optJSONObject("error")?.optString("message")
                        ?.takeIf { it.isNotBlank() }
                        ?: "Server returned HTTP ${response.code}"
                    return@withContext Result.failure(IOException(errMsg))
                }
                val arr = json.optJSONArray("models") ?: JSONArray()
                val list = mutableListOf<GeminiModelInfo>()
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    list.add(
                        GeminiModelInfo(
                            id = item.optString("id"),
                            displayName = item.optString("displayName", item.optString("id")),
                            tier = item.optString("tier", "free"),
                            supportsVision = item.optBoolean("supportsVision", true)
                        )
                    )
                }
                Result.success(list)
            }
        } catch (e: Exception) {
            Result.failure(IOException(e.message ?: "Unable to connect to NOVA backend"))
        }
    }

    fun streamChat(
        baseUrl: String,
        model: String,
        messages: List<ChatMessage>,
        mode: String,
        studyLanguage: String
    ): Flow<StreamEvent> = flow {
        val url = "${normalizeBaseUrl(baseUrl)}/api/chat/stream"
        val payloadMessages = JSONArray()
        for (msg in messages) {
            if (!msg.errorMessage.isNullOrBlank()) continue
            val obj = JSONObject().apply {
                put("role", msg.role)
                put("content", msg.content)
            }
            if (msg.attachments.isNotEmpty()) {
                val attArr = JSONArray()
                for (att in msg.attachments) {
                    attArr.put(
                        JSONObject().apply {
                            put("name", att.name)
                            put("mimeType", att.mimeType)
                            put("data", att.base64Data)
                            put("kind", "image")
                        }
                    )
                }
                obj.put("attachments", attArr)
            }
            payloadMessages.put(obj)
        }

        val root = JSONObject().apply {
            put("model", model)
            put("messages", payloadMessages)
            put("mode", mode)
            put("studyLanguage", studyLanguage)
            put("useWebSearch", false)
        }

        val request = Request.Builder()
            .url(url)
            .post(root.toString().toRequestBody(jsonMediaType))
            .header("Accept", "text/event-stream")
            .build()

        val call = client.newCall(request)
        try {
            call.execute().use { response ->
                val contentType = response.header("Content-Type").orEmpty()
                if (!response.isSuccessful && !contentType.contains("text/event-stream")) {
                    val raw = response.body?.string().orEmpty()
                    val msg = runCatching {
                        JSONObject(raw).optJSONObject("error")?.optString("message")
                    }.getOrNull()?.takeIf { !it.isNullOrBlank() }
                        ?: "Server returned HTTP ${response.code}"
                    emit(StreamEvent.Error(msg))
                    return@flow
                }

                val source = response.body?.source()
                if (source == null) {
                    emit(StreamEvent.Error("Server returned an empty stream."))
                    return@flow
                }

                var eventName = "message"
                val dataLines = StringBuilder()

                while (!source.exhausted()) {
                    currentCoroutineContext().ensureActive()
                    val line = source.readUtf8Line() ?: break
                    if (line.isBlank()) {
                        if (dataLines.isNotEmpty()) {
                            val rawData = dataLines.toString().trim()
                            dataLines.setLength(0)
                            val parsed = runCatching { JSONObject(rawData) }.getOrNull()
                            when (eventName) {
                                "chunk" -> {
                                    val delta = sanitizeTextDelta(parsed?.optString("text").orEmpty())
                                    if (delta.isNotEmpty()) {
                                        emit(StreamEvent.Chunk(delta))
                                    }
                                }
                                "error" -> {
                                    val errTitle = parsed?.optString("title").orEmpty()
                                    val errMsg = parsed?.optString("message").orEmpty()
                                    val hint = parsed?.optString("hint").orEmpty()
                                    val full = listOf(errTitle, errMsg, hint)
                                        .filter { it.isNotBlank() }
                                        .joinToString("\n")
                                        .ifBlank { "An API error occurred." }
                                    emit(StreamEvent.Error(full))
                                    return@flow
                                }
                                "done" -> {
                                    emit(StreamEvent.Done)
                                    return@flow
                                }
                            }
                            eventName = "message"
                        }
                    } else if (line.startsWith("event:")) {
                        eventName = line.removePrefix("event:").trim()
                    } else if (line.startsWith("data:")) {
                        if (dataLines.isNotEmpty()) dataLines.append('\n')
                        dataLines.append(line.removePrefix("data:").trim())
                    }
                }
                emit(StreamEvent.Done)
            }
        } catch (e: Exception) {
            if (!call.isCanceled()) {
                emit(StreamEvent.Error(e.message ?: "Network error during streaming."))
            }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun generateNanoBananaImage(
        baseUrl: String,
        prompt: String,
        model: String,
        referenceBase64: String? = null,
        referenceMimeType: String? = null,
        confirmPaidRequest: Boolean
    ): NanoBananaResponse = withContext(Dispatchers.IO) {
        if (!confirmPaidRequest) {
            return@withContext NanoBananaResponse(
                errorMessage = "Paid API billing confirmation is required before calling Nano Banana."
            )
        }
        try {
            val url = "${normalizeBaseUrl(baseUrl)}/api/image/nano-banana"
            val bodyJson = JSONObject().apply {
                put("prompt", prompt)
                put("model", model)
                put("confirmPaidRequest", true)
                if (!referenceBase64.isNullOrBlank() && !referenceMimeType.isNullOrBlank()) {
                    put("imageBase64", referenceBase64)
                    put("mimeType", referenceMimeType)
                }
            }
            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                val json = if (raw.isNotBlank()) JSONObject(raw) else JSONObject()
                val errObj = json.optJSONObject("error")
                if (!response.isSuccessful || errObj != null) {
                    val msg = listOf(
                        errObj?.optString("title").orEmpty(),
                        errObj?.optString("message").orEmpty(),
                        errObj?.optString("hint").orEmpty()
                    ).filter { it.isNotBlank() }.joinToString("\n")
                        .ifBlank { "Image generation failed (HTTP ${response.code})" }
                    return@withContext NanoBananaResponse(errorMessage = msg)
                }
                NanoBananaResponse(
                    imageBase64 = json.optString("imageBase64").takeIf { it.isNotBlank() },
                    mimeType = json.optString("mimeType", "image/png"),
                    text = json.optString("text").takeIf { it.isNotBlank() },
                    modelUsed = json.optString("modelUsed", model)
                )
            }
        } catch (e: Exception) {
            NanoBananaResponse(errorMessage = e.message ?: "Network error contacting image server")
        }
    }

    private fun sanitizeTextDelta(text: String): String {
        return text
            .replace(Regex("</?thought>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("dalle\\.text2im", RegexOption.IGNORE_CASE), "")
    }
}
