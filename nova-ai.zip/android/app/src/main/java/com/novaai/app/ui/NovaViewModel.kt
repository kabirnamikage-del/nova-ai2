package com.novaai.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.novaai.app.data.AppPreferences
import com.novaai.app.data.AssistantMode
import com.novaai.app.data.ChatAttachment
import com.novaai.app.data.ChatMessage
import com.novaai.app.data.Conversation
import com.novaai.app.data.ConversationRepository
import com.novaai.app.data.GeminiModelInfo
import com.novaai.app.data.GeneratedImageItem
import com.novaai.app.data.NovaApiClient
import com.novaai.app.data.StreamEvent
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class PendingPaidImagePrompt(
    val prompt: String,
    val attachments: List<ChatAttachment>,
    val model: String = "gemini-3.1-flash-lite-image"
)

data class NovaUiState(
    val preferences: AppPreferences,
    val conversations: List<Conversation> = emptyList(),
    val activeConversationId: String? = null,
    val activeMode: AssistantMode = AssistantMode.GENERAL,
    val imageMode: Boolean = false,
    val pendingAttachments: List<ChatAttachment> = emptyList(),
    val models: List<GeminiModelInfo> = emptyList(),
    val modelsLoading: Boolean = false,
    val modelsError: String? = null,
    val isStreaming: Boolean = false,
    val streamingMessageId: String? = null,
    val pendingPaidImagePrompt: PendingPaidImagePrompt? = null,
    val searchQuery: String = ""
) {
    val activeConversation: Conversation?
        get() = conversations.firstOrNull { it.id == activeConversationId }
}

class NovaViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ConversationRepository(application)
    private val apiClient = NovaApiClient()
    private var activeStreamJob: Job? = null

    private val initialPrefs = repository.loadPreferences()
    private val _uiState = MutableStateFlow(
        NovaUiState(
            preferences = initialPrefs,
            conversations = repository.loadConversations()
        )
    )
    val uiState: StateFlow<NovaUiState> = _uiState.asStateFlow()

    init {
        refreshModels()
    }

    fun refreshModels() {
        viewModelScope.launch {
            _uiState.update { it.copy(modelsLoading = true, modelsError = null) }
            val result = apiClient.fetchModels(_uiState.value.preferences.backendBaseUrl)
            result.fold(
                onSuccess = { list ->
                    _uiState.update { state ->
                        val validModel = if (list.any { it.id == state.preferences.selectedModelId }) {
                            state.preferences.selectedModelId
                        } else {
                            list.firstOrNull { it.tier != "paid" }?.id
                                ?: list.firstOrNull()?.id
                                ?: state.preferences.selectedModelId
                        }
                        val nextPrefs = state.preferences.copy(selectedModelId = validModel)
                        repository.savePreferences(nextPrefs)
                        state.copy(
                            preferences = nextPrefs,
                            models = list,
                            modelsLoading = false,
                            modelsError = null
                        )
                    }
                },
                onFailure = { err ->
                    _uiState.update {
                        it.copy(
                            modelsLoading = false,
                            modelsError = err.message ?: "Unable to fetch Gemini models"
                        )
                    }
                }
            )
        }
    }

    fun updatePreferences(transform: (AppPreferences) -> AppPreferences) {
        val next = transform(_uiState.value.preferences)
        repository.savePreferences(next)
        _uiState.update { it.copy(preferences = next) }
    }

    fun setMode(mode: AssistantMode) {
        _uiState.update { it.copy(activeMode = mode) }
    }

    fun toggleImageMode() {
        _uiState.update { it.copy(imageMode = !it.imageMode) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun newChat() {
        stopGeneration()
        _uiState.update {
            it.copy(
                activeConversationId = null,
                pendingAttachments = emptyList()
            )
        }
    }

    fun selectConversation(id: String) {
        if (_uiState.value.isStreaming && _uiState.value.activeConversationId != id) {
            stopGeneration()
        }
        val found = _uiState.value.conversations.firstOrNull { it.id == id }
        val mode = AssistantMode.entries.firstOrNull { it.id == found?.mode } ?: AssistantMode.GENERAL
        _uiState.update {
            it.copy(
                activeConversationId = id,
                activeMode = mode
            )
        }
    }

    fun renameConversation(id: String, newTitle: String) {
        val trimmed = newTitle.trim()
        if (trimmed.isEmpty()) return
        updateConversations { list ->
            list.map {
                if (it.id == id) it.copy(title = trimmed, updatedAt = System.currentTimeMillis()) else it
            }
        }
    }

    fun deleteConversation(id: String) {
        if (_uiState.value.activeConversationId == id) {
            stopGeneration()
        }
        updateConversations { list -> list.filterNot { it.id == id } }
        if (_uiState.value.activeConversationId == id) {
            _uiState.update { it.copy(activeConversationId = null) }
        }
    }

    fun addAttachment(att: ChatAttachment) {
        _uiState.update { state ->
            state.copy(pendingAttachments = (state.pendingAttachments + att).take(4))
        }
    }

    fun removeAttachment(id: String) {
        _uiState.update { state ->
            state.copy(pendingAttachments = state.pendingAttachments.filterNot { it.id == id })
        }
    }

    fun sendMessage(rawText: String) {
        val state = _uiState.value
        if (state.isStreaming) return
        val prompt = rawText.trim()
        val attachments = state.pendingAttachments
        if (prompt.isEmpty() && attachments.isEmpty()) return

        if (state.imageMode) {
            _uiState.update {
                it.copy(
                    pendingPaidImagePrompt = PendingPaidImagePrompt(
                        prompt = prompt.ifBlank { "Create a creative illustration" },
                        attachments = attachments
                    ),
                    pendingAttachments = emptyList()
                )
            }
            return
        }

        val now = System.currentTimeMillis()
        val userMsg = ChatMessage(
            role = "user",
            content = prompt.ifBlank { "Analyze this image." },
            attachments = attachments,
            createdAt = now
        )
        val assistantMsgId = UUID.randomUUID().toString()
        val assistantPlaceholder = ChatMessage(
            id = assistantMsgId,
            role = "assistant",
            content = "",
            modelUsed = state.preferences.selectedModelId,
            modeUsed = state.activeMode.id,
            createdAt = now + 1
        )

        val currentConv = state.activeConversation
        val updatedConv = if (currentConv != null) {
            currentConv.copy(
                mode = state.activeMode.id,
                model = state.preferences.selectedModelId,
                messages = currentConv.messages + userMsg + assistantPlaceholder,
                updatedAt = now
            )
        } else {
            Conversation(
                title = (prompt.ifBlank { "Image Analysis" }).take(42),
                mode = state.activeMode.id,
                model = state.preferences.selectedModelId,
                messages = listOf(userMsg, assistantPlaceholder),
                createdAt = now,
                updatedAt = now
            )
        }

        _uiState.update {
            it.copy(
                pendingAttachments = emptyList(),
                activeConversationId = updatedConv.id
            )
        }
        upsertConversation(updatedConv)

        val historyToSend = updatedConv.messages.dropLast(1)
        startStream(
            conversationId = updatedConv.id,
            assistantMsgId = assistantMsgId,
            history = historyToSend,
            model = state.preferences.selectedModelId,
            mode = state.activeMode.id
        )
    }

    fun regenerateLastAssistant(assistantMsgId: String) {
        val state = _uiState.value
        val conv = state.activeConversation ?: return
        if (state.isStreaming) return
        val idx = conv.messages.indexOfFirst { it.id == assistantMsgId }
        if (idx <= 0) return

        val historyUpToUser = conv.messages.take(idx)
        val resetPlaceholder = conv.messages[idx].copy(
            content = "",
            errorMessage = null,
            modelUsed = state.preferences.selectedModelId,
            modeUsed = state.activeMode.id
        )
        val updatedConv = conv.copy(
            messages = historyUpToUser + resetPlaceholder + conv.messages.drop(idx + 1),
            updatedAt = System.currentTimeMillis()
        )
        upsertConversation(updatedConv)
        startStream(
            conversationId = conv.id,
            assistantMsgId = assistantMsgId,
            history = historyUpToUser,
            model = state.preferences.selectedModelId,
            mode = state.activeMode.id
        )
    }

    fun stopGeneration() {
        activeStreamJob?.cancel()
        activeStreamJob = null
        _uiState.update { it.copy(isStreaming = false, streamingMessageId = null) }
    }

    fun dismissPaidImageDialog() {
        _uiState.update { it.copy(pendingPaidImagePrompt = null) }
    }

    fun selectPaidImageModel(model: String) {
        _uiState.update { state ->
            state.copy(
                pendingPaidImagePrompt = state.pendingPaidImagePrompt?.copy(model = model)
            )
        }
    }

    fun confirmAndGenerateImage() {
        val state = _uiState.value
        val pending = state.pendingPaidImagePrompt ?: return
        _uiState.update { it.copy(pendingPaidImagePrompt = null, isStreaming = true) }

        val now = System.currentTimeMillis()
        val currentConv = state.activeConversation
        val refFromAttachment = pending.attachments.firstOrNull()
        val refFromHistory = if (refFromAttachment == null && currentConv != null) {
            currentConv.messages.asReversed()
                .firstNotNullOfOrNull { it.generatedImages.lastOrNull() }
        } else null

        val userMsg = ChatMessage(
            role = "user",
            content = pending.prompt,
            attachments = pending.attachments,
            createdAt = now
        )
        val assistantMsgId = UUID.randomUUID().toString()
        val assistantPlaceholder = ChatMessage(
            id = assistantMsgId,
            role = "assistant",
            content = "",
            modelUsed = pending.model,
            modeUsed = "general",
            createdAt = now + 1
        )

        val targetConv = if (currentConv != null) {
            currentConv.copy(
                messages = currentConv.messages + userMsg + assistantPlaceholder,
                updatedAt = now
            )
        } else {
            Conversation(
                title = pending.prompt.take(42),
                mode = "general",
                model = state.preferences.selectedModelId,
                messages = listOf(userMsg, assistantPlaceholder),
                createdAt = now,
                updatedAt = now
            )
        }

        _uiState.update {
            it.copy(
                activeConversationId = targetConv.id,
                streamingMessageId = assistantMsgId
            )
        }
        upsertConversation(targetConv)

        viewModelScope.launch {
            try {
                val res = apiClient.generateNanoBananaImage(
                    baseUrl = _uiState.value.preferences.backendBaseUrl,
                    prompt = pending.prompt,
                    model = pending.model,
                    referenceBase64 = refFromAttachment?.base64Data ?: refFromHistory?.base64Data,
                    referenceMimeType = refFromAttachment?.mimeType ?: refFromHistory?.mimeType,
                    confirmPaidRequest = true
                )

                updateMessageInConversation(targetConv.id, assistantMsgId) { msg ->
                    if (!res.errorMessage.isNullOrBlank()) {
                        msg.copy(errorMessage = res.errorMessage)
                    } else if (!res.imageBase64.isNullOrBlank()) {
                        msg.copy(
                            content = res.text ?: "Generated with ${res.modelUsed ?: pending.model}:",
                            generatedImages = listOf(
                                GeneratedImageItem(
                                    mimeType = res.mimeType,
                                    base64Data = res.imageBase64,
                                    prompt = pending.prompt,
                                    model = res.modelUsed ?: pending.model
                                )
                            )
                        )
                    } else {
                        msg.copy(errorMessage = "Nano Banana completed without returning an image.")
                    }
                }
            } finally {
                _uiState.update { it.copy(isStreaming = false, streamingMessageId = null) }
            }
        }
    }

    private fun startStream(
        conversationId: String,
        assistantMsgId: String,
        history: List<ChatMessage>,
        model: String,
        mode: String
    ) {
        activeStreamJob?.cancel()
        _uiState.update { it.copy(isStreaming = true, streamingMessageId = assistantMsgId) }

        activeStreamJob = viewModelScope.launch {
            val buffer = StringBuilder()
            try {
                apiClient.streamChat(
                    baseUrl = _uiState.value.preferences.backendBaseUrl,
                    model = model,
                    messages = history,
                    mode = mode,
                    studyLanguage = _uiState.value.preferences.studyLanguage
                ).collect { event ->
                    when (event) {
                        is StreamEvent.Chunk -> {
                            buffer.append(event.textDelta)
                            updateMessageInConversation(conversationId, assistantMsgId) { msg ->
                                msg.copy(content = buffer.toString())
                            }
                        }
                        is StreamEvent.Error -> {
                            updateMessageInConversation(conversationId, assistantMsgId) { msg ->
                                msg.copy(errorMessage = event.message)
                            }
                        }
                        StreamEvent.Done -> Unit
                    }
                }
            } finally {
                _uiState.update { it.copy(isStreaming = false, streamingMessageId = null) }
            }
        }
    }

    private fun updateMessageInConversation(
        conversationId: String,
        messageId: String,
        transform: (ChatMessage) -> ChatMessage
    ) {
        updateConversations { list ->
            list.map { conv ->
                if (conv.id != conversationId) conv
                else conv.copy(
                    updatedAt = System.currentTimeMillis(),
                    messages = conv.messages.map { m ->
                        if (m.id == messageId) transform(m) else m
                    }
                )
            }
        }
    }

    private fun upsertConversation(conv: Conversation) {
        updateConversations { list ->
            val exists = list.any { it.id == conv.id }
            val next = if (exists) list.map { if (it.id == conv.id) conv else it } else listOf(conv) + list
            next.sortedByDescending { it.updatedAt }
        }
    }

    private fun updateConversations(transform: (List<Conversation>) -> List<Conversation>) {
        val next = transform(_uiState.value.conversations)
        repository.saveConversations(next)
        _uiState.update { it.copy(conversations = next) }
    }
}
