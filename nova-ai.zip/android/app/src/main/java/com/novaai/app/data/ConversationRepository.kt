package com.novaai.app.data

import android.content.Context
import com.novaai.app.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ConversationRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("nova_ai_prefs", Context.MODE_PRIVATE)
    private val historyFile: File get() = File(context.filesDir, "nova_conversations.json")

    fun loadPreferences(): AppPreferences {
        val defaultUrl = BuildConfig.NOVA_API_BASE_URL
        val savedUrl = prefs.getString("backend_url", defaultUrl).orEmpty().ifBlank { defaultUrl }
        return AppPreferences(
            backendBaseUrl = savedUrl,
            selectedModelId = prefs.getString("selected_model", "gemini-3.1-flash-lite")
                ?: "gemini-3.1-flash-lite",
            studyLanguage = prefs.getString("study_language", "bilingual") ?: "bilingual",
            darkTheme = prefs.getBoolean("dark_theme", true)
        )
    }

    fun savePreferences(preferences: AppPreferences) {
        prefs.edit()
            .putString("backend_url", preferences.backendBaseUrl.trim())
            .putString("selected_model", preferences.selectedModelId)
            .putString("study_language", preferences.studyLanguage)
            .putBoolean("dark_theme", preferences.darkTheme)
            .apply()
    }

    fun loadConversations(): List<Conversation> {
        if (!historyFile.exists()) return emptyList()
        return runCatching {
            val raw = historyFile.readText()
            val arr = JSONArray(raw)
            val list = mutableListOf<Conversation>()
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val msgArr = c.optJSONArray("messages") ?: JSONArray()
                val messages = mutableListOf<ChatMessage>()
                for (j in 0 until msgArr.length()) {
                    val m = msgArr.getJSONObject(j)
                    val attList = mutableListOf<ChatAttachment>()
                    val attArr = m.optJSONArray("attachments") ?: JSONArray()
                    for (k in 0 until attArr.length()) {
                        val a = attArr.getJSONObject(k)
                        attList.add(
                            ChatAttachment(
                                id = a.optString("id"),
                                name = a.optString("name", "image.jpg"),
                                mimeType = a.optString("mimeType", "image/jpeg"),
                                base64Data = a.optString("base64Data"),
                                sizeBytes = a.optLong("sizeBytes", 0L)
                            )
                        )
                    }
                    val genList = mutableListOf<GeneratedImageItem>()
                    val genArr = m.optJSONArray("generatedImages") ?: JSONArray()
                    for (k in 0 until genArr.length()) {
                        val g = genArr.getJSONObject(k)
                        genList.add(
                            GeneratedImageItem(
                                id = g.optString("id"),
                                mimeType = g.optString("mimeType", "image/png"),
                                base64Data = g.optString("base64Data"),
                                prompt = g.optString("prompt"),
                                model = g.optString("model")
                            )
                        )
                    }
                    messages.add(
                        ChatMessage(
                            id = m.optString("id"),
                            role = m.optString("role", "user"),
                            content = m.optString("content"),
                            attachments = attList,
                            generatedImages = genList,
                            modelUsed = m.optString("modelUsed").takeIf { it.isNotBlank() },
                            modeUsed = m.optString("modeUsed").takeIf { it.isNotBlank() },
                            errorMessage = m.optString("errorMessage").takeIf { it.isNotBlank() },
                            createdAt = m.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                list.add(
                    Conversation(
                        id = c.optString("id"),
                        title = c.optString("title", "New Chat"),
                        mode = c.optString("mode", AssistantMode.GENERAL.id),
                        model = c.optString("model", "gemini-3.1-flash-lite"),
                        messages = messages,
                        createdAt = c.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = c.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
            list.sortedByDescending { it.updatedAt }
        }.getOrDefault(emptyList())
    }

    fun saveConversations(conversations: List<Conversation>) {
        runCatching {
            val arr = JSONArray()
            for (c in conversations) {
                val msgArr = JSONArray()
                for (m in c.messages) {
                    val attArr = JSONArray()
                    for (a in m.attachments) {
                        attArr.put(
                            JSONObject().apply {
                                put("id", a.id)
                                put("name", a.name)
                                put("mimeType", a.mimeType)
                                put("base64Data", a.base64Data)
                                put("sizeBytes", a.sizeBytes)
                            }
                        )
                    }
                    val genArr = JSONArray()
                    for (g in m.generatedImages) {
                        genArr.put(
                            JSONObject().apply {
                                put("id", g.id)
                                put("mimeType", g.mimeType)
                                put("base64Data", g.base64Data)
                                put("prompt", g.prompt)
                                put("model", g.model)
                            }
                        )
                    }
                    msgArr.put(
                        JSONObject().apply {
                            put("id", m.id)
                            put("role", m.role)
                            put("content", m.content)
                            put("attachments", attArr)
                            put("generatedImages", genArr)
                            put("modelUsed", m.modelUsed ?: "")
                            put("modeUsed", m.modeUsed ?: "")
                            put("errorMessage", m.errorMessage ?: "")
                            put("createdAt", m.createdAt)
                        }
                    )
                }
                arr.put(
                    JSONObject().apply {
                        put("id", c.id)
                        put("title", c.title)
                        put("mode", c.mode)
                        put("model", c.model)
                        put("messages", msgArr)
                        put("createdAt", c.createdAt)
                        put("updatedAt", c.updatedAt)
                    }
                )
            }
            historyFile.writeText(arr.toString())
        }
    }
}
