package com.novaai.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NovaViolet = Color(0xFF8B5CF6)
val NovaCyan = Color(0xFF22D3EE)
val NovaDarkBg = Color(0xFF0D0D10)
val NovaDarkSurface = Color(0xFF17171C)
val NovaDarkCard = Color(0xFF1E1E26)

private val DarkColorScheme = darkColorScheme(
    primary = NovaViolet,
    onPrimary = Color.White,
    secondary = NovaCyan,
    onSecondary = Color(0xFF062028),
    background = NovaDarkBg,
    onBackground = Color(0xFFF3F4F6),
    surface = NovaDarkSurface,
    onSurface = Color(0xFFF3F4F6),
    surfaceVariant = NovaDarkCard,
    onSurfaceVariant = Color(0xFFA1A1AA),
    outline = Color(0xFF2E2E38)
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF7C3AED),
    onPrimary = Color.White,
    secondary = Color(0xFF0891B2),
    onSecondary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFE2E8F0)
)

@Composable
fun NovaAITheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        content = content
    )
}
