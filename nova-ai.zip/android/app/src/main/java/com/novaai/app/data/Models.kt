package com.novaai.app.data

import java.util.UUID

enum class AssistantMode(val id: String, val label: String, val hint: String) {
    GENERAL("general", "Assistant", "Ask NOVA anything..."),
    STUDY("study", "Study · বাংলা", "Ask a study question in বাংলা or English..."),
    CODING("coding", "Coding", "Ask about code, bugs, or architecture..."),
    WRITING("writing", "Writing", "Draft, edit, or translate text...")
}

data class GeminiModelInfo(
    val id: String,
    val displayName: String,
    val tier: String = "free",
    val supportsVision: Boolean = true
)

data class ChatAttachment(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val mimeType: String,
    val base64Data: String,
    val sizeBytes: Long
)

data class GeneratedImageItem(
    val id: String = UUID.randomUUID().toString(),
    val mimeType: String,
    val base64Data: String,
    val prompt: String,
    val model: String
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String, // "user" | "assistant"
    val content: String,
    val attachments: List<ChatAttachment> = emptyList(),
    val generatedImages: List<GeneratedImageItem> = emptyList(),
    val modelUsed: String? = null,
    val modeUsed: String? = null,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "New Chat",
    val mode: String = AssistantMode.GENERAL.id,
    val model: String = "gemini-3.1-flash-lite",
    val messages: List<ChatMessage> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class AppPreferences(
    val backendBaseUrl: String,
    val selectedModelId: String = "gemini-3.1-flash-lite",
    val studyLanguage: String = "bilingual",
    val darkTheme: Boolean = true
)
