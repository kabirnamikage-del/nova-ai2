package com.novaai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.novaai.app.ui.NovaAppScreen
import com.novaai.app.ui.NovaViewModel
import com.novaai.app.ui.theme.NovaAITheme

class MainActivity : ComponentActivity() {
    private val viewModel: NovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        setContent {
            val state by viewModel.uiState.collectAsState()
            NovaAITheme(darkTheme = state.preferences.darkTheme) {
                NovaAppScreen(viewModel = viewModel)
            }
        }
    }
}
