package com.novaai.app.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.app.data.AssistantMode
import com.novaai.app.data.ChatAttachment
import com.novaai.app.data.ChatMessage
import com.novaai.app.data.Conversation
import com.novaai.app.ui.theme.NovaCyan
import com.novaai.app.ui.theme.NovaViolet
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaAppScreen(viewModel: NovaViewModel) {
    val state by viewModel.uiState.collectAsState()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<Conversation?>(null) }

    if (showSettings) {
        SettingsScreen(
            state = state,
            onBack = { showSettings = false },
            onRefreshModels = { viewModel.refreshModels() },
            onSelectModel = { mdl ->
                viewModel.updatePreferences { it.copy(selectedModelId = mdl) }
            },
            onUpdateBackendUrl = { url ->
                viewModel.updatePreferences { it.copy(backendBaseUrl = url) }
            },
            onToggleDarkTheme = { dark ->
                viewModel.updatePreferences { it.copy(darkTheme = dark) }
            },
            onChangeStudyLang = { lang ->
                viewModel.updatePreferences { it.copy(studyLanguage = lang) }
            }
        )
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 310.dp)) {
                Column(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NOVA AI",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = {
                            viewModel.updatePreferences { it.copy(darkTheme = !it.darkTheme) }
                        }) {
                            Icon(
                                imageVector = if (state.preferences.darkTheme) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                contentDescription = "Toggle theme"
                            )
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.newChat()
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("New Chat")
                    }

                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("Search conversations...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )

                    Spacer(Modifier.height(10.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))

                    val filtered = remember(state.conversations, state.searchQuery) {
                        val q = state.searchQuery.trim().lowercase()
                        if (q.isEmpty()) state.conversations
                        else state.conversations.filter {
                            it.title.lowercase().contains(q) ||
                                it.messages.any { m -> m.content.lowercase().contains(q) }
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filtered, key = { it.id }) { conv ->
                            val selected = conv.id == state.activeConversationId
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    viewModel.selectConversation(conv.id)
                                    scope.launch { drawerState.close() }
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = conv.title,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                        fontSize = 14.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                    IconButton(
                                        onClick = { renameTarget = conv },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(Icons.Rounded.Edit, contentDescription = "Rename", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteConversation(conv.id) },
                                        modifier = Modifier.size(30.dp)
                                    ) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    OutlinedButton(
                        onClick = {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/"))
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Free Gemini Web Images", fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            scope.launch { drawerState.close() }
                            showSettings = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Settings & Models", fontSize = 13.sp)
                    }
                }
            }
        }
    ) {
        ChatScaffold(
            state = state,
            viewModel = viewModel,
            onOpenDrawer = { scope.launch { drawerState.open() } },
            onOpenSettings = { showSettings = true }
        )
    }

    renameTarget?.let { conv ->
        var draft by remember(conv.id) { mutableStateOf(conv.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Conversation") },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.renameConversation(conv.id, draft)
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }

    state.pendingPaidImagePrompt?.let { pending ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissPaidImageDialog() },
            icon = { Icon(Icons.Rounded.WarningAmber, contentDescription = null, tint = Color(0xFFF59E0B)) },
            title = { Text("Paid API Billing Confirmation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Nano Banana image generation requires an eligible paid Gemini API billing account on the server. NOVA AI never triggers paid generation silently.",
                        fontSize = 13.sp
                    )
                    Text("Prompt: ${pending.prompt}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = pending.model == "gemini-3.1-flash-lite-image",
                            onClick = { viewModel.selectPaidImageModel("gemini-3.1-flash-lite-image") },
                            label = { Text("Nano Banana 2", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = pending.model == "gemini-nano-banana-2.1",
                            onClick = { viewModel.selectPaidImageModel("gemini-nano-banana-2.1") },
                            label = { Text("Nano Banana Pro", fontSize = 11.sp) }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { viewModel.confirmAndGenerateImage() }) {
                    Text("Confirm & Generate")
                }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        viewModel.dismissPaidImageDialog()
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://gemini.google.com/"))
                        )
                    }) { Text("Free Web") }
                    TextButton(onClick = { viewModel.dismissPaidImageDialog() }) { Text("Cancel") }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScaffold(
    state: NovaUiState,
    viewModel: NovaViewModel,
    onOpenDrawer: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val messages = state.activeConversation?.messages.orEmpty()

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            uriToAttachment(context, uri)?.let { viewModel.addAttachment(it) }
        }
    }

    LaunchedEffect(messages.size, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize().imePadding().navigationBarsPadding(),
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Rounded.Menu, contentDescription = "Open menu")
                    }
                },
                title = {
                    Column {
                        Text("NOVA AI", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            text = state.preferences.selectedModelId,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.newChat() }) {
                        Icon(Icons.Rounded.Add, contentDescription = "New Chat")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Rounded.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            if (!state.modelsError.isNullOrBlank()) {
                Surface(
                    color = Color(0x33EF4444),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = state.modelsError,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { viewModel.refreshModels() }) {
                            Text("Retry")
                        }
                    }
                }
            }

            if (messages.isEmpty()) {
                EmptyChatView(
                    modifier = Modifier.weight(1f),
                    mode = state.activeMode,
                    onPickPrompt = { prompt -> viewModel.sendMessage(prompt) }
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        MessageBubbleItem(
                            message = msg,
                            isStreaming = state.streamingMessageId == msg.id,
                            onRegenerate = { viewModel.regenerateLastAssistant(msg.id) }
                        )
                    }
                }
            }

            // Mode switcher + In-Chat Image Mode toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AssistantMode.entries.forEach { m ->
                    FilterChip(
                        selected = !state.imageMode && state.activeMode == m,
                        onClick = {
                            if (state.imageMode) viewModel.toggleImageMode()
                            viewModel.setMode(m)
                        },
                        label = { Text(m.label, fontSize = 12.sp) }
                    )
                }
                FilterChip(
                    selected = state.imageMode,
                    onClick = { viewModel.toggleImageMode() },
                    leadingIcon = { Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(15.dp)) },
                    label = { Text(if (state.imageMode) "Image (Paid)" else "Image Mode", fontSize = 12.sp) }
                )
            }

            // Attachment preview + OCR quick chips
            if (state.pendingAttachments.isNotEmpty()) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        state.pendingAttachments.forEach { att ->
                            val bmp = remember(att.id) { decodeBase64Bitmap(att.base64Data) }
                            Box(modifier = Modifier.size(64.dp)) {
                                if (bmp != null) {
                                    Image(
                                        bitmap = bmp.asImageBitmap(),
                                        contentDescription = att.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp))
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.removeAttachment(att.id) },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .size(22.dp)
                                        .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                                ) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "Describe image" to "Describe this image in detail.",
                            "বাংলা + English OCR" to "Extract all Bengali (বাংলা) and English text from this image accurately.",
                            "Extract English" to "Extract all visible English text cleanly."
                        ).forEach { (label, prompt) ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.clickable { inputText = prompt }
                            ) {
                                Text(label, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                            }
                        }
                    }
                }
            }

            // Input bar
            Surface(
                shape = RoundedCornerShape(24.dp),
                tonalElevation = 3.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    IconButton(onClick = { imagePicker.launch("image/*") }) {
                        Icon(Icons.Rounded.AttachFile, contentDescription = "Attach image")
                    }
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                if (state.imageMode) "Describe an image (requires paid API confirmation)..."
                                else state.activeMode.hint,
                                fontSize = 14.sp
                            )
                        },
                        maxLines = 5,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    if (state.isStreaming) {
                        IconButton(
                            onClick = { viewModel.stopGeneration() },
                            modifier = Modifier
                                .size(44.dp)
                                .background(MaterialTheme.colorScheme.onBackground, CircleShape)
                        ) {
                            Icon(
                                Icons.Rounded.Stop,
                                contentDescription = "Stop",
                                tint = MaterialTheme.colorScheme.background
                            )
                        }
                    } else {
                        val canSend = inputText.isNotBlank() || state.pendingAttachments.isNotEmpty()
                        IconButton(
                            enabled = canSend,
                            onClick = {
                                val textToSend = inputText
                                inputText = ""
                                viewModel.sendMessage(textToSend)
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (canSend) Brush.horizontalGradient(listOf(NovaViolet, NovaCyan))
                                    else Brush.horizontalGradient(listOf(Color.Gray, Color.Gray)),
                                    CircleShape
                                )
                        ) {
                            Icon(
                                Icons.AutoMirrored.Rounded.Send,
                                contentDescription = "Send",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChatView(
    modifier: Modifier,
    mode: AssistantMode,
    onPickPrompt: (String) -> Unit
) {
    val suggestions = when (mode) {
        AssistantMode.STUDY -> listOf(
            "সহজ বাংলায় নিউটনের গতিসূত্র বুঝিয়ে দাও",
            "Explain photosynthesis in simple English and Bengali",
            "Create 5 MCQ practice questions on quadratic equations"
        )
        AssistantMode.CODING -> listOf(
            "Explain Kotlin Coroutines vs Threads cleanly",
            "Write a clean REST API fetch helper with timeout",
            "Debug an ArrayIndexOutOfBoundsException"
        )
        AssistantMode.WRITING -> listOf(
            "Write a polite professional email requesting a deadline extension",
            "Summarize key ideas into crisp bullet points",
            "Translate an English paragraph into natural Bengali"
        )
        AssistantMode.GENERAL -> listOf(
            "Hi! Introduce what you can help me with today",
            "সহজ বাংলায় আজকের একটি নতুন কিছু শেখাও",
            "Help me plan a productive study schedule"
        )
    }

    Column(
        modifier = modifier.fillMaxWidth().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(Brush.linearGradient(listOf(NovaViolet, NovaCyan)), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text("NOVA AI", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Bilingual assistant · Image Vision & OCR · Coding & Study",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(22.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            suggestions.forEach { prompt ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth().clickable { onPickPrompt(prompt) }
                ) {
                    Text(prompt, fontSize = 13.sp, modifier = Modifier.padding(14.dp))
                }
            }
        }
    }
}

@Composable
private fun MessageBubbleItem(
    message: ChatMessage,
    isStreaming: Boolean,
    onRegenerate: () -> Unit
) {
    val isUser = message.role == "user"
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (isUser) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = NovaViolet,
                modifier = Modifier.widthIn(max = 310.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    message.attachments.forEach { att ->
                        val bmp = remember(att.id) { decodeBase64Bitmap(att.base64Data) }
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = att.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(12.dp))
                            )
                        }
                    }
                    if (message.content.isNotBlank()) {
                        Text(message.content, color = Color.White, fontSize = 15.sp)
                    }
                }
            }
        } else {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "NOVA AI · ${message.modelUsed ?: "gemini"}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (!message.errorMessage.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0x22EF4444),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(message.errorMessage, fontSize = 13.sp, color = Color(0xFFFCA5A5))
                            TextButton(onClick = onRegenerate) { Text("Retry") }
                        }
                    }
                } else if (message.content.isBlank() && isStreaming) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text("Thinking...", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else if (message.content.isNotBlank()) {
                    Text(message.content, fontSize = 15.sp, lineHeight = 22.sp)
                }

                message.generatedImages.forEach { img ->
                    val bmp = remember(img.id) { decodeBase64Bitmap(img.base64Data) }
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = img.prompt,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(14.dp))
                        )
                    }
                }

                if (!isStreaming && message.content.isNotBlank()) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { clipboard.setText(AnnotatedString(message.content)) },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                        }
                        IconButton(
                            onClick = {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    putExtra(Intent.EXTRA_TEXT, message.content)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share NOVA AI response"))
                            },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Rounded.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                        }
                        IconButton(
                            onClick = onRegenerate,
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Regenerate", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    state: NovaUiState,
    onBack: () -> Unit,
    onRefreshModels: () -> Unit,
    onSelectModel: (String) -> Unit,
    onUpdateBackendUrl: (String) -> Unit,
    onToggleDarkTheme: (Boolean) -> Unit,
    onChangeStudyLang: (String) -> Unit
) {
    var urlDraft by remember(state.preferences.backendBaseUrl) {
        mutableStateOf(state.preferences.backendBaseUrl)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Settings", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Security Architecture", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(
                        "No GEMINI_API_KEY is stored inside this Android APK. All requests go over HTTPS to your NOVA AI backend server.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("NOVA Backend HTTPS URL", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                OutlinedTextField(
                    value = urlDraft,
                    onValueChange = { urlDraft = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    onUpdateBackendUrl(urlDraft)
                    onRefreshModels()
                }) {
                    Text("Save URL & Refresh Models")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Dark Theme", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Switch(
                    checked = state.preferences.darkTheme,
                    onCheckedChange = onToggleDarkTheme
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Study Mode Language", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("bilingual" to "বাং + En", "bengali" to "বাংলা", "english" to "English")
                        .forEach { (id, label) ->
                            FilterChip(
                                selected = state.preferences.studyLanguage == id,
                                onClick = { onChangeStudyLang(id) },
                                label = { Text(label, fontSize = 12.sp) }
                            )
                        }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Active Gemini Model", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    TextButton(onClick = onRefreshModels) { Text("Refresh") }
                }
                if (state.modelsLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp))
                } else {
                    state.models.forEach { mdl ->
                        val active = mdl.id == state.preferences.selectedModelId
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (active) NovaViolet.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth().clickable { onSelectModel(mdl.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mdl.displayName, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                    Text("${mdl.id} · ${mdl.tier}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (active) Text("Active", fontSize = 11.sp, color = NovaCyan, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun decodeBase64Bitmap(base64: String) = runCatching {
    val bytes = Base64.decode(base64, Base64.DEFAULT)
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
}.getOrNull()

private fun uriToAttachment(context: Context, uri: Uri): ChatAttachment? {
    return runCatching {
        val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
        var fileName = "image.jpg"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) {
                fileName = cursor.getString(idx) ?: fileName
            }
        }
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        if (bytes.size > 8 * 1024 * 1024) return null
        ChatAttachment(
            name = fileName,
            mimeType = mime,
            base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP),
            sizeBytes = bytes.size.toLong()
        )
    }.getOrNull()
}
