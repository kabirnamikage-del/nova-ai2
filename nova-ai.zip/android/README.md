# NOVA AI — Native Android App (Kotlin + Jetpack Compose)

Native Android Studio project (`minSdk = 28`, Android 9+) for **NOVA AI**.

## Security Architecture
- **Zero API keys inside the APK:** `GEMINI_API_KEY` is never compiled into `BuildConfig`, strings, or Kotlin source.
- Connects exclusively over HTTPS to your NOVA AI backend (`https://ais-pre-yunfqdqnm624fhusqm5zmc-1009477330172.asia-east1.run.app`, editable in **Settings**).
- `network_security_config.xml` enforces HTTPS (`cleartextTrafficPermitted="false"`) for all external hosts.

## Features
- Real-time SSE streaming chat (`/api/chat/stream`) with Stop & Regenerate
- Conversation history saved locally (`New Chat`, `Rename`, `Delete`, `Search`)
- Modes: `Assistant`, `Study · বাংলা` (Bilingual Bengali/English), `Coding`, `Writing`
- Image attachment, preview before sending, Vision Q&A, and Bengali/English OCR quick chips
- In-Chat Image Mode (`/api/image/nano-banana`) with an **explicit Paid API Billing Confirmation dialog** + quick link to free Gemini Web (`https://gemini.google.com/`)
- Copy & native Android Share sheet support
- Dark/Light Material 3 themes and proper IME keyboard padding (`adjustResize` + `imePadding()`)

---

## Option 1: Build APK Automatically with GitHub Actions (No Android Studio Needed)
1. Push this repository to GitHub (the workflow lives at `.github/workflows/android.yml`).
2. Open your GitHub repository → **Actions** → **Build NOVA AI Android APK**.
3. Click **Run workflow** (or push any change under `android/`).
4. Once finished, download the **`nova-ai-debug-apk`** artifact (`app-debug.apk`) and install it on your Android phone.

## Option 2: Build Debug APK Locally with Gradle CLI
Requirements: **JDK 17** and **Android SDK (API 35)** installed with `ANDROID_HOME` configured.

```bash
cd android
gradle assembleDebug
```
The built APK will be at:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Option 3: Open in Android Studio
1. Open **Android Studio** → **Open** → select the `android/` folder.
2. Wait for Gradle Sync to finish.
3. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)** (or **Run** directly on a USB/Wi-Fi Android device).
