export function containsBengali(text: string): boolean {
  return /[\u0980-\u09FF]/.test(text);
}

export function markdownToPlainSpeech(markdown: string): string {
  return markdown
    // Replace fenced code blocks with a brief spoken cue
    .replace(/```[\w-]*\n[\s\S]*?```/g, ' Code snippet omitted for speech. ')
    // Inline code
    .replace(/`([^`]+)`/g, '$1')
    // Markdown links [text](url) -> text
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Headings & blockquotes
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/^>\s?/gm, '')
    // Bold / italic / strikethrough
    .replace(/(\*\*|__|\*|_|~~)/g, '')
    // List bullets
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    // Tables pipes
    .replace(/\|/g, ' ')
    // Collapse extra whitespace
    .replace(/\n{2,}/g, '. ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function pickBestVoice(
  voices: SpeechSynthesisVoice[],
  text: string,
  preferredVoiceURI?: string
): SpeechSynthesisVoice | undefined {
  if (voices.length === 0) return undefined;

  const isBengali = containsBengali(text);
  if (isBengali) {
    const bnVoice = voices.find((v) => v.lang.toLowerCase().startsWith('bn'));
    if (bnVoice) return bnVoice;
  }

  if (preferredVoiceURI) {
    const preferred = voices.find((v) => v.voiceURI === preferredVoiceURI);
    if (preferred) return preferred;
  }

  const enVoice =
    voices.find((v) => v.lang.toLowerCase().startsWith('en') && v.localService) ||
    voices.find((v) => v.lang.toLowerCase().startsWith('en'));

  return enVoice ?? voices[0];
}
