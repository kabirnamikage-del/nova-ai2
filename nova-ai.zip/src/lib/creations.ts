export interface VisualCreation {
  id: string;
  title: string;
  prompt: string;
  style: string;
  aspectRatio: string;
  mood: string;
  svgCode: string;
  createdAt: number;
  conversationId?: string;
  isPreset?: boolean;
}

const LS_CREATIONS_KEY = 'nova_visual_creations_v1';

export const PRESET_CREATIONS: VisualCreation[] = [
  {
    id: 'preset-moonlit-sky',
    title: 'Moonlit Night Sky',
    prompt: 'Anime style night sky with glowing full moon, silhouettes of rooftops and stars',
    style: 'Anime',
    aspectRatio: '1:1',
    mood: 'Calm',
    createdAt: 1795100000000,
    isPreset: true,
    svgCode: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#0b132b"/>
      <stop offset="60%" stop-color="#1c2541"/>
      <stop offset="100%" stop-color="#3a506b"/>
    </linearGradient>
    <radialGradient id="moonGlow" cx="72%" cy="24%" r="32%">
      <stop offset="0%" stop-color="#fef9c3" stop-opacity="0.95"/>
      <stop offset="40%" stop-color="#93c5fd" stop-opacity="0.28"/>
      <stop offset="100%" stop-color="#1c2541" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#g1)"/>
  <rect width="400" height="400" fill="url(#moonGlow)"/>
  <circle cx="290" cy="96" r="34" fill="#fef3c7"/>
  <circle cx="65" cy="70" r="1.8" fill="#e0f2fe" opacity="0.9"/>
  <circle cx="145" cy="48" r="1.4" fill="#fff" opacity="0.8"/>
  <circle cx="215" cy="110" r="2" fill="#bae6fd" opacity="0.85"/>
  <circle cx="95" cy="150" r="1.5" fill="#fff" opacity="0.7"/>
  <circle cx="348" cy="160" r="1.8" fill="#e0f2fe" opacity="0.85"/>
  <path d="M0 320 Q90 270 190 315 T400 300 L400 400 L0 400 Z" fill="#0f172a"/>
  <path d="M25 400 L25 275 L78 245 L130 275 L130 400 Z" fill="#090d16"/>
  <rect x="64" y="295" width="18" height="24" rx="2" fill="#fde68a" opacity="0.85"/>
  <path d="M235 400 L235 288 L295 258 L355 288 L355 400 Z" fill="#0b101b"/>
  <rect x="282" y="310" width="16" height="22" rx="2" fill="#38bdf8" opacity="0.6"/>
</svg>`,
  },
  {
    id: 'preset-golden-lake',
    title: 'Golden Sunset Lake',
    prompt: 'Warm golden sunset reflecting across a tranquil forest lake',
    style: 'Illustration',
    aspectRatio: '1:1',
    mood: 'Calm',
    createdAt: 1795090000000,
    isPreset: true,
    svgCode: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="sky2" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ea580c"/>
      <stop offset="48%" stop-color="#fb923c"/>
      <stop offset="100%" stop-color="#fde047"/>
    </linearGradient>
    <linearGradient id="water2" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#f59e0b"/>
      <stop offset="55%" stop-color="#9a3412"/>
      <stop offset="100%" stop-color="#27140d"/>
    </linearGradient>
  </defs>
  <rect width="400" height="230" fill="url(#sky2)"/>
  <circle cx="205" cy="180" r="36" fill="#fef08a"/>
  <path d="M0 225 Q110 198 205 222 Q305 200 400 225 L400 232 L0 232 Z" fill="#29150e"/>
  <rect y="230" width="400" height="170" fill="url(#water2)"/>
  <ellipse cx="205" cy="260" rx="28" ry="6" fill="#fef08a" opacity="0.85"/>
  <ellipse cx="205" cy="285" rx="44" ry="5" fill="#fde047" opacity="0.65"/>
  <ellipse cx="205" cy="316" rx="64" ry="4" fill="#fb923c" opacity="0.45"/>
  <path d="M0 0 L150 0 Q105 90 40 135 L0 165 Z" fill="#1c100b" opacity="0.9"/>
</svg>`,
  },
  {
    id: 'preset-cozy-cat',
    title: 'Cozy Cat Portrait',
    prompt: 'Minimalist illustration of a cute cat resting on a warm blanket',
    style: 'Minimalist',
    aspectRatio: '1:1',
    mood: 'Calm',
    createdAt: 1795080000000,
    isPreset: true,
    svgCode: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="bg3" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#27272a"/>
      <stop offset="100%" stop-color="#18181b"/>
    </linearGradient>
  </defs>
  <rect width="400" height="400" fill="url(#bg3)"/>
  <ellipse cx="200" cy="315" rx="165" ry="70" fill="#3f3f46"/>
  <ellipse cx="200" cy="235" rx="108" ry="86" fill="#e4e4e7"/>
  <polygon points="118,175 132,102 178,154" fill="#d4d4d8"/>
  <polygon points="282,175 268,102 222,154" fill="#d4d4d8"/>
  <polygon points="128,162 138,118 168,152" fill="#fda4af" opacity="0.65"/>
  <polygon points="272,162 262,118 232,152" fill="#fda4af" opacity="0.65"/>
  <path d="M148 228 Q165 238 182 228" stroke="#27272a" stroke-width="5" fill="none" stroke-linecap="round"/>
  <path d="M218 228 Q235 238 252 228" stroke="#27272a" stroke-width="5" fill="none" stroke-linecap="round"/>
  <polygon points="193,246 207,246 200,255" fill="#fb7185"/>
  <path d="M188 263 Q200 272 212 263" stroke="#52525b" stroke-width="3.5" fill="none" stroke-linecap="round"/>
  <ellipse cx="145" cy="302" rx="34" ry="20" fill="#f4f4f5"/>
</svg>`,
  },
  {
    id: 'preset-rainy-street',
    title: 'Rainy City Night',
    prompt: 'Atmospheric rainy city street illuminated by warm streetlamps and neon reflections',
    style: 'Cyberpunk',
    aspectRatio: '1:1',
    mood: 'Dramatic',
    createdAt: 1795070000000,
    isPreset: true,
    svgCode: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="night4" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#090d1a"/>
      <stop offset="55%" stop-color="#172038"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
    <radialGradient id="lampL" cx="30%" cy="46%" r="22%">
      <stop offset="0%" stop-color="#fde68a" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#fde68a" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="lampR" cx="72%" cy="42%" r="24%">
      <stop offset="0%" stop-color="#38bdf8" stop-opacity="0.8"/>
      <stop offset="100%" stop-color="#38bdf8" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="400" height="400" fill="url(#night4)"/>
  <polygon points="150,250 250,250 385,400 15,400" fill="#111827"/>
  <rect x="20" y="90" width="85" height="220" fill="#0b101d"/>
  <rect x="295" y="75" width="90" height="235" fill="#0b101d"/>
  <rect width="400" height="400" fill="url(#lampL)"/>
  <rect width="400" height="400" fill="url(#lampR)"/>
  <line x1="198" y1="255" x2="195" y2="395" stroke="#fbbf24" stroke-width="3" stroke-dasharray="14 14" opacity="0.7"/>
  <line x1="120" y1="280" x2="90" y2="390" stroke="#fde68a" stroke-width="4" opacity="0.45"/>
  <line x1="285" y1="275" x2="315" y2="390" stroke="#22d3ee" stroke-width="4" opacity="0.45"/>
</svg>`,
  },
  {
    id: 'preset-aurora-peaks',
    title: 'Aurora Mountain Peaks',
    prompt: 'Vibrant violet and cyan northern lights glowing above dark alpine peaks',
    style: 'Illustration',
    aspectRatio: '1:1',
    mood: 'Vibrant',
    createdAt: 1795060000000,
    isPreset: true,
    svgCode: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="aur5" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#09090f"/>
      <stop offset="100%" stop-color="#131629"/>
    </linearGradient>
    <linearGradient id="ribbon5" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#8b5cf6" stop-opacity="0.8"/>
      <stop offset="50%" stop-color="#06b6d4" stop-opacity="0.85"/>
      <stop offset="100%" stop-color="#34d399" stop-opacity="0.7"/>
    </linearGradient>
  </defs>
  <rect width="400" height="400" fill="url(#aur5)"/>
  <path d="M0 155 Q110 75 215 135 T400 105 L400 185 Q290 215 195 170 T0 205 Z" fill="url(#ribbon5)" opacity="0.65"/>
  <polygon points="0,330 95,195 190,330" fill="#1e1b4b"/>
  <polygon points="120,330 235,160 350,330" fill="#0f172a"/>
  <polygon points="245,330 335,205 400,310 400,330" fill="#1e293b"/>
  <rect y="330" width="400" height="70" fill="#090d16"/>
</svg>`,
  },
  {
    id: 'preset-violet-skyline',
    title: 'Violet City Skyline',
    prompt: 'Futuristic twilight city skyline with glowing purple clouds and cyan lights',
    style: 'Cyberpunk',
    aspectRatio: '1:1',
    mood: 'Vibrant',
    createdAt: 1795050000000,
    isPreset: true,
    svgCode: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
  <defs>
    <linearGradient id="twi6" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#311042"/>
      <stop offset="50%" stop-color="#7c3aed"/>
      <stop offset="100%" stop-color="#f43f5e"/>
    </linearGradient>
  </defs>
  <rect width="400" height="400" fill="url(#twi6)"/>
  <circle cx="215" cy="235" r="52" fill="#fda4af" opacity="0.8"/>
  <rect x="25" y="210" width="44" height="190" fill="#141126"/>
  <rect x="82" y="170" width="52" height="230" fill="#0f0d1e"/>
  <rect x="148" y="205" width="40" height="195" fill="#1b1635"/>
  <rect x="198" y="95" width="46" height="305" fill="#0d0b1a"/>
  <polygon points="221,48 225,95 217,95" fill="#22d3ee"/>
  <rect x="258" y="185" width="54" height="215" fill="#141126"/>
  <rect x="324" y="220" width="50" height="180" fill="#0f0d1e"/>
  <rect x="208" y="125" width="6" height="18" fill="#22d3ee" opacity="0.85"/>
  <rect x="226" y="155" width="6" height="18" fill="#a78bfa" opacity="0.85"/>
  <rect x="96" y="195" width="8" height="12" fill="#38bdf8" opacity="0.75"/>
</svg>`,
  },
];

export function loadUserCreations(): VisualCreation[] {
  try {
    const raw = localStorage.getItem(LS_CREATIONS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as VisualCreation[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveUserCreation(creation: VisualCreation): VisualCreation[] {
  const existing = loadUserCreations();
  const next = [
    creation,
    ...existing.filter((item) => item.id !== creation.id),
  ].slice(0, 30);
  try {
    localStorage.setItem(LS_CREATIONS_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage limit errors
  }
  return next;
}

export function deleteUserCreation(id: string): VisualCreation[] {
  const next = loadUserCreations().filter((item) => item.id !== id);
  try {
    localStorage.setItem(LS_CREATIONS_KEY, JSON.stringify(next));
  } catch {
    // Ignore
  }
  return next;
}

export function extractSvgFromMarkdown(markdown: string): string | null {
  const fenced = markdown.match(/```(?:svg|xml|html)?\s*\n([\s\S]*?)```/i);
  if (fenced) {
    const inner = fenced[1].trim();
    const svgInnerMatch = inner.match(/<svg[\s\S]*?<\/svg>/i);
    if (svgInnerMatch) {
      return svgInnerMatch[0].trim();
    }
  }
  const direct = markdown.match(/<svg[\s\S]*?<\/svg>/i);
  if (direct) {
    return direct[0].trim();
  }
  return null;
}

export function svgToObjectUrl(svgCode: string): string {
  const blob = new Blob([svgCode], { type: 'image/svg+xml;charset=utf-8' });
  return URL.createObjectURL(blob);
}

export function downloadSvgFile(svgCode: string, filename = 'nova-visual.svg'): void {
  const url = svgToObjectUrl(svgCode);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function downloadSvgAsPng(svgCode: string, filename = 'nova-visual.png'): void {
  const url = svgToObjectUrl(svgCode);
  const img = new Image();
  img.onload = () => {
    const w = Math.max(img.naturalWidth || 1024, 1024);
    const h = Math.max(img.naturalHeight || 1024, 1024);
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      URL.revokeObjectURL(url);
      return;
    }
    ctx.drawImage(img, 0, 0, w, h);
    canvas.toBlob((pngBlob) => {
      URL.revokeObjectURL(url);
      if (!pngBlob) return;
      const pngUrl = URL.createObjectURL(pngBlob);
      const a = document.createElement('a');
      a.href = pngUrl;
      a.download = filename;
      a.click();
      URL.revokeObjectURL(pngUrl);
    }, 'image/png');
  };
  img.onerror = () => URL.revokeObjectURL(url);
  img.src = url;
}
