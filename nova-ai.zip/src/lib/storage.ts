import type { AppSettings, Conversation, ThemeMode } from '../types/chat.ts';

const DB_NAME = 'nova_ai_db';
const DB_VERSION = 1;
const STORE_NAME = 'conversations';

const LS_CONVERSATIONS_KEY = 'nova_conversations_fallback';
const LS_SETTINGS_KEY = 'nova_settings';
const LS_ACTIVE_CHAT_KEY = 'nova_active_conversation';
const LS_SELECTED_MODEL_KEY = 'nova_selected_model_v2';
const LS_THEME_KEY = 'nova-theme';

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  defaultMode: 'general',
  studyLanguage: 'bilingual',
  defaultWebSearch: false,
  speechRecognitionLang: 'auto',
  ttsVoiceURI: '',
  ttsRate: 1.0,
  autoSpeak: false,
};

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('IndexedDB open failed'));
  });
}

export async function loadConversations(): Promise<Conversation[]> {
  try {
    const db = await openDatabase();
    return await new Promise<Conversation[]>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = (req.result as Conversation[]) ?? [];
        list.sort((a, b) => b.updatedAt - a.updatedAt);
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    try {
      const raw = localStorage.getItem(LS_CONVERSATIONS_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw) as Conversation[];
      return Array.isArray(parsed)
        ? parsed.sort((a, b) => b.updatedAt - a.updatedAt)
        : [];
    } catch {
      return [];
    }
  }
}

export async function saveConversation(conversation: Conversation): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(conversation);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    try {
      const existing = await loadConversations();
      const idx = existing.findIndex((c) => c.id === conversation.id);
      if (idx >= 0) existing[idx] = conversation;
      else existing.unshift(conversation);
      localStorage.setItem(LS_CONVERSATIONS_KEY, JSON.stringify(existing));
    } catch {
      // Ignore storage quota fallback errors
    }
  }
}

export async function deleteConversationFromStore(id: string): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    try {
      const existing = await loadConversations();
      const filtered = existing.filter((c) => c.id !== id);
      localStorage.setItem(LS_CONVERSATIONS_KEY, JSON.stringify(filtered));
    } catch {
      // Ignore
    }
  }
}

export async function clearAllConversationsFromStore(): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    try {
      localStorage.removeItem(LS_CONVERSATIONS_KEY);
    } catch {
      // Ignore
    }
  }
}

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(LS_SETTINGS_KEY);
    const savedTheme = localStorage.getItem(LS_THEME_KEY) as ThemeMode | null;
    if (!raw) {
      return {
        ...DEFAULT_SETTINGS,
        theme: savedTheme === 'light' ? 'light' : 'dark',
      };
    }
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      theme:
        savedTheme === 'light' || savedTheme === 'dark'
          ? savedTheme
          : parsed.theme === 'light'
            ? 'light'
            : 'dark',
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(LS_SETTINGS_KEY, JSON.stringify(settings));
    localStorage.setItem(LS_THEME_KEY, settings.theme);
  } catch {
    // Ignore
  }
}

export function applyThemeToDocument(theme: ThemeMode): void {
  const root = document.documentElement;
  if (theme === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }
  try {
    localStorage.setItem(LS_THEME_KEY, theme);
  } catch {
    // Ignore
  }
}

export function loadActiveConversationId(): string | null {
  try {
    return localStorage.getItem(LS_ACTIVE_CHAT_KEY);
  } catch {
    return null;
  }
}

export function saveActiveConversationId(id: string | null): void {
  try {
    if (id) localStorage.setItem(LS_ACTIVE_CHAT_KEY, id);
    else localStorage.removeItem(LS_ACTIVE_CHAT_KEY);
  } catch {
    // Ignore
  }
}

export function loadSavedModelId(): string | null {
  try {
    return localStorage.getItem(LS_SELECTED_MODEL_KEY);
  } catch {
    return null;
  }
}

export function saveSelectedModelId(modelId: string): void {
  try {
    localStorage.setItem(LS_SELECTED_MODEL_KEY, modelId);
  } catch {
    // Ignore
  }
}
