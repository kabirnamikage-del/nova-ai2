import type { AssistantMode, StudyLanguage } from '../types/chat.ts';

export interface ModeDefinition {
  id: AssistantMode;
  label: string;
  shortLabel: string;
  description: string;
  placeholder: string;
  starters: Array<{
    title: string;
    subtitle: string;
    prompt: string;
  }>;
}

export const ASSISTANT_MODES: Record<AssistantMode, ModeDefinition> = {
  general: {
    id: 'general',
    label: 'Assistant',
    shortLabel: 'Assistant',
    description: 'Fast, clear intelligence for everyday questions, research, and image analysis.',
    placeholder: 'Ask NOVA anything, or attach an image...',
    starters: [
      {
        title: 'Compare complex ideas clearly',
        subtitle: 'Structured breakdown with real-world trade-offs',
        prompt: 'Explain the difference between nuclear fission and fusion with a clear real-world analogy and safety comparison.',
      },
      {
        title: 'Study with Bengali support',
        subtitle: 'Dual-language intuition for science or math',
        prompt: 'Explain how photosynthesis works step-by-step, and include a clear explanation in Bengali (বাংলায় সহজ ব্যাখ্যা).',
      },
      {
        title: 'Analyze code or architecture',
        subtitle: 'Clean TypeScript & system design patterns',
        prompt: 'Design a clean, production-ready debounced search hook in React with TypeScript and abort cancellation.',
      },
      {
        title: 'Create a visual diagram or artwork',
        subtitle: 'Interactive SVG graphic with PNG/SVG export',
        prompt: 'Draw a clean, modern visual diagram in SVG showing how HTTPS TLS encryption works between a browser and a server.',
      },
    ],
  },
  study: {
    id: 'study',
    label: 'Study & বাংলা',
    shortLabel: 'Study',
    description: 'Step-by-step student tutor with intuition, worked examples, and Bengali explanations.',
    placeholder: 'Ask a study question in English or বাংলা...',
    starters: [
      {
        title: 'Physics concept in বাংলা + English',
        subtitle: 'Newton’s laws with everyday examples',
        prompt: 'নিউটনের গতির দ্বিতীয় সূত্র (F = ma) সহজ উদাহরণসহ বাংলা ও ইংরেজিতে বুঝিয়ে দাও এবং ২টি অনুশীলন প্রশ্ন দাও।',
      },
      {
        title: 'Master calculus intuition',
        subtitle: 'Derivatives and integrals made visual',
        prompt: 'Teach me what derivatives and integrals actually represent geometrically, step-by-step with a worked example and Bengali summary.',
      },
      {
        title: 'Organic chemistry mechanism',
        subtitle: 'Exam-focused step breakdown',
        prompt: 'Explain SN1 vs SN2 reactions for an exam: key differences, conditions, and a quick memory trick.',
      },
      {
        title: 'Summarize textbook notes',
        subtitle: 'Turn dense chapters into active recall cards',
        prompt: 'Create a 5-point active recall study sheet on cellular respiration (Glycolysis, Krebs Cycle, ETC) with key takeaways.',
      },
    ],
  },
  coding: {
    id: 'coding',
    label: 'Coding',
    shortLabel: 'Coding',
    description: 'Production-grade code generation, debugging, refactoring, and complexity analysis.',
    placeholder: 'Paste code, describe a bug, or design a feature...',
    starters: [
      {
        title: 'Debug async race condition',
        subtitle: 'Identify and fix subtle React state issues',
        prompt: 'Show how stale closures and race conditions happen in React useEffect data fetching, and write the cleanest fix using AbortController.',
      },
      {
        title: 'Algorithm & complexity breakdown',
        subtitle: 'Optimal time & space solution',
        prompt: 'Solve the "Longest Substring Without Repeating Characters" problem in TypeScript with sliding window and explain O(n) complexity.',
      },
      {
        title: 'SQL query optimization',
        subtitle: 'Indexing and CTE best practices',
        prompt: 'Explain when to use a composite index vs a partial index in PostgreSQL with concrete query plan examples.',
      },
      {
        title: 'REST API error handling',
        subtitle: 'Clean Express middleware patterns',
        prompt: 'Write a clean TypeScript Express error-handling middleware pattern with typed application errors and safe client responses.',
      },
    ],
  },
  writing: {
    id: 'writing',
    label: 'Writing',
    shortLabel: 'Writing',
    description: 'Editorial clarity, tone refinement, essays, summaries, and bilingual drafting.',
    placeholder: 'Share text to polish or describe what you want to write...',
    starters: [
      {
        title: 'Polish & tighten prose',
        subtitle: 'Improve flow without losing your voice',
        prompt: 'Give me 5 actionable editing principles to make technical blog posts clearer, punchier, and easier to scan.',
      },
      {
        title: 'Structure a persuasive essay',
        subtitle: 'Strong thesis and counterarguments',
        prompt: 'Create a detailed essay outline on how open-source AI models accelerate university research in developing nations.',
      },
      {
        title: 'Formal Bengali letter / article',
        subtitle: 'Natural, dignified Bangla phrasing',
        prompt: 'একটি বিজ্ঞান ক্লাবের বার্ষিক প্রদর্শনীতে প্রধান অতিথিকে আমন্ত্রণ জানিয়ে একটি মার্জিত বাংলা আমন্ত্রণপত্র লিখে দাও।',
      },
      {
        title: 'Executive summary rewrite',
        subtitle: 'Distill long notes into key decisions',
        prompt: 'Provide a concise template for turning messy meeting notes into an executive summary with owners and next steps.',
      },
    ],
  },
};

export const MODE_LIST: ModeDefinition[] = [
  ASSISTANT_MODES.general,
  ASSISTANT_MODES.study,
  ASSISTANT_MODES.coding,
  ASSISTANT_MODES.writing,
];

export const STUDY_LANGUAGE_OPTIONS: Array<{
  id: StudyLanguage;
  label: string;
  description: string;
}> = [
  {
    id: 'bilingual',
    label: 'English + বাংলা',
    description: 'Academic English paired with clear Bengali explanations',
  },
  {
    id: 'bengali',
    label: 'বাংলা Primary',
    description: 'Explanations primarily in Bengali with key English terms',
  },
  {
    id: 'english',
    label: 'English Only',
    description: 'Standard English academic tutoring unless asked in Bengali',
  },
];
