import { initializeApp } from 'firebase/app';
import {
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  getAuth,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import type { AssistantMode, ChatMessage, Conversation } from '../types/chat.ts';
import type {
  FirestoreAuditLogRecord,
  UserAccountStatus,
  UserDirectoryRecord,
  UserTier,
} from '../types/admin.ts';

export const SUPER_ADMIN_EMAIL = 'kabirnamikage@gmail.com';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: Array<{
      providerId?: string | null;
      email?: string | null;
    }>;
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (
      error instanceof Error &&
      error.message.includes('the client is offline')
    ) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

void testConnection();

export async function signInWithGoogleAccount(): Promise<User> {
  const cred = await signInWithPopup(auth, googleProvider);
  return cred.user;
}

export async function signUpWithEmailAccount(params: {
  name: string;
  email: string;
  password: string;
}): Promise<User> {
  const cred = await createUserWithEmailAndPassword(
    auth,
    params.email.trim(),
    params.password
  );
  if (params.name.trim()) {
    await updateProfile(cred.user, { displayName: params.name.trim() });
  }
  await sendEmailVerification(cred.user);
  return cred.user;
}

export async function signInWithEmailAccount(params: {
  email: string;
  password: string;
}): Promise<User> {
  const cred = await signInWithEmailAndPassword(
    auth,
    params.email.trim(),
    params.password
  );
  return cred.user;
}

export async function resendVerificationEmailForUser(user: User): Promise<void> {
  await sendEmailVerification(user);
}

export async function sendPasswordReset(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

export async function signOutAccount(): Promise<void> {
  await signOut(auth);
}

export async function ensureUserPrivateProfile(user: User): Promise<void> {
  if (!user.emailVerified) return;
  const profilePath = `users/${user.uid}/private/profile`;
  const ref = doc(db, 'users', user.uid, 'private', 'profile');
  const displayName = (
    user.displayName?.trim() ||
    user.email?.split('@')[0] ||
    'NOVA User'
  ).slice(0, 100);
  const email = (user.email || 'user@nova.local').slice(0, 254);

  try {
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        uid: user.uid,
        email,
        displayName,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        email,
        displayName,
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(
      error,
      OperationType.WRITE,
      profilePath
    );
  }
}

const ALLOWED_MODES = new Set<AssistantMode>([
  'general',
  'study',
  'coding',
  'writing',
]);

function toValidMode(mode: unknown): AssistantMode {
  return typeof mode === 'string' && ALLOWED_MODES.has(mode as AssistantMode)
    ? (mode as AssistantMode)
    : 'general';
}

export async function syncConversationToCloud(
  uid: string,
  conv: Conversation
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const convPath = `users/${uid}/conversations/${conv.id}`;
  const convRef = doc(db, 'users', uid, 'conversations', conv.id);

  try {
    const existing = await getDoc(convRef);
    const title = (conv.title.trim() || 'New Chat').slice(0, 120);
    const model = (conv.model.trim() || 'gemini-3.1-flash-lite').slice(0, 100);
    const mode = toValidMode(conv.mode);

    if (!existing.exists()) {
      await setDoc(convRef, {
        id: conv.id,
        ownerId: uid,
        title,
        mode,
        model,
        pinned: Boolean(conv.pinned),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(convRef, {
        title,
        mode,
        model,
        pinned: Boolean(conv.pinned),
        updatedAt: serverTimestamp(),
      });
    }

    for (const msg of conv.messages) {
      if (msg.error) continue;
      const msgPath = `${convPath}/messages/${msg.id}`;
      const msgRef = doc(db, 'users', uid, 'conversations', conv.id, 'messages', msg.id);
      const safeContent = (msg.content || '').slice(0, 100000);
      const safeModeUsed = msg.modeUsed ? toValidMode(msg.modeUsed) : undefined;
      try {
        const msgSnap = await getDoc(msgRef);
        if (!msgSnap.exists()) {
          await setDoc(msgRef, {
            id: msg.id,
            ownerId: uid,
            role: msg.role,
            content: safeContent,
            ...(msg.modelUsed ? { modelUsed: msg.modelUsed.slice(0, 100) } : {}),
            ...(safeModeUsed ? { modeUsed: safeModeUsed } : {}),
            clientCreatedAt: msg.createdAt,
            createdAt: serverTimestamp(),
          });
        } else if (msgSnap.data()?.content !== safeContent) {
          await updateDoc(msgRef, {
            content: safeContent,
            ...(msg.modelUsed ? { modelUsed: msg.modelUsed.slice(0, 100) } : {}),
            ...(safeModeUsed ? { modeUsed: safeModeUsed } : {}),
          });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, msgPath);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, convPath);
  }
}

export async function loadCloudConversations(
  uid: string
): Promise<Conversation[]> {
  if (!auth.currentUser?.emailVerified) return [];
  const listPath = `users/${uid}/conversations`;
  try {
    const q = query(
      collection(db, 'users', uid, 'conversations'),
      where('ownerId', '==', uid)
    );
    const snap = await getDocs(q);
    const results: Conversation[] = [];

    for (const d of snap.docs) {
      const data = d.data();
      const msgPath = `${listPath}/${d.id}/messages`;
      let messages: ChatMessage[] = [];
      try {
        const msgQ = query(
          collection(db, 'users', uid, 'conversations', d.id, 'messages'),
          where('ownerId', '==', uid)
        );
        const msgSnap = await getDocs(msgQ);
        messages = msgSnap.docs
          .map((md) => {
            const m = md.data();
            return {
              id: String(m.id || md.id),
              role: (m.role === 'assistant' ? 'assistant' : 'user') as ChatMessage['role'],
              content: String(m.content || ''),
              modelUsed: typeof m.modelUsed === 'string' ? m.modelUsed : undefined,
              modeUsed: m.modeUsed as AssistantMode | undefined,
              createdAt:
                typeof m.clientCreatedAt === 'number'
                  ? m.clientCreatedAt
                  : Date.now(),
            };
          })
          .sort((a, b) => a.createdAt - b.createdAt);
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, msgPath);
      }

      results.push({
        id: String(data.id || d.id),
        title: String(data.title || 'New Chat'),
        mode: toValidMode(data.mode),
        model: String(data.model || 'gemini-3.1-flash-lite'),
        pinned: Boolean(data.pinned),
        messages,
        createdAt: data.createdAt?.toMillis?.() ?? Date.now(),
        updatedAt: data.updatedAt?.toMillis?.() ?? Date.now(),
      });
    }

    return results.sort((a, b) => b.updatedAt - a.updatedAt);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, listPath);
  }
}

export async function deleteCloudConversation(
  uid: string,
  conversationId: string
): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const convPath = `users/${uid}/conversations/${conversationId}`;
  try {
    const msgSnap = await getDocs(
      query(
        collection(db, 'users', uid, 'conversations', conversationId, 'messages'),
        where('ownerId', '==', uid)
      )
    );
    const batch = writeBatch(db);
    for (const md of msgSnap.docs) {
      batch.delete(md.ref);
    }
    batch.delete(doc(db, 'users', uid, 'conversations', conversationId));
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, convPath);
  }
}

export async function clearAllCloudConversations(uid: string): Promise<void> {
  if (!auth.currentUser?.emailVerified) return;
  const listPath = `users/${uid}/conversations`;
  try {
    const snap = await getDocs(
      query(
        collection(db, 'users', uid, 'conversations'),
        where('ownerId', '==', uid)
      )
    );
    for (const d of snap.docs) {
      await deleteCloudConversation(uid, d.id);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, listPath);
  }
}

export async function syncUserDirectoryAccount(
  user: User,
  conversationCount?: number
): Promise<UserDirectoryRecord | null> {
  if (!user.emailVerified) return null;
  const userPath = `users/${user.uid}`;
  const ref = doc(db, 'users', user.uid);
  const email = (user.email || 'user@nova.local').slice(0, 254);
  const displayName = (
    user.displayName?.trim() ||
    user.email?.split('@')[0] ||
    'NOVA User'
  ).slice(0, 100);
  const provider = (user.providerData?.[0]?.providerId || 'password').slice(0, 40);
  const isAdminEmail = email.trim().toLowerCase() === SUPER_ADMIN_EMAIL;

  try {
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, {
        uid: user.uid,
        email,
        displayName,
        status: 'active',
        tier: isAdminEmail ? 'admin' : 'free',
        suspendedUntil: null,
        provider,
        conversationCount: Math.max(0, conversationCount ?? 0),
        createdAt: serverTimestamp(),
        lastActiveAt: serverTimestamp(),
      });
      const created = await getDoc(ref);
      const d = created.data();
      return {
        uid: user.uid,
        email,
        displayName,
        status: (d?.status as UserAccountStatus) || 'active',
        tier: (d?.tier as UserTier) || (isAdminEmail ? 'admin' : 'free'),
        suspendedUntil: typeof d?.suspendedUntil === 'number' ? d.suspendedUntil : null,
        provider,
        conversationCount: typeof d?.conversationCount === 'number' ? d.conversationCount : 0,
        createdAt: d?.createdAt?.toMillis?.() ?? Date.now(),
        lastActiveAt: d?.lastActiveAt?.toMillis?.() ?? Date.now(),
      };
    }

    const existing = snap.data();
    await updateDoc(ref, {
      displayName,
      provider,
      ...(typeof conversationCount === 'number'
        ? { conversationCount: Math.max(0, Math.floor(conversationCount)) }
        : {}),
      lastActiveAt: serverTimestamp(),
    });

    return {
      uid: String(existing.uid || user.uid),
      email: String(existing.email || email),
      displayName,
      status: (existing.status as UserAccountStatus) || 'active',
      tier: (existing.tier as UserTier) || (isAdminEmail ? 'admin' : 'free'),
      suspendedUntil:
        typeof existing.suspendedUntil === 'number' ? existing.suspendedUntil : null,
      provider,
      conversationCount:
        typeof conversationCount === 'number'
          ? conversationCount
          : typeof existing.conversationCount === 'number'
            ? existing.conversationCount
            : 0,
      createdAt: existing.createdAt?.toMillis?.() ?? Date.now(),
      lastActiveAt: Date.now(),
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, userPath);
  }
}

export async function fetchAllUserAccounts(): Promise<UserDirectoryRecord[]> {
  if (!auth.currentUser?.emailVerified) return [];
  try {
    const snap = await getDocs(collection(db, 'users'));
    return snap.docs
      .map((d) => {
        const data = d.data();
        return {
          uid: String(data.uid || d.id),
          email: String(data.email || ''),
          displayName: String(data.displayName || 'User'),
          status: (data.status as UserAccountStatus) || 'active',
          tier: (data.tier as UserTier) || 'free',
          suspendedUntil:
            typeof data.suspendedUntil === 'number' ? data.suspendedUntil : null,
          provider: typeof data.provider === 'string' ? data.provider : 'unknown',
          conversationCount:
            typeof data.conversationCount === 'number' ? data.conversationCount : 0,
          createdAt: data.createdAt?.toMillis?.() ?? 0,
          lastActiveAt: data.lastActiveAt?.toMillis?.() ?? 0,
        };
      })
      .sort((a, b) => b.lastActiveAt - a.lastActiveAt);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'users');
  }
}

export async function adminUpdateUserAccount(
  targetUid: string,
  patch: {
    status?: UserAccountStatus;
    tier?: UserTier;
    suspendedUntil?: number | null;
  }
): Promise<void> {
  const path = `users/${targetUid}`;
  try {
    await updateDoc(doc(db, 'users', targetUid), {
      ...(patch.status ? { status: patch.status } : {}),
      ...(patch.tier ? { tier: patch.tier } : {}),
      ...(patch.suspendedUntil !== undefined
        ? { suspendedUntil: patch.suspendedUntil }
        : {}),
      lastActiveAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adminDeleteUserDirectory(targetUid: string): Promise<void> {
  const path = `users/${targetUid}`;
  try {
    await deleteDoc(doc(db, 'users', targetUid));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function logAdminAudit(params: {
  action: string;
  targetType: string;
  targetId: string;
  details: string;
}): Promise<void> {
  const user = auth.currentUser;
  if (!user || !user.emailVerified) return;
  const id = `aud_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const path = `admin_audit_logs/${id}`;
  try {
    await setDoc(doc(db, 'admin_audit_logs', id), {
      id,
      actorUid: user.uid,
      actorEmail: (user.email || '').slice(0, 254),
      action: params.action.slice(0, 120),
      targetType: params.targetType.slice(0, 60),
      targetId: params.targetId.slice(0, 128),
      details: params.details.slice(0, 1000),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function loadAdminAuditLogs(): Promise<FirestoreAuditLogRecord[]> {
  if (!auth.currentUser?.emailVerified) return [];
  try {
    const snap = await getDocs(collection(db, 'admin_audit_logs'));
    return snap.docs
      .map((d) => {
        const data = d.data();
        return {
          id: String(data.id || d.id),
          actorUid: String(data.actorUid || ''),
          actorEmail: String(data.actorEmail || ''),
          action: String(data.action || ''),
          targetType: String(data.targetType || ''),
          targetId: String(data.targetId || ''),
          details: String(data.details || ''),
          createdAt: data.createdAt?.toMillis?.() ?? 0,
        };
      })
      .sort((a, b) => b.createdAt - a.createdAt)
      .slice(0, 150);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'admin_audit_logs');
  }
}
