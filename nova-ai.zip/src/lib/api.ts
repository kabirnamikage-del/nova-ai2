import type {
  AiImageResult,
  ApiErrorInfo,
  AssistantMode,
  ChatMessage,
  GeminiModelInfo,
  GroundingSource,
  HealthStatus,
  ImageAnalysisResponse,
  ImageAnalysisTask,
  ImageProviderStatus,
  StudyLanguage,
} from '../types/chat.ts';

export async function fetchHealth(verify = false): Promise<HealthStatus> {
  try {
    const res = await fetch(`/api/health${verify ? '?verify=true' : ''}`);
    const data = (await res.json()) as HealthStatus;
    return data;
  } catch {
    return {
      ok: false,
      configured: false,
      verified: false,
      searchGroundingAvailable: false,
      timestamp: Date.now(),
      error: {
        code: 'NETWORK_ERROR',
        title: 'Server Unreachable',
        message: 'Unable to reach the NOVA AI backend server.',
        hint: 'Check that the server is running and reload the page.',
      },
    };
  }
}

export async function fetchAvailableModels(): Promise<{
  models: GeminiModelInfo[];
  error?: ApiErrorInfo;
}> {
  try {
    const res = await fetch('/api/models');
    const data = (await res.json()) as {
      models?: GeminiModelInfo[];
      error?: ApiErrorInfo;
    };
    return {
      models: Array.isArray(data.models) ? data.models : [],
      error: data.error,
    };
  } catch {
    return {
      models: [],
      error: {
        code: 'NETWORK_ERROR',
        title: 'Failed to Load Models',
        message: 'Could not retrieve the available Gemini model list.',
        hint: 'Check your connection and click refresh.',
      },
    };
  }
}

export interface StreamChatParams {
  model: string;
  messages: ChatMessage[];
  mode: AssistantMode;
  studyLanguage: StudyLanguage;
  useWebSearch: boolean;
  signal: AbortSignal;
  onChunk: (delta: string) => void;
  onGrounding: (sources: GroundingSource[], queries: string[]) => void;
  onError: (err: ApiErrorInfo) => void;
  onDone: () => void;
}

export async function streamChatCompletion(params: StreamChatParams): Promise<void> {
  const {
    model,
    messages,
    mode,
    studyLanguage,
    useWebSearch,
    signal,
    onChunk,
    onGrounding,
    onError,
    onDone,
  } = params;

  const internalController = new AbortController();
  let timedOut = false;
  let inactivityTimer: ReturnType<typeof setTimeout> | null = null;
  let totalTimer: ReturnType<typeof setTimeout> | null = null;

  const resetInactivityTimer = () => {
    if (inactivityTimer) clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(() => {
      timedOut = true;
      internalController.abort();
    }, 28_000);
  };

  const onCallerAbort = () => {
    internalController.abort();
  };

  if (signal.aborted) {
    onDone();
    return;
  }
  signal.addEventListener('abort', onCallerAbort);

  totalTimer = setTimeout(() => {
    timedOut = true;
    internalController.abort();
  }, 90_000);
  resetInactivityTimer();

  try {
    const payloadMessages = messages.map((m) => ({
      role: m.role,
      content: m.content,
      attachments: m.attachments?.map((a) => ({
        name: a.name,
        mimeType: a.mimeType,
        data: a.data,
        kind: a.kind,
      })),
      error: m.error ? true : undefined,
    }));

    const res = await fetch('/api/chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        messages: payloadMessages,
        mode,
        studyLanguage,
        useWebSearch,
      }),
      signal: internalController.signal,
    });

    resetInactivityTimer();

    const contentType = res.headers.get('content-type') || '';
    if (!res.ok && !contentType.includes('text/event-stream')) {
      let errBody: { error?: ApiErrorInfo } = {};
      try {
        errBody = (await res.json()) as { error?: ApiErrorInfo };
      } catch {
        // Ignore JSON parse error
      }
      onError(
        errBody.error ?? {
          code: `HTTP_${res.status}`,
          title: 'Request Failed',
          message: `The server returned status ${res.status}.`,
          hint: 'Please try again.',
          status: res.status,
        }
      );
      return;
    }

    if (!res.body) {
      onError({
        code: 'STREAM_ERROR',
        title: 'Empty Stream',
        message: 'The server did not return a response stream.',
        hint: 'Please retry your message.',
      });
      return;
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let finishedNormally = false;

    const processBlock = (rawBlock: string) => {
      const lines = rawBlock.split(/\r?\n/);
      let eventName = 'message';
      const dataLines: string[] = [];

      for (const line of lines) {
        if (!line || line.startsWith(':')) {
          continue;
        }
        if (line.startsWith('event:')) {
          eventName = line.slice(6).trim();
        } else if (line.startsWith('data:')) {
          dataLines.push(line.slice(5).trim());
        }
      }

      if (dataLines.length === 0) return;
      const rawData = dataLines.join('\n');

      try {
        const parsed = JSON.parse(rawData) as Record<string, unknown>;
        if (eventName === 'chunk' && typeof parsed.text === 'string') {
          onChunk(parsed.text);
        } else if (eventName === 'grounding') {
          const sources = Array.isArray(parsed.sources)
            ? (parsed.sources as GroundingSource[])
            : [];
          const queries = Array.isArray(parsed.searchQueries)
            ? (parsed.searchQueries as string[])
            : [];
          onGrounding(sources, queries);
        } else if (eventName === 'error') {
          finishedNormally = true;
          onError(parsed as unknown as ApiErrorInfo);
        } else if (eventName === 'done') {
          finishedNormally = true;
          onDone();
        }
      } catch {
        // Ignore malformed SSE frame
      }
    };

    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        resetInactivityTimer();
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split(/\r?\n\r?\n/);
        buffer = parts.pop() ?? '';

        for (const block of parts) {
          if (block.trim()) {
            processBlock(block);
          }
        }
      }
    } finally {
      try {
        reader.releaseLock();
      } catch {
        // Ignore
      }
    }

    if (buffer.trim()) {
      processBlock(buffer);
    }

    if (!finishedNormally) {
      onDone();
    }
  } catch (err) {
    if (timedOut) {
      onError({
        code: 'MODEL_TIMEOUT',
        title: 'Response Timed Out',
        message: 'No response was received from the Gemini API before the timeout.',
        hint: 'Click Retry, or select Gemini 3.1 Flash Lite in the model selector.',
      });
      return;
    }
    if (
      signal.aborted ||
      (err instanceof DOMException && err.name === 'AbortError')
    ) {
      onDone();
      return;
    }
    onError({
      code: 'NETWORK_ERROR',
      title: 'Connection Interrupted',
      message:
        err instanceof Error
          ? err.message
          : 'Network error while streaming response.',
      hint: 'Check your internet connection and click Retry.',
    });
  } finally {
    if (inactivityTimer) clearTimeout(inactivityTimer);
    if (totalTimer) clearTimeout(totalTimer);
    signal.removeEventListener('abort', onCallerAbort);
  }
}

export async function generateConversationTitle(
  prompt: string,
  model: string
): Promise<string | null> {
  try {
    const res = await fetch('/api/chat/title', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, model }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { title?: string };
    return data.title?.trim() || null;
  } catch {
    return null;
  }
}

export async function transcribeAudioBlob(
  blob: Blob,
  language: string
): Promise<{ text?: string; error?: ApiErrorInfo }> {
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Failed to read audio recording'));
    reader.readAsDataURL(blob);
  });

  try {
    const res = await fetch('/api/transcribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        audioBase64: base64,
        mimeType: blob.type || 'audio/webm',
        language,
      }),
    });
    const data = (await res.json()) as { text?: string; error?: ApiErrorInfo };
    return data;
  } catch {
    return {
      error: {
        code: 'NETWORK_ERROR',
        title: 'Transcription Failed',
        message: 'Could not reach the transcription service.',
        hint: 'Check your connection and try speaking again.',
      },
    };
  }
}

export async function analyzeImageWithGemini(params: {
  imageBase64: string;
  mimeType: string;
  task: ImageAnalysisTask;
  question?: string;
  model?: string;
  signal?: AbortSignal;
}): Promise<ImageAnalysisResponse> {
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 30_000);

  const onAbort = () => controller.abort();
  params.signal?.addEventListener('abort', onAbort);

  try {
    const res = await fetch('/api/image/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        imageBase64: params.imageBase64,
        mimeType: params.mimeType,
        task: params.task,
        question: params.question ?? '',
        ...(params.model ? { model: params.model } : {}),
      }),
      signal: controller.signal,
    });

    const data = (await res.json().catch(() => ({}))) as ImageAnalysisResponse;
    if (!res.ok && !data.error) {
      return {
        error: {
          code: `HTTP_${res.status}`,
          title: 'Image Analysis Failed',
          message: `Server returned status ${res.status}.`,
          hint: 'Please check your image and try again.',
          status: res.status,
        },
      };
    }
    return data;
  } catch (err) {
    if (timedOut) {
      return {
        error: {
          code: 'MODEL_TIMEOUT',
          title: 'Image Analysis Timed Out',
          message: 'The vision model took too long to respond.',
          hint: 'Try again or use a smaller JPG/PNG/WEBP image.',
        },
      };
    }
    if (params.signal?.aborted) {
      return {
        error: {
          code: 'ABORTED',
          title: 'Analysis Cancelled',
          message: 'Image analysis was cancelled.',
        },
      };
    }
    return {
      error: {
        code: 'NETWORK_ERROR',
        title: 'Network Error',
        message:
          err instanceof Error
            ? err.message
            : 'Unable to reach the image understanding service.',
        hint: 'Check your internet connection and retry.',
      },
    };
  } finally {
    clearTimeout(timer);
    params.signal?.removeEventListener('abort', onAbort);
  }
}

export async function fetchImageProviderStatus(): Promise<ImageProviderStatus> {
  try {
    const res = await fetch('/api/image/provider');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as ImageProviderStatus;
  } catch {
    return {
      available: false,
      providerName: 'Unavailable',
      supportsGeneration: false,
      supportsEditing: false,
      reasonCode: 'PROVIDER_NOT_CONFIGURED',
      title: 'Unable to Check Image Provider',
      message: 'Could not reach the backend image provider status endpoint.',
      hint: 'Verify that the NOVA AI server is running and reload.',
      supportedProviders: [],
    };
  }
}

export interface NanoBananaTurnPayload {
  role: 'user' | 'model';
  text?: string;
  imageBase64?: string;
  mimeType?: string;
}

export async function runNanoBananaImage(params: {
  prompt: string;
  model?: 'gemini-3.1-flash-lite-image' | 'gemini-nano-banana-2.1';
  aspectRatio?: string;
  imageSize?: '1K' | '2K' | '4K';
  imageBase64?: string;
  mimeType?: string;
  history?: NanoBananaTurnPayload[];
  confirmPaidRequest: boolean;
}): Promise<AiImageResult> {
  const controller = new AbortController();
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 50_000);

  try {
    const res = await fetch('/api/image/nano-banana', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
      signal: controller.signal,
    });
    const data = (await res.json().catch(() => ({}))) as AiImageResult;
    if (!res.ok && !data.error) {
      return {
        error: {
          code: `HTTP_${res.status}`,
          title: 'Nano Banana Image Request Failed',
          message: `Server returned status ${res.status}.`,
          status: res.status,
        },
      };
    }
    return data;
  } catch (err) {
    if (timedOut) {
      return {
        error: {
          code: 'MODEL_TIMEOUT',
          title: 'Image Generation Timed Out',
          message: 'The Nano Banana model took too long to respond.',
          hint: 'Retry with a simpler prompt or 1K resolution.',
        },
      };
    }
    return {
      error: {
        code: 'NETWORK_ERROR',
        title: 'Network Error',
        message:
          err instanceof Error
            ? err.message
            : 'Unable to reach the Nano Banana endpoint.',
        hint: 'Check your connection and try again.',
      },
    };
  } finally {
    clearTimeout(timer);
  }
}

export async function generateAiImage(params: {
  prompt: string;
  aspectRatio?: string;
  model?: string;
  imageSize?: '1K' | '2K' | '4K';
  confirmPaidRequest?: boolean;
}): Promise<AiImageResult> {
  try {
    const res = await fetch('/api/image/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = (await res.json().catch(() => ({}))) as AiImageResult;
    if (!res.ok && !data.error) {
      return {
        error: {
          code: `HTTP_${res.status}`,
          title: 'Image Generation Unavailable',
          message: `Server returned status ${res.status}.`,
          status: res.status,
        },
      };
    }
    return data;
  } catch {
    return {
      error: {
        code: 'NETWORK_ERROR',
        title: 'Network Error',
        message: 'Unable to reach the AI image generation endpoint.',
        hint: 'Check your connection and try again.',
      },
    };
  }
}

export async function editAiImage(params: {
  prompt: string;
  imageBase64: string;
  mimeType: string;
  model?: string;
  aspectRatio?: string;
  imageSize?: '1K' | '2K' | '4K';
  history?: NanoBananaTurnPayload[];
  confirmPaidRequest?: boolean;
}): Promise<AiImageResult> {
  try {
    const res = await fetch('/api/image/edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = (await res.json().catch(() => ({}))) as AiImageResult;
    if (!res.ok && !data.error) {
      return {
        error: {
          code: `HTTP_${res.status}`,
          title: 'AI Image Editing Unavailable',
          message: `Server returned status ${res.status}.`,
          status: res.status,
        },
      };
    }
    return data;
  } catch {
    return {
      error: {
        code: 'NETWORK_ERROR',
        title: 'Network Error',
        message: 'Unable to reach the AI image editing endpoint.',
        hint: 'Check your connection and try again.',
      },
    };
  }
}
