const TOOL_JSON_FENCE_RE =
  /```(?:json|tool_code|javascript)?\s*\n\s*\{[\s\S]*?(?:"action"\s*:|"action_input"\s*:|"dalle\.text2im"|dalle\.text2im|"tool_calls"\s*:)[\s\S]*?\}\s*\n?```/gi;

const INLINE_DALLE_RE =
  /\{\s*"(?:action|thought|tool)"\s*:\s*"[^"]*"[\s\S]*?(?:"action_input"|"dalle\.text2im")[\s\S]*?\}/gi;

const THOUGHT_TAG_RE = /<thought>[\s\S]*?<\/thought>/gi;

export function sanitizeAssistantMarkdown(raw: string): string {
  if (!raw) return '';

  let cleaned = raw.replace(THOUGHT_TAG_RE, '');

  const hadFakeImageToolCall =
    /dalle\.text2im/i.test(cleaned) ||
    /"action"\s*:\s*"[^"]*image/i.test(cleaned);

  cleaned = cleaned.replace(TOOL_JSON_FENCE_RE, '');
  cleaned = cleaned.replace(INLINE_DALLE_RE, '');

  // Strip standalone JSON lines that only contain action / action_input / thought keys
  cleaned = cleaned
    .split('\n')
    .filter((line) => {
      const trimmed = line.trim();
      if (
        trimmed.startsWith('{') &&
        trimmed.endsWith('}') &&
        (/"action"\s*:/.test(trimmed) ||
          /"action_input"\s*:/.test(trimmed) ||
          /"thought"\s*:/.test(trimmed) ||
          /dalle\.text2im/i.test(trimmed))
      ) {
        return false;
      }
      return true;
    })
    .join('\n')
    .trim();

  if (hadFakeImageToolCall && cleaned.length === 0) {
    return 'NOVA AI does not use fake `dalle.text2im` tool calls. To generate an AI image, click **Generate Image in Gemini** (`https://gemini.google.com/`), download the image, and upload it back into NOVA—or open **Image Assistant → AI Generate** if you have an eligible paid Nano Banana API key configured.';
  }

  return cleaned;
}
