import { auth } from './firebase.ts';
import type {
  AdminConfigDocument,
  BackendAuditLogEntry,
  BackupSnapshotMeta,
  BuilderGenerateRequest,
  BuilderProposalRecord,
  DiffLine,
  GitStatusReport,
  PublicAppConfig,
  SuperPowerConfig,
  SuperPowerHistoryEntry,
  SuperPowerTestRequest,
  SuperPowerTestResponse,
  TelemetrySnapshot,
  ValidationResult,
  WorkspaceFileNode,
} from '../types/admin.ts';

let activeStepUpPin = '';

export function setAdminStepUpPin(pin: string): void {
  activeStepUpPin = pin.trim();
}

export function getAdminStepUpPin(): string {
  return activeStepUpPin;
}

async function adminFetch<T>(
  url: string,
  init: RequestInit & { timeoutMs?: number } = {}
): Promise<T> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('You must be signed in with your authorized Google account.');
  }
  const token = await user.getIdToken();
  const headers = new Headers(init.headers);
  headers.set('Authorization', `Bearer ${token}`);
  if (init.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  if (activeStepUpPin) {
    headers.set('X-Admin-Pin', activeStepUpPin);
  }

  const { timeoutMs = 45_000, ...fetchInit } = init;
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      ...fetchInit,
      headers,
      signal: controller.signal,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg =
        data?.error?.message ||
        data?.message ||
        `Request failed with HTTP ${res.status}`;
      const err = new Error(msg) as Error & { code?: string; status?: number };
      err.code = data?.error?.code;
      err.status = res.status;
      throw err;
    }
    return data as T;
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Request timed out. Please try again.');
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}

export async function fetchPublicAppConfig(): Promise<PublicAppConfig | null> {
  try {
    const res = await fetch('/api/app-config');
    if (!res.ok) return null;
    return (await res.json()) as PublicAppConfig;
  } catch {
    return null;
  }
}

export interface AdminSessionCheck {
  authorized: boolean;
  stepUpPinRequired: boolean;
  principal?: {
    uid: string;
    email: string;
    name: string;
    provider: string;
  };
  error?: {
    code: string;
    title: string;
    message: string;
  };
}

export async function verifyAdminSession(): Promise<AdminSessionCheck> {
  const user = auth.currentUser;
  if (!user) {
    return {
      authorized: false,
      stepUpPinRequired: false,
      error: {
        code: 'AUTH_REQUIRED',
        title: 'Sign-In Required',
        message: 'Sign in with Google OAuth to verify Super Admin access.',
      },
    };
  }
  try {
    const token = await user.getIdToken();
    const res = await fetch('/api/admin/session', {
      headers: { Authorization: `Bearer ${token}` },
    });
    const data = (await res.json().catch(() => ({}))) as AdminSessionCheck;
    return {
      authorized: Boolean(res.ok && data.authorized),
      stepUpPinRequired: Boolean(data.stepUpPinRequired),
      principal: data.principal,
      error: data.error,
    };
  } catch {
    return {
      authorized: false,
      stepUpPinRequired: false,
      error: {
        code: 'NETWORK_ERROR',
        title: 'Verification Unavailable',
        message: 'Unable to reach the backend admin verification endpoint.',
      },
    };
  }
}

export interface AdminOverviewPayload {
  telemetry: TelemetrySnapshot;
  config: AdminConfigDocument;
  geminiConfigured: boolean;
  imageProvider: {
    available: boolean;
    providerName: string;
    reasonCode: string;
    title: string;
  };
  git: GitStatusReport;
  stepUpPinRequired: boolean;
}

export function fetchAdminOverview(): Promise<AdminOverviewPayload> {
  return adminFetch<AdminOverviewPayload>('/api/admin/overview');
}

export function saveAdminConfigRemote(
  config: AdminConfigDocument
): Promise<{ config: AdminConfigDocument }> {
  return adminFetch<{ config: AdminConfigDocument }>('/api/admin/config', {
    method: 'PUT',
    body: JSON.stringify(config),
  });
}

export function syncAndroidFilesRemote(params: {
  appName: string;
  launcherColor: string;
  splashBackground: string;
}): Promise<{
  backupId: string;
  updatedFiles: string[];
  config: AdminConfigDocument;
}> {
  return adminFetch('/api/admin/android-sync', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export function fetchWorkspaceTree(): Promise<{ tree: WorkspaceFileNode[] }> {
  return adminFetch('/api/admin/files');
}

export function fetchWorkspaceFile(path: string): Promise<{
  path: string;
  content: string;
  protected: boolean;
  size: number;
}> {
  return adminFetch(`/api/admin/file?path=${encodeURIComponent(path)}`);
}

export function previewFileDiff(
  path: string,
  content: string
): Promise<{ diffLines: DiffLine[]; stats: { added: number; removed: number } }> {
  return adminFetch('/api/admin/file/diff', {
    method: 'POST',
    body: JSON.stringify({ path, content }),
  });
}

export function saveWorkspaceFile(
  path: string,
  content: string,
  reason?: string
): Promise<{
  backup: BackupSnapshotMeta;
  appliedPaths: string[];
  validation: ValidationResult;
}> {
  return adminFetch('/api/admin/file', {
    method: 'PUT',
    body: JSON.stringify({ path, content, reason }),
  });
}

export function runWorkspaceValidation(): Promise<{ validation: ValidationResult }> {
  return adminFetch('/api/admin/validate', { method: 'POST' });
}

export function fetchBackupSnapshots(): Promise<{ backups: BackupSnapshotMeta[] }> {
  return adminFetch('/api/admin/backups');
}

export function rollbackBackupRemote(
  backupId: string
): Promise<{
  restoredPaths: string[];
  validation: ValidationResult;
  message?: string;
}> {
  return adminFetch('/api/admin/rollback', {
    method: 'POST',
    body: JSON.stringify({ backupId }),
    timeoutMs: 90_000,
  });
}

export interface SuperPowerPayload {
  config: SuperPowerConfig;
  history: SuperPowerHistoryEntry[];
  availableModels: Array<{ id: string; displayName: string; tier: 'free' | 'paid' }>;
  geminiConfigured: boolean;
  imageProvider: {
    available: boolean;
    providerName: string;
    reasonCode: string;
    title: string;
  };
}

export function fetchSuperPowerRemote(): Promise<SuperPowerPayload> {
  return adminFetch<SuperPowerPayload>('/api/admin/super-power');
}

export function saveSuperPowerRemote(params: {
  config: SuperPowerConfig;
  note?: string;
}): Promise<{
  config: SuperPowerConfig;
  history: SuperPowerHistoryEntry[];
  publicConfig: PublicAppConfig;
}> {
  return adminFetch('/api/admin/super-power', {
    method: 'PUT',
    body: JSON.stringify(params),
  });
}

export function restoreSuperPowerRemote(historyId: string): Promise<{
  config: SuperPowerConfig;
  history: SuperPowerHistoryEntry[];
  restoredFromVersion: number;
  publicConfig: PublicAppConfig;
}> {
  return adminFetch('/api/admin/super-power/restore', {
    method: 'POST',
    body: JSON.stringify({ historyId }),
  });
}

export function testSuperPowerRemote(
  params: SuperPowerTestRequest
): Promise<SuperPowerTestResponse> {
  return adminFetch<SuperPowerTestResponse>('/api/admin/super-power/test', {
    method: 'POST',
    body: JSON.stringify(params),
    timeoutMs: 60_000,
  });
}

export function fetchBuilderProposalsRemote(): Promise<{
  proposals: BuilderProposalRecord[];
  workspaceFiles: string[];
}> {
  return adminFetch('/api/admin/super-power/builder/proposals');
}

export function generateBuilderChangesRemote(
  params: BuilderGenerateRequest
): Promise<{
  proposal: BuilderProposalRecord;
  proposals: BuilderProposalRecord[];
}> {
  return adminFetch('/api/admin/super-power/builder/generate', {
    method: 'POST',
    body: JSON.stringify(params),
    timeoutMs: 120_000,
  });
}

export async function applyBuilderChangesRemote(proposalId: string): Promise<{
  ok: boolean;
  proposal: BuilderProposalRecord;
  proposals: BuilderProposalRecord[];
  backup: BackupSnapshotMeta;
  backups: BackupSnapshotMeta[];
  validation: ValidationResult;
  buildValidation?: ValidationResult;
}> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('You must be signed in with your authorized Google account.');
  }
  const token = await user.getIdToken();
  const headers = new Headers({
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  });
  if (activeStepUpPin) {
    headers.set('X-Admin-Pin', activeStepUpPin);
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 130_000);
  try {
    const res = await fetch('/api/admin/super-power/builder/apply', {
      method: 'POST',
      headers,
      body: JSON.stringify({ proposalId }),
      signal: controller.signal,
    });
    const data = await res.json().catch(() => ({}));
    // HTTP 422 means validation ran cleanly and failed safely (auto-reverted), returning structured failure report!
    if (!res.ok && res.status !== 422) {
      throw new Error(data?.error?.message || `Apply failed with HTTP ${res.status}`);
    }
    return data as {
      ok: boolean;
      proposal: BuilderProposalRecord;
      proposals: BuilderProposalRecord[];
      backup: BackupSnapshotMeta;
      backups: BackupSnapshotMeta[];
      validation: ValidationResult;
      buildValidation?: ValidationResult;
    };
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Apply & validation timed out. Check Backups to verify state.');
    }
    throw err;
  } finally {
    window.clearTimeout(timer);
  }
}

export function rejectBuilderChangesRemote(proposalId: string): Promise<{
  proposal: BuilderProposalRecord;
  proposals: BuilderProposalRecord[];
}> {
  return adminFetch('/api/admin/super-power/builder/reject', {
    method: 'POST',
    body: JSON.stringify({ proposalId }),
  });
}

export function rollbackBuilderChangesRemote(proposalId: string): Promise<{
  proposal: BuilderProposalRecord;
  proposals: BuilderProposalRecord[];
  restoredPaths: string[];
  validation: ValidationResult;
  backups: BackupSnapshotMeta[];
}> {
  return adminFetch('/api/admin/super-power/builder/rollback', {
    method: 'POST',
    body: JSON.stringify({ proposalId }),
    timeoutMs: 90_000,
  });
}

export function fetchGitStatus(): Promise<{ git: GitStatusReport }> {
  return adminFetch('/api/admin/git/status');
}

export function createGitBranchRemote(
  branchName: string
): Promise<{ ok: boolean; branch: string; output: string }> {
  return adminFetch('/api/admin/git/branch', {
    method: 'POST',
    body: JSON.stringify({ branchName }),
  });
}

export function commitGitChangesRemote(
  message: string
): Promise<{ ok: boolean; output: string }> {
  return adminFetch('/api/admin/git/commit', {
    method: 'POST',
    body: JSON.stringify({ message }),
  });
}

export function runGitBuildSuiteRemote(): Promise<{
  lint: ValidationResult;
  build: ValidationResult;
}> {
  return adminFetch('/api/admin/git/build', { method: 'POST' });
}

export function pushGitHubRemote(
  branchName?: string
): Promise<{ ok: boolean; output: string }> {
  return adminFetch('/api/admin/git/push', {
    method: 'POST',
    body: JSON.stringify({ branchName }),
  });
}

export function fetchBackendAuditLogs(): Promise<{ logs: BackendAuditLogEntry[] }> {
  return adminFetch('/api/admin/audit-logs');
}
