import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  AlertTriangle,
  ArrowDown,
  ExternalLink,
  Loader2,
  ShieldAlert,
  Sparkles,
  Wrench,
  X,
} from 'lucide-react';
import { AdminPanel } from './components/AdminPanel.tsx';
import { AuthGate } from './components/AuthGate.tsx';
import { ChatComposer } from './components/ChatComposer.tsx';
import { CreateVisualView } from './components/CreateVisualView.tsx';
import { EmptyState } from './components/EmptyState.tsx';
import { ErrorBanner } from './components/ErrorBanner.tsx';
import { HeaderBar } from './components/HeaderBar.tsx';
import { ImageAssistantView } from './components/ImageAssistantView.tsx';
import { LibraryView } from './components/LibraryView.tsx';
import { MessageBubble } from './components/MessageBubble.tsx';
import { NovaLogo } from './components/NovaLogo.tsx';
import { SettingsModal } from './components/SettingsModal.tsx';
import { Sidebar, type AppSection } from './components/Sidebar.tsx';
import { fetchPublicAppConfig, verifyAdminSession } from './lib/adminApi.ts';
import {
  auth,
  clearAllCloudConversations,
  deleteCloudConversation,
  ensureUserPrivateProfile,
  loadCloudConversations,
  signOutAccount,
  syncConversationToCloud,
  syncUserDirectoryAccount,
} from './lib/firebase.ts';
import type { PublicAppConfig, UserDirectoryRecord } from './types/admin.ts';
import {
  fetchAvailableModels,
  fetchHealth,
  generateConversationTitle,
  runNanoBananaImage,
  streamChatCompletion,
} from './lib/api.ts';
import {
  PRESET_CREATIONS,
  deleteUserCreation,
  extractSvgFromMarkdown,
  loadUserCreations,
  saveUserCreation,
  type VisualCreation,
} from './lib/creations.ts';
import { sanitizeAssistantMarkdown } from './lib/sanitize.ts';
import { markdownToPlainSpeech, pickBestVoice } from './lib/speech.ts';
import {
  applyThemeToDocument,
  clearAllConversationsFromStore,
  deleteConversationFromStore,
  loadActiveConversationId,
  loadConversations,
  loadSavedModelId,
  loadSettings,
  saveActiveConversationId,
  saveConversation,
  saveSelectedModelId,
  saveSettings,
} from './lib/storage.ts';
import type {
  ApiErrorInfo,
  AppSettings,
  AssistantMode,
  ChatAttachment,
  ChatMessage,
  Conversation,
  GeminiModelInfo,
  GeneratedChatImage,
  HealthStatus,
  ResponseVersion,
} from './types/chat.ts';

function toResponseVersion(msg: ChatMessage): ResponseVersion {
  return {
    content: msg.content,
    sources: msg.sources,
    searchQueries: msg.searchQueries,
    modelUsed: msg.modelUsed,
    modeUsed: msg.modeUsed,
    createdAt: msg.createdAt,
    error: msg.error,
  };
}

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(() =>
    loadActiveConversationId()
  );

  const [isTemporaryChat, setIsTemporaryChat] = useState(false);
  const [tempConversation, setTempConversation] = useState<Conversation | null>(
    null
  );

  const [models, setModels] = useState<GeminiModelInfo[]>([]);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [selectedModelId, setSelectedModelId] = useState<string>(
    () => loadSavedModelId() ?? ''
  );

  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [verifyingHealth, setVerifyingHealth] = useState(false);
  const [globalError, setGlobalError] = useState<ApiErrorInfo | null>(null);

  const [mode, setMode] = useState<AssistantMode>(
    () => loadSettings().defaultMode
  );
  const [useWebSearch, setUseWebSearch] = useState<boolean>(
    () => loadSettings().defaultWebSearch
  );

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [desktopSidebarOpen, setDesktopSidebarOpen] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<AppSection>('chat');
  const [userCreations, setUserCreations] = useState<VisualCreation[]>(() =>
    loadUserCreations()
  );
  const [studioInitialPrompt, setStudioInitialPrompt] = useState<
    string | undefined
  >(undefined);
  const [pendingAiEditImage, setPendingAiEditImage] =
    useState<GeneratedChatImage | null>(null);

  const [streamingChatId, setStreamingChatId] = useState<string | null>(null);
  const [streamingMsgId, setStreamingMsgId] = useState<string | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const [showScrollDown, setShowScrollDown] = useState(false);

  const [authReady, setAuthReady] = useState(false);
  const [authUser, setAuthUser] = useState<User | null>(null);
  const [, setAuthTick] = useState(0);
  const [publicConfig, setPublicConfig] = useState<PublicAppConfig | null>(null);
  const [userDirectory, setUserDirectory] = useState<UserDirectoryRecord | null>(null);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [adminOpen, setAdminOpen] = useState(() => {
    if (typeof window === 'undefined') return false;
    return (
      window.location.hash === '#admin' ||
      new URLSearchParams(window.location.search).get('admin') === '1'
    );
  });

  const [chatImageMode, setChatImageMode] = useState(false);
  const [pendingImageRequest, setPendingImageRequest] = useState<{
    prompt: string;
    attachments: ChatAttachment[];
    model: 'gemini-3.1-flash-lite-image' | 'gemini-nano-banana-2.1';
  } | null>(null);
  const [generatingInChatImage, setGeneratingInChatImage] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  const isSendingRef = useRef(false);
  const pendingVisualMetaRef = useRef<{
    prompt: string;
    style: string;
    aspectRatio: string;
    mood: string;
  } | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const shouldAutoScrollRef = useRef(true);

  const conversationsRef = useRef<Conversation[]>(conversations);
  conversationsRef.current = conversations;
  const tempConversationRef = useRef<Conversation | null>(tempConversation);
  tempConversationRef.current = tempConversation;

  // Subscribe to Firebase Authentication state
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setAuthUser(user);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  const publicConfigRef = useRef<PublicAppConfig | null>(null);
  publicConfigRef.current = publicConfig;
  const hadSavedModelRef = useRef<boolean>(Boolean(loadSavedModelId()));

  // Load live server app customization & feature controls
  useEffect(() => {
    void fetchPublicAppConfig().then((cfg) => {
      if (!cfg) return;
      setPublicConfig(cfg);
      if (!hadSavedModelRef.current && cfg.superPower?.defaultChatModel) {
        setSelectedModelId((prev) => prev || cfg.superPower!.defaultChatModel);
      }
    });
  }, []);

  // Sync page title & CSS primary accent when live config changes
  useEffect(() => {
    const name = publicConfig?.customization.appName?.trim() || 'NOVA AI';
    document.title = `${name} — Personal AI Workspace`;
    if (publicConfig?.customization.primaryColor) {
      document.documentElement.style.setProperty(
        '--nova-primary',
        publicConfig.customization.primaryColor
      );
    }
  }, [publicConfig]);

  // Listen for #admin hash navigation
  useEffect(() => {
    const onHash = () => {
      if (window.location.hash === '#admin') {
        setAdminOpen(true);
      }
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  // Apply theme to document root whenever settings.theme changes
  useEffect(() => {
    applyThemeToDocument(settings.theme);
  }, [settings.theme]);

  // Load local IndexedDB + private per-user Firestore conversations & backend Super Admin check
  useEffect(() => {
    if (!authReady) return;
    if (!authUser || !authUser.emailVerified) {
      setConversations([]);
      setActiveId(null);
      setTempConversation(null);
      setUserDirectory(null);
      setIsSuperAdmin(false);
      return;
    }

    let mounted = true;
    void ensureUserPrivateProfile(authUser).catch((err) => {
      console.warn('Profile sync warning:', err);
    });

    // Cryptographically verify Super Admin access via backend Firebase ID Token check
    void verifyAdminSession().then((res) => {
      if (mounted) setIsSuperAdmin(Boolean(res.authorized));
    });

    void syncUserDirectoryAccount(authUser).then((rec) => {
      if (mounted && rec) setUserDirectory(rec);
    }).catch((err) => {
      console.warn('User directory sync warning:', err);
    });

    Promise.all([
      loadConversations(),
      loadCloudConversations(authUser.uid).catch((err) => {
        console.warn('Cloud load fallback to local:', err);
        return [] as Conversation[];
      }),
    ]).then(([localLoaded, cloudLoaded]) => {
      if (!mounted) return;
      const mergedMap = new Map<string, Conversation>();
      for (const c of cloudLoaded) {
        mergedMap.set(c.id, c);
      }
      for (const lc of localLoaded) {
        const existing = mergedMap.get(lc.id);
        if (!existing || lc.updatedAt >= existing.updatedAt) {
          mergedMap.set(lc.id, lc);
        } else {
          // Keep rich local attachments/images when cloud version is newer metadata
          const localMsgMap = new Map(lc.messages.map((m) => [m.id, m]));
          mergedMap.set(lc.id, {
            ...existing,
            messages: existing.messages.map((cm) => {
              const lm = localMsgMap.get(cm.id);
              return lm
                ? {
                    ...cm,
                    attachments: lm.attachments,
                    generatedImages: lm.generatedImages,
                  }
                : cm;
            }),
          });
        }
      }

      const merged = Array.from(mergedMap.values()).sort(
        (a, b) => b.updatedAt - a.updatedAt
      );
      setConversations(merged);
      const savedActive = loadActiveConversationId();
      if (savedActive && merged.some((c) => c.id === savedActive)) {
        setActiveId(savedActive);
        const found = merged.find((c) => c.id === savedActive);
        if (found) setMode(found.mode);
      } else {
        setActiveId(null);
      }
    });

    return () => {
      mounted = false;
    };
  }, [authReady, authUser]);

  const refreshModelsAndHealth = useCallback(async (verify = false) => {
    setModelsLoading(true);
    if (verify) setVerifyingHealth(true);

    const [healthRes, modelsRes] = await Promise.all([
      fetchHealth(verify),
      fetchAvailableModels(),
    ]);

    setHealth(healthRes);
    if (verify) setVerifyingHealth(false);

    if (modelsRes.error) {
      setGlobalError(modelsRes.error);
    } else if (!healthRes.ok && healthRes.error) {
      setGlobalError(healthRes.error);
    } else {
      setGlobalError(null);
    }

    setModels(modelsRes.models);
    setModelsLoading(false);

    if (modelsRes.models.length > 0) {
      setSelectedModelId((prev) => {
        if (prev && modelsRes.models.some((m) => m.id === prev)) {
          return prev;
        }
        const spDefault = publicConfigRef.current?.superPower?.defaultChatModel;
        const preferred =
          (spDefault &&
            modelsRes.models.find((m) => m.id === spDefault)?.id) ??
          modelsRes.models.find((m) => m.id === 'gemini-3.1-flash-lite')?.id ??
          modelsRes.models.find((m) => m.id === 'gemini-3.5-flash-lite')?.id ??
          modelsRes.models.find((m) => m.tier !== 'paid')?.id ??
          modelsRes.models[0].id;
        saveSelectedModelId(preferred);
        return preferred;
      });
    }
  }, []);

  useEffect(() => {
    void refreshModelsAndHealth(false);
  }, [refreshModelsAndHealth]);

  const activeConversation = useMemo(() => {
    if (isTemporaryChat) return tempConversation;
    return conversations.find((c) => c.id === activeId) ?? null;
  }, [isTemporaryChat, tempConversation, conversations, activeId]);

  const activeModelInfo = useMemo(
    () => models.find((m) => m.id === selectedModelId) ?? null,
    [models, selectedModelId]
  );

  const effectiveTier = isSuperAdmin ? 'admin' : userDirectory?.tier || 'free';
  const tierFeatures = publicConfig?.features[effectiveTier];

  const visibleModels = useMemo(() => {
    if (!tierFeatures || tierFeatures.premiumChatModels) return models;
    return models.filter((m) => m.tier !== 'paid');
  }, [models, tierFeatures]);

  const customAppName = publicConfig?.customization.appName?.trim() || 'NOVA AI';
  const customLogoUrl =
    publicConfig?.customization.logoMode === 'custom' &&
    publicConfig?.customization.customLogoDataUrl
      ? publicConfig.customization.customLogoDataUrl
      : undefined;

  const allCreations = useMemo(
    () => [...userCreations, ...PRESET_CREATIONS],
    [userCreations]
  );

  const searchGroundingSupported = Boolean(
    health?.searchGroundingAvailable &&
      (publicConfig?.superPower?.features.webSearchEnabled ?? true) &&
      (activeModelInfo ? activeModelInfo.supportsSearchGrounding : false)
  );

  const updateSettings = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  }, []);

  const toggleTheme = useCallback(() => {
    updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' });
  }, [settings.theme, updateSettings]);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    const el = scrollContainerRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior });
  }, []);

  const handleScroll = () => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const nearBottom = distanceFromBottom < 120;
    shouldAutoScrollRef.current = nearBottom;
    setShowScrollDown(
      !nearBottom && (activeConversation?.messages.length ?? 0) > 0
    );
  };

  useEffect(() => {
    if (shouldAutoScrollRef.current) {
      scrollToBottom('auto');
    }
  }, [activeConversation?.messages.length, streamingMsgId, scrollToBottom]);

  const speakText = useCallback(
    (msgId: string, content: string) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        setGlobalError({
          code: 'TTS_UNSUPPORTED',
          title: 'Speech Playback Unavailable',
          message: 'Text-to-Speech is not supported in this browser.',
          hint: 'Try Chrome, Safari, or Edge on desktop or Android.',
        });
        return;
      }

      if (speakingMsgId === msgId) {
        window.speechSynthesis.cancel();
        setSpeakingMsgId(null);
        return;
      }

      window.speechSynthesis.cancel();
      const plain = markdownToPlainSpeech(content);
      if (!plain) return;

      const utterance = new SpeechSynthesisUtterance(plain);
      const voices = window.speechSynthesis.getVoices();
      const chosen = pickBestVoice(voices, plain, settings.ttsVoiceURI);
      if (chosen) utterance.voice = chosen;
      utterance.rate = settings.ttsRate;
      utterance.onend = () => setSpeakingMsgId(null);
      utterance.onerror = () => setSpeakingMsgId(null);

      setSpeakingMsgId(msgId);
      window.speechSynthesis.speak(utterance);
    },
    [settings.ttsRate, settings.ttsVoiceURI, speakingMsgId]
  );

  const stopGenerating = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    isSendingRef.current = false;
    setStreamingChatId(null);
    setStreamingMsgId(null);
  }, []);

  const handleNewChat = useCallback(() => {
    if (streamingChatId) stopGenerating();
    setIsTemporaryChat(false);
    setTempConversation(null);
    setActiveId(null);
    saveActiveConversationId(null);
    setMode(settings.defaultMode);
    setUseWebSearch(settings.defaultWebSearch);
  }, [
    settings.defaultMode,
    settings.defaultWebSearch,
    stopGenerating,
    streamingChatId,
  ]);

  const handleToggleTemporaryChat = useCallback(() => {
    if (streamingChatId) stopGenerating();
    setIsTemporaryChat((prev) => {
      const next = !prev;
      setTempConversation(null);
      if (next) {
        setActiveId(null);
      }
      return next;
    });
  }, [stopGenerating, streamingChatId]);

  // Keyboard shortcuts: Ctrl/Cmd+K for search, Ctrl/Cmd+Shift+O for New Chat
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (!mod) return;
      if (e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setDesktopSidebarOpen(true);
        window.setTimeout(() => searchInputRef.current?.focus(), 60);
      } else if (e.shiftKey && e.key.toLowerCase() === 'o') {
        e.preventDefault();
        handleNewChat();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleNewChat]);

  const handleSelectConversation = useCallback(
    (id: string) => {
      if (streamingChatId && streamingChatId !== id) {
        stopGenerating();
      }
      setIsTemporaryChat(false);
      setTempConversation(null);
      setActiveId(id);
      saveActiveConversationId(id);
      const conv = conversationsRef.current.find((c) => c.id === id);
      if (conv) {
        setMode(conv.mode);
        if (
          !selectedModelId &&
          conv.model &&
          models.some((m) => m.id === conv.model)
        ) {
          setSelectedModelId(conv.model);
          saveSelectedModelId(conv.model);
        }
      }
      shouldAutoScrollRef.current = true;
    },
    [models, selectedModelId, stopGenerating, streamingChatId]
  );

  const upsertConversationState = useCallback(
    (updated: Conversation, persist = true, temporary = false) => {
      if (temporary) {
        setTempConversation(updated);
        return;
      }
      setConversations((prev) => {
        const exists = prev.some((c) => c.id === updated.id);
        const next = exists
          ? prev.map((c) => (c.id === updated.id ? updated : c))
          : [updated, ...prev];
        return [...next].sort((a, b) => b.updatedAt - a.updatedAt);
      });
      if (persist) {
        void saveConversation(updated);
        if (auth.currentUser?.emailVerified) {
          void syncConversationToCloud(auth.currentUser.uid, updated).catch(
            (err) => {
              console.warn('Firestore sync warning:', err);
            }
          );
        }
      }
    },
    []
  );

  const updateStreamingMessageInStore = useCallback(
    (
      convId: string,
      temporary: boolean,
      assistantMsgId: string,
      updater: (m: ChatMessage) => ChatMessage
    ) => {
      const mapConv = (c: Conversation): Conversation => {
        if (c.id !== convId) return c;
        return {
          ...c,
          updatedAt: Date.now(),
          messages: c.messages.map((m) =>
            m.id === assistantMsgId ? updater(m) : m
          ),
        };
      };

      if (temporary) {
        setTempConversation((prev) => (prev ? mapConv(prev) : prev));
      } else {
        setConversations((prev) => prev.map(mapConv));
      }
    },
    []
  );

  const runStreamForConversation = useCallback(
    async (
      conv: Conversation,
      historyMessages: ChatMessage[],
      assistantMsgId: string,
      activeModel: string,
      activeMode: AssistantMode,
      webSearch: boolean,
      temporary: boolean
    ) => {
      const controller = new AbortController();
      abortRef.current = controller;
      isSendingRef.current = true;
      setStreamingChatId(conv.id);
      setStreamingMsgId(assistantMsgId);
      setGlobalError(null);
      shouldAutoScrollRef.current = true;

      let accumulatedText = '';
      let latestSources = undefined as ChatMessage['sources'];
      let latestQueries = undefined as string[] | undefined;
      let latestError = undefined as ApiErrorInfo | undefined;

      try {
        await streamChatCompletion({
          model: activeModel,
          messages: historyMessages,
          mode: activeMode,
          studyLanguage: settings.studyLanguage,
          useWebSearch: webSearch,
          signal: controller.signal,
          onChunk: (delta) => {
            accumulatedText += delta;
            updateStreamingMessageInStore(
              conv.id,
              temporary,
              assistantMsgId,
              (m) => {
                const updated: ChatMessage = {
                  ...m,
                  content: accumulatedText,
                };
                if (updated.versions && updated.versions.length > 0) {
                  const idx =
                    updated.activeVersionIndex ?? updated.versions.length - 1;
                  updated.versions = updated.versions.map((v, i) =>
                    i === idx ? { ...v, content: accumulatedText } : v
                  );
                }
                return updated;
              }
            );
            if (shouldAutoScrollRef.current) {
              scrollToBottom('auto');
            }
          },
          onGrounding: (sources, queries) => {
            latestSources = sources;
            latestQueries = queries;
            updateStreamingMessageInStore(
              conv.id,
              temporary,
              assistantMsgId,
              (m) => {
                const updated: ChatMessage = {
                  ...m,
                  sources,
                  searchQueries: queries,
                };
                if (updated.versions && updated.versions.length > 0) {
                  const idx =
                    updated.activeVersionIndex ?? updated.versions.length - 1;
                  updated.versions = updated.versions.map((v, i) =>
                    i === idx
                      ? { ...v, sources, searchQueries: queries }
                      : v
                  );
                }
                return updated;
              }
            );
          },
          onError: (err) => {
            latestError = err;
            updateStreamingMessageInStore(
              conv.id,
              temporary,
              assistantMsgId,
              (m) => {
                const updated: ChatMessage = { ...m, error: err };
                if (updated.versions && updated.versions.length > 0) {
                  const idx =
                    updated.activeVersionIndex ?? updated.versions.length - 1;
                  updated.versions = updated.versions.map((v, i) =>
                    i === idx ? { ...v, error: err } : v
                  );
                }
                return updated;
              }
            );
          },
          onDone: () => {
            // Final persistence happens right after await resolves
          },
        });

        if (
          !accumulatedText.trim() &&
          !latestError &&
          !controller.signal.aborted
        ) {
          latestError = {
            code: 'EMPTY_RESPONSE',
            title: 'No Response Received',
            message: 'The assistant completed without returning a reply.',
            hint: 'Click Retry or switch models in the model selector.',
          };
          updateStreamingMessageInStore(
            conv.id,
            temporary,
            assistantMsgId,
            (m) => ({ ...m, error: latestError })
          );
        }
      } finally {
        abortRef.current = null;
        isSendingRef.current = false;
        setStreamingChatId(null);
        setStreamingMsgId(null);
      }

      // Auto-save any generated SVG visual artwork to Library & Your creations
      if (!latestError && accumulatedText.trim()) {
        const extractedSvg = extractSvgFromMarkdown(accumulatedText);
        if (extractedSvg) {
          const studioMeta = pendingVisualMetaRef.current;
          pendingVisualMetaRef.current = null;
          const fallbackPrompt =
            historyMessages[historyMessages.length - 1]?.content ??
            'Generated visual';
          const rawTitle = studioMeta?.prompt || fallbackPrompt;
          const nextList = saveUserCreation({
            id: crypto.randomUUID(),
            title: rawTitle.trim().slice(0, 48) || 'Generated Visual',
            prompt: studioMeta?.prompt || fallbackPrompt,
            style: studioMeta?.style || 'Illustration',
            aspectRatio: studioMeta?.aspectRatio || '1:1',
            mood: studioMeta?.mood || 'Vibrant',
            svgCode: extractedSvg,
            createdAt: Date.now(),
            conversationId: temporary ? undefined : conv.id,
          });
          setUserCreations(nextList);
        } else {
          pendingVisualMetaRef.current = null;
        }
      } else {
        pendingVisualMetaRef.current = null;
      }

      if (temporary) {
        if (settings.autoSpeak && accumulatedText && !latestError) {
          speakText(assistantMsgId, accumulatedText);
        }
        return;
      }

      // Persist final conversation snapshot with sanitized assistant markdown
      const cleanFinalText = sanitizeAssistantMarkdown(accumulatedText);
      const latestConv = conversationsRef.current.find((c) => c.id === conv.id);
      if (latestConv) {
        const finalized: Conversation = {
          ...latestConv,
          updatedAt: Date.now(),
          messages: latestConv.messages.map((m) => {
            if (m.id !== assistantMsgId) return m;
            const nextMsg: ChatMessage = {
              ...m,
              content: cleanFinalText || m.content,
              sources: latestSources ?? m.sources,
              searchQueries: latestQueries ?? m.searchQueries,
              error: latestError ?? m.error,
            };
            if (nextMsg.versions && nextMsg.versions.length > 0) {
              const idx =
                nextMsg.activeVersionIndex ?? nextMsg.versions.length - 1;
              nextMsg.versions = nextMsg.versions.map((v, i) =>
                i === idx ? toResponseVersion(nextMsg) : v
              );
            }
            return nextMsg;
          }),
        };
        await saveConversation(finalized);
        if (auth.currentUser?.emailVerified) {
          void syncConversationToCloud(auth.currentUser.uid, finalized).catch(
            (err) => {
              console.warn('Firestore final sync warning:', err);
            }
          );
        }
      }

      if (settings.autoSpeak && accumulatedText && !latestError) {
        speakText(assistantMsgId, accumulatedText);
      }

      // Generate concise smart title on the very first turn
      if (
        historyMessages.length === 1 &&
        !latestError &&
        accumulatedText.trim().length > 0
      ) {
        const firstPrompt = historyMessages[0].content;
        if (firstPrompt) {
          const smartTitle = await generateConversationTitle(
            firstPrompt,
            activeModel
          );
          if (smartTitle) {
            setConversations((prev) =>
              prev.map((c) => {
                if (c.id !== conv.id) return c;
                const renamed = { ...c, title: smartTitle };
                void saveConversation(renamed);
                if (auth.currentUser?.emailVerified) {
                  void syncConversationToCloud(
                    auth.currentUser.uid,
                    renamed
                  ).catch(() => {});
                }
                return renamed;
              })
            );
          }
        }
      }
    },
    [
      scrollToBottom,
      settings.autoSpeak,
      settings.studyLanguage,
      speakText,
      updateStreamingMessageInStore,
    ]
  );

  const handleSendMessage = useCallback(
    async (
      rawText: string,
      attachments: ChatAttachment[],
      overrideMode?: AssistantMode,
      options?: { forceNew?: boolean }
    ) => {
      if (isSendingRef.current || streamingChatId) return;

      if (!selectedModelId) {
        setGlobalError({
          code: 'NO_MODEL',
          title: 'No Gemini Model Available',
          message: 'No active Gemini chat model is currently selected.',
          hint: 'Refresh the model selector or check your server connection in Settings.',
        });
        return;
      }

      isSendingRef.current = true;
      const activeMode = overrideMode ?? mode;
      const now = Date.now();
      const currentConv = options?.forceNew
        ? null
        : isTemporaryChat
          ? tempConversationRef.current
          : conversationsRef.current.find((c) => c.id === activeId) ?? null;

      const userMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: rawText,
        attachments: attachments.length > 0 ? attachments : undefined,
        createdAt: now,
      };

      const assistantMsgId = crypto.randomUUID();
      const assistantPlaceholder: ChatMessage = {
        id: assistantMsgId,
        role: 'assistant',
        content: '',
        modelUsed: selectedModelId,
        modeUsed: activeMode,
        createdAt: now + 1,
      };

      let targetConv: Conversation;
      let priorAndNewUserMessages: ChatMessage[];

      if (currentConv) {
        priorAndNewUserMessages = [...currentConv.messages, userMessage];
        targetConv = {
          ...currentConv,
          mode: activeMode,
          model: selectedModelId,
          messages: [...priorAndNewUserMessages, assistantPlaceholder],
          updatedAt: now,
        };
      } else {
        const initialTitle =
          rawText.trim().slice(0, 44) ||
          (attachments.length > 0 ? 'File Analysis' : 'New Conversation');
        priorAndNewUserMessages = [userMessage];
        targetConv = {
          id: crypto.randomUUID(),
          title: initialTitle,
          mode: activeMode,
          model: selectedModelId,
          messages: [userMessage, assistantPlaceholder],
          createdAt: now,
          updatedAt: now,
        };
        if (!isTemporaryChat) {
          setActiveId(targetConv.id);
          saveActiveConversationId(targetConv.id);
        }
      }

      upsertConversationState(targetConv, !isTemporaryChat, isTemporaryChat);

      await runStreamForConversation(
        targetConv,
        priorAndNewUserMessages,
        assistantMsgId,
        selectedModelId,
        activeMode,
        useWebSearch && searchGroundingSupported,
        isTemporaryChat
      );
    },
    [
      activeId,
      isTemporaryChat,
      mode,
      runStreamForConversation,
      searchGroundingSupported,
      selectedModelId,
      streamingChatId,
      upsertConversationState,
      useWebSearch,
    ]
  );

  const handleRegenerate = useCallback(
    async (assistantMsgId: string) => {
      if (
        isSendingRef.current ||
        !activeConversation ||
        !selectedModelId ||
        streamingChatId
      ) {
        return;
      }
      isSendingRef.current = true;

      const idx = activeConversation.messages.findIndex(
        (m) => m.id === assistantMsgId
      );
      if (idx <= 0) {
        isSendingRef.current = false;
        return;
      }

      const existingMsg = activeConversation.messages[idx];
      const existingVersions: ResponseVersion[] =
        existingMsg.versions && existingMsg.versions.length > 0
          ? [...existingMsg.versions]
          : existingMsg.content || existingMsg.error
            ? [toResponseVersion(existingMsg)]
            : [];

      const newDraft: ResponseVersion = {
        content: '',
        modelUsed: selectedModelId,
        modeUsed: mode,
        createdAt: Date.now(),
      };
      const nextVersions = [...existingVersions, newDraft];
      const nextIdx = nextVersions.length - 1;

      const historyUpToUser = activeConversation.messages.slice(0, idx);
      const updatedAssistantMsg: ChatMessage = {
        ...existingMsg,
        content: '',
        sources: undefined,
        searchQueries: undefined,
        error: undefined,
        modelUsed: selectedModelId,
        modeUsed: mode,
        createdAt: Date.now(),
        versions: nextVersions,
        activeVersionIndex: nextIdx,
      };

      const updatedConv: Conversation = {
        ...activeConversation,
        mode,
        model: selectedModelId,
        messages: [
          ...historyUpToUser,
          updatedAssistantMsg,
          ...activeConversation.messages.slice(idx + 1),
        ],
        updatedAt: Date.now(),
      };

      upsertConversationState(updatedConv, !isTemporaryChat, isTemporaryChat);

      await runStreamForConversation(
        updatedConv,
        historyUpToUser,
        assistantMsgId,
        selectedModelId,
        mode,
        useWebSearch && searchGroundingSupported,
        isTemporaryChat
      );
    },
    [
      activeConversation,
      isTemporaryChat,
      mode,
      runStreamForConversation,
      searchGroundingSupported,
      selectedModelId,
      streamingChatId,
      upsertConversationState,
      useWebSearch,
    ]
  );

  const handleSelectResponseVersion = useCallback(
    (assistantMsgId: string, versionIndex: number) => {
      if (!activeConversation || streamingChatId) return;
      const updated: Conversation = {
        ...activeConversation,
        messages: activeConversation.messages.map((m) => {
          if (m.id !== assistantMsgId || !m.versions?.[versionIndex]) return m;
          const v = m.versions[versionIndex];
          return {
            ...m,
            content: v.content,
            sources: v.sources,
            searchQueries: v.searchQueries,
            modelUsed: v.modelUsed,
            modeUsed: v.modeUsed,
            error: v.error,
            activeVersionIndex: versionIndex,
          };
        }),
      };
      upsertConversationState(updated, !isTemporaryChat, isTemporaryChat);
    },
    [
      activeConversation,
      isTemporaryChat,
      streamingChatId,
      upsertConversationState,
    ]
  );

  const handleEditUserMessage = useCallback(
    async (userMsgId: string, newContent: string) => {
      if (
        isSendingRef.current ||
        !activeConversation ||
        !selectedModelId ||
        streamingChatId
      ) {
        return;
      }

      const idx = activeConversation.messages.findIndex(
        (m) => m.id === userMsgId
      );
      if (idx < 0) return;

      isSendingRef.current = true;
      const editedUserMsg: ChatMessage = {
        ...activeConversation.messages[idx],
        content: newContent,
        createdAt: Date.now(),
      };
      const priorAndEdited = [
        ...activeConversation.messages.slice(0, idx),
        editedUserMsg,
      ];

      const assistantMsgId = crypto.randomUUID();
      const assistantPlaceholder: ChatMessage = {
        id: assistantMsgId,
        role: 'assistant',
        content: '',
        modelUsed: selectedModelId,
        modeUsed: mode,
        createdAt: Date.now() + 1,
      };

      const updatedConv: Conversation = {
        ...activeConversation,
        mode,
        model: selectedModelId,
        messages: [...priorAndEdited, assistantPlaceholder],
        updatedAt: Date.now(),
      };

      upsertConversationState(updatedConv, !isTemporaryChat, isTemporaryChat);

      await runStreamForConversation(
        updatedConv,
        priorAndEdited,
        assistantMsgId,
        selectedModelId,
        mode,
        useWebSearch && searchGroundingSupported,
        isTemporaryChat
      );
    },
    [
      activeConversation,
      isTemporaryChat,
      mode,
      runStreamForConversation,
      searchGroundingSupported,
      selectedModelId,
      streamingChatId,
      upsertConversationState,
      useWebSearch,
    ]
  );

  const handleRefineResponse = useCallback(
    (type: 'shorter' | 'detailed' | 'bengali', previousResponse: string) => {
      if (isSendingRef.current || streamingChatId) return;
      const snippet = previousResponse.slice(0, 600);
      const suffix = previousResponse.length > 600 ? '...' : '';

      if (type === 'bengali') {
        setMode('study');
        const prompt = `উপরের বিষয়টি একজন ছাত্রের মতো করে সহজ ও প্রাঞ্জল বাংলায় (সহজ উদাহরণসহ) বুঝিয়ে দাও:\n\n"${snippet}${suffix}"`;
        void handleSendMessage(prompt, [], 'study');
        return;
      }

      if (type === 'shorter') {
        void handleSendMessage(
          `Summarize and condense your previous response into key bullet points that are quick to scan:\n\n"${snippet}${suffix}"`,
          []
        );
        return;
      }

      void handleSendMessage(
        `Expand on your previous response with deeper examples, edge cases, and practical details:\n\n"${snippet}${suffix}"`,
        []
      );
    },
    [handleSendMessage, streamingChatId]
  );

  const handleRenameConversation = useCallback(
    (id: string, title: string) => {
      const target = conversationsRef.current.find((c) => c.id === id);
      if (!target) return;
      const updated = { ...target, title, updatedAt: Date.now() };
      upsertConversationState(updated, true, false);
    },
    [upsertConversationState]
  );

  const handleTogglePinConversation = useCallback(
    (id: string) => {
      const target = conversationsRef.current.find((c) => c.id === id);
      if (!target) return;
      const updated = { ...target, pinned: !target.pinned };
      upsertConversationState(updated, true, false);
    },
    [upsertConversationState]
  );

  const handleExportActiveChat = useCallback(() => {
    if (!activeConversation || activeConversation.messages.length === 0) return;
    const lines: string[] = [
      `# ${activeConversation.title}`,
      `Mode: ${activeConversation.mode} | Model: ${activeConversation.model}`,
      '',
    ];
    for (const m of activeConversation.messages) {
      lines.push(m.role === 'user' ? '## You' : '## NOVA AI');
      if (m.attachments?.length) {
        lines.push(
          `Attachments: ${m.attachments.map((a) => a.name).join(', ')}`
        );
      }
      lines.push(m.content);
      if (m.sources?.length) {
        lines.push('');
        lines.push('Sources:');
        for (const s of m.sources) {
          lines.push(`- [${s.title}](${s.uri})`);
        }
      }
      lines.push('');
    }
    const blob = new Blob([lines.join('\n')], {
      type: 'text/markdown;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = activeConversation.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 40);
    a.href = url;
    a.download = `${safeName || 'nova-chat'}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [activeConversation]);

  const handleDeleteConversation = useCallback(
    (id: string) => {
      if (streamingChatId === id) stopGenerating();
      setConversations((prev) => prev.filter((c) => c.id !== id));
      void deleteConversationFromStore(id);
      if (auth.currentUser?.emailVerified) {
        void deleteCloudConversation(auth.currentUser.uid, id).catch((err) => {
          console.warn('Firestore delete warning:', err);
        });
      }
      if (activeId === id) {
        setActiveId(null);
        saveActiveConversationId(null);
      }
    },
    [activeId, stopGenerating, streamingChatId]
  );

  const handleClearAllConversations = useCallback(async () => {
    if (streamingChatId) stopGenerating();
    setConversations([]);
    setActiveId(null);
    saveActiveConversationId(null);
    await clearAllConversationsFromStore();
    if (auth.currentUser?.emailVerified) {
      await clearAllCloudConversations(auth.currentUser.uid).catch((err) => {
        console.warn('Firestore clear warning:', err);
      });
    }
  }, [stopGenerating, streamingChatId]);

  const handleSignOut = useCallback(async () => {
    stopGenerating();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setSpeakingMsgId(null);
    setSettingsOpen(false);
    setGlobalError(null);
    setConversations([]);
    setTempConversation(null);
    setActiveId(null);
    saveActiveConversationId(null);
    await signOutAccount();
  }, [stopGenerating]);

  const handleCopyMessage = useCallback(async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
    } catch {
      // Ignore clipboard failure
    }
  }, []);

  const handleGenerateVisualFromStudio = useCallback(
    async (opts: {
      prompt: string;
      style: string;
      aspectRatio: string;
      mood: string;
      attachments: ChatAttachment[];
    }) => {
      pendingVisualMetaRef.current = {
        prompt: opts.prompt,
        style: opts.style,
        aspectRatio: opts.aspectRatio,
        mood: opts.mood,
      };
      setIsTemporaryChat(false);
      setTempConversation(null);
      setActiveId(null);
      saveActiveConversationId(null);
      setMode('general');
      setActiveSection('chat');

      const aspectViewBox =
        opts.aspectRatio === '16:9'
          ? '0 0 800 450'
          : opts.aspectRatio === '4:3'
            ? '0 0 800 600'
            : opts.aspectRatio === '3:4'
              ? '0 0 600 800'
              : '0 0 600 600';

      const composedPrompt = [
        `Create a rich, detailed, polished visual artwork for: "${opts.prompt}".`,
        `Style: ${opts.style}. Mood: ${opts.mood}. Aspect ratio: ${opts.aspectRatio}.`,
        `Output a complete, self-contained \`\`\`svg code block using viewBox="${aspectViewBox}" with rich gradients, clean layered shapes, depth, and balanced composition (no external image URLs or scripts).`,
      ].join(' ');

      await handleSendMessage(composedPrompt, opts.attachments, 'general', {
        forceNew: true,
      });
    },
    [handleSendMessage]
  );

  const handleSendGeneratedToChat = useCallback(
    (image: GeneratedChatImage, caption?: string) => {
      const now = Date.now();
      const currentConv = isTemporaryChat
        ? tempConversationRef.current
        : conversationsRef.current.find((c) => c.id === activeId) ?? null;

      const userMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content: image.prompt || 'Generate image',
        createdAt: now,
      };
      const assistantMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: caption || `Generated with ${image.model || 'Nano Banana'}:`,
        generatedImages: [image],
        modelUsed: image.model || 'gemini-3.1-flash-lite-image',
        modeUsed: 'general',
        createdAt: now + 1,
      };

      const targetConv: Conversation = currentConv
        ? {
            ...currentConv,
            messages: [...currentConv.messages, userMsg, assistantMsg],
            updatedAt: now,
          }
        : {
            id: crypto.randomUUID(),
            title: (image.prompt || 'Generated Image').slice(0, 44),
            mode: 'general',
            model: selectedModelId || 'gemini-3.1-flash-lite',
            messages: [userMsg, assistantMsg],
            createdAt: now,
            updatedAt: now,
          };

      if (!currentConv && !isTemporaryChat) {
        setActiveId(targetConv.id);
        saveActiveConversationId(targetConv.id);
      }
      upsertConversationState(targetConv, !isTemporaryChat, isTemporaryChat);
      setActiveSection('chat');
    },
    [activeId, isTemporaryChat, selectedModelId, upsertConversationState]
  );

  const handleRegenerateGeneratedImage = useCallback(
    async (messageId: string, prompt: string, model?: string) => {
      if (!activeConversation) return;
      const targetModel =
        model === 'gemini-nano-banana-2.1'
          ? 'gemini-nano-banana-2.1'
          : 'gemini-3.1-flash-lite-image';

      const result = await runNanoBananaImage({
        prompt,
        model: targetModel,
        confirmPaidRequest: true,
      });

      if (result.error) {
        setGlobalError(result.error);
        return;
      }

      if (result.imageBase64) {
        const nextImg: GeneratedChatImage = {
          id: crypto.randomUUID(),
          mimeType: result.mimeType || 'image/png',
          data: result.imageBase64,
          prompt,
          model: result.modelUsed || targetModel,
        };
        const updated: Conversation = {
          ...activeConversation,
          updatedAt: Date.now(),
          messages: activeConversation.messages.map((m) =>
            m.id === messageId
              ? {
                  ...m,
                  generatedImages: [nextImg],
                  content:
                    result.text ||
                    `Regenerated with ${nextImg.model || 'Nano Banana'}:`,
                }
              : m
          ),
        };
        upsertConversationState(updated, !isTemporaryChat, isTemporaryChat);
      }
    },
    [activeConversation, isTemporaryChat, upsertConversationState]
  );

  const executeConfirmedInChatImage = useCallback(async () => {
    if (!pendingImageRequest || generatingInChatImage || streamingChatId) return;
    const req = pendingImageRequest;
    setPendingImageRequest(null);
    setGeneratingInChatImage(true);
    setGlobalError(null);

    const now = Date.now();
    const currentConv = isTemporaryChat
      ? tempConversationRef.current
      : conversationsRef.current.find((c) => c.id === activeId) ?? null;

    // Look up latest reference image (user attachment OR most recent generated image in conversation)
    const attachedImg = req.attachments.find(
      (a) => a.kind === 'image' || a.mimeType.startsWith('image/')
    );
    let lastGeneratedImg: GeneratedChatImage | undefined;
    if (!attachedImg && currentConv) {
      for (let i = currentConv.messages.length - 1; i >= 0; i--) {
        const imgs = currentConv.messages[i].generatedImages;
        if (imgs && imgs.length > 0) {
          lastGeneratedImg = imgs[imgs.length - 1];
          break;
        }
      }
    }

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: req.prompt || 'Generate image',
      attachments: req.attachments.length > 0 ? req.attachments : undefined,
      createdAt: now,
    };
    const assistantMsgId = crypto.randomUUID();
    const assistantPlaceholder: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '',
      modelUsed: req.model,
      modeUsed: 'general',
      createdAt: now + 1,
    };

    const targetConv: Conversation = currentConv
      ? {
          ...currentConv,
          messages: [...currentConv.messages, userMsg, assistantPlaceholder],
          updatedAt: now,
        }
      : {
          id: crypto.randomUUID(),
          title: (req.prompt || 'Image Generation').slice(0, 44),
          mode: 'general',
          model: selectedModelId || 'gemini-3.1-flash-lite',
          messages: [userMsg, assistantPlaceholder],
          createdAt: now,
          updatedAt: now,
        };

    if (!currentConv && !isTemporaryChat) {
      setActiveId(targetConv.id);
      saveActiveConversationId(targetConv.id);
    }

    upsertConversationState(targetConv, !isTemporaryChat, isTemporaryChat);
    setStreamingChatId(targetConv.id);
    setStreamingMsgId(assistantMsgId);

    try {
      const refImage = attachedImg
        ? { data: attachedImg.data, mimeType: attachedImg.mimeType }
        : lastGeneratedImg
          ? { data: lastGeneratedImg.data, mimeType: lastGeneratedImg.mimeType }
          : undefined;

      const result = await runNanoBananaImage({
        prompt: req.prompt || 'Create an artistic illustration',
        model: req.model,
        imageBase64: refImage?.data,
        mimeType: refImage?.mimeType,
        confirmPaidRequest: true,
      });

      const finalMsg: ChatMessage = result.error
        ? {
            ...assistantPlaceholder,
            content: '',
            error: result.error,
          }
        : result.imageBase64
          ? {
              ...assistantPlaceholder,
              content:
                result.text ||
                `Generated with ${result.modelUsed || req.model}:`,
              generatedImages: [
                {
                  id: crypto.randomUUID(),
                  mimeType: result.mimeType || 'image/png',
                  data: result.imageBase64,
                  prompt: req.prompt,
                  model: result.modelUsed || req.model,
                },
              ],
            }
          : {
              ...assistantPlaceholder,
              error: {
                code: 'EMPTY_IMAGE_RESPONSE',
                title: 'No Image Returned',
                message: 'Nano Banana completed without returning an image.',
                hint: 'Try rephrasing your visual prompt or switch to Free Gemini Web.',
              },
            };

      const latestList = isTemporaryChat
        ? tempConversationRef.current
        : conversationsRef.current.find((c) => c.id === targetConv.id);
      const baseConv = latestList || targetConv;
      const finalizedConv: Conversation = {
        ...baseConv,
        updatedAt: Date.now(),
        messages: baseConv.messages.map((m) =>
          m.id === assistantMsgId ? finalMsg : m
        ),
      };
      upsertConversationState(finalizedConv, !isTemporaryChat, isTemporaryChat);
    } finally {
      setGeneratingInChatImage(false);
      setStreamingChatId(null);
      setStreamingMsgId(null);
    }
  }, [
    activeId,
    generatingInChatImage,
    isTemporaryChat,
    pendingImageRequest,
    selectedModelId,
    streamingChatId,
    upsertConversationState,
  ]);

  if (!authReady) {
    return (
      <div className="min-h-[100dvh] flex flex-col items-center justify-center gap-4 bg-slate-50 dark:bg-[#0d0d10] text-slate-900 dark:text-slate-100">
        <NovaLogo size={46} />
        <div className="flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
          <Loader2 className="h-4 w-4 animate-spin text-violet-500" />
          <span>Securing your NOVA AI session...</span>
        </div>
      </div>
    );
  }

  if (!authUser || !authUser.emailVerified) {
    return (
      <AuthGate
        unverifiedUser={authUser}
        onVerificationRefreshed={async () => {
          if (!auth.currentUser) return;
          await auth.currentUser.reload();
          await auth.currentUser.getIdToken(true);
          setAuthTick((t) => t + 1);
          setAuthUser(auth.currentUser);
        }}
      />
    );
  }

  // Blocked or active temporary suspension enforcement (Admin never blocked)
  const activeSuspension =
    userDirectory?.status === 'suspended' &&
    (!userDirectory.suspendedUntil || Date.now() < userDirectory.suspendedUntil);
  if (!isSuperAdmin && (userDirectory?.status === 'blocked' || activeSuspension)) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-[#0d0d10] text-slate-100 p-4">
        <div className="w-full max-w-md rounded-2xl border border-rose-500/30 bg-[#141418] p-6 text-center space-y-4">
          <div className="mx-auto h-12 w-12 rounded-2xl bg-rose-500/15 text-rose-400 flex items-center justify-center">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <h1 className="font-display text-xl font-semibold text-white">
            {userDirectory?.status === 'blocked'
              ? 'Account Blocked'
              : 'Account Temporarily Suspended'}
          </h1>
          <p className="text-sm text-slate-400 leading-relaxed">
            {userDirectory?.status === 'blocked'
              ? 'Your access to this workspace has been disabled by the administrator.'
              : `Your account is temporarily suspended${
                  userDirectory?.suspendedUntil
                    ? ` until ${new Date(userDirectory.suspendedUntil).toLocaleString()}`
                    : ''
                }.`}
          </p>
          <button
            type="button"
            onClick={() => void handleSignOut()}
            className="w-full min-h-[42px] rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-sm font-medium text-white"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  // Maintenance mode gate for non-admin users
  if (publicConfig?.customization.maintenanceMode && !isSuperAdmin) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-[#0d0d10] text-slate-100 p-4">
        <div className="w-full max-w-md rounded-2xl border border-amber-500/30 bg-[#141418] p-6 text-center space-y-4">
          <div className="mx-auto h-12 w-12 rounded-2xl bg-amber-500/15 text-amber-400 flex items-center justify-center">
            <Wrench className="h-6 w-6" />
          </div>
          <h1 className="font-display text-xl font-semibold text-white">
            {customAppName} Maintenance
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            {publicConfig.customization.maintenanceMessage ||
              'Scheduled maintenance is in progress. Please check back shortly.'}
          </p>
          <button
            type="button"
            onClick={() => void handleSignOut()}
            className="w-full min-h-[42px] rounded-xl border border-white/10 hover:bg-white/[0.08] text-xs font-medium text-slate-300"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  if (adminOpen) {
    return (
      <AdminPanel
        onClose={() => {
          setAdminOpen(false);
          if (window.location.hash === '#admin') {
            window.history.replaceState(null, '', window.location.pathname + window.location.search);
          }
        }}
        onConfigUpdated={(cfg) => {
          const prevSpDefault = publicConfig?.superPower?.defaultChatModel;
          const nextSpDefault = cfg.superPower?.defaultChatModel;
          setPublicConfig(cfg);
          if (
            nextSpDefault &&
            nextSpDefault !== prevSpDefault &&
            models.some((m) => m.id === nextSpDefault)
          ) {
            setSelectedModelId(nextSpDefault);
            saveSelectedModelId(nextSpDefault);
          }
          void refreshModelsAndHealth(false);
        }}
      />
    );
  }

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-slate-50 dark:bg-[#141418] text-slate-900 dark:text-slate-100">
      <Sidebar
        conversations={conversations}
        activeConversationId={isTemporaryChat ? null : activeId}
        activeSection={activeSection}
        activeMode={mode}
        onSelectSection={(sec) => {
          setActiveSection(sec);
          if (sec !== 'create') {
            setStudioInitialPrompt(undefined);
          }
        }}
        onSelectMode={(selectedMode) => {
          handleNewChat();
          setMode(selectedMode);
          setActiveSection('chat');
        }}
        onSelectConversation={(id) => {
          handleSelectConversation(id);
          setActiveSection('chat');
        }}
        onNewChat={() => {
          handleNewChat();
          setActiveSection('chat');
        }}
        onRenameConversation={handleRenameConversation}
        onTogglePinConversation={handleTogglePinConversation}
        onDeleteConversation={handleDeleteConversation}
        mobileOpen={mobileMenuOpen}
        desktopOpen={desktopSidebarOpen}
        onToggleDesktopSidebar={() => setDesktopSidebarOpen((v) => !v)}
        onCloseMobile={() => setMobileMenuOpen(false)}
        theme={settings.theme}
        onToggleTheme={toggleTheme}
        onOpenSettings={() => setSettingsOpen(true)}
        searchInputRef={searchInputRef}
        currentUser={{
          displayName: authUser.displayName,
          email: authUser.email,
          photoURL: authUser.photoURL,
        }}
        onSignOut={() => void handleSignOut()}
        appName={customAppName}
        customLogoUrl={customLogoUrl}
        sidebarVisibility={publicConfig?.customization.sidebarItems}
        allowThemeSwitch={tierFeatures?.customBrandingThemes ?? true}
        isSuperAdmin={isSuperAdmin}
        onOpenAdminPanel={() => setAdminOpen(true)}
      />

      <div className="flex min-w-0 flex-1 flex-col h-full">
        {publicConfig?.customization.announcement.enabled &&
          publicConfig.customization.announcement.text.trim() && (
            <div
              className={`px-4 py-2 text-xs font-medium text-center border-b ${
                publicConfig.customization.announcement.severity === 'critical'
                  ? 'bg-rose-500/15 border-rose-500/30 text-rose-200'
                  : publicConfig.customization.announcement.severity === 'warning'
                    ? 'bg-amber-500/15 border-amber-500/30 text-amber-200'
                    : 'bg-cyan-500/15 border-cyan-500/30 text-cyan-200'
              }`}
            >
              {publicConfig.customization.announcement.text}
            </div>
          )}

        <HeaderBar
          theme={settings.theme}
          onToggleTheme={toggleTheme}
          desktopSidebarOpen={desktopSidebarOpen}
          onToggleMobileMenu={() => setMobileMenuOpen(true)}
          onToggleDesktopSidebar={() => setDesktopSidebarOpen((v) => !v)}
          onNewChat={() => {
            handleNewChat();
            setActiveSection('chat');
          }}
          isTemporaryChat={isTemporaryChat}
          onToggleTemporaryChat={() => {
            handleToggleTemporaryChat();
            setActiveSection('chat');
          }}
          canExportChat={Boolean(
            activeSection === 'chat' &&
              activeConversation &&
              activeConversation.messages.length > 0
          )}
          onExportChat={handleExportActiveChat}
          onOpenSettings={() => setSettingsOpen(true)}
          models={visibleModels}
          selectedModelId={selectedModelId}
          onSelectModel={(id) => {
            setSelectedModelId(id);
            saveSelectedModelId(id);
          }}
          modelsLoading={modelsLoading}
          onRefreshModels={() => void refreshModelsAndHealth(false)}
          appName={customAppName}
          customLogoUrl={customLogoUrl}
          allowThemeSwitch={tierFeatures?.customBrandingThemes ?? true}
        />

        {activeSection === 'create' ? (
          <main className="relative flex-1 min-h-0 flex flex-col">
            {globalError && (
              <div className="mx-auto w-full max-w-4xl px-4 sm:px-8 pt-4">
                <ErrorBanner
                  error={globalError}
                  onRetry={() => void refreshModelsAndHealth(true)}
                  onDismiss={() => setGlobalError(null)}
                  onOpenSettings={() => setSettingsOpen(true)}
                />
              </div>
            )}
            <CreateVisualView
              creations={allCreations}
              isGenerating={Boolean(streamingChatId)}
              initialPrompt={studioInitialPrompt}
              onGenerateVisual={handleGenerateVisualFromStudio}
              onOpenLibrary={() => setActiveSection('library')}
            />
          </main>
        ) : activeSection === 'image-assistant' ? (
          <main className="relative flex-1 min-h-0 flex flex-col">
            <ImageAssistantView
              initialEditImage={pendingAiEditImage}
              onClearInitialEditImage={() => setPendingAiEditImage(null)}
              onContinueInChat={(prompt, attachment) => {
                setActiveSection('chat');
                void handleSendMessage(prompt, [attachment], 'general', {
                  forceNew: true,
                });
              }}
              onSendGeneratedToChat={handleSendGeneratedToChat}
              onOpenSvgStudio={() => setActiveSection('create')}
              onOpenSettings={() => setSettingsOpen(true)}
            />
          </main>
        ) : activeSection === 'library' ? (
          <main className="relative flex-1 min-h-0 flex flex-col">
            <LibraryView
              creations={allCreations}
              conversations={conversations}
              onDeleteCreation={(id) => {
                setUserCreations(deleteUserCreation(id));
              }}
              onOpenCreateStudio={(prefill) => {
                setStudioInitialPrompt(prefill);
                setActiveSection('create');
              }}
              onOpenConversation={(cid) => {
                handleSelectConversation(cid);
                setActiveSection('chat');
              }}
            />
          </main>
        ) : (
          <>
            {/* Scrollable Chat Viewport */}
            <main className="relative flex-1 min-h-0 flex flex-col">
              <div
                ref={scrollContainerRef}
                onScroll={handleScroll}
                className="flex-1 overflow-y-auto px-3 sm:px-6 py-4 sm:py-6"
              >
                <div className="mx-auto max-w-3xl space-y-6">
                  {globalError && (
                    <ErrorBanner
                      error={globalError}
                      onRetry={() => void refreshModelsAndHealth(true)}
                      onDismiss={() => setGlobalError(null)}
                      onOpenSettings={() => setSettingsOpen(true)}
                    />
                  )}

                  {!activeConversation ||
                  activeConversation.messages.length === 0 ? (
                    <EmptyState
                      mode={mode}
                      onSelectPrompt={(prompt) =>
                        void handleSendMessage(prompt, [])
                      }
                      welcomeMessage={publicConfig?.customization.welcomeMessage}
                      appDescription={publicConfig?.customization.appDescription}
                      customLogoUrl={customLogoUrl}
                    />
                  ) : (
                    activeConversation.messages.map((msg) => (
                      <MessageBubble
                        key={msg.id}
                        message={msg}
                        isStreaming={streamingMsgId === msg.id}
                        isSpeaking={speakingMsgId === msg.id}
                        canEditOrRegenerate={!streamingChatId}
                        onCopy={handleCopyMessage}
                        onRegenerate={handleRegenerate}
                        onSelectVersion={handleSelectResponseVersion}
                        onEditUserMessage={(msgId, newText) =>
                          void handleEditUserMessage(msgId, newText)
                        }
                        onSpeakToggle={speakText}
                        onRefineResponse={handleRefineResponse}
                        onEditGeneratedImage={(img) => {
                          setPendingAiEditImage(img);
                          setActiveSection('image-assistant');
                        }}
                        onRegenerateGeneratedImage={(msgId, prompt, mdl) =>
                          void handleRegenerateGeneratedImage(msgId, prompt, mdl)
                        }
                        onOpenSettings={() => setSettingsOpen(true)}
                      />
                    ))
                  )}
                </div>
              </div>

              {showScrollDown && (
                <button
                  type="button"
                  onClick={() => {
                    shouldAutoScrollRef.current = true;
                    scrollToBottom('smooth');
                  }}
                  aria-label="Scroll to latest message"
                  className="absolute bottom-4 right-4 sm:right-8 z-20 min-h-[42px] min-w-[42px] flex items-center justify-center rounded-full border border-slate-200 dark:border-white/15 bg-white/95 dark:bg-[#1b1b20]/95 text-slate-700 dark:text-slate-200 shadow-lg hover:scale-105 transition-transform"
                >
                  <ArrowDown className="h-4 w-4" />
                </button>
              )}
            </main>

            <ChatComposer
              mode={mode}
              onChangeMode={setMode}
              useWebSearch={useWebSearch}
              onToggleWebSearch={() => setUseWebSearch((v) => !v)}
              searchGroundingSupported={searchGroundingSupported}
              imageMode={chatImageMode}
              onToggleImageMode={() => setChatImageMode((v) => !v)}
              isTemporaryChat={isTemporaryChat}
              isStreaming={Boolean(streamingChatId) || generatingInChatImage}
              disabled={!selectedModelId && models.length === 0}
              speechLang={settings.speechRecognitionLang}
              onSend={(text, attachments) => {
                if (chatImageMode) {
                  setPendingImageRequest({
                    prompt: text,
                    attachments,
                    model: 'gemini-3.1-flash-lite-image',
                  });
                  return;
                }
                void handleSendMessage(text, attachments);
              }}
              onStop={stopGenerating}
              onVoiceError={(err) => setGlobalError(err)}
            />
          </>
        )}
      </div>

      {pendingImageRequest && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 backdrop-blur-sm p-4"
          onClick={() => setPendingImageRequest(null)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="paid-image-confirm-title"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl border border-amber-500/30 bg-white dark:bg-[#17171c] p-5 sm:p-6 shadow-2xl space-y-4 text-slate-900 dark:text-slate-100"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="h-9 w-9 rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div>
                  <h2
                    id="paid-image-confirm-title"
                    className="font-display text-base font-semibold"
                  >
                    Paid API Billing Confirmation
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Nano Banana in-chat image generation
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPendingImageRequest(null)}
                aria-label="Cancel"
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#111115] p-3 space-y-1.5 text-xs">
              <div className="text-slate-600 dark:text-slate-300">
                <span className="font-semibold">Prompt:</span>{' '}
                {pendingImageRequest.prompt || 'Create an artistic visual'}
              </div>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                Gemini Nano Banana image generation requires an eligible paid Gemini API billing account. NOVA AI never submits paid requests silently.
              </p>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="modal-nanobanana-model"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Select Nano Banana Model
              </label>
              <select
                id="modal-nanobanana-model"
                value={pendingImageRequest.model}
                onChange={(e) =>
                  setPendingImageRequest((prev) =>
                    prev
                      ? {
                          ...prev,
                          model: e.target.value as
                            | 'gemini-3.1-flash-lite-image'
                            | 'gemini-nano-banana-2.1',
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#111115] px-3 text-xs"
              >
                <option value="gemini-3.1-flash-lite-image">
                  Nano Banana 2 (gemini-3.1-flash-lite-image)
                </option>
                <option value="gemini-nano-banana-2.1">
                  Nano Banana Pro (gemini-nano-banana-2.1)
                </option>
              </select>
            </div>

            <div className="flex flex-col gap-2 pt-1">
              <button
                type="button"
                onClick={() => void executeConfirmedInChatImage()}
                className="w-full min-h-[42px] inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-xs font-semibold hover:opacity-95"
              >
                <Sparkles className="h-4 w-4" />
                <span>Confirm Paid Request &amp; Generate</span>
              </button>
              <div className="grid grid-cols-2 gap-2">
                <a
                  href="https://gemini.google.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setPendingImageRequest(null)}
                  className="min-h-[38px] inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                >
                  <span>Free Gemini Web</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
                <button
                  type="button"
                  onClick={() => setPendingImageRequest(null)}
                  className="min-h-[38px] rounded-xl border border-slate-200 dark:border-white/10 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={updateSettings}
        health={health}
        verifyingHealth={verifyingHealth}
        onVerifyConnection={() => void refreshModelsAndHealth(true)}
        models={models}
        selectedModelId={selectedModelId}
        onSelectModel={(id) => {
          setSelectedModelId(id);
          saveSelectedModelId(id);
        }}
        modelsLoading={modelsLoading}
        onRefreshModels={() => void refreshModelsAndHealth(false)}
        conversations={conversations}
        onClearAllConversations={handleClearAllConversations}
        currentUser={{
          displayName: authUser.displayName,
          email: authUser.email,
          emailVerified: authUser.emailVerified,
        }}
        onSignOut={() => void handleSignOut()}
      />
    </div>
  );
}
