export type AssistantMode = 'general' | 'study' | 'coding' | 'writing';

export type StudyLanguage = 'bilingual' | 'bengali' | 'english';

export type ThemeMode = 'dark' | 'light';

export interface ChatAttachment {
  id: string;
  name: string;
  mimeType: string;
  data: string; // base64 for image/pdf, or plain text for text/code files
  size: number;
  kind?: 'image' | 'pdf' | 'text';
}

export type ImageAttachment = ChatAttachment;

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ApiErrorInfo {
  code: string;
  title: string;
  message: string;
  hint?: string;
  status?: number;
}

export interface ResponseVersion {
  content: string;
  sources?: GroundingSource[];
  searchQueries?: string[];
  modelUsed?: string;
  modeUsed?: AssistantMode;
  createdAt: number;
  error?: ApiErrorInfo;
}

export interface GeneratedChatImage {
  id: string;
  mimeType: string;
  data: string; // base64
  prompt?: string;
  model?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  attachments?: ChatAttachment[];
  generatedImages?: GeneratedChatImage[];
  sources?: GroundingSource[];
  searchQueries?: string[];
  modelUsed?: string;
  modeUsed?: AssistantMode;
  createdAt: number;
  error?: ApiErrorInfo;
  versions?: ResponseVersion[];
  activeVersionIndex?: number;
}

export interface Conversation {
  id: string;
  title: string;
  mode: AssistantMode;
  model: string;
  messages: ChatMessage[];
  pinned?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface GeminiModelInfo {
  id: string;
  name: string;
  displayName: string;
  description: string;
  inputTokenLimit?: number;
  outputTokenLimit?: number;
  supportsSearchGrounding: boolean;
  supportsVision: boolean;
  tier?: 'free' | 'paid';
}

export interface HealthStatus {
  ok: boolean;
  configured: boolean;
  verified?: boolean;
  searchGroundingAvailable: boolean;
  timestamp: number;
  error?: ApiErrorInfo;
}

export interface AppSettings {
  theme: ThemeMode;
  defaultMode: AssistantMode;
  studyLanguage: StudyLanguage;
  defaultWebSearch: boolean;
  speechRecognitionLang: 'auto' | 'en-US' | 'bn-BD';
  ttsVoiceURI: string;
  ttsRate: number;
  autoSpeak: boolean;
}

export type ImageAnalysisTask = 'describe' | 'qa' | 'ocr_bilingual' | 'ocr_english';

export interface ImageAnalysisResponse {
  text?: string;
  modelUsed?: string;
  requestedModel?: string;
  fallbackNotice?: string;
  error?: ApiErrorInfo;
}

export interface ImageProviderStatus {
  available: boolean;
  providerName: string;
  supportsGeneration: boolean;
  supportsEditing: boolean;
  reasonCode: 'READY' | 'PAID_KEY_REQUIRED' | 'PROVIDER_NOT_CONFIGURED';
  title: string;
  message: string;
  hint: string;
  nanoBananaModels?: Array<{
    id: 'gemini-3.1-flash-lite-image' | 'gemini-nano-banana-2.1';
    label: string;
    description: string;
    supportsImageSize: boolean;
    paidRequired: boolean;
  }>;
  supportedProviders: Array<{
    id: string;
    label: string;
    envHint: string;
  }>;
}

export interface AiImageResult {
  imageBase64?: string;
  mimeType?: string;
  text?: string;
  providerName?: string;
  modelUsed?: string;
  error?: ApiErrorInfo;
}
