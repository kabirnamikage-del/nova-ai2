export type UserAccountStatus = 'active' | 'blocked' | 'suspended';
export type UserTier = 'free' | 'premium' | 'admin';

export interface FeatureControlMatrix {
  advancedModes: boolean;
  premiumChatModels: boolean;
  imageGeneration: boolean;
  imageEditing: boolean;
  advancedFileUploads: boolean;
  voiceFeatures: boolean;
  customBrandingThemes: boolean;
  dailyRequestLimit: number;
  maxUploadMb: number;
}

export interface AnnouncementBanner {
  enabled: boolean;
  text: string;
  severity: 'info' | 'warning' | 'critical';
}

export interface SidebarVisibilityConfig {
  createVisual: boolean;
  imageAssistant: boolean;
  library: boolean;
  studyMode: boolean;
  codingMode: boolean;
  writingMode: boolean;
}

export interface AppCustomizationConfig {
  appName: string;
  appDescription: string;
  welcomeMessage: string;
  logoMode: 'nova' | 'custom';
  customLogoDataUrl: string;
  defaultTheme: 'dark' | 'light';
  primaryColor: string;
  accentColor: string;
  chatBubbleStyle: 'rounded' | 'compact' | 'glass';
  maintenanceMode: boolean;
  maintenanceMessage: string;
  announcement: AnnouncementBanner;
  sidebarItems: SidebarVisibilityConfig;
  android: {
    appName: string;
    launcherColor: string;
    splashBackground: string;
    lastSyncedAt: number | null;
  };
}

export interface AdminConfigDocument {
  version: number;
  updatedAt: number;
  customization: AppCustomizationConfig;
  features: Record<UserTier, FeatureControlMatrix>;
  paidImageBillingConfirmedByAdmin: boolean;
}

export interface PublicSuperPowerSnapshot {
  defaultChatModel: string;
  visionModel: string;
  imageProviderMode: SuperPowerImageProviderMode;
  features: {
    chatEnabled: boolean;
    streamingEnabled: boolean;
    webSearchEnabled: boolean;
    visionEnabled: boolean;
    voiceEnabled: boolean;
    autoTitleEnabled: boolean;
    svgDiagramsEnabled: boolean;
  };
}

export interface PublicAppConfig {
  version: number;
  updatedAt: number;
  customization: AppCustomizationConfig;
  features: Record<UserTier, FeatureControlMatrix>;
  paidImageBillingConfirmedByAdmin: boolean;
  superPower?: PublicSuperPowerSnapshot;
}

export type SuperPowerPersonalityPreset =
  | 'nova-balanced'
  | 'friendly-mentor'
  | 'concise-executive'
  | 'technical-architect'
  | 'creative-storyteller'
  | 'bilingual-tutor';

export type SuperPowerTone = 'neutral' | 'warm' | 'direct' | 'academic' | 'playful';

export type SuperPowerVerbosity = 'concise' | 'balanced' | 'detailed';

export type SuperPowerThinkingLevel = 'auto' | 'low' | 'medium' | 'high';

export type SuperPowerImageProviderMode = 'hybrid' | 'web-only' | 'nano-banana-enabled';

export type SuperPowerLanguagePriority =
  | 'match-user'
  | 'english-first'
  | 'bengali-first'
  | 'bilingual-bn-en';

export interface SuperPowerConfig {
  version: number;
  updatedAt: number;
  updatedBy: string;
  personality: {
    preset: SuperPowerPersonalityPreset;
    tone: SuperPowerTone;
    languagePriority: SuperPowerLanguagePriority;
    empathyBoost: boolean;
    citationsStrictness: boolean;
  };
  systemPrompt: string;
  customInstructions: string;
  models: {
    defaultChatModel: string;
    fallbackChatModel: string;
    visionModel: string;
    titleModel: string;
    autoFallbackEnabled: boolean;
  };
  provider: {
    activeProvider: 'google-gemini';
    searchGroundingProvider: 'google-search' | 'disabled';
    imageProviderMode: SuperPowerImageProviderMode;
    requestTimeoutMs: number;
    retryOnBusy: boolean;
    maxBusyRetries: number;
  };
  features: {
    chatEnabled: boolean;
    streamingEnabled: boolean;
    webSearchEnabled: boolean;
    visionEnabled: boolean;
    voiceEnabled: boolean;
    autoTitleEnabled: boolean;
    svgDiagramsEnabled: boolean;
  };
  responseBehavior: {
    thinkingLevel: SuperPowerThinkingLevel;
    verbosity: SuperPowerVerbosity;
    markdownFormatting: boolean;
    includeFollowUpSuggestions: boolean;
    admitUncertainty: boolean;
  };
}

export interface SuperPowerHistoryEntry {
  id: string;
  version: number;
  savedAt: number;
  actorEmail: string;
  note: string;
  action: 'save' | 'restore';
  restoredFromVersion?: number;
  config: SuperPowerConfig;
}

export interface SuperPowerTestRequest {
  prompt: string;
  mode?: 'general' | 'study' | 'coding' | 'writing';
  studyLanguage?: 'bilingual' | 'english' | 'bengali';
  useWebSearch?: boolean;
  draftConfig?: SuperPowerConfig;
}

export interface SuperPowerTestResponse {
  ok: boolean;
  text: string;
  modelUsed: string;
  fallbackUsed: boolean;
  latencyMs: number;
  appliedThinkingLevel: string;
  systemInstructionPreview: string;
}

export type BuilderInputMode = 'prompt' | 'code' | 'image';

export interface BuilderImageAttachment {
  id: string;
  name: string;
  mimeType: 'image/png' | 'image/jpeg' | 'image/webp';
  dataUrl: string;
  sizeBytes?: number;
}

export interface BuilderProposedFileChange {
  path: string;
  action: 'modify' | 'create';
  rationale: string;
  language: string;
  oldContent: string;
  newContent: string;
  diffLines: DiffLine[];
  stats: { added: number; removed: number };
  originalSha256: string | null;
}

export type BuilderProposalStatus =
  | 'pending'
  | 'applied'
  | 'rejected'
  | 'rolled-back'
  | 'failed';

export interface BuilderProposalRecord {
  id: string;
  createdAt: number;
  actorEmail: string;
  inputModes: BuilderInputMode[];
  prompt: string;
  revisionNote: string;
  codeLanguage?: string;
  targetFile?: string;
  hasCodeSnippet: boolean;
  imageNames: string[];
  modelUsed: string;
  fallbackUsed: boolean;
  inspectedFiles: string[];
  summary: string;
  notes: string[];
  status: BuilderProposalStatus;
  changes: BuilderProposedFileChange[];
  backupId?: string;
  appliedAt?: number;
  rolledBackAt?: number;
  validation?: ValidationResult;
  buildValidation?: ValidationResult;
  errorMessage?: string;
}

export interface BuilderGenerateRequest {
  inputModes: BuilderInputMode[];
  prompt: string;
  revisionNote?: string;
  codeSnippet?: string;
  codeLanguage?: string;
  targetFile?: string;
  images?: Array<{
    name: string;
    mimeType: string;
    base64: string;
  }>;
  preferredModel?: string;
}

export interface DailyTelemetryBucket {
  date: string;
  requests: number;
  errors: number;
  quotaErrors: number;
  chat: number;
  image: number;
}

export interface ModelTelemetryEntry {
  requests: number;
  errors: number;
  quotaErrors: number;
  lastUsedAt: number;
}

export interface TelemetryErrorEvent {
  id: string;
  timestamp: number;
  route: string;
  model?: string;
  code: string;
  status: number;
  message: string;
}

export interface TelemetrySnapshot {
  totalRequests: number;
  totalSuccess: number;
  totalErrors: number;
  quotaErrors429: number;
  chatRequests: number;
  imageAnalysisRequests: number;
  imageGenRequests: number;
  voiceRequests: number;
  byDay: DailyTelemetryBucket[];
  byModel: Record<string, ModelTelemetryEntry>;
  recentErrors: TelemetryErrorEvent[];
}

export interface UserDirectoryRecord {
  uid: string;
  email: string;
  displayName: string;
  status: UserAccountStatus;
  tier: UserTier;
  suspendedUntil: number | null;
  provider?: string;
  conversationCount?: number;
  createdAt: number;
  lastActiveAt: number;
}

export interface FirestoreAuditLogRecord {
  id: string;
  actorUid: string;
  actorEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  createdAt: number;
}

export interface BackendAuditLogEntry {
  id: string;
  timestamp: number;
  actorEmail: string;
  action: string;
  target: string;
  details: string;
}

export interface WorkspaceFileNode {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  protected?: boolean;
  children?: WorkspaceFileNode[];
}

export interface DiffLine {
  type: 'context' | 'add' | 'remove';
  oldLine?: number;
  newLine?: number;
  text: string;
}

export interface BackupSnapshotMeta {
  id: string;
  createdAt: number;
  reason: string;
  files: Array<{ path: string; existed: boolean; size: number }>;
}

export interface ValidationResult {
  ok: boolean;
  command: string;
  output: string;
  durationMs: number;
}

export interface GitStatusReport {
  gitAvailable: boolean;
  isGitRepo: boolean;
  branch: string;
  clean: boolean;
  changedFiles: Array<{ status: string; path: string }>;
  recentCommits: Array<{ hash: string; date: string; message: string; author: string }>;
  githubConfigured: boolean;
  githubRepo: string;
  githubBranch: string;
  notes: string[];
}