import { useMemo, useState, type RefObject } from 'react';
import {
  Check,
  Code2,
  Feather,
  GraduationCap,
  ImagePlus,
  Images,
  LayoutGrid,
  LogOut,
  MessageSquare,
  Moon,
  PanelLeft,
  Pencil,
  Pin,
  PinOff,
  ScanEye,
  Search,
  Settings,
  ShieldCheck,
  SquarePen,
  Sun,
  Trash2,
  User,
  X,
} from 'lucide-react';
import type { AssistantMode, Conversation, ThemeMode } from '../types/chat.ts';
import type { SidebarVisibilityConfig } from '../types/admin.ts';
import { NovaLogo } from './NovaLogo.tsx';

export type AppSection = 'chat' | 'create' | 'library' | 'image-assistant';

interface SidebarProps {
  conversations: Conversation[];
  activeConversationId: string | null;
  activeSection: AppSection;
  activeMode: AssistantMode;
  onSelectSection: (section: AppSection) => void;
  onSelectMode: (mode: AssistantMode) => void;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onRenameConversation: (id: string, title: string) => void;
  onTogglePinConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  mobileOpen: boolean;
  desktopOpen: boolean;
  onToggleDesktopSidebar: () => void;
  onCloseMobile: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onOpenSettings: () => void;
  searchInputRef?: RefObject<HTMLInputElement | null>;
  currentUser?: {
    displayName: string | null;
    email: string | null;
    photoURL: string | null;
  } | null;
  onSignOut?: () => void;
  appName?: string;
  customLogoUrl?: string;
  sidebarVisibility?: SidebarVisibilityConfig;
  allowThemeSwitch?: boolean;
  isSuperAdmin?: boolean;
  onOpenAdminPanel?: () => void;
}

function getDateBucket(timestamp: number): string {
  const now = new Date();
  const startOfToday = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate()
  ).getTime();
  const startOfYesterday = startOfToday - 86_400_000;
  const sevenDaysAgo = startOfToday - 7 * 86_400_000;

  if (timestamp >= startOfToday) return 'Today';
  if (timestamp >= startOfYesterday) return 'Yesterday';
  if (timestamp >= sevenDaysAgo) return 'Previous 7 Days';
  return 'Earlier';
}

export function Sidebar({
  conversations,
  activeConversationId,
  activeSection,
  activeMode,
  onSelectSection,
  onSelectMode,
  onSelectConversation,
  onNewChat,
  onRenameConversation,
  onTogglePinConversation,
  onDeleteConversation,
  mobileOpen,
  desktopOpen,
  onToggleDesktopSidebar,
  onCloseMobile,
  theme,
  onToggleTheme,
  onOpenSettings,
  searchInputRef,
  currentUser,
  onSignOut,
  appName = 'NOVA AI',
  customLogoUrl,
  sidebarVisibility,
  allowThemeSwitch = true,
  isSuperAdmin = false,
  onOpenAdminPanel,
}: SidebarProps) {
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftTitle, setDraftTitle] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  }, [conversations, query]);

  const grouped = useMemo(() => {
    const order = ['Pinned', 'Today', 'Yesterday', 'Previous 7 Days', 'Earlier'];
    const map = new Map<string, Conversation[]>();
    for (const label of order) map.set(label, []);
    for (const c of filtered) {
      const bucket = c.pinned ? 'Pinned' : getDateBucket(c.updatedAt);
      map.get(bucket)?.push(c);
    }
    return order
      .map((label) => ({ label, items: map.get(label) ?? [] }))
      .filter((g) => g.items.length > 0);
  }, [filtered]);

  const startRename = (conv: Conversation) => {
    setEditingId(conv.id);
    setDraftTitle(conv.title);
    setConfirmDeleteId(null);
  };

  const commitRename = (id: string) => {
    const trimmed = draftTitle.trim();
    if (trimmed) {
      onRenameConversation(id, trimmed);
    }
    setEditingId(null);
  };

  const handleOpenSearch = () => {
    setSearchOpen(true);
    window.setTimeout(() => searchInputRef?.current?.focus(), 40);
  };

  const modeLinks: Array<{
    id: AssistantMode;
    label: string;
    icon: typeof LayoutGrid;
  }> = [
    { id: 'general', label: 'Assistant', icon: LayoutGrid },
    { id: 'study', label: 'Study · বাংলা', icon: GraduationCap },
    { id: 'coding', label: 'Coding', icon: Code2 },
    { id: 'writing', label: 'Writing', icon: Feather },
  ];

  const sidebarContent = (
    <div className="flex h-full flex-col bg-slate-100/95 dark:bg-[#0d0d0f] border-r border-slate-200 dark:border-white/[0.07] text-slate-900 dark:text-slate-100">
      {/* Top Brand + Collapse Button (matching reference screenshot) */}
      <div className="flex items-center justify-between px-3.5 pt-3 pb-2">
        <button
          type="button"
          onClick={() => {
            onNewChat();
            onCloseMobile();
          }}
          className="flex items-center gap-2.5 rounded-xl px-1.5 py-1.5 hover:bg-slate-200/70 dark:hover:bg-white/[0.06] transition-colors min-w-0"
        >
          <NovaLogo size={26} customLogoUrl={customLogoUrl} />
          <span className="font-display text-sm font-bold tracking-tight text-slate-900 dark:text-white truncate">
            {appName}
          </span>
        </button>

        <button
          type="button"
          onClick={onToggleDesktopSidebar}
          aria-label="Collapse sidebar"
          title="Close sidebar"
          className="hidden lg:flex min-h-[36px] min-w-[36px] items-center justify-center rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-white/[0.06] transition-colors"
        >
          <PanelLeft className="h-[18px] w-[18px]" />
        </button>

        <button
          type="button"
          onClick={onCloseMobile}
          aria-label="Close sidebar"
          className="lg:hidden min-h-[44px] min-w-[44px] -mr-1.5 flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-400 hover:bg-slate-200/70 dark:hover:bg-white/[0.06]"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Primary ChatGPT-Style Navigation */}
      <nav aria-label="Primary navigation" className="px-2.5 space-y-0.5">
        <button
          type="button"
          onClick={() => {
            onNewChat();
            onCloseMobile();
          }}
          className="w-full min-h-[40px] flex items-center gap-3 rounded-xl px-3 text-sm font-medium text-slate-800 dark:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f] transition-colors"
        >
          <SquarePen className="h-[17px] w-[17px] text-slate-600 dark:text-slate-300 shrink-0" />
          <span>New chat</span>
        </button>

        <button
          type="button"
          onClick={handleOpenSearch}
          className={`w-full min-h-[40px] flex items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors ${
            searchOpen
              ? 'bg-slate-200/70 dark:bg-[#1a1a1f] text-slate-900 dark:text-white'
              : 'text-slate-800 dark:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f]'
          }`}
        >
          <Search className="h-[17px] w-[17px] text-slate-600 dark:text-slate-300 shrink-0" />
          <span>Search</span>
        </button>

        {searchOpen && (
          <div className="px-1 py-1.5">
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 dark:text-slate-500"
                aria-hidden="true"
              />
              <input
                ref={searchInputRef}
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Escape') {
                    setQuery('');
                    setSearchOpen(false);
                  }
                }}
                placeholder="Search chats..."
                aria-label="Search conversations"
                className="w-full min-h-[36px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#16161b] pl-8 pr-7 text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  aria-label="Clear search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        )}

        {(sidebarVisibility?.library ?? true) && (
          <button
            type="button"
            onClick={() => {
              onSelectSection('library');
              onCloseMobile();
            }}
            className={`w-full min-h-[40px] flex items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors ${
              activeSection === 'library'
                ? 'bg-slate-200/85 dark:bg-[#212126] text-slate-900 dark:text-white'
                : 'text-slate-800 dark:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f]'
            }`}
          >
            <Images className="h-[17px] w-[17px] text-slate-600 dark:text-slate-300 shrink-0" />
            <span>Library</span>
          </button>
        )}
      </nav>

      <div className="mx-3.5 my-2.5 border-b border-slate-200 dark:border-white/[0.08]" />

      {/* Studio & Assistant Mode Navigation */}
      <nav aria-label="Studio and modes" className="px-2.5 space-y-0.5">
        {(sidebarVisibility?.createVisual ?? true) && (
          <button
            type="button"
            onClick={() => {
              onSelectSection('create');
              onCloseMobile();
            }}
            className={`w-full min-h-[40px] flex items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors ${
              activeSection === 'create'
                ? 'bg-slate-200/85 dark:bg-[#212126] text-slate-900 dark:text-white'
                : 'text-slate-800 dark:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f]'
            }`}
          >
            <ImagePlus className="h-[17px] w-[17px] text-violet-600 dark:text-cyan-400 shrink-0" />
            <span>Create a visual</span>
          </button>
        )}

        {(sidebarVisibility?.imageAssistant ?? true) && (
          <button
            type="button"
            onClick={() => {
              onSelectSection('image-assistant');
              onCloseMobile();
            }}
            className={`w-full min-h-[40px] flex items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors ${
              activeSection === 'image-assistant'
                ? 'bg-slate-200/85 dark:bg-[#212126] text-slate-900 dark:text-white'
                : 'text-slate-800 dark:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f]'
            }`}
          >
            <ScanEye className="h-[17px] w-[17px] text-cyan-600 dark:text-cyan-400 shrink-0" />
            <span>Image Assistant</span>
          </button>
        )}

        {modeLinks
          .filter((item) => {
            if (item.id === 'study') return sidebarVisibility?.studyMode ?? true;
            if (item.id === 'coding') return sidebarVisibility?.codingMode ?? true;
            if (item.id === 'writing') return sidebarVisibility?.writingMode ?? true;
            return true;
          })
          .map((item) => {
            const Icon = item.icon;
            const isActive =
              activeSection === 'chat' &&
              activeConversationId === null &&
              activeMode === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectMode(item.id);
                  onSelectSection('chat');
                  onCloseMobile();
                }}
                className={`w-full min-h-[38px] flex items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-slate-200/85 dark:bg-[#212126] text-slate-900 dark:text-white'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f]'
                }`}
              >
                <Icon className="h-[16px] w-[16px] text-slate-500 dark:text-slate-400 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}

        {isSuperAdmin && onOpenAdminPanel && (
          <button
            type="button"
            onClick={() => {
              onOpenAdminPanel();
              onCloseMobile();
            }}
            className="w-full min-h-[38px] flex items-center gap-3 rounded-xl px-3 text-sm font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/25 transition-colors mt-1"
          >
            <ShieldCheck className="h-[16px] w-[16px] shrink-0" />
            <span>Super Admin Panel</span>
          </button>
        )}
      </nav>

      <div className="mx-3.5 my-2.5 border-b border-slate-200 dark:border-white/[0.08]" />

      {/* Scrollable Conversation History */}
      <div className="flex-1 overflow-y-auto px-2.5 pb-4 space-y-4">
        {grouped.length === 0 ? (
          <div className="px-3 py-6 text-center">
            <MessageSquare className="mx-auto h-6 w-6 text-slate-400 dark:text-slate-600 mb-1.5" />
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {query.trim()
                ? 'No matching chats.'
                : 'Your chats will appear here.'}
            </p>
          </div>
        ) : (
          grouped.map((group) => (
            <div key={group.label} className="space-y-0.5">
              <div className="px-2.5 pb-1 text-[11px] font-medium text-slate-500 dark:text-slate-500">
                {group.label}
              </div>
              {group.items.map((conv) => {
                const isActive =
                  activeSection === 'chat' && conv.id === activeConversationId;
                const isEditing = editingId === conv.id;
                const isConfirmingDelete = confirmDeleteId === conv.id;

                return (
                  <div
                    key={conv.id}
                    className={`group relative rounded-xl transition-colors ${
                      isActive
                        ? 'bg-slate-200/85 dark:bg-[#212126] text-slate-900 dark:text-white'
                        : 'hover:bg-slate-200/60 dark:hover:bg-[#18181d] text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {isEditing ? (
                      <div className="flex items-center gap-1 p-1.5">
                        <input
                          type="text"
                          value={draftTitle}
                          onChange={(e) => setDraftTitle(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') commitRename(conv.id);
                            if (e.key === 'Escape') setEditingId(null);
                          }}
                          autoFocus
                          aria-label="Conversation title"
                          className="min-w-0 flex-1 rounded-lg border border-violet-500/50 bg-white dark:bg-[#141418] px-2.5 py-1 text-sm text-slate-900 dark:text-white focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => commitRename(conv.id)}
                          aria-label="Save title"
                          className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg text-cyan-600 dark:text-cyan-400 hover:bg-black/5 dark:hover:bg-white/10"
                        >
                          <Check className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          aria-label="Cancel rename"
                          className="min-h-[32px] min-w-[32px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-black/5 dark:hover:bg-white/10"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 px-2.5 py-2">
                        <button
                          type="button"
                          onClick={() => {
                            onSelectConversation(conv.id);
                            onSelectSection('chat');
                            onCloseMobile();
                          }}
                          className="min-w-0 flex-1 text-left"
                        >
                          <div className="truncate text-[13px] font-medium leading-snug">
                            {conv.title}
                          </div>
                        </button>

                        {isConfirmingDelete ? (
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteConversation(conv.id);
                                setConfirmDeleteId(null);
                              }}
                              aria-label="Confirm delete conversation"
                              className="rounded-lg bg-rose-600 hover:bg-rose-700 text-white px-2 py-1 text-xs font-medium transition-colors"
                            >
                              Delete
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              aria-label="Cancel delete"
                              className="min-h-[28px] min-w-[28px] flex items-center justify-center rounded-lg text-slate-500 hover:bg-black/5 dark:hover:bg-white/10"
                            >
                              <X className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-0.5 shrink-0 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 lg:focus-within:opacity-100 transition-opacity">
                            <button
                              type="button"
                              onClick={() => onTogglePinConversation(conv.id)}
                              aria-label={
                                conv.pinned
                                  ? `Unpin ${conv.title}`
                                  : `Pin ${conv.title}`
                              }
                              title={conv.pinned ? 'Unpin' : 'Pin'}
                              className="min-h-[28px] min-w-[28px] flex items-center justify-center rounded-lg text-slate-500 hover:text-cyan-600 dark:text-slate-400 dark:hover:text-cyan-400 hover:bg-black/5 dark:hover:bg-white/10"
                            >
                              {conv.pinned ? (
                                <PinOff className="h-3.5 w-3.5" />
                              ) : (
                                <Pin className="h-3.5 w-3.5" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => startRename(conv)}
                              aria-label={`Rename ${conv.title}`}
                              title="Rename"
                              className="min-h-[28px] min-w-[28px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10"
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(conv.id)}
                              aria-label={`Delete ${conv.title}`}
                              title="Delete"
                              className="min-h-[28px] min-w-[28px] flex items-center justify-center rounded-lg text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-black/5 dark:hover:bg-white/10"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))
        )}
      </div>

      {/* Bottom Profile, Settings & Sign Out Row */}
      <div className="border-t border-slate-200 dark:border-white/[0.07] px-2.5 py-2.5 flex items-center justify-between gap-1.5 pb-safe">
        <button
          type="button"
          onClick={() => {
            onOpenSettings();
            onCloseMobile();
          }}
          className="flex-1 min-w-0 min-h-[42px] flex items-center gap-2.5 rounded-xl px-2 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f] transition-colors text-left"
        >
          {currentUser?.photoURL ? (
            <img
              src={currentUser.photoURL}
              alt={currentUser.displayName || 'User avatar'}
              referrerPolicy="no-referrer"
              className="h-8 w-8 rounded-full object-cover shrink-0 border border-white/10"
            />
          ) : (
            <span className="h-8 w-8 rounded-full bg-gradient-to-br from-violet-600 to-cyan-500 text-white flex items-center justify-center shrink-0 text-xs font-bold">
              {currentUser?.displayName?.[0]?.toUpperCase() ||
                currentUser?.email?.[0]?.toUpperCase() || <User className="h-4 w-4" />}
            </span>
          )}
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium text-slate-900 dark:text-slate-100">
              {currentUser?.displayName ||
                currentUser?.email?.split('@')[0] ||
                'NOVA Workspace'}
            </div>
            <div className="truncate text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <Settings className="h-3 w-3 shrink-0" />
              <span className="truncate">
                {currentUser?.email || 'Settings'}
              </span>
            </div>
          </div>
        </button>

        {allowThemeSwitch && (
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={
              theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'
            }
            title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
            className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f] transition-colors shrink-0"
          >
            {theme === 'dark' ? (
              <Sun className="h-4 w-4 text-amber-400" />
            ) : (
              <Moon className="h-4 w-4 text-violet-600" />
            )}
          </button>
        )}

        {onSignOut && (
          <button
            type="button"
            onClick={() => {
              onCloseMobile();
              onSignOut();
            }}
            aria-label="Sign out"
            title="Sign out"
            className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 hover:bg-slate-200/70 dark:hover:bg-[#1a1a1f] transition-colors shrink-0"
          >
            <LogOut className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {desktopOpen && (
        <aside
          aria-label="Workspace sidebar"
          className="hidden lg:block w-[264px] shrink-0 h-full"
        >
          {sidebarContent}
        </aside>
      )}

      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside
            aria-label="Workspace sidebar"
            className="relative z-10 w-[84vw] max-w-[310px] h-full shadow-2xl"
          >
            {sidebarContent}
          </aside>
        </div>
      )}
    </>
  );
}
