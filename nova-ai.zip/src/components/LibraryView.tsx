import { useEffect, useMemo, useState } from 'react';
import {
  Download,
  ImagePlus,
  Images,
  MessageSquare,
  Search,
  Sparkles,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  downloadSvgAsPng,
  downloadSvgFile,
  svgToObjectUrl,
  type VisualCreation,
} from '../lib/creations.ts';
import type { Conversation } from '../types/chat.ts';

interface LibraryViewProps {
  creations: VisualCreation[];
  conversations: Conversation[];
  onDeleteCreation: (id: string) => void;
  onOpenCreateStudio: (prefillPrompt?: string) => void;
  onOpenConversation: (conversationId: string) => void;
}

type LibraryFilter = 'all' | 'created' | 'uploaded';

interface UploadedImageItem {
  id: string;
  name: string;
  mimeType: string;
  dataUrl: string;
  createdAt: number;
  conversationId: string;
  conversationTitle: string;
}

function SvgThumb({
  item,
  onClick,
}: {
  item: VisualCreation;
  onClick: () => void;
}) {
  const url = useMemo(() => svgToObjectUrl(item.svgCode), [item.svgCode]);

  useEffect(() => {
    return () => URL.revokeObjectURL(url);
  }, [url]);

  return (
    <button
      type="button"
      onClick={onClick}
      className="group relative aspect-square w-full overflow-hidden rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-100 dark:bg-[#1b1b20] text-left focus:outline-none focus:ring-2 focus:ring-violet-500/60"
    >
      <img
        src={url}
        alt={item.title}
        referrerPolicy="no-referrer"
        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
      />
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-3 pt-8 opacity-95 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
        <div className="truncate text-xs font-semibold text-white">
          {item.title}
        </div>
        <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-300">
          <span>{item.style}</span>
          <span aria-hidden="true">·</span>
          <span>{item.isPreset ? 'Sample' : 'Generated'}</span>
        </div>
      </div>
    </button>
  );
}

export function LibraryView({
  creations,
  conversations,
  onDeleteCreation,
  onOpenCreateStudio,
  onOpenConversation,
}: LibraryViewProps) {
  const [filter, setFilter] = useState<LibraryFilter>('all');
  const [query, setQuery] = useState('');
  const [selectedCreation, setSelectedCreation] =
    useState<VisualCreation | null>(null);
  const [selectedUpload, setSelectedUpload] =
    useState<UploadedImageItem | null>(null);

  const uploadedImages = useMemo<UploadedImageItem[]>(() => {
    const items: UploadedImageItem[] = [];
    for (const conv of conversations) {
      for (const msg of conv.messages) {
        if (!msg.attachments?.length) continue;
        for (const att of msg.attachments) {
          if (att.kind === 'image' || att.mimeType.startsWith('image/')) {
            items.push({
              id: `${msg.id}-${att.id}`,
              name: att.name,
              mimeType: att.mimeType,
              dataUrl: `data:${att.mimeType};base64,${att.data}`,
              createdAt: msg.createdAt,
              conversationId: conv.id,
              conversationTitle: conv.title,
            });
          }
        }
      }
    }
    return items.sort((a, b) => b.createdAt - a.createdAt);
  }, [conversations]);

  const normalizedQuery = query.trim().toLowerCase();

  const filteredCreations = useMemo(() => {
    if (filter === 'uploaded') return [];
    if (!normalizedQuery) return creations;
    return creations.filter(
      (c) =>
        c.title.toLowerCase().includes(normalizedQuery) ||
        c.prompt.toLowerCase().includes(normalizedQuery) ||
        c.style.toLowerCase().includes(normalizedQuery)
    );
  }, [creations, filter, normalizedQuery]);

  const filteredUploads = useMemo(() => {
    if (filter === 'created') return [];
    if (!normalizedQuery) return uploadedImages;
    return uploadedImages.filter(
      (u) =>
        u.name.toLowerCase().includes(normalizedQuery) ||
        u.conversationTitle.toLowerCase().includes(normalizedQuery)
    );
  }, [filter, normalizedQuery, uploadedImages]);

  const selectedCreationUrl = useMemo(
    () => (selectedCreation ? svgToObjectUrl(selectedCreation.svgCode) : null),
    [selectedCreation]
  );

  useEffect(() => {
    return () => {
      if (selectedCreationUrl) URL.revokeObjectURL(selectedCreationUrl);
    };
  }, [selectedCreationUrl]);

  const totalShown = filteredCreations.length + filteredUploads.length;

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 sm:py-8">
      <div className="mx-auto max-w-5xl space-y-6">
        {/* Top Library Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-semibold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
              <Images className="h-6 w-6 text-violet-500 dark:text-cyan-400" />
              <span>Library</span>
            </h1>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              All visuals generated in NOVA AI and images shared in your chats
            </p>
          </div>

          <button
            type="button"
            onClick={() => onOpenCreateStudio()}
            className="min-h-[42px] inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 px-4 text-sm font-semibold text-white shadow-sm transition-all active:scale-[0.98] whitespace-nowrap shrink-0"
          >
            <ImagePlus className="h-4 w-4" />
            <span>Create a visual</span>
          </button>
        </div>

        {/* Filter Tabs + Search */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div
            role="tablist"
            aria-label="Filter library items"
            className="inline-flex items-center gap-1 rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-100/80 dark:bg-[#1b1b20] p-1 self-start"
          >
            {(
              [
                { id: 'all', label: `All (${creations.length + uploadedImages.length})` },
                { id: 'created', label: `Created (${creations.length})` },
                { id: 'uploaded', label: `Uploaded (${uploadedImages.length})` },
              ] as const
            ).map((tab) => {
              const active = filter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setFilter(tab.id)}
                  className={`min-h-[34px] rounded-lg px-3 text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-[#2a2a32] text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="relative w-full sm:w-64">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 dark:text-slate-500"
              aria-hidden="true"
            />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search visuals..."
              aria-label="Search visual library"
              className="w-full min-h-[40px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1b1b20] pl-9 pr-3 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
            />
          </div>
        </div>

        {/* Empty State */}
        {totalShown === 0 ? (
          <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] py-14 px-6 text-center">
            <Sparkles className="mx-auto h-8 w-8 text-slate-400 dark:text-slate-500 mb-3" />
            <h2 className="text-base font-semibold text-slate-900 dark:text-white">
              No visuals match your filter
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              {filter === 'uploaded'
                ? 'Upload an image in any chat and it will automatically appear here.'
                : 'Try clearing your search or create a brand new visual in Studio.'}
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            {filteredCreations.length > 0 && (
              <section className="space-y-3">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Generated &amp; Studio Artwork
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
                  {filteredCreations.map((item) => (
                    <SvgThumb
                      key={item.id}
                      item={item}
                      onClick={() => setSelectedCreation(item)}
                    />
                  ))}
                </div>
              </section>
            )}

            {filteredUploads.length > 0 && (
              <section className="space-y-3">
                <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <Upload className="h-3.5 w-3.5" />
                  <span>Uploaded in Chats</span>
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
                  {filteredUploads.map((upload) => (
                    <button
                      key={upload.id}
                      type="button"
                      onClick={() => setSelectedUpload(upload)}
                      className="group relative aspect-square w-full overflow-hidden rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-100 dark:bg-[#1b1b20] text-left focus:outline-none focus:ring-2 focus:ring-violet-500/60"
                    >
                      <img
                        src={upload.dataUrl}
                        alt={upload.name}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                      />
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-3 pt-8 opacity-95 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                        <div className="truncate text-xs font-semibold text-white">
                          {upload.name}
                        </div>
                        <div className="mt-0.5 truncate text-[11px] text-slate-300">
                          {upload.conversationTitle}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>

      {/* Generated Visual Preview Lightbox */}
      {selectedCreation && selectedCreationUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setSelectedCreation(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl rounded-2xl border border-white/10 bg-[#141418] text-slate-100 overflow-hidden shadow-2xl"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
              <div className="min-w-0">
                <h3 className="text-sm font-semibold truncate">
                  {selectedCreation.title}
                </h3>
                <p className="text-xs text-slate-400 truncate">
                  {selectedCreation.style} · {selectedCreation.aspectRatio} ·{' '}
                  {selectedCreation.mood}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCreation(null)}
                aria-label="Close preview"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4 bg-[#0b0b0e] flex items-center justify-center">
              <img
                src={selectedCreationUrl}
                alt={selectedCreation.title}
                referrerPolicy="no-referrer"
                className="max-h-[55vh] rounded-xl object-contain"
              />
            </div>
            <div className="px-4 pt-3 pb-1 text-xs text-slate-400 line-clamp-2">
              {selectedCreation.prompt}
            </div>
            <div className="p-4 flex flex-wrap items-center justify-between gap-2.5 border-t border-white/10">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const prompt = selectedCreation.prompt;
                    setSelectedCreation(null);
                    onOpenCreateStudio(prompt);
                  }}
                  className="min-h-[38px] rounded-xl border border-white/15 px-3 py-1.5 text-xs font-medium hover:bg-white/10 transition-colors"
                >
                  Open in Studio
                </button>
                {selectedCreation.conversationId && (
                  <button
                    type="button"
                    onClick={() => {
                      const cid = selectedCreation.conversationId!;
                      setSelectedCreation(null);
                      onOpenConversation(cid);
                    }}
                    className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-white/15 px-3 py-1.5 text-xs font-medium hover:bg-white/10 transition-colors"
                  >
                    <MessageSquare className="h-3.5 w-3.5" />
                    <span>View Chat</span>
                  </button>
                )}
                {!selectedCreation.isPreset && (
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteCreation(selectedCreation.id);
                      setSelectedCreation(null);
                    }}
                    className="min-h-[38px] inline-flex items-center gap-1 rounded-xl border border-rose-500/30 text-rose-300 px-3 py-1.5 text-xs font-medium hover:bg-rose-500/15 transition-colors"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Delete</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    downloadSvgFile(
                      selectedCreation.svgCode,
                      `${selectedCreation.id}.svg`
                    )
                  }
                  className="min-h-[38px] rounded-xl border border-white/15 px-3 py-1.5 text-xs font-medium hover:bg-white/10 transition-colors"
                >
                  SVG
                </button>
                <button
                  type="button"
                  onClick={() =>
                    downloadSvgAsPng(
                      selectedCreation.svgCode,
                      `${selectedCreation.id}.png`
                    )
                  }
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:opacity-95"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download PNG</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Uploaded Image Preview Lightbox */}
      {selectedUpload && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setSelectedUpload(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl rounded-2xl border border-white/10 bg-[#141418] text-slate-100 overflow-hidden shadow-2xl"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
              <div className="min-w-0">
                <h3 className="text-sm font-semibold truncate">
                  {selectedUpload.name}
                </h3>
                <p className="text-xs text-slate-400 truncate">
                  From chat: {selectedUpload.conversationTitle}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedUpload(null)}
                aria-label="Close preview"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4 bg-[#0b0b0e] flex items-center justify-center">
              <img
                src={selectedUpload.dataUrl}
                alt={selectedUpload.name}
                referrerPolicy="no-referrer"
                className="max-h-[55vh] rounded-xl object-contain"
              />
            </div>
            <div className="p-4 flex items-center justify-between gap-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const cid = selectedUpload.conversationId;
                  setSelectedUpload(null);
                  onOpenConversation(cid);
                }}
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-white/15 px-3.5 py-1.5 text-xs font-medium hover:bg-white/10 transition-colors"
              >
                <MessageSquare className="h-3.5 w-3.5" />
                <span>Open Conversation</span>
              </button>
              <a
                href={selectedUpload.dataUrl}
                download={selectedUpload.name}
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:opacity-95"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
