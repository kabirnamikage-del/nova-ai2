import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  Crop,
  Download,
  FlipHorizontal2,
  FlipVertical2,
  Lock,
  RotateCcw,
  RotateCw,
  ScanEye,
  Sliders,
  Sparkles,
  Unlock,
  Upload,
} from 'lucide-react';

export interface EditorImageAsset {
  name: string;
  mimeType: string;
  base64: string;
}

interface CanvasPhotoEditorProps {
  initialImage?: EditorImageAsset | null;
  onSendToAnalyze?: (asset: EditorImageAsset) => void;
}

type FilterPresetId =
  | 'none'
  | 'grayscale'
  | 'sepia'
  | 'warm'
  | 'cool'
  | 'vivid'
  | 'high-contrast'
  | 'invert';

interface EditorState {
  rotation: number; // 0, 90, 180, 270
  flipH: boolean;
  flipV: boolean;
  brightness: number; // 100 = normal
  contrast: number; // 100 = normal
  saturation: number; // 100 = normal
  filter: FilterPresetId;
  cropRect: { x: number; y: number; w: number; h: number } | null; // normalized 0..1 on current oriented canvas
}

const DEFAULT_EDITOR_STATE: EditorState = {
  rotation: 0,
  flipH: false,
  flipV: false,
  brightness: 100,
  contrast: 100,
  saturation: 100,
  filter: 'none',
  cropRect: null,
};

const FILTER_PRESETS: Array<{ id: FilterPresetId; label: string }> = [
  { id: 'none', label: 'Original' },
  { id: 'grayscale', label: 'Grayscale' },
  { id: 'sepia', label: 'Sepia' },
  { id: 'warm', label: 'Warm' },
  { id: 'cool', label: 'Cool' },
  { id: 'vivid', label: 'Vivid' },
  { id: 'high-contrast', label: 'High Contrast' },
  { id: 'invert', label: 'Invert' },
];

function buildCanvasFilterString(state: EditorState): string {
  const parts: string[] = [
    `brightness(${state.brightness}%)`,
    `contrast(${state.contrast}%)`,
    `saturate(${state.saturation}%)`,
  ];

  switch (state.filter) {
    case 'grayscale':
      parts.push('grayscale(100%)');
      break;
    case 'sepia':
      parts.push('sepia(85%)');
      break;
    case 'warm':
      parts.push('sepia(30%) saturate(125%) brightness(103%)');
      break;
    case 'cool':
      parts.push('hue-rotate(185deg) saturate(85%) brightness(102%)');
      break;
    case 'vivid':
      parts.push('saturate(150%) contrast(112%)');
      break;
    case 'high-contrast':
      parts.push('contrast(145%) brightness(104%)');
      break;
    case 'invert':
      parts.push('invert(100%)');
      break;
    default:
      break;
  }

  return parts.join(' ');
}

export function CanvasPhotoEditor({
  initialImage,
  onSendToAnalyze,
}: CanvasPhotoEditorProps) {
  const [sourceImage, setSourceImage] = useState<HTMLImageElement | null>(null);
  const [fileName, setFileName] = useState('edited-photo');
  const [editorState, setEditorState] =
    useState<EditorState>(DEFAULT_EDITOR_STATE);

  // Target resize dimensions (of the currently oriented/cropped image)
  const [resizeWidth, setResizeWidth] = useState<number>(0);
  const [resizeHeight, setResizeHeight] = useState<number>(0);
  const [lockAspect, setLockAspect] = useState<boolean>(true);
  const [exportFormat, setExportFormat] = useState<
    'image/png' | 'image/jpeg' | 'image/webp'
  >('image/png');

  // Interactive crop staging (percentages 0..100)
  const [cropMode, setCropMode] = useState(false);
  const [cropLeft, setCropLeft] = useState(10);
  const [cropTop, setCropTop] = useState(10);
  const [cropRight, setCropRight] = useState(90);
  const [cropBottom, setCropBottom] = useState(90);

  const [uploadError, setUploadError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const loadImageFromDataUrl = useCallback((dataUrl: string, name: string) => {
    const img = new Image();
    img.onload = () => {
      setSourceImage(img);
      setFileName(name.replace(/\.[^.]+$/, '') || 'edited-photo');
      setEditorState(DEFAULT_EDITOR_STATE);
      setResizeWidth(img.naturalWidth);
      setResizeHeight(img.naturalHeight);
      setCropMode(false);
      setCropLeft(10);
      setCropTop(10);
      setCropRight(90);
      setCropBottom(90);
      setUploadError(null);
      setStatusMessage(null);
    };
    img.onerror = () => {
      setUploadError('Could not decode image. Please select a valid JPG, PNG, or WEBP file.');
    };
    img.src = dataUrl;
  }, []);

  useEffect(() => {
    if (initialImage?.base64 && initialImage?.mimeType) {
      loadImageFromDataUrl(
        `data:${initialImage.mimeType};base64,${initialImage.base64}`,
        initialImage.name
      );
    }
  }, [initialImage, loadImageFromDataUrl]);

  const handleFileChange = (files: FileList | null) => {
    if (!files?.length) return;
    const file = files[0];
    const lower = file.name.toLowerCase();
    const valid =
      file.type === 'image/jpeg' ||
      file.type === 'image/jpg' ||
      file.type === 'image/png' ||
      file.type === 'image/webp' ||
      /\.(jpg|jpeg|png|webp)$/i.test(lower);
    if (!valid) {
      setUploadError('Unsupported file format. Please upload JPG, JPEG, PNG, or WEBP.');
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      setUploadError('Image exceeds 12 MB limit for browser editing.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      loadImageFromDataUrl(String(reader.result ?? ''), file.name);
    };
    reader.readAsDataURL(file);
  };

  // Compute oriented dimensions before resize
  const getOrientedDimensions = useCallback(
    (img: HTMLImageElement, state: EditorState) => {
      const rotated = state.rotation % 180 !== 0;
      const baseW = rotated ? img.naturalHeight : img.naturalWidth;
      const baseH = rotated ? img.naturalWidth : img.naturalHeight;
      if (!state.cropRect) {
        return { width: baseW, height: baseH };
      }
      return {
        width: Math.max(1, Math.round(baseW * state.cropRect.w)),
        height: Math.max(1, Math.round(baseH * state.cropRect.h)),
      };
    },
    []
  );

  // Render final edited image onto an arbitrary target canvas
  const renderToCanvas = useCallback(
    (
      targetCanvas: HTMLCanvasElement,
      img: HTMLImageElement,
      state: EditorState,
      outWidth?: number,
      outHeight?: number
    ) => {
      const rotated = state.rotation % 180 !== 0;
      const orientedW = rotated ? img.naturalHeight : img.naturalWidth;
      const orientedH = rotated ? img.naturalWidth : img.naturalHeight;

      // Step 1: draw oriented + filtered image to offscreen canvas
      const orientedCanvas = document.createElement('canvas');
      orientedCanvas.width = orientedW;
      orientedCanvas.height = orientedH;
      const oCtx = orientedCanvas.getContext('2d');
      if (!oCtx) return;

      oCtx.save();
      oCtx.filter = buildCanvasFilterString(state);
      oCtx.translate(orientedW / 2, orientedH / 2);
      oCtx.rotate((state.rotation * Math.PI) / 180);
      oCtx.scale(state.flipH ? -1 : 1, state.flipV ? -1 : 1);
      oCtx.drawImage(
        img,
        -img.naturalWidth / 2,
        -img.naturalHeight / 2,
        img.naturalWidth,
        img.naturalHeight
      );
      oCtx.restore();

      // Step 2: apply crop & resize onto targetCanvas
      const sx = state.cropRect ? Math.round(state.cropRect.x * orientedW) : 0;
      const sy = state.cropRect ? Math.round(state.cropRect.y * orientedH) : 0;
      const sw = state.cropRect
        ? Math.max(1, Math.round(state.cropRect.w * orientedW))
        : orientedW;
      const sh = state.cropRect
        ? Math.max(1, Math.round(state.cropRect.h * orientedH))
        : orientedH;

      const finalW = Math.max(1, outWidth || sw);
      const finalH = Math.max(1, outHeight || sh);

      targetCanvas.width = finalW;
      targetCanvas.height = finalH;
      const tCtx = targetCanvas.getContext('2d');
      if (!tCtx) return;
      tCtx.clearRect(0, 0, finalW, finalH);
      tCtx.drawImage(orientedCanvas, sx, sy, sw, sh, 0, 0, finalW, finalH);
    },
    []
  );

  // Sync live preview canvas whenever state changes
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas || !sourceImage) return;
    renderToCanvas(
      canvas,
      sourceImage,
      editorState,
      resizeWidth || undefined,
      resizeHeight || undefined
    );
  }, [editorState, renderToCanvas, resizeHeight, resizeWidth, sourceImage]);

  const handleRotate = (deltaDeg: number) => {
    if (!sourceImage) return;
    setEditorState((prev) => {
      const nextRot = (prev.rotation + deltaDeg + 360) % 360;
      const nextState = { ...prev, rotation: nextRot, cropRect: null };
      const dims = getOrientedDimensions(sourceImage, nextState);
      setResizeWidth(dims.width);
      setResizeHeight(dims.height);
      return nextState;
    });
    setCropMode(false);
  };

  const applyCropSelection = () => {
    if (!sourceImage) return;
    const x1 = Math.min(cropLeft, cropRight - 5) / 100;
    const x2 = Math.max(cropLeft + 5, cropRight) / 100;
    const y1 = Math.min(cropTop, cropBottom - 5) / 100;
    const y2 = Math.max(cropTop + 5, cropBottom) / 100;

    setEditorState((prev) => {
      // Compose relative to any existing cropRect
      const base = prev.cropRect ?? { x: 0, y: 0, w: 1, h: 1 };
      const nextCrop = {
        x: base.x + x1 * base.w,
        y: base.y + y1 * base.h,
        w: (x2 - x1) * base.w,
        h: (y2 - y1) * base.h,
      };
      const nextState = { ...prev, cropRect: nextCrop };
      const dims = getOrientedDimensions(sourceImage, nextState);
      setResizeWidth(dims.width);
      setResizeHeight(dims.height);
      return nextState;
    });

    setCropMode(false);
    setCropLeft(10);
    setCropTop(10);
    setCropRight(90);
    setCropBottom(90);
    setStatusMessage('Crop applied to canvas.');
  };

  const setCropPresetAspect = (ratio: number | null) => {
    if (!ratio) {
      setCropLeft(10);
      setCropTop(10);
      setCropRight(90);
      setCropBottom(90);
      return;
    }
    const w = Math.max(1, resizeWidth || 100);
    const h = Math.max(1, resizeHeight || 100);
    const currentRatio = w / h;
    if (currentRatio > ratio) {
      const targetWFrac = (ratio / currentRatio) * 80;
      const padX = (100 - targetWFrac) / 2;
      setCropLeft(Math.round(padX));
      setCropRight(Math.round(100 - padX));
      setCropTop(10);
      setCropBottom(90);
    } else {
      const targetHFrac = (currentRatio / ratio) * 80;
      const padY = (100 - targetHFrac) / 2;
      setCropLeft(10);
      setCropRight(90);
      setCropTop(Math.round(padY));
      setCropBottom(Math.round(100 - padY));
    }
  };

  const handleWidthChange = (nextW: number) => {
    const safeW = Math.max(1, Math.min(8000, nextW || 1));
    if (lockAspect && resizeWidth > 0 && resizeHeight > 0) {
      const ratio = resizeHeight / resizeWidth;
      setResizeHeight(Math.max(1, Math.round(safeW * ratio)));
    }
    setResizeWidth(safeW);
  };

  const handleHeightChange = (nextH: number) => {
    const safeH = Math.max(1, Math.min(8000, nextH || 1));
    if (lockAspect && resizeWidth > 0 && resizeHeight > 0) {
      const ratio = resizeWidth / resizeHeight;
      setResizeWidth(Math.max(1, Math.round(safeH * ratio)));
    }
    setResizeHeight(safeH);
  };

  const handleResetAll = () => {
    if (!sourceImage) return;
    setEditorState(DEFAULT_EDITOR_STATE);
    setResizeWidth(sourceImage.naturalWidth);
    setResizeHeight(sourceImage.naturalHeight);
    setCropMode(false);
    setStatusMessage('Reset to original image.');
  };

  const handleDownload = () => {
    const canvas = previewCanvasRef.current;
    if (!canvas || !sourceImage) return;
    const ext =
      exportFormat === 'image/jpeg'
        ? 'jpg'
        : exportFormat === 'image/webp'
          ? 'webp'
          : 'png';
    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${fileName}-edited.${ext}`;
        a.click();
        URL.revokeObjectURL(url);
        setStatusMessage(`Downloaded ${fileName}-edited.${ext}`);
      },
      exportFormat,
      0.92
    );
  };

  const handleSendEditedToAnalyze = () => {
    const canvas = previewCanvasRef.current;
    if (!canvas || !sourceImage || !onSendToAnalyze) return;
    const dataUrl = canvas.toDataURL('image/png');
    const comma = dataUrl.indexOf(',');
    onSendToAnalyze({
      name: `${fileName}-edited.png`,
      mimeType: 'image/png',
      base64: comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl,
    });
  };

  return (
    <div className="space-y-5">
      {/* Honest Non-AI Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] px-4 py-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="h-9 w-9 rounded-xl bg-slate-100 dark:bg-white/[0.06] flex items-center justify-center text-cyan-600 dark:text-cyan-400 shrink-0">
            <Sliders className="h-4 w-4" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold text-slate-900 dark:text-white">
              Basic Photo Editor (Non-AI Canvas Tools)
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              100% browser-based HTML5 Canvas editing: crop, rotate, flip, resize, brightness, contrast, saturation &amp; filters.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <input
            ref={fileInputRef}
            type="file"
            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => {
              handleFileChange(e.target.files);
              e.target.value = '';
            }}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.05] hover:bg-slate-100 dark:hover:bg-white/[0.1] px-3.5 text-xs font-medium text-slate-800 dark:text-slate-100 transition-colors whitespace-nowrap"
          >
            <Upload className="h-3.5 w-3.5" />
            <span>{sourceImage ? 'Change Photo' : 'Upload Photo'}</span>
          </button>
        </div>
      </div>

      {uploadError && (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-xs text-rose-700 dark:text-rose-300">
          {uploadError}
        </div>
      )}

      {!sourceImage ? (
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="w-full rounded-3xl border-2 border-dashed border-slate-300 dark:border-white/15 bg-white/70 dark:bg-[#1b1b20]/60 hover:border-violet-500/50 dark:hover:border-cyan-400/50 py-16 px-6 text-center transition-colors"
        >
          <Upload className="mx-auto h-9 w-9 text-slate-400 dark:text-slate-500 mb-3" />
          <div className="text-base font-semibold text-slate-900 dark:text-white">
            Upload a photo to start editing
          </div>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Supports JPG, JPEG, PNG, and WEBP · Processed locally in your browser
          </p>
        </button>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Canvas Preview Area */}
          <div className="lg:col-span-7 space-y-3">
            <div className="relative overflow-hidden rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-200/70 dark:bg-[#0d0d10] p-4 flex items-center justify-center min-h-[300px] sm:min-h-[400px]">
              <div className="relative inline-block max-w-full">
                <canvas
                  ref={previewCanvasRef}
                  aria-label="Edited photo preview canvas"
                  className="max-h-[55vh] max-w-full rounded-lg shadow-lg block object-contain"
                />

                {cropMode && (
                  <div
                    aria-label="Crop boundary preview"
                    style={{
                      left: `${cropLeft}%`,
                      top: `${cropTop}%`,
                      width: `${Math.max(5, cropRight - cropLeft)}%`,
                      height: `${Math.max(5, cropBottom - cropTop)}%`,
                    }}
                    className="absolute border-2 border-cyan-400 bg-cyan-400/10 shadow-[0_0_0_9999px_rgba(0,0,0,0.48)] pointer-events-none"
                  />
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="font-mono tabular-nums">
                Output: {resizeWidth} × {resizeHeight} px
              </span>
              {statusMessage && (
                <span className="text-cyan-600 dark:text-cyan-400 font-medium">
                  {statusMessage}
                </span>
              )}
            </div>
          </div>

          {/* Controls Panel */}
          <div className="lg:col-span-5 space-y-4 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] p-4">
            {/* Transform: Rotate, Flip & Crop */}
            <div className="space-y-2.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Transform &amp; Crop
              </div>
              <div className="grid grid-cols-5 gap-1.5">
                <button
                  type="button"
                  onClick={() => handleRotate(-90)}
                  title="Rotate 90° Left"
                  className="min-h-[40px] flex flex-col items-center justify-center gap-0.5 rounded-xl border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06] text-[11px] font-medium"
                >
                  <RotateCcw className="h-4 w-4" />
                  <span>-90°</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleRotate(90)}
                  title="Rotate 90° Right"
                  className="min-h-[40px] flex flex-col items-center justify-center gap-0.5 rounded-xl border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06] text-[11px] font-medium"
                >
                  <RotateCw className="h-4 w-4" />
                  <span>+90°</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setEditorState((p) => ({ ...p, flipH: !p.flipH }))
                  }
                  title="Flip Horizontal"
                  className={`min-h-[40px] flex flex-col items-center justify-center gap-0.5 rounded-xl border text-[11px] font-medium ${
                    editorState.flipH
                      ? 'border-cyan-500/60 bg-cyan-500/12 text-cyan-700 dark:text-cyan-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                  }`}
                >
                  <FlipHorizontal2 className="h-4 w-4" />
                  <span>Flip X</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setEditorState((p) => ({ ...p, flipV: !p.flipV }))
                  }
                  title="Flip Vertical"
                  className={`min-h-[40px] flex flex-col items-center justify-center gap-0.5 rounded-xl border text-[11px] font-medium ${
                    editorState.flipV
                      ? 'border-cyan-500/60 bg-cyan-500/12 text-cyan-700 dark:text-cyan-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                  }`}
                >
                  <FlipVertical2 className="h-4 w-4" />
                  <span>Flip Y</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCropMode((c) => !c)}
                  title="Crop Frame"
                  className={`min-h-[40px] flex flex-col items-center justify-center gap-0.5 rounded-xl border text-[11px] font-medium ${
                    cropMode
                      ? 'border-violet-500 bg-violet-500/15 text-violet-700 dark:text-violet-300'
                      : 'border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                  }`}
                >
                  <Crop className="h-4 w-4" />
                  <span>Crop</span>
                </button>
              </div>

              {cropMode && (
                <div className="rounded-xl border border-violet-500/30 bg-violet-500/5 p-3 space-y-2.5">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {[
                      { label: 'Free', ratio: null },
                      { label: '1:1', ratio: 1 },
                      { label: '4:3', ratio: 4 / 3 },
                      { label: '16:9', ratio: 16 / 9 },
                      { label: '3:4', ratio: 3 / 4 },
                    ].map((p) => (
                      <button
                        key={p.label}
                        type="button"
                        onClick={() => setCropPresetAspect(p.ratio)}
                        className="rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-[#141418] px-2.5 py-1 text-[11px] font-medium hover:border-cyan-500/50"
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <label className="space-y-1">
                      <span>Left ({cropLeft}%)</span>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0, cropRight - 10)}
                        value={cropLeft}
                        onChange={(e) => setCropLeft(Number(e.target.value))}
                        className="w-full accent-cyan-500"
                      />
                    </label>
                    <label className="space-y-1">
                      <span>Right ({cropRight}%)</span>
                      <input
                        type="range"
                        min={Math.min(100, cropLeft + 10)}
                        max={100}
                        value={cropRight}
                        onChange={(e) => setCropRight(Number(e.target.value))}
                        className="w-full accent-cyan-500"
                      />
                    </label>
                    <label className="space-y-1">
                      <span>Top ({cropTop}%)</span>
                      <input
                        type="range"
                        min={0}
                        max={Math.max(0, cropBottom - 10)}
                        value={cropTop}
                        onChange={(e) => setCropTop(Number(e.target.value))}
                        className="w-full accent-cyan-500"
                      />
                    </label>
                    <label className="space-y-1">
                      <span>Bottom ({cropBottom}%)</span>
                      <input
                        type="range"
                        min={Math.min(100, cropTop + 10)}
                        max={100}
                        value={cropBottom}
                        onChange={(e) => setCropBottom(Number(e.target.value))}
                        className="w-full accent-cyan-500"
                      />
                    </label>
                  </div>

                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setCropMode(false)}
                      className="rounded-lg px-2.5 py-1 text-xs text-slate-600 dark:text-slate-300 hover:bg-black/5 dark:hover:bg-white/10"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={applyCropSelection}
                      className="inline-flex items-center gap-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1 text-xs font-semibold"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Apply Crop</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Resize */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Resize (px)
                </span>
                <button
                  type="button"
                  onClick={() => setLockAspect((v) => !v)}
                  className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 dark:text-slate-300 hover:text-cyan-500"
                >
                  {lockAspect ? (
                    <>
                      <Lock className="h-3 w-3 text-cyan-500" />
                      <span>Aspect Locked</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="h-3 w-3" />
                      <span>Unlocked</span>
                    </>
                  )}
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label className="space-y-1">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Width
                  </span>
                  <input
                    type="number"
                    min={1}
                    max={8000}
                    value={resizeWidth}
                    onChange={(e) => handleWidthChange(Number(e.target.value))}
                    className="w-full min-h-[36px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-2.5 text-xs font-mono"
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    Height
                  </span>
                  <input
                    type="number"
                    min={1}
                    max={8000}
                    value={resizeHeight}
                    onChange={(e) => handleHeightChange(Number(e.target.value))}
                    className="w-full min-h-[36px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-2.5 text-xs font-mono"
                  />
                </label>
              </div>
            </div>

            {/* Adjustments */}
            <div className="space-y-2.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Color &amp; Tone
              </div>
              {[
                {
                  label: 'Brightness',
                  val: editorState.brightness,
                  min: 40,
                  max: 180,
                  onChange: (v: number) =>
                    setEditorState((p) => ({ ...p, brightness: v })),
                },
                {
                  label: 'Contrast',
                  val: editorState.contrast,
                  min: 40,
                  max: 180,
                  onChange: (v: number) =>
                    setEditorState((p) => ({ ...p, contrast: v })),
                },
                {
                  label: 'Saturation',
                  val: editorState.saturation,
                  min: 0,
                  max: 200,
                  onChange: (v: number) =>
                    setEditorState((p) => ({ ...p, saturation: v })),
                },
              ].map((slider) => (
                <div key={slider.label} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-700 dark:text-slate-200">
                      {slider.label}
                    </span>
                    <span className="font-mono tabular-nums text-[11px] text-cyan-600 dark:text-cyan-400">
                      {slider.val}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={slider.min}
                    max={slider.max}
                    value={slider.val}
                    onChange={(e) => slider.onChange(Number(e.target.value))}
                    aria-label={slider.label}
                    className="w-full accent-violet-600"
                  />
                </div>
              ))}
            </div>

            {/* Preset Filters */}
            <div className="space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Filters</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {FILTER_PRESETS.map((preset) => {
                  const active = editorState.filter === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() =>
                        setEditorState((p) => ({ ...p, filter: preset.id }))
                      }
                      className={`rounded-xl border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                        active
                          ? 'border-violet-500 bg-violet-500/15 text-violet-700 dark:text-cyan-300'
                          : 'border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06] text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {preset.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Actions: Reset, Format & Download */}
            <div className="pt-2 border-t border-slate-200 dark:border-white/[0.08] space-y-2.5">
              <div className="flex items-center gap-2">
                <select
                  aria-label="Export format"
                  value={exportFormat}
                  onChange={(e) =>
                    setExportFormat(
                      e.target.value as 'image/png' | 'image/jpeg' | 'image/webp'
                    )
                  }
                  className="min-h-[40px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-2.5 text-xs font-medium"
                >
                  <option value="image/png">PNG</option>
                  <option value="image/jpeg">JPEG</option>
                  <option value="image/webp">WEBP</option>
                </select>

                <button
                  type="button"
                  onClick={handleResetAll}
                  className="min-h-[40px] rounded-xl border border-slate-200 dark:border-white/10 px-3 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                >
                  Reset
                </button>

                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 px-3 text-xs font-semibold text-white shadow-sm"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download</span>
                </button>
              </div>

              {onSendToAnalyze && (
                <button
                  type="button"
                  onClick={handleSendEditedToAnalyze}
                  className="w-full min-h-[38px] inline-flex items-center justify-center gap-1.5 rounded-xl border border-cyan-500/40 bg-cyan-500/10 hover:bg-cyan-500/15 text-xs font-medium text-cyan-700 dark:text-cyan-300 transition-colors"
                >
                  <ScanEye className="h-3.5 w-3.5" />
                  <span>Analyze Edited Image with Gemini Vision</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
