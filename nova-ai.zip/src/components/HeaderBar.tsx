import { useEffect, useRef, useState } from 'react';
import {
  Check,
  ChevronDown,
  Download,
  Menu,
  MessageCircleDashed,
  Moon,
  PanelLeft,
  RefreshCw,
  Settings,
  SquarePen,
  Sun,
} from 'lucide-react';
import type { GeminiModelInfo, ThemeMode } from '../types/chat.ts';
import { NovaLogo } from './NovaLogo.tsx';

interface HeaderBarProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  desktopSidebarOpen: boolean;
  onToggleMobileMenu: () => void;
  onToggleDesktopSidebar: () => void;
  onNewChat: () => void;
  isTemporaryChat: boolean;
  onToggleTemporaryChat: () => void;
  canExportChat: boolean;
  onExportChat: () => void;
  onOpenSettings: () => void;
  models: GeminiModelInfo[];
  selectedModelId: string;
  onSelectModel: (modelId: string) => void;
  modelsLoading: boolean;
  onRefreshModels: () => void;
  appName?: string;
  customLogoUrl?: string;
  allowThemeSwitch?: boolean;
}

export function HeaderBar({
  theme,
  onToggleTheme,
  desktopSidebarOpen,
  onToggleMobileMenu,
  onToggleDesktopSidebar,
  onNewChat,
  isTemporaryChat,
  onToggleTemporaryChat,
  canExportChat,
  onExportChat,
  onOpenSettings,
  models,
  selectedModelId,
  onSelectModel,
  modelsLoading,
  onRefreshModels,
  appName = 'NOVA AI',
  customLogoUrl,
  allowThemeSwitch = true,
}: HeaderBarProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node)
      ) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', onOutside);
    return () => document.removeEventListener('mousedown', onOutside);
  }, []);

  const currentModel = models.find((m) => m.id === selectedModelId);
  const displayLabel = currentModel
    ? currentModel.displayName
    : modelsLoading
      ? 'Loading models...'
      : models.length === 0
        ? 'No models available'
        : selectedModelId || 'Select model';

  return (
    <header className="sticky top-0 z-30 h-14 shrink-0 border-b border-slate-200/80 dark:border-white/[0.06] bg-white/90 dark:bg-[#141418]/90 backdrop-blur-md px-3 sm:px-5 flex items-center justify-between gap-2">
      {/* Left: Sidebar Toggle + Brand & Model Switcher (ChatGPT style) */}
      <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
        <button
          type="button"
          onClick={onToggleMobileMenu}
          aria-label="Open sidebar"
          className="lg:hidden min-h-[44px] min-w-[44px] -ml-1.5 flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
        >
          <Menu className="h-5 w-5" />
        </button>

        {!desktopSidebarOpen && (
          <button
            type="button"
            onClick={onToggleDesktopSidebar}
            aria-label="Open sidebar"
            title="Open sidebar"
            className="hidden lg:flex min-h-[38px] min-w-[38px] items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
          >
            <PanelLeft className="h-[18px] w-[18px]" />
          </button>
        )}

        <div className="relative min-w-0" ref={dropdownRef}>
          <button
            type="button"
            onClick={() => setDropdownOpen((o) => !o)}
            aria-haspopup="listbox"
            aria-expanded={dropdownOpen}
            className="min-h-[38px] max-w-[195px] sm:max-w-[280px] flex items-center gap-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/[0.06] px-2 sm:px-2.5 py-1.5 text-sm font-semibold text-slate-900 dark:text-slate-100 transition-colors"
          >
            {!desktopSidebarOpen && (
              <NovaLogo size={22} customLogoUrl={customLogoUrl} className="hidden sm:block shrink-0" />
            )}
            <span className="truncate">
              <span className="font-display font-bold">{appName}</span>
              <span className="mx-1.5 text-slate-300 dark:text-slate-600 font-normal">
                ·
              </span>
              <span className="text-xs sm:text-sm font-medium text-slate-600 dark:text-slate-300">
                {displayLabel}
              </span>
            </span>
            <ChevronDown
              className={`h-4 w-4 shrink-0 text-slate-500 dark:text-slate-400 transition-transform duration-150 ${
                dropdownOpen ? 'rotate-180' : ''
              }`}
            />
          </button>

          {dropdownOpen && (
            <div
              role="listbox"
              aria-label="Available Gemini models"
              className="absolute left-0 mt-2 w-72 sm:w-80 max-h-[65vh] overflow-y-auto rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1b1b20] shadow-2xl p-2 z-50"
            >
              <div className="flex items-center justify-between px-2.5 py-1.5 border-b border-slate-100 dark:border-white/[0.06] mb-1">
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Available Gemini Models
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRefreshModels();
                  }}
                  aria-label="Refresh available models"
                  className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-violet-600 dark:text-cyan-400 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
                >
                  <RefreshCw
                    className={`h-3.5 w-3.5 ${modelsLoading ? 'animate-spin' : ''}`}
                  />
                  Refresh
                </button>
              </div>

              {models.length === 0 ? (
                <div className="px-3 py-4 text-center text-xs text-slate-500 dark:text-slate-400">
                  {modelsLoading
                    ? 'Fetching models from Gemini API...'
                    : 'No chat models returned by the API. Check server configuration in Settings.'}
                </div>
              ) : (
                <div className="space-y-1">
                  {models.map((m) => {
                    const selected = m.id === selectedModelId;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        role="option"
                        aria-selected={selected}
                        onClick={() => {
                          onSelectModel(m.id);
                          setDropdownOpen(false);
                        }}
                        className={`w-full text-left rounded-xl px-3 py-2.5 transition-colors flex items-start justify-between gap-2 ${
                          selected
                            ? 'bg-violet-500/12 dark:bg-white/[0.08] text-slate-900 dark:text-white'
                            : 'hover:bg-slate-100 dark:hover:bg-white/[0.05] text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-medium truncate">
                              {m.displayName}
                            </span>
                            {m.tier === 'paid' ? (
                              <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-400 shrink-0">
                                · Paid
                              </span>
                            ) : (
                              <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 shrink-0">
                                · Free
                              </span>
                            )}
                          </div>
                          <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            <span className="font-mono truncate">{m.id}</span>
                            {m.supportsSearchGrounding && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-cyan-600 dark:text-cyan-400 shrink-0">
                                  Search
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                        {selected && (
                          <Check className="h-4 w-4 shrink-0 mt-0.5 text-violet-600 dark:text-cyan-400" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right: Compact Workspace Utilities */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        <button
          type="button"
          onClick={onToggleTemporaryChat}
          aria-pressed={isTemporaryChat}
          aria-label="Toggle temporary chat"
          title={
            isTemporaryChat
              ? 'Temporary chat active (not saved)'
              : 'Temporary chat'
          }
          className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl transition-colors ${
            isTemporaryChat
              ? 'bg-violet-500/15 text-violet-700 dark:text-cyan-300'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
          }`}
        >
          <MessageCircleDashed className="h-[18px] w-[18px]" />
        </button>

        {canExportChat && (
          <button
            type="button"
            onClick={onExportChat}
            aria-label="Export conversation as Markdown"
            title="Export chat (.md)"
            className="hidden sm:flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
          >
            <Download className="h-[18px] w-[18px]" />
          </button>
        )}

        <button
          type="button"
          onClick={onNewChat}
          aria-label="New chat"
          title="New chat"
          className="lg:hidden min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
        >
          <SquarePen className="h-[18px] w-[18px]" />
        </button>

        {allowThemeSwitch && (
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={
              theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'
            }
            title={theme === 'dark' ? 'Light theme' : 'Dark theme'}
            className="hidden sm:flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
          >
            {theme === 'dark' ? (
              <Sun className="h-[18px] w-[18px]" />
            ) : (
              <Moon className="h-[18px] w-[18px]" />
            )}
          </button>
        )}

        <button
          type="button"
          onClick={onOpenSettings}
          aria-label="Open settings"
          title="Settings"
          className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
        >
          <Settings className="h-[18px] w-[18px]" />
        </button>
      </div>
    </header>
  );
}
