import { useState, type FormEvent } from 'react';
import {
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  LogOut,
  Mail,
  RefreshCw,
  ShieldCheck,
  User as UserIcon,
} from 'lucide-react';
import type { User } from 'firebase/auth';
import {
  resendVerificationEmailForUser,
  sendPasswordReset,
  signInWithEmailAccount,
  signInWithGoogleAccount,
  signOutAccount,
  signUpWithEmailAccount,
} from '../lib/firebase.ts';
import { NovaLogo } from './NovaLogo.tsx';

interface AuthGateProps {
  unverifiedUser?: User | null;
  onVerificationRefreshed?: () => Promise<void>;
}

function formatAuthError(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err ?? '');
  if (
    raw.includes('auth/operation-not-allowed') ||
    raw.includes('auth/admin-restricted-operation')
  ) {
    return 'Email/Password sign-in is not yet enabled in your Firebase Console (Authentication → Sign-in method → Email/Password). You can sign in immediately with Google below, or enable Email/Password in Firebase Console.';
  }
  if (raw.includes('auth/invalid-credential') || raw.includes('auth/wrong-password')) {
    return 'Incorrect email or password. Please check your credentials and try again.';
  }
  if (raw.includes('auth/user-not-found')) {
    return 'No account found with this email. Switch to Sign Up to create your private account.';
  }
  if (raw.includes('auth/email-already-in-use')) {
    return 'An account already exists with this email. Switch to Sign In instead.';
  }
  if (raw.includes('auth/weak-password')) {
    return 'Please choose a stronger password (at least 6 characters).';
  }
  if (raw.includes('auth/invalid-email')) {
    return 'Please enter a valid email address.';
  }
  if (raw.includes('auth/popup-closed-by-user')) {
    return 'Sign-in popup was closed before completing.';
  }
  if (raw.includes('auth/popup-blocked')) {
    return 'Browser blocked the Google sign-in popup. Please allow popups for this site and retry.';
  }
  return raw || 'Authentication failed. Please try again.';
}

export function AuthGate({
  unverifiedUser,
  onVerificationRefreshed,
}: AuthGateProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  if (unverifiedUser) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-slate-50 dark:bg-[#0d0d10] text-slate-900 dark:text-slate-100 px-4 py-8">
        <div className="w-full max-w-md rounded-3xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#17171c] p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col items-center text-center space-y-3">
            <NovaLogo size={46} />
            <h1 className="font-display text-2xl font-semibold">
              Verify Your Email
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              To keep your private NOVA AI workspace secured, please click the verification link sent to{' '}
              <span className="font-medium text-slate-900 dark:text-white">
                {unverifiedUser.email}
              </span>
              .
            </p>
          </div>

          {error && (
            <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-700 dark:text-rose-300">
              {error}
            </div>
          )}
          {notice && (
            <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 px-3.5 py-2.5 text-xs text-cyan-800 dark:text-cyan-300 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              <span>{notice}</span>
            </div>
          )}

          <div className="space-y-2.5">
            <button
              type="button"
              disabled={loading}
              onClick={async () => {
                setLoading(true);
                setError(null);
                try {
                  await onVerificationRefreshed?.();
                } catch (err) {
                  setError(formatAuthError(err));
                } finally {
                  setLoading(false);
                }
              }}
              className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-sm font-semibold hover:opacity-95 disabled:opacity-50"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              <span>I&apos;ve Verified — Enter NOVA AI</span>
            </button>

            <button
              type="button"
              disabled={loading}
              onClick={async () => {
                setLoading(true);
                setError(null);
                setNotice(null);
                try {
                  await resendVerificationEmailForUser(unverifiedUser);
                  setNotice('Verification link resent. Check your inbox and spam folder.');
                } catch (err) {
                  setError(formatAuthError(err));
                } finally {
                  setLoading(false);
                }
              }}
              className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06] text-xs font-medium"
            >
              Resend Verification Email
            </button>

            <button
              type="button"
              onClick={() => void signOutAccount()}
              className="w-full min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Use a different account</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleGoogleSignIn = async () => {
    if (googleLoading || loading) return;
    setGoogleLoading(true);
    setError(null);
    setNotice(null);
    try {
      await signInWithGoogleAccount();
    } catch (err) {
      setError(formatAuthError(err));
    } finally {
      setGoogleLoading(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (loading || googleLoading) return;
    setError(null);
    setNotice(null);

    if (!email.trim() || !password) {
      setError('Please enter both your email and password.');
      return;
    }
    if (mode === 'signup' && password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'signup') {
        await signUpWithEmailAccount({
          name: name.trim() || email.split('@')[0],
          email,
          password,
        });
        setNotice('Account created! Check your email for the verification link.');
      } else {
        await signInWithEmailAccount({ email, password });
      }
    } catch (err) {
      setError(formatAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    setError(null);
    setNotice(null);
    if (!email.trim()) {
      setError('Enter your email address above first to receive a password reset link.');
      return;
    }
    setLoading(true);
    try {
      await sendPasswordReset(email);
      setNotice('Password reset link sent to your email.');
    } catch (err) {
      setError(formatAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[100dvh] flex items-center justify-center bg-slate-50 dark:bg-[#0d0d10] text-slate-900 dark:text-slate-100 px-4 py-8">
      <div className="w-full max-w-md rounded-3xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#17171c] p-6 sm:p-8 shadow-2xl space-y-6">
        {/* Header */}
        <div className="flex flex-col items-center text-center space-y-2.5">
          <NovaLogo size={46} />
          <h1 className="font-display text-2xl font-semibold tracking-tight">
            {mode === 'login' ? 'Sign in to NOVA AI' : 'Create your NOVA AI account'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
            Private personal AI workspace protected by Firebase Authentication
          </p>
        </div>

        {/* Google One-Tap Sign-In */}
        <button
          type="button"
          disabled={googleLoading || loading}
          onClick={() => void handleGoogleSignIn()}
          className="w-full min-h-[46px] flex items-center justify-center gap-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-slate-50 dark:bg-[#1f1f26] hover:bg-slate-100 dark:hover:bg-[#272730] text-sm font-semibold transition-colors disabled:opacity-50"
        >
          {googleLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96z"
              />
            </svg>
          )}
          <span>Continue with Google</span>
        </button>

        <div className="relative flex items-center py-0.5">
          <div className="flex-grow border-t border-slate-200 dark:border-white/10" />
          <span className="shrink mx-3 text-[11px] uppercase tracking-wider text-slate-400">
            or with email
          </span>
          <div className="flex-grow border-t border-slate-200 dark:border-white/10" />
        </div>

        {/* Mode Toggle Tabs */}
        <div className="grid grid-cols-2 rounded-xl bg-slate-100 dark:bg-[#121216] p-1 border border-slate-200 dark:border-white/[0.06]">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
              setNotice(null);
            }}
            className={`min-h-[36px] rounded-lg text-xs font-semibold transition-colors ${
              mode === 'login'
                ? 'bg-white dark:bg-[#26262e] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setError(null);
              setNotice(null);
            }}
            className={`min-h-[36px] rounded-lg text-xs font-semibold transition-colors ${
              mode === 'signup'
                ? 'bg-white dark:bg-[#26262e] text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            Sign Up
          </button>
        </div>

        {error && (
          <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-700 dark:text-rose-300 leading-relaxed">
            {error}
          </div>
        )}
        {notice && (
          <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/10 px-3.5 py-2.5 text-xs text-cyan-800 dark:text-cyan-300 leading-relaxed">
            {notice}
          </div>
        )}

        <form onSubmit={(e) => void handleSubmit(e)} className="space-y-3.5">
          {mode === 'signup' && (
            <div className="space-y-1">
              <label
                htmlFor="auth-name"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Your Name
              </label>
              <div className="relative">
                <UserIcon className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  id="auth-name"
                  type="text"
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Kamrun Kabir"
                  className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#121216] pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                />
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label
              htmlFor="auth-email"
              className="block text-xs font-medium text-slate-600 dark:text-slate-300"
            >
              Email Address
            </label>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                id="auth-email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#121216] pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
              />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label
                htmlFor="auth-password"
                className="block text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Password
              </label>
              {mode === 'login' && (
                <button
                  type="button"
                  onClick={() => void handleForgotPassword()}
                  className="text-xs font-medium text-violet-600 dark:text-cyan-400 hover:underline"
                >
                  Forgot password?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                id="auth-password"
                type={showPassword ? 'text' : 'password'}
                required
                minLength={6}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimum 6 characters"
                className="w-full min-h-[42px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#121216] pl-9 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || googleLoading}
            className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white text-sm font-semibold shadow-sm disabled:opacity-50"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            <span>{mode === 'login' ? 'Log In Securely' : 'Create Account'}</span>
          </button>
        </form>

        <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
          <ShieldCheck className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
          <span>Per-user isolated chats &amp; server-side API keys</span>
        </div>
      </div>
    </div>
  );
}
