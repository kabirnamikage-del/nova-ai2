import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Code2,
  Crown,
  FileCode,
  Folder,
  FolderOpen,
  GitBranch,
  GitCommit,
  History,
  KeyRound,
  LayoutDashboard,
  Loader2,
  Lock,
  Palette,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Smartphone,
  Trash2,
  Upload,
  UserCheck,
  Users,
  UserX,
  X,
  Zap,
} from 'lucide-react';
import {
  commitGitChangesRemote,
  createGitBranchRemote,
  fetchAdminOverview,
  fetchBackendAuditLogs,
  fetchBackupSnapshots,
  fetchGitStatus,
  fetchWorkspaceFile,
  fetchWorkspaceTree,
  previewFileDiff,
  pushGitHubRemote,
  rollbackBackupRemote,
  runGitBuildSuiteRemote,
  runWorkspaceValidation,
  saveAdminConfigRemote,
  saveWorkspaceFile,
  setAdminStepUpPin,
  syncAndroidFilesRemote,
  verifyAdminSession,
  type AdminOverviewPayload,
  type AdminSessionCheck,
} from '../lib/adminApi.ts';
import { SuperPowerSection } from './SuperPowerSection.tsx';
import {
  adminDeleteUserDirectory,
  adminUpdateUserAccount,
  fetchAllUserAccounts,
  loadAdminAuditLogs,
  logAdminAudit,
} from '../lib/firebase.ts';
import type {
  AdminConfigDocument,
  BackendAuditLogEntry,
  BackupSnapshotMeta,
  DiffLine,
  FeatureControlMatrix,
  FirestoreAuditLogRecord,
  GitStatusReport,
  PublicAppConfig,
  UserDirectoryRecord,
  UserTier,
  ValidationResult,
  WorkspaceFileNode,
} from '../types/admin.ts';

type AdminTab =
  | 'overview'
  | 'users'
  | 'features'
  | 'customize'
  | 'super-power'
  | 'editor'
  | 'git'
  | 'audit';

interface AdminPanelProps {
  onClose: () => void;
  onConfigUpdated: (cfg: PublicAppConfig) => void;
}

const FEATURE_ROWS: Array<{
  key: keyof Omit<FeatureControlMatrix, 'dailyRequestLimit' | 'maxUploadMb'>;
  label: string;
  hint: string;
  paidNote?: boolean;
}> = [
  {
    key: 'advancedModes',
    label: 'Advanced AI Modes',
    hint: 'Study (Bengali/English), Coding, and Writing modes',
  },
  {
    key: 'premiumChatModels',
    label: 'Premium Chat Models',
    hint: 'Paid-tier Gemini models in model selector',
  },
  {
    key: 'imageGeneration',
    label: 'AI Image Generation',
    hint: 'Nano Banana raster image generation (requires paid billing)',
    paidNote: true,
  },
  {
    key: 'imageEditing',
    label: 'Image Editing Tools',
    hint: 'Canvas photo editor & AI image edit workflows',
  },
  {
    key: 'advancedFileUploads',
    label: 'Advanced File Uploads',
    hint: 'PDF, code, and multi-image attachments',
  },
  {
    key: 'voiceFeatures',
    label: 'Voice Input & Speech',
    hint: 'Microphone transcription and read-aloud TTS',
  },
  {
    key: 'customBrandingThemes',
    label: 'Theme Switching',
    hint: 'Allow users to toggle dark & light appearance',
  },
];

function formatDateTime(ts: number | null | undefined): string {
  if (!ts) return 'Never';
  return new Date(ts).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function FileTreeItem({
  node,
  depth,
  selectedPath,
  expandedDirs,
  onToggleDir,
  onSelectFile,
}: {
  node: WorkspaceFileNode;
  depth: number;
  selectedPath: string;
  expandedDirs: Set<string>;
  onToggleDir: (path: string) => void;
  onSelectFile: (path: string) => void;
}) {
  const isDir = node.type === 'directory';
  const expanded = expandedDirs.has(node.path);
  const selected = !isDir && node.path === selectedPath;

  return (
    <div>
      <button
        type="button"
        onClick={() => (isDir ? onToggleDir(node.path) : onSelectFile(node.path))}
        style={{ paddingLeft: `${8 + depth * 12}px` }}
        className={`w-full flex items-center gap-1.5 py-1.5 pr-2 text-left text-xs rounded-lg transition-colors ${
          selected
            ? 'bg-violet-500/20 text-white font-medium'
            : 'text-slate-300 hover:bg-white/[0.05]'
        }`}
      >
        {isDir ? (
          <>
            {expanded ? (
              <ChevronDown className="h-3.5 w-3.5 text-slate-500 shrink-0" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-slate-500 shrink-0" />
            )}
            {expanded ? (
              <FolderOpen className="h-3.5 w-3.5 text-amber-400 shrink-0" />
            ) : (
              <Folder className="h-3.5 w-3.5 text-amber-400 shrink-0" />
            )}
          </>
        ) : (
          <>
            <span className="w-3.5 shrink-0" />
            <FileCode className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
          </>
        )}
        <span className="truncate flex-1">{node.name}</span>
        {node.protected && (
          <Lock className="h-3 w-3 text-amber-400 shrink-0" aria-label="Protected read-only" />
        )}
      </button>

      {isDir && expanded && node.children && (
        <div>
          {node.children.map((child) => (
            <FileTreeItem
              key={child.path}
              node={child}
              depth={depth + 1}
              selectedPath={selectedPath}
              expandedDirs={expandedDirs}
              onToggleDir={onToggleDir}
              onSelectFile={onSelectFile}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function AdminPanel({ onClose, onConfigUpdated }: AdminPanelProps) {
  const [sessionLoading, setSessionLoading] = useState(true);
  const [session, setSession] = useState<AdminSessionCheck | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [toast, setToast] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [stepUpPinInput, setStepUpPinInput] = useState('');

  // Overview & config state
  const [overview, setOverview] = useState<AdminOverviewPayload | null>(null);
  const [configDraft, setConfigDraft] = useState<AdminConfigDocument | null>(null);
  const [savingConfig, setSavingConfig] = useState(false);
  const [syncingAndroid, setSyncingAndroid] = useState(false);
  const [billingConfirmModal, setBillingConfirmModal] = useState(false);

  // User management state (Firestore directory)
  const [users, setUsers] = useState<UserDirectoryRecord[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [userSearch, setUserSearch] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState<string>('all');
  const [userActionBusy, setUserActionBusy] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<UserDirectoryRecord | null>(null);
  const [deleteConfirmText, setDeleteConfirmText] = useState('');

  // Code editor validation & backup state
  const [lastValidation, setLastValidation] = useState<ValidationResult | null>(null);
  const [backups, setBackups] = useState<BackupSnapshotMeta[]>([]);
  const [rollingBackId, setRollingBackId] = useState<string | null>(null);

  // Direct Code Editor state
  const [fileTree, setFileTree] = useState<WorkspaceFileNode[]>([]);
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(() => new Set(['src', 'server']));
  const [selectedFilePath, setSelectedFilePath] = useState('');
  const [originalFileContent, setOriginalFileContent] = useState('');
  const [editorContent, setEditorContent] = useState('');
  const [editorProtected, setEditorProtected] = useState(false);
  const [editorLoading, setEditorLoading] = useState(false);
  const [editorSaving, setEditorSaving] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [diffPreview, setDiffPreview] = useState<{
    diffLines: DiffLine[];
    stats: { added: number; removed: number };
  } | null>(null);

  // Git & Build state
  const [gitStatus, setGitStatus] = useState<GitStatusReport | null>(null);
  const [gitBranchInput, setGitBranchInput] = useState('admin-update');
  const [gitCommitMsg, setGitCommitMsg] = useState('');
  const [gitBusy, setGitBusy] = useState<string | null>(null);
  const [gitOutput, setGitOutput] = useState('');
  const [buildResult, setBuildResult] = useState<{
    lint: ValidationResult;
    build: ValidationResult;
  } | null>(null);

  // Audit logs state
  const [firestoreAudits, setFirestoreAudits] = useState<FirestoreAuditLogRecord[]>([]);
  const [backendAudits, setBackendAudits] = useState<BackendAuditLogEntry[]>([]);

  const showToast = useCallback((type: 'ok' | 'err', text: string) => {
    setToast({ type, text });
    window.setTimeout(() => {
      setToast((prev) => (prev?.text === text ? null : prev));
    }, 5000);
  }, []);

  const loadAllAdminData = useCallback(async () => {
    try {
      const [ov, userList, bakRes, treeRes, gitRes, bAudits, fAudits] =
        await Promise.all([
          fetchAdminOverview(),
          fetchAllUserAccounts().catch(() => [] as UserDirectoryRecord[]),
          fetchBackupSnapshots().catch(() => ({ backups: [] as BackupSnapshotMeta[] })),
          fetchWorkspaceTree().catch(() => ({ tree: [] as WorkspaceFileNode[] })),
          fetchGitStatus().catch(() => ({ git: null })),
          fetchBackendAuditLogs().catch(() => ({ logs: [] as BackendAuditLogEntry[] })),
          loadAdminAuditLogs().catch(() => [] as FirestoreAuditLogRecord[]),
        ]);
      setOverview(ov);
      setConfigDraft(ov.config);
      setUsers(userList);
      setBackups(bakRes.backups);
      setFileTree(treeRes.tree);
      if (gitRes.git) setGitStatus(gitRes.git);
      setBackendAudits(bAudits.logs);
      setFirestoreAudits(fAudits);
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Failed to load admin data');
    }
  }, [showToast]);

  useEffect(() => {
    let active = true;
    setSessionLoading(true);
    verifyAdminSession().then((res) => {
      if (!active) return;
      setSession(res);
      setSessionLoading(false);
      if (res.authorized) {
        void loadAllAdminData();
      }
    });
    return () => {
      active = false;
    };
  }, [loadAllAdminData]);

  // Derived user metrics
  const userMetrics = useMemo(() => {
    const now = Date.now();
    const sevenDaysAgo = now - 7 * 86_400_000;
    const total = users.length;
    const active = users.filter((u) => u.status === 'active').length;
    const blocked = users.filter((u) => u.status === 'blocked').length;
    const suspended = users.filter((u) => u.status === 'suspended').length;
    const new7d = users.filter((u) => u.createdAt >= sevenDaysAgo).length;
    const totalConversations = users.reduce(
      (sum, u) => sum + (u.conversationCount ?? 0),
      0
    );
    return { total, active, blocked, suspended, new7d, totalConversations };
  }, [users]);

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    return users.filter((u) => {
      if (userStatusFilter !== 'all' && u.status !== userStatusFilter) return false;
      if (!q) return true;
      return (
        u.email.toLowerCase().includes(q) ||
        u.uid.toLowerCase().includes(q) ||
        u.displayName.toLowerCase().includes(q)
      );
    });
  }, [users, userSearch, userStatusFilter]);

  const refreshUsers = async () => {
    setUsersLoading(true);
    try {
      const list = await fetchAllUserAccounts();
      setUsers(list);
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Unable to fetch users');
    } finally {
      setUsersLoading(false);
    }
  };

  const handleUserStatusChange = async (
    user: UserDirectoryRecord,
    status: 'active' | 'blocked' | 'suspended',
    suspendDays?: number
  ) => {
    if (user.tier === 'admin') {
      showToast('err', 'Super Admin account cannot be blocked or suspended.');
      return;
    }
    setUserActionBusy(user.uid);
    try {
      const suspendedUntil =
        status === 'suspended' && suspendDays
          ? Date.now() + suspendDays * 86_400_000
          : null;
      await adminUpdateUserAccount(user.uid, { status, suspendedUntil });
      await logAdminAudit({
        action: `USER_${status.toUpperCase()}`,
        targetType: 'user',
        targetId: user.uid,
        details: `Set ${user.email} status to ${status}${suspendDays ? ` (${suspendDays}d)` : ''}`,
      });
      await refreshUsers();
      setFirestoreAudits(await loadAdminAuditLogs());
      showToast('ok', `Updated ${user.email} status to ${status}.`);
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'User update failed');
    } finally {
      setUserActionBusy(null);
    }
  };

  const handleUserTierChange = async (user: UserDirectoryRecord, tier: UserTier) => {
    if (user.tier === 'admin' || tier === 'admin') {
      showToast('err', 'Admin role cannot be reassigned.');
      return;
    }
    setUserActionBusy(user.uid);
    try {
      await adminUpdateUserAccount(user.uid, { tier });
      await logAdminAudit({
        action: 'USER_TIER_CHANGE',
        targetType: 'user',
        targetId: user.uid,
        details: `Changed ${user.email} tier to ${tier}`,
      });
      await refreshUsers();
      setFirestoreAudits(await loadAdminAuditLogs());
      showToast('ok', `Updated ${user.email} access level to ${tier}.`);
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Tier update failed');
    } finally {
      setUserActionBusy(null);
    }
  };

  const handleConfirmDeleteUser = async () => {
    if (!deleteTarget) return;
    if (deleteConfirmText.trim() !== 'DELETE') return;
    setUserActionBusy(deleteTarget.uid);
    try {
      await adminDeleteUserDirectory(deleteTarget.uid);
      await logAdminAudit({
        action: 'USER_DELETE_DIRECTORY',
        targetType: 'user',
        targetId: deleteTarget.uid,
        details: `Deleted account directory record for ${deleteTarget.email}`,
      });
      setDeleteTarget(null);
      setDeleteConfirmText('');
      await refreshUsers();
      setFirestoreAudits(await loadAdminAuditLogs());
      showToast('ok', 'User account directory removed.');
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Delete failed');
    } finally {
      setUserActionBusy(null);
    }
  };

  const handleSaveConfig = async (override?: AdminConfigDocument) => {
    const payload = override || configDraft;
    if (!payload) return;

    // Require explicit paid billing confirmation if enabling imageGeneration on Free/Premium
    const wantsImageGen =
      payload.features.free.imageGeneration || payload.features.premium.imageGeneration;
    if (wantsImageGen && !payload.paidImageBillingConfirmedByAdmin) {
      setBillingConfirmModal(true);
      return;
    }

    setSavingConfig(true);
    try {
      const res = await saveAdminConfigRemote(payload);
      setConfigDraft(res.config);
      setOverview((prev) => (prev ? { ...prev, config: res.config } : prev));
      onConfigUpdated(res.config);
      setBackendAudits((await fetchBackendAuditLogs()).logs);
      showToast('ok', 'Saved configuration & applied live changes.');
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Failed to save config');
    } finally {
      setSavingConfig(false);
    }
  };

  const handleSyncAndroid = async () => {
    if (!configDraft) return;
    setSyncingAndroid(true);
    try {
      const res = await syncAndroidFilesRemote({
        appName: configDraft.customization.android.appName,
        launcherColor: configDraft.customization.android.launcherColor,
        splashBackground: configDraft.customization.android.splashBackground,
      });
      setConfigDraft(res.config);
      onConfigUpdated(res.config);
      setBackups((await fetchBackupSnapshots()).backups);
      setBackendAudits((await fetchBackendAuditLogs()).logs);
      showToast(
        'ok',
        `Synced ${res.updatedFiles.length} Android source file(s). New APK build required for Android devices.`
      );
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Android sync failed');
    } finally {
      setSyncingAndroid(false);
    }
  };

  const handleOpenFile = async (relPath: string) => {
    setEditorLoading(true);
    setDiffPreview(null);
    try {
      const file = await fetchWorkspaceFile(relPath);
      setSelectedFilePath(file.path);
      setOriginalFileContent(file.content);
      setEditorContent(file.content);
      setEditorProtected(file.protected);
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Unable to open file');
    } finally {
      setEditorLoading(false);
    }
  };

  const handleSaveEditorFile = async () => {
    if (!selectedFilePath || editorProtected) return;
    setEditorSaving(true);
    try {
      const res = await saveWorkspaceFile(selectedFilePath, editorContent);
      setOriginalFileContent(editorContent);
      setLastValidation(res.validation);
      setBackups((await fetchBackupSnapshots()).backups);
      setBackendAudits((await fetchBackendAuditLogs()).logs);
      showToast(
        res.validation.ok ? 'ok' : 'err',
        res.validation.ok
          ? `Saved ${selectedFilePath} (backup ${res.backup.id}, TypeScript passed)`
          : `Saved ${selectedFilePath}, but TypeScript check reported issues.`
      );
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Save failed');
    } finally {
      setEditorSaving(false);
    }
  };

  const handlePreviewEditorDiff = async () => {
    if (!selectedFilePath) return;
    try {
      const diff = await previewFileDiff(selectedFilePath, editorContent);
      setDiffPreview(diff);
    } catch (err) {
      showToast('err', err instanceof Error ? err.message : 'Diff preview failed');
    }
  };

  const handleRollback = async (backupId: string) => {
    setRollingBackId(backupId);
    try {
      const res = await rollbackBackupRemote(backupId);
      setLastValidation(res.validation);
      const [bakRes, treeRes, auditRes] = await Promise.all([
        fetchBackupSnapshots().catch(() => null),
        fetchWorkspaceTree().catch(() => null),
        fetchBackendAuditLogs().catch(() => null),
      ]);
      if (bakRes) setBackups(bakRes.backups);
      if (treeRes) setFileTree(treeRes.tree);
      if (auditRes) setBackendAudits(auditRes.logs);

      if (selectedFilePath && res.restoredPaths.includes(selectedFilePath)) {
        await handleOpenFile(selectedFilePath);
      }
      const okMsg = res.message || 'Changes Rolled Back Successfully!';
      showToast('ok', okMsg);
    } catch {
      showToast('err', 'Unable to Apply Changes. Please Retry.');
    } finally {
      setRollingBackId(null);
    }
  };

  // Loading authentication verification screen
  if (sessionLoading) {
    return (
      <div className="min-h-[100dvh] w-full bg-[#0d0d10] text-slate-100 flex flex-col items-center justify-center gap-3 p-6">
        <Loader2 className="h-6 w-6 animate-spin text-violet-400" />
        <p className="text-sm text-slate-400">Verifying Super Admin Google OAuth token on backend...</p>
      </div>
    );
  }

  // Strict server-verified Access Denied gate
  if (!session?.authorized) {
    return (
      <div className="min-h-[100dvh] w-full bg-[#0d0d10] text-slate-100 flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-2xl border border-rose-500/30 bg-[#141418] p-6 space-y-4 text-center">
          <div className="mx-auto h-12 w-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <h1 className="font-display text-xl font-semibold text-white">Access Denied</h1>
          <p className="text-sm text-slate-400 leading-relaxed">
            {session?.error?.message ||
              'You are not authorized to access the NOVA AI Super Admin Control Panel.'}
          </p>
          <button
            type="button"
            onClick={onClose}
            className="w-full min-h-[42px] rounded-xl bg-white/[0.08] hover:bg-white/[0.14] text-sm font-medium text-white transition-colors"
          >
            Return to NOVA AI
          </button>
        </div>
      </div>
    );
  }

  const navTabs: Array<{ id: AdminTab; label: string; icon: typeof LayoutDashboard }> = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'features', label: 'Feature Control', icon: Sliders },
    { id: 'customize', label: 'Customization', icon: Palette },
    { id: 'super-power', label: 'Super Power', icon: Zap },
    { id: 'editor', label: 'Code Editor', icon: Code2 },
    { id: 'git', label: 'Updates & Git', icon: GitBranch },
    { id: 'audit', label: 'Audit Logs', icon: History },
  ];

  // Daily chart data (14 days)
  const chartDays = overview?.telemetry.byDay.slice(-14) ?? [];
  const maxDayReq = Math.max(1, ...chartDays.map((d) => d.requests));

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0d0d10] text-slate-100 overflow-hidden">
      {/* Top Admin Header */}
      <header className="h-14 shrink-0 border-b border-white/[0.08] bg-[#141418] px-3 sm:px-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.09] px-3 text-xs font-medium text-slate-200 whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to App</span>
          </button>
          <div className="flex items-center gap-2 min-w-0">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            <span className="font-display text-sm sm:text-base font-semibold tracking-tight truncate">
              Super Admin Control Panel
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {overview?.stepUpPinRequired && (
            <div className="hidden sm:flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-2.5 py-1">
              <KeyRound className="h-3.5 w-3.5 text-amber-400 shrink-0" />
              <input
                type="password"
                value={stepUpPinInput}
                onChange={(e) => {
                  setStepUpPinInput(e.target.value);
                  setAdminStepUpPin(e.target.value);
                }}
                placeholder="Admin Step-Up PIN"
                className="w-28 bg-transparent text-xs text-white placeholder:text-amber-300/60 focus:outline-none"
              />
            </div>
          )}

          <div className="hidden md:flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-2.5 py-1 text-xs text-slate-300">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            <span className="font-mono">{session.principal?.email}</span>
          </div>

          <button
            type="button"
            onClick={() => void loadAllAdminData()}
            aria-label="Refresh admin data"
            className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.09] text-slate-300"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* Mobile step-up PIN prompt if configured */}
      {overview?.stepUpPinRequired && (
        <div className="sm:hidden border-b border-amber-500/20 bg-amber-500/10 px-3 py-2 flex items-center gap-2">
          <KeyRound className="h-3.5 w-3.5 text-amber-400 shrink-0" />
          <input
            type="password"
            value={stepUpPinInput}
            onChange={(e) => {
              setStepUpPinInput(e.target.value);
              setAdminStepUpPin(e.target.value);
            }}
            placeholder="Enter ADMIN_STEPUP_PIN for write actions"
            className="flex-1 bg-transparent text-xs text-white placeholder:text-amber-300/70 focus:outline-none"
          />
        </div>
      )}

      {/* Toast Feedback Banner */}
      {toast && (
        <div
          className={`px-4 py-2 text-xs font-medium border-b flex items-center justify-between gap-2 ${
            toast.type === 'ok'
              ? 'bg-emerald-500/12 border-emerald-500/25 text-emerald-300'
              : 'bg-rose-500/12 border-rose-500/25 text-rose-300'
          }`}
        >
          <span>{toast.text}</span>
          <button type="button" onClick={() => setToast(null)} className="p-0.5 hover:text-white">
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      <div className="flex flex-1 min-h-0 flex-col lg:flex-row">
        {/* Sidebar / Mobile Horizontal Tab Strip */}
        <nav
          aria-label="Admin sections"
          className="lg:w-56 shrink-0 border-b lg:border-b-0 lg:border-r border-white/[0.08] bg-[#121216] p-2 flex lg:flex-col gap-1 overflow-x-auto no-scrollbar"
        >
          {navTabs.map((t) => {
            const Icon = t.icon;
            const active = activeTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id)}
                className={`min-h-[38px] flex items-center gap-2.5 rounded-xl px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-violet-600/20 border border-violet-500/40 text-white'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-white/[0.05] border border-transparent'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Main Scrollable Admin Content */}
        <main className="flex-1 min-w-0 overflow-y-auto p-4 sm:p-6">
          <div className="mx-auto max-w-6xl space-y-6">
            {/* ============================================================== */}
            {/* 1. DASHBOARD OVERVIEW                                          */}
            {/* ============================================================== */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h2 className="font-display text-lg font-semibold text-white">
                    Platform Overview
                  </h2>
                  <p className="text-xs text-slate-400">
                    Real-time account metrics from Firestore and live server-side Gemini telemetry.
                  </p>
                </div>

                {/* KPI Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                  {[
                    { label: 'Total Users', value: userMetrics.total, sub: 'Registered' },
                    { label: 'Active Users', value: userMetrics.active, sub: 'Verified active' },
                    {
                      label: 'Blocked / Susp.',
                      value: userMetrics.blocked + userMetrics.suspended,
                      sub: `${userMetrics.blocked} blk · ${userMetrics.suspended} susp`,
                    },
                    { label: 'New Users (7d)', value: userMetrics.new7d, sub: 'Last 7 days' },
                    {
                      label: 'Conversations',
                      value: userMetrics.totalConversations,
                      sub: 'User count sum',
                    },
                    {
                      label: 'API Requests',
                      value: overview?.telemetry.totalRequests ?? 0,
                      sub: `${overview?.telemetry.quotaErrors429 ?? 0} quota 429s`,
                    },
                  ].map((kpi) => (
                    <div
                      key={kpi.label}
                      className="rounded-xl border border-white/[0.08] bg-[#141418] p-3.5"
                    >
                      <div className="text-[11px] font-medium text-slate-400">{kpi.label}</div>
                      <div className="mt-1 font-mono text-2xl font-semibold tabular-nums text-white">
                        {kpi.value}
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">{kpi.sub}</div>
                    </div>
                  ))}
                </div>

                {/* Traffic Chart & Gemini Service Status */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div className="lg:col-span-2 rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-sm font-semibold text-white">
                          API Usage & Error Trend
                        </h3>
                        <p className="text-xs text-slate-400">
                          Daily chat, vision, and image API volume tracked by Express backend
                        </p>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400">
                        <span className="flex items-center gap-1">
                          <span className="h-2 w-2 rounded-sm bg-violet-500" /> Requests
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="h-2 w-2 rounded-sm bg-rose-500" /> Errors
                        </span>
                      </div>
                    </div>

                    {chartDays.length === 0 ? (
                      <div className="h-44 flex items-center justify-center rounded-xl border border-dashed border-white/10 text-xs text-slate-500">
                        No API traffic recorded yet in this server session. Send a chat or image request to populate telemetry.
                      </div>
                    ) : (
                      <div className="h-44 w-full flex items-end gap-2 pt-4">
                        {chartDays.map((day) => {
                          const reqPct = Math.max(6, Math.round((day.requests / maxDayReq) * 100));
                          const errPct =
                            day.errors > 0
                              ? Math.max(6, Math.round((day.errors / maxDayReq) * 100))
                              : 0;
                          return (
                            <div
                              key={day.date}
                              className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end min-w-0"
                            >
                              <div className="w-full max-w-[34px] flex items-end justify-center gap-1 h-32">
                                <div
                                  title={`${day.date}: ${day.requests} requests`}
                                  style={{ height: `${reqPct}%` }}
                                  className="w-1/2 rounded-t bg-violet-500/85 transition-all"
                                />
                                {errPct > 0 && (
                                  <div
                                    title={`${day.date}: ${day.errors} errors`}
                                    style={{ height: `${errPct}%` }}
                                    className="w-1/2 rounded-t bg-rose-500/85 transition-all"
                                  />
                                )}
                              </div>
                              <span className="font-mono text-[10px] text-slate-500 truncate">
                                {day.date.slice(5)}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {/* Gemini Quota & Health */}
                  <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                    <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                      <Activity className="h-4 w-4 text-cyan-400" />
                      <span>Gemini & Provider Status</span>
                    </h3>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center justify-between py-1.5 border-b border-white/[0.06]">
                        <span className="text-slate-400">GEMINI_API_KEY</span>
                        <span
                          className={
                            overview?.geminiConfigured
                              ? 'text-emerald-400 font-medium'
                              : 'text-rose-400 font-medium'
                          }
                        >
                          {overview?.geminiConfigured ? 'Configured' : 'Missing'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5 border-b border-white/[0.06]">
                        <span className="text-slate-400">Image Provider</span>
                        <span className="text-slate-200 font-medium truncate max-w-[160px]">
                          {overview?.imageProvider.providerName || 'Hybrid'}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5 border-b border-white/[0.06]">
                        <span className="text-slate-400">Success / Total</span>
                        <span className="font-mono tabular-nums text-slate-200">
                          {overview?.telemetry.totalSuccess ?? 0} /{' '}
                          {overview?.telemetry.totalRequests ?? 0}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5 border-b border-white/[0.06]">
                        <span className="text-slate-400">429 Quota Errors</span>
                        <span
                          className={`font-mono tabular-nums ${
                            (overview?.telemetry.quotaErrors429 ?? 0) > 0
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }`}
                        >
                          {overview?.telemetry.quotaErrors429 ?? 0}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1.5">
                        <span className="text-slate-400">Total Errors</span>
                        <span className="font-mono tabular-nums text-rose-400">
                          {overview?.telemetry.totalErrors ?? 0}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Model Breakdown + Recent Errors */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                    <h3 className="text-sm font-semibold text-white">Usage by Gemini Model</h3>
                    {Object.keys(overview?.telemetry.byModel ?? {}).length === 0 ? (
                      <p className="text-xs text-slate-500 py-4">No model requests recorded yet.</p>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs text-left">
                          <thead>
                            <tr className="border-b border-white/[0.08] text-slate-400">
                              <th className="py-2 pr-3 font-medium">Model</th>
                              <th className="py-2 px-2 font-medium text-right">Calls</th>
                              <th className="py-2 px-2 font-medium text-right">Errors</th>
                              <th className="py-2 pl-2 font-medium text-right">429s</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/[0.05]">
                            {Object.entries(overview?.telemetry.byModel ?? {}).map(
                              ([modelId, stat]) => (
                                <tr key={modelId}>
                                  <td className="py-2 pr-3 font-mono text-slate-200">{modelId}</td>
                                  <td className="py-2 px-2 text-right font-mono tabular-nums">
                                    {stat.requests}
                                  </td>
                                  <td className="py-2 px-2 text-right font-mono tabular-nums text-rose-400">
                                    {stat.errors}
                                  </td>
                                  <td className="py-2 pl-2 text-right font-mono tabular-nums text-amber-400">
                                    {stat.quotaErrors}
                                  </td>
                                </tr>
                              )
                            )}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>

                  <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                    <h3 className="text-sm font-semibold text-white">Recent API Errors</h3>
                    {(overview?.telemetry.recentErrors.length ?? 0) === 0 ? (
                      <p className="text-xs text-emerald-400/80 py-4">
                        No errors logged in recent telemetry.
                      </p>
                    ) : (
                      <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                        {overview?.telemetry.recentErrors.slice(0, 12).map((err) => (
                          <div
                            key={err.id}
                            className="rounded-lg border border-rose-500/20 bg-rose-500/[0.05] px-3 py-2 text-xs"
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-mono font-semibold text-rose-300">
                                {err.status} {err.code}
                              </span>
                              <span className="text-[11px] text-slate-500">
                                {formatDateTime(err.timestamp)}
                              </span>
                            </div>
                            <p className="mt-0.5 text-slate-300 break-words">{err.message}</p>
                            <div className="mt-0.5 font-mono text-[10px] text-slate-500">
                              {err.route} {err.model ? `· ${err.model}` : ''}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ============================================================== */}
            {/* 2. USER MANAGEMENT                                             */}
            {/* ============================================================== */}
            {activeTab === 'users' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-lg font-semibold text-white">
                      User Management
                    </h2>
                    <p className="text-xs text-slate-400">
                      Privacy-enforced directory: never displays passwords, auth tokens, or private user conversations.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void refreshUsers()}
                    className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] px-3 text-xs font-medium text-slate-200 whitespace-nowrap shrink-0"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${usersLoading ? 'animate-spin' : ''}`} />
                    <span>Refresh Users</span>
                  </button>
                </div>

                {/* Search & Status Filters */}
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="search"
                      value={userSearch}
                      onChange={(e) => setUserSearch(e.target.value)}
                      placeholder="Search by email, UID, or name..."
                      className="w-full min-h-[40px] rounded-xl border border-white/10 bg-[#141418] pl-9 pr-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
                    />
                  </div>
                  <select
                    value={userStatusFilter}
                    onChange={(e) => setUserStatusFilter(e.target.value)}
                    aria-label="Filter users by status"
                    className="min-h-[40px] rounded-xl border border-white/10 bg-[#141418] px-3 text-xs text-slate-200"
                  >
                    <option value="all">All Statuses ({users.length})</option>
                    <option value="active">Active ({userMetrics.active})</option>
                    <option value="suspended">Suspended ({userMetrics.suspended})</option>
                    <option value="blocked">Blocked ({userMetrics.blocked})</option>
                  </select>
                </div>

                {/* Users Table */}
                <div className="rounded-xl border border-white/[0.08] bg-[#141418] overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead>
                        <tr className="border-b border-white/[0.08] text-slate-400 bg-white/[0.02]">
                          <th className="py-3 px-4 font-medium">User & Email</th>
                          <th className="py-3 px-3 font-medium">UID</th>
                          <th className="py-3 px-3 font-medium">Created / Active</th>
                          <th className="py-3 px-3 font-medium">Status</th>
                          <th className="py-3 px-3 font-medium">Tier</th>
                          <th className="py-3 px-4 font-medium text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/[0.06]">
                        {filteredUsers.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-slate-500">
                              No user directory records match this filter.
                            </td>
                          </tr>
                        ) : (
                          filteredUsers.map((u) => {
                            const isSelfAdmin = u.tier === 'admin';
                            const busy = userActionBusy === u.uid;
                            return (
                              <tr key={u.uid} className="hover:bg-white/[0.02]">
                                <td className="py-3 px-4">
                                  <div className="font-medium text-white">{u.displayName}</div>
                                  <div className="text-[11px] text-slate-400">{u.email}</div>
                                </td>
                                <td className="py-3 px-3 font-mono text-[11px] text-slate-400 max-w-[140px] truncate">
                                  {u.uid}
                                </td>
                                <td className="py-3 px-3 text-[11px] text-slate-400">
                                  <div>C: {formatDateTime(u.createdAt)}</div>
                                  <div>A: {formatDateTime(u.lastActiveAt)}</div>
                                </td>
                                <td className="py-3 px-3">
                                  <span
                                    className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium ${
                                      u.status === 'active'
                                        ? 'bg-emerald-500/15 text-emerald-300'
                                        : u.status === 'suspended'
                                          ? 'bg-amber-500/15 text-amber-300'
                                          : 'bg-rose-500/15 text-rose-300'
                                    }`}
                                  >
                                    {u.status}
                                  </span>
                                </td>
                                <td className="py-3 px-3">
                                  {isSelfAdmin ? (
                                    <span className="inline-flex items-center gap-1 text-violet-300 font-semibold">
                                      <Crown className="h-3.5 w-3.5" />
                                      admin
                                    </span>
                                  ) : (
                                    <select
                                      value={u.tier}
                                      disabled={busy}
                                      onChange={(e) =>
                                        void handleUserTierChange(u, e.target.value as UserTier)
                                      }
                                      className="rounded-lg border border-white/10 bg-[#0d0d10] px-2 py-1 text-[11px] text-slate-200"
                                    >
                                      <option value="free">free</option>
                                      <option value="premium">premium</option>
                                    </select>
                                  )}
                                </td>
                                <td className="py-3 px-4">
                                  {isSelfAdmin ? (
                                    <div className="text-right text-[11px] text-slate-500">
                                      Protected Super Admin
                                    </div>
                                  ) : (
                                    <div className="flex items-center justify-end gap-1.5 flex-wrap">
                                      {u.status === 'active' ? (
                                        <>
                                          <button
                                            type="button"
                                            disabled={busy}
                                            onClick={() =>
                                              void handleUserStatusChange(u, 'suspended', 1)
                                            }
                                            className="rounded-lg border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 px-2 py-1 text-[11px] text-amber-300 whitespace-nowrap"
                                          >
                                            Suspend 24h
                                          </button>
                                          <button
                                            type="button"
                                            disabled={busy}
                                            onClick={() =>
                                              void handleUserStatusChange(u, 'blocked')
                                            }
                                            className="inline-flex items-center gap-1 rounded-lg border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 px-2 py-1 text-[11px] text-rose-300 whitespace-nowrap"
                                          >
                                            <UserX className="h-3 w-3" />
                                            Block
                                          </button>
                                        </>
                                      ) : (
                                        <button
                                          type="button"
                                          disabled={busy}
                                          onClick={() => void handleUserStatusChange(u, 'active')}
                                          className="inline-flex items-center gap-1 rounded-lg border border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20 px-2 py-1 text-[11px] text-emerald-300 whitespace-nowrap"
                                        >
                                          <UserCheck className="h-3 w-3" />
                                          Restore
                                        </button>
                                      )}
                                      <button
                                        type="button"
                                        disabled={busy}
                                        onClick={() => {
                                          setDeleteTarget(u);
                                          setDeleteConfirmText('');
                                        }}
                                        aria-label={`Delete ${u.email}`}
                                        className="rounded-lg border border-white/10 hover:border-rose-500/40 hover:bg-rose-500/15 p-1.5 text-slate-400 hover:text-rose-300"
                                      >
                                        <Trash2 className="h-3.5 w-3.5" />
                                      </button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* ============================================================== */}
            {/* 3. PREMIUM FEATURE CONTROL                                     */}
            {/* ============================================================== */}
            {activeTab === 'features' && configDraft && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-lg font-semibold text-white">
                      Tier & Premium Feature Controls
                    </h2>
                    <p className="text-xs text-slate-400">
                      Configure capabilities separately for Free users, Premium users, and your Super Admin account.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={savingConfig}
                    onClick={() => void handleSaveConfig()}
                    className="min-h-[38px] inline-flex items-center gap-2 rounded-xl bg-violet-600 hover:bg-violet-500 px-4 text-xs font-semibold text-white whitespace-nowrap shrink-0"
                  >
                    {savingConfig ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Save className="h-3.5 w-3.5" />
                    )}
                    <span>Save Feature Matrix</span>
                  </button>
                </div>

                {/* Paid Image Model Billing Guard */}
                <div className="rounded-xl border border-amber-500/30 bg-amber-500/[0.06] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                      <AlertTriangle className="h-4 w-4 shrink-0" />
                      <span>Paid API Billing Confirmation for Image Generation</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Nano Banana image generation models require a billing-enabled Gemini API key. NOVA AI never presents paid models as free.
                    </p>
                  </div>
                  <label className="flex items-center gap-2 text-xs text-white shrink-0 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={configDraft.paidImageBillingConfirmedByAdmin}
                      onChange={(e) =>
                        setConfigDraft({
                          ...configDraft,
                          paidImageBillingConfirmedByAdmin: e.target.checked,
                        })
                      }
                      className="h-4 w-4 rounded accent-violet-500"
                    />
                    <span>Paid Billing Confirmed</span>
                  </label>
                </div>

                {/* Matrix Table */}
                <div className="rounded-xl border border-white/[0.08] bg-[#141418] overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-white/[0.08] bg-white/[0.02] text-slate-400">
                        <th className="py-3 px-4 font-medium">Feature / Limit</th>
                        <th className="py-3 px-4 font-medium text-center">Free Users</th>
                        <th className="py-3 px-4 font-medium text-center">Premium Users</th>
                        <th className="py-3 px-4 font-medium text-center">Super Admin</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06]">
                      {FEATURE_ROWS.map((row) => (
                        <tr key={row.key}>
                          <td className="py-3 px-4">
                            <div className="font-medium text-white">{row.label}</div>
                            <div className="text-[11px] text-slate-400">{row.hint}</div>
                          </td>
                          {(['free', 'premium', 'admin'] as UserTier[]).map((tier) => (
                            <td key={tier} className="py-3 px-4 text-center">
                              <input
                                type="checkbox"
                                checked={configDraft.features[tier][row.key]}
                                onChange={(e) =>
                                  setConfigDraft({
                                    ...configDraft,
                                    features: {
                                      ...configDraft.features,
                                      [tier]: {
                                        ...configDraft.features[tier],
                                        [row.key]: e.target.checked,
                                      },
                                    },
                                  })
                                }
                                aria-label={`${row.label} for ${tier}`}
                                className="h-4 w-4 rounded accent-violet-500 cursor-pointer"
                              />
                            </td>
                          ))}
                        </tr>
                      ))}
                      <tr>
                        <td className="py-3 px-4">
                          <div className="font-medium text-white">Daily Request Limit</div>
                          <div className="text-[11px] text-slate-400">
                            Max AI turns per day per tier
                          </div>
                        </td>
                        {(['free', 'premium', 'admin'] as UserTier[]).map((tier) => (
                          <td key={tier} className="py-3 px-4 text-center">
                            <input
                              type="number"
                              min={1}
                              max={100000}
                              value={configDraft.features[tier].dailyRequestLimit}
                              onChange={(e) =>
                                setConfigDraft({
                                  ...configDraft,
                                  features: {
                                    ...configDraft.features,
                                    [tier]: {
                                      ...configDraft.features[tier],
                                      dailyRequestLimit: Math.max(1, Number(e.target.value) || 1),
                                    },
                                  },
                                })
                              }
                              className="w-24 rounded-lg border border-white/10 bg-[#0d0d10] px-2 py-1 text-center font-mono text-xs text-white"
                            />
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className="py-3 px-4">
                          <div className="font-medium text-white">Max File Upload (MB)</div>
                          <div className="text-[11px] text-slate-400">Attachment ceiling per file</div>
                        </td>
                        {(['free', 'premium', 'admin'] as UserTier[]).map((tier) => (
                          <td key={tier} className="py-3 px-4 text-center">
                            <input
                              type="number"
                              min={1}
                              max={50}
                              value={configDraft.features[tier].maxUploadMb}
                              onChange={(e) =>
                                setConfigDraft({
                                  ...configDraft,
                                  features: {
                                    ...configDraft.features,
                                    [tier]: {
                                      ...configDraft.features[tier],
                                      maxUploadMb: Math.max(1, Number(e.target.value) || 1),
                                    },
                                  },
                                })
                              }
                              className="w-24 rounded-lg border border-white/10 bg-[#0d0d10] px-2 py-1 text-center font-mono text-xs text-white"
                            />
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* ============================================================== */}
            {/* 4. LIVE APP CUSTOMIZATION                                      */}
            {/* ============================================================== */}
            {activeTab === 'customize' && configDraft && (
              <div className="space-y-6">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="font-display text-lg font-semibold text-white">
                      Live App Customization
                    </h2>
                    <p className="text-xs text-slate-400">
                      Web branding & toggles apply immediately on save; Android launcher/theme changes require a new APK build.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={savingConfig}
                    onClick={() => void handleSaveConfig()}
                    className="min-h-[38px] inline-flex items-center gap-2 rounded-xl bg-violet-600 hover:bg-violet-500 px-4 text-xs font-semibold text-white whitespace-nowrap shrink-0"
                  >
                    {savingConfig ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Save className="h-3.5 w-3.5" />
                    )}
                    <span>Save Web Changes Live</span>
                  </button>
                </div>

                {/* Web Live Branding Section */}
                <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
                    <h3 className="text-sm font-semibold text-white">
                      Web Live Branding & Appearance
                    </h3>
                    <span className="rounded-md bg-emerald-500/15 px-2 py-0.5 text-[11px] font-medium text-emerald-300">
                      Applies Immediately on Web
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <label className="block space-y-1.5 text-xs">
                      <span className="text-slate-300 font-medium">App Name</span>
                      <input
                        type="text"
                        value={configDraft.customization.appName}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              appName: e.target.value,
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 text-white"
                      />
                    </label>

                    <label className="block space-y-1.5 text-xs">
                      <span className="text-slate-300 font-medium">Welcome Heading</span>
                      <input
                        type="text"
                        value={configDraft.customization.welcomeMessage}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              welcomeMessage: e.target.value,
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 text-white"
                      />
                    </label>
                  </div>

                  <label className="block space-y-1.5 text-xs">
                    <span className="text-slate-300 font-medium">App Description</span>
                    <textarea
                      rows={2}
                      value={configDraft.customization.appDescription}
                      onChange={(e) =>
                        setConfigDraft({
                          ...configDraft,
                          customization: {
                            ...configDraft.customization,
                            appDescription: e.target.value,
                          },
                        })
                      }
                      className="w-full rounded-xl border border-white/10 bg-[#0d0d10] p-3 text-white"
                    />
                  </label>

                  {/* Logo, Colors & Chat Appearance */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <div className="space-y-1.5 text-xs">
                      <span className="text-slate-300 font-medium block">Custom Logo</span>
                      <div className="flex items-center gap-2">
                        <label className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-[#0d0d10] hover:bg-white/[0.05] px-3 cursor-pointer text-slate-200">
                          <Upload className="h-3.5 w-3.5" />
                          <span>Upload</span>
                          <input
                            type="file"
                            accept="image/png,image/jpeg,image/webp,image/svg+xml"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (!file || file.size > 250_000) {
                                showToast('err', 'Logo must be under 250 KB.');
                                return;
                              }
                              const reader = new FileReader();
                              reader.onload = () => {
                                setConfigDraft({
                                  ...configDraft,
                                  customization: {
                                    ...configDraft.customization,
                                    logoMode: 'custom',
                                    customLogoDataUrl: String(reader.result || ''),
                                  },
                                });
                              };
                              reader.readAsDataURL(file);
                            }}
                          />
                        </label>
                        {configDraft.customization.logoMode === 'custom' && (
                          <button
                            type="button"
                            onClick={() =>
                              setConfigDraft({
                                ...configDraft,
                                customization: {
                                  ...configDraft.customization,
                                  logoMode: 'nova',
                                  customLogoDataUrl: '',
                                },
                              })
                            }
                            className="text-rose-300 underline"
                          >
                            Reset
                          </button>
                        )}
                      </div>
                    </div>

                    <label className="block space-y-1.5 text-xs">
                      <span className="text-slate-300 font-medium">Primary Color</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={configDraft.customization.primaryColor}
                          onChange={(e) =>
                            setConfigDraft({
                              ...configDraft,
                              customization: {
                                ...configDraft.customization,
                                primaryColor: e.target.value,
                              },
                            })
                          }
                          className="h-9 w-10 rounded-lg border border-white/10 bg-transparent cursor-pointer"
                        />
                        <input
                          type="text"
                          value={configDraft.customization.primaryColor}
                          onChange={(e) =>
                            setConfigDraft({
                              ...configDraft,
                              customization: {
                                ...configDraft.customization,
                                primaryColor: e.target.value,
                              },
                            })
                          }
                          className="min-w-0 flex-1 min-h-[36px] rounded-lg border border-white/10 bg-[#0d0d10] px-2 font-mono text-xs text-white"
                        />
                      </div>
                    </label>

                    <label className="block space-y-1.5 text-xs">
                      <span className="text-slate-300 font-medium">Default Theme</span>
                      <select
                        value={configDraft.customization.defaultTheme}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              defaultTheme: e.target.value as 'dark' | 'light',
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 text-white"
                      >
                        <option value="dark">Dark</option>
                        <option value="light">Light</option>
                      </select>
                    </label>

                    <label className="block space-y-1.5 text-xs">
                      <span className="text-slate-300 font-medium">Chat Appearance</span>
                      <select
                        value={configDraft.customization.chatBubbleStyle}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              chatBubbleStyle: e.target.value as
                                | 'rounded'
                                | 'compact'
                                | 'glass',
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 text-white"
                      >
                        <option value="rounded">Modern Rounded</option>
                        <option value="compact">Compact Dense</option>
                        <option value="glass">Glass Surface</option>
                      </select>
                    </label>
                  </div>

                  {/* Sidebar Feature Visibility */}
                  <div className="pt-2 border-t border-white/[0.06] space-y-2">
                    <div className="text-xs font-medium text-slate-300">
                      Sidebar Navigation & Mode Visibility
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                      {(
                        [
                          ['createVisual', 'Create a Visual'],
                          ['imageAssistant', 'Image Assistant'],
                          ['library', 'Library'],
                          ['studyMode', 'Study Mode'],
                          ['codingMode', 'Coding Mode'],
                          ['writingMode', 'Writing Mode'],
                        ] as const
                      ).map(([k, lbl]) => (
                        <label
                          key={k}
                          className="flex items-center gap-2 rounded-xl border border-white/[0.08] bg-[#0d0d10] px-3 py-2 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={configDraft.customization.sidebarItems[k]}
                            onChange={(e) =>
                              setConfigDraft({
                                ...configDraft,
                                customization: {
                                  ...configDraft.customization,
                                  sidebarItems: {
                                    ...configDraft.customization.sidebarItems,
                                    [k]: e.target.checked,
                                  },
                                },
                              })
                            }
                            className="h-4 w-4 rounded accent-violet-500"
                          />
                          <span>{lbl}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Announcement Banner & Maintenance Mode */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-white/[0.06]">
                    <div className="space-y-2 rounded-xl border border-white/[0.08] bg-[#0d0d10] p-3.5 text-xs">
                      <label className="flex items-center justify-between font-medium text-white cursor-pointer">
                        <span>Announcement Banner</span>
                        <input
                          type="checkbox"
                          checked={configDraft.customization.announcement.enabled}
                          onChange={(e) =>
                            setConfigDraft({
                              ...configDraft,
                              customization: {
                                ...configDraft.customization,
                                announcement: {
                                  ...configDraft.customization.announcement,
                                  enabled: e.target.checked,
                                },
                              },
                            })
                          }
                          className="h-4 w-4 rounded accent-violet-500"
                        />
                      </label>
                      <input
                        type="text"
                        placeholder="Banner message shown to all users..."
                        value={configDraft.customization.announcement.text}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              announcement: {
                                ...configDraft.customization.announcement,
                                text: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full min-h-[36px] rounded-lg border border-white/10 bg-[#141418] px-2.5 text-white"
                      />
                      <select
                        value={configDraft.customization.announcement.severity}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              announcement: {
                                ...configDraft.customization.announcement,
                                severity: e.target.value as 'info' | 'warning' | 'critical',
                              },
                            },
                          })
                        }
                        className="w-full min-h-[34px] rounded-lg border border-white/10 bg-[#141418] px-2.5 text-slate-200"
                      >
                        <option value="info">Info (Blue/Cyan)</option>
                        <option value="warning">Warning (Amber)</option>
                        <option value="critical">Critical (Rose)</option>
                      </select>
                    </div>

                    <div className="space-y-2 rounded-xl border border-rose-500/20 bg-rose-500/[0.04] p-3.5 text-xs">
                      <label className="flex items-center justify-between font-medium text-white cursor-pointer">
                        <span>Maintenance Mode (Admin Bypasses)</span>
                        <input
                          type="checkbox"
                          checked={configDraft.customization.maintenanceMode}
                          onChange={(e) =>
                            setConfigDraft({
                              ...configDraft,
                              customization: {
                                ...configDraft.customization,
                                maintenanceMode: e.target.checked,
                              },
                            })
                          }
                          className="h-4 w-4 rounded accent-rose-500"
                        />
                      </label>
                      <textarea
                        rows={3}
                        value={configDraft.customization.maintenanceMessage}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              maintenanceMessage: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-lg border border-white/10 bg-[#141418] p-2.5 text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Android Native Settings (Requires New APK Build) */}
                <div className="rounded-xl border border-amber-500/25 bg-[#141418] p-5 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
                    <div className="flex items-center gap-2">
                      <Smartphone className="h-4 w-4 text-amber-400" />
                      <h3 className="text-sm font-semibold text-white">
                        Android Native App Branding
                      </h3>
                    </div>
                    <span className="rounded-md bg-amber-500/15 px-2 py-0.5 text-[11px] font-medium text-amber-300">
                      Requires New APK Build to Ship to Devices
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                    <label className="block space-y-1.5">
                      <span className="text-slate-300 font-medium">Android App Name</span>
                      <input
                        type="text"
                        value={configDraft.customization.android.appName}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              android: {
                                ...configDraft.customization.android,
                                appName: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 text-white"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-slate-300 font-medium">Launcher Accent Hex</span>
                      <input
                        type="text"
                        value={configDraft.customization.android.launcherColor}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              android: {
                                ...configDraft.customization.android,
                                launcherColor: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 font-mono text-white"
                      />
                    </label>
                    <label className="block space-y-1.5">
                      <span className="text-slate-300 font-medium">Splash Screen Hex</span>
                      <input
                        type="text"
                        value={configDraft.customization.android.splashBackground}
                        onChange={(e) =>
                          setConfigDraft({
                            ...configDraft,
                            customization: {
                              ...configDraft.customization,
                              android: {
                                ...configDraft.customization.android,
                                splashBackground: e.target.value,
                              },
                            },
                          })
                        }
                        className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 font-mono text-white"
                      />
                    </label>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <span className="text-[11px] text-slate-400">
                      Last synced to `android/app/src/main/res/`:{' '}
                      {formatDateTime(configDraft.customization.android.lastSyncedAt)}
                    </span>
                    <button
                      type="button"
                      disabled={syncingAndroid}
                      onClick={() => void handleSyncAndroid()}
                      className="min-h-[38px] inline-flex items-center gap-2 rounded-xl border border-amber-500/40 bg-amber-500/15 hover:bg-amber-500/25 px-4 text-xs font-semibold text-amber-200 whitespace-nowrap"
                    >
                      {syncingAndroid ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Smartphone className="h-3.5 w-3.5" />
                      )}
                      <span>Sync to Android Source Files</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* ============================================================== */}
            {/* 5. SUPER POWER — CENTRAL NOVA AI MANAGEMENT SYSTEM             */}
            {/* ============================================================== */}
            {activeTab === 'super-power' && (
              <SuperPowerSection
                onPublicConfigUpdated={onConfigUpdated}
                onAuditRefresh={async () => {
                  const res = await fetchBackendAuditLogs().catch(() => null);
                  if (res) setBackendAudits(res.logs);
                }}
                onWorkspaceMutated={async () => {
                  const [bakRes, treeRes, gitRes] = await Promise.all([
                    fetchBackupSnapshots().catch(() => null),
                    fetchWorkspaceTree().catch(() => null),
                    fetchGitStatus().catch(() => null),
                  ]);
                  if (bakRes) setBackups(bakRes.backups);
                  if (treeRes) setFileTree(treeRes.tree);
                  if (gitRes) setGitStatus(gitRes.git);
                }}
                onToast={showToast}
              />
            )}

            {/* ============================================================== */}
            {/* 6. DIRECT CODE EDITOR                                          */}
            {/* ============================================================== */}
            {activeTab === 'editor' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="font-display text-lg font-semibold text-white">
                      Direct Code Editor &amp; Rollback
                    </h2>
                    <p className="text-xs text-slate-400">
                      Protected files (.env, firebase-applet-config.json, firestore.rules, package.json, adminAuth.ts) are locked against modification.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        const res = await runWorkspaceValidation();
                        setLastValidation(res.validation);
                        showToast(
                          res.validation.ok ? 'ok' : 'err',
                          res.validation.ok ? 'TypeScript check passed.' : 'TypeScript reported errors.'
                        );
                      }}
                      className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] px-3 text-xs font-medium text-slate-200 whitespace-nowrap"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" />
                      <span>Run tsc --noEmit</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                  {/* File Explorer */}
                  <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-2.5 max-h-[540px] overflow-y-auto">
                    <div className="px-2 pb-2 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                      Workspace Files
                    </div>
                    {fileTree.map((node) => (
                      <FileTreeItem
                        key={node.path}
                        node={node}
                        depth={0}
                        selectedPath={selectedFilePath}
                        expandedDirs={expandedDirs}
                        onToggleDir={(p) =>
                          setExpandedDirs((prev) => {
                            const next = new Set(prev);
                            if (next.has(p)) next.delete(p);
                            else next.add(p);
                            return next;
                          })
                        }
                        onSelectFile={(p) => void handleOpenFile(p)}
                      />
                    ))}
                  </div>

                  {/* Editor Pane */}
                  <div className="lg:col-span-3 rounded-xl border border-white/[0.08] bg-[#141418] flex flex-col overflow-hidden">
                    {!selectedFilePath ? (
                      <div className="h-96 flex items-center justify-center text-xs text-slate-500">
                        Select a file from the left tree to view or edit.
                      </div>
                    ) : editorLoading ? (
                      <div className="h-96 flex items-center justify-center gap-2 text-xs text-slate-400">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Loading {selectedFilePath}...</span>
                      </div>
                    ) : (
                      <>
                        <div className="px-3 py-2.5 border-b border-white/[0.08] flex flex-wrap items-center justify-between gap-2 bg-white/[0.02]">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="font-mono text-xs text-white truncate">
                              {selectedFilePath}
                            </span>
                            {editorProtected && (
                              <span className="inline-flex items-center gap-1 rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-amber-300">
                                <Lock className="h-3 w-3" /> PROTECTED
                              </span>
                            )}
                            {editorContent !== originalFileContent && (
                              <span className="rounded bg-violet-500/20 px-1.5 py-0.5 text-[10px] text-violet-300">
                                Modified
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              disabled={editorContent === originalFileContent}
                              onClick={() => void handlePreviewEditorDiff()}
                              className="min-h-[32px] rounded-lg border border-white/10 hover:bg-white/[0.08] disabled:opacity-40 px-2.5 text-xs text-slate-200"
                            >
                              Diff Preview
                            </button>
                            <button
                              type="button"
                              disabled={
                                editorProtected ||
                                editorSaving ||
                                editorContent === originalFileContent
                              }
                              onClick={() => void handleSaveEditorFile()}
                              className="min-h-[32px] inline-flex items-center gap-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 disabled:opacity-40 px-3 text-xs font-semibold text-white"
                            >
                              {editorSaving ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                              ) : (
                                <Save className="h-3.5 w-3.5" />
                              )}
                              <span>Save + Backup</span>
                            </button>
                          </div>
                        </div>

                        {/* Search & Replace Bar */}
                        {!editorProtected && (
                          <div className="px-3 py-2 border-b border-white/[0.06] flex flex-wrap items-center gap-2 bg-[#101014]">
                            <input
                              type="text"
                              value={findText}
                              onChange={(e) => setFindText(e.target.value)}
                              placeholder="Find..."
                              className="min-h-[30px] w-40 rounded-lg border border-white/10 bg-[#141418] px-2 text-xs text-white"
                            />
                            <input
                              type="text"
                              value={replaceText}
                              onChange={(e) => setReplaceText(e.target.value)}
                              placeholder="Replace with..."
                              className="min-h-[30px] w-40 rounded-lg border border-white/10 bg-[#141418] px-2 text-xs text-white"
                            />
                            <button
                              type="button"
                              disabled={!findText}
                              onClick={() =>
                                setEditorContent((prev) =>
                                  findText ? prev.replaceAll(findText, replaceText) : prev
                                )
                              }
                              className="min-h-[30px] rounded-lg border border-white/10 hover:bg-white/[0.08] disabled:opacity-40 px-2.5 text-xs text-slate-200"
                            >
                              Replace All
                            </button>
                          </div>
                        )}

                        {diffPreview ? (
                          <div className="p-3 space-y-2 max-h-[430px] overflow-y-auto bg-[#0d0d10]">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-mono text-slate-300">
                                +{diffPreview.stats.added} / -{diffPreview.stats.removed}
                              </span>
                              <button
                                type="button"
                                onClick={() => setDiffPreview(null)}
                                className="text-violet-300 underline"
                              >
                                Back to Editor
                              </button>
                            </div>
                            <div className="font-mono text-[11px] leading-5">
                              {diffPreview.diffLines.map((line, i) => (
                                <div
                                  key={i}
                                  className={`px-2 whitespace-pre-wrap break-all ${
                                    line.type === 'add'
                                      ? 'bg-emerald-500/15 text-emerald-200'
                                      : line.type === 'remove'
                                        ? 'bg-rose-500/15 text-rose-200'
                                        : 'text-slate-400'
                                  }`}
                                >
                                  {line.type === 'add' ? '+ ' : line.type === 'remove' ? '- ' : '  '}
                                  {line.text}
                                </div>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <textarea
                            value={editorContent}
                            readOnly={editorProtected}
                            onChange={(e) => setEditorContent(e.target.value)}
                            spellCheck={false}
                            className="w-full h-[430px] bg-[#0d0d10] p-3 font-mono text-xs leading-5 text-slate-100 focus:outline-none resize-none"
                          />
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Backups & Rollback List */}
                <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                  <h3 className="text-sm font-semibold text-white">
                    Automatic Backup Snapshots ({backups.length})
                  </h3>
                  {backups.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      Backups are automatically created whenever you save in the Code Editor, apply AI updates, or sync Android source files.
                    </p>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto">
                      {backups.map((b) => (
                        <div
                          key={b.id}
                          className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-white/[0.06] bg-[#0d0d10] px-3 py-2 text-xs"
                        >
                          <div className="min-w-0">
                            <div className="font-medium text-white truncate">{b.reason}</div>
                            <div className="font-mono text-[11px] text-slate-400">
                              {b.id} · {formatDateTime(b.createdAt)} ·{' '}
                              {b.files.map((f) => f.path).join(', ')}
                            </div>
                          </div>
                          <button
                            type="button"
                            disabled={rollingBackId === b.id}
                            onClick={() => void handleRollback(b.id)}
                            className="min-h-[30px] inline-flex items-center gap-1 rounded-lg border border-amber-500/35 bg-amber-500/10 hover:bg-amber-500/20 px-2.5 text-[11px] font-medium text-amber-200 whitespace-nowrap"
                          >
                            <RotateCcw className="h-3 w-3" />
                            <span>Restore</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ============================================================== */}
            {/* 7. REAL PROJECT UPDATE SYSTEM (GIT / GITHUB / BUILD)           */}
            {/* ============================================================== */}
            {activeTab === 'git' && (
              <div className="space-y-5">
                <div>
                  <h2 className="font-display text-lg font-semibold text-white">
                    Project Updates, Build Validation &amp; GitHub
                  </h2>
                  <p className="text-xs text-slate-400">
                    Real workspace Git status, lint/build verification, and optional GitHub branch push (no simulated deployments).
                  </p>
                </div>

                {gitStatus && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3 text-xs">
                      <h3 className="text-sm font-semibold text-white">Repository Status</h3>
                      <div className="space-y-2">
                        <div className="flex justify-between py-1 border-b border-white/[0.06]">
                          <span className="text-slate-400">Git CLI / Repo</span>
                          <span className="font-mono text-white">
                            {gitStatus.gitAvailable
                              ? gitStatus.isGitRepo
                                ? `Active (${gitStatus.branch})`
                                : 'No .git repository'
                              : 'Git CLI not installed'}
                          </span>
                        </div>
                        <div className="flex justify-between py-1 border-b border-white/[0.06]">
                          <span className="text-slate-400">Working Tree</span>
                          <span className={gitStatus.clean ? 'text-emerald-400' : 'text-amber-300'}>
                            {gitStatus.clean
                              ? 'Clean'
                              : `${gitStatus.changedFiles.length} changed file(s)`}
                          </span>
                        </div>
                        <div className="flex justify-between py-1">
                          <span className="text-slate-400">GitHub Integration</span>
                          <span
                            className={
                              gitStatus.githubConfigured ? 'text-emerald-400' : 'text-slate-400'
                            }
                          >
                            {gitStatus.githubConfigured
                              ? `Token configured (${gitStatus.githubRepo || 'origin'})`
                              : 'GITHUB_TOKEN not set'}
                          </span>
                        </div>
                      </div>
                      {gitStatus.notes.map((n, i) => (
                        <div
                          key={i}
                          className="rounded-lg border border-amber-500/20 bg-amber-500/10 p-2.5 text-[11px] text-amber-200"
                        >
                          {n}
                        </div>
                      ))}
                    </div>

                    <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3 text-xs">
                      <h3 className="text-sm font-semibold text-white">Build &amp; Git Actions</h3>
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          disabled={Boolean(gitBusy)}
                          onClick={async () => {
                            setGitBusy('build');
                            try {
                              const res = await runGitBuildSuiteRemote();
                              setBuildResult(res);
                              showToast(
                                res.lint.ok && res.build.ok ? 'ok' : 'err',
                                res.lint.ok && res.build.ok
                                  ? 'npm run lint and npm run build both passed.'
                                  : 'Build validation reported issues.'
                              );
                            } finally {
                              setGitBusy(null);
                            }
                          }}
                          className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 px-3.5 text-xs font-semibold text-white"
                        >
                          {gitBusy === 'build' ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <Play className="h-3.5 w-3.5" />
                          )}
                          <span>Run Lint &amp; Production Build</span>
                        </button>
                      </div>

                      {gitStatus.isGitRepo && (
                        <div className="space-y-2 pt-2 border-t border-white/[0.06]">
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={gitBranchInput}
                              onChange={(e) => setGitBranchInput(e.target.value)}
                              placeholder="Branch name..."
                              className="flex-1 min-h-[34px] rounded-lg border border-white/10 bg-[#0d0d10] px-2.5 font-mono text-xs text-white"
                            />
                            <button
                              type="button"
                              disabled={Boolean(gitBusy)}
                              onClick={async () => {
                                setGitBusy('branch');
                                try {
                                  const r = await createGitBranchRemote(gitBranchInput);
                                  setGitOutput(r.output);
                                  setGitStatus((await fetchGitStatus()).git);
                                } catch (e) {
                                  setGitOutput(e instanceof Error ? e.message : 'Error');
                                } finally {
                                  setGitBusy(null);
                                }
                              }}
                              className="min-h-[34px] rounded-lg border border-white/10 hover:bg-white/[0.08] px-3 text-xs text-slate-200 whitespace-nowrap"
                            >
                              Checkout Branch
                            </button>
                          </div>

                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={gitCommitMsg}
                              onChange={(e) => setGitCommitMsg(e.target.value)}
                              placeholder="Commit message..."
                              className="flex-1 min-h-[34px] rounded-lg border border-white/10 bg-[#0d0d10] px-2.5 text-xs text-white"
                            />
                            <button
                              type="button"
                              disabled={Boolean(gitBusy) || !gitCommitMsg.trim()}
                              onClick={async () => {
                                setGitBusy('commit');
                                try {
                                  const r = await commitGitChangesRemote(gitCommitMsg);
                                  setGitOutput(r.output);
                                  setGitCommitMsg('');
                                  setGitStatus((await fetchGitStatus()).git);
                                } catch (e) {
                                  setGitOutput(e instanceof Error ? e.message : 'Error');
                                } finally {
                                  setGitBusy(null);
                                }
                              }}
                              className="min-h-[34px] inline-flex items-center gap-1 rounded-lg border border-white/10 hover:bg-white/[0.08] px-3 text-xs text-slate-200 whitespace-nowrap"
                            >
                              <GitCommit className="h-3.5 w-3.5" />
                              <span>Commit</span>
                            </button>
                          </div>

                          <button
                            type="button"
                            disabled={Boolean(gitBusy) || !gitStatus.githubConfigured}
                            onClick={async () => {
                              setGitBusy('push');
                              try {
                                const r = await pushGitHubRemote(gitStatus.branch);
                                setGitOutput(r.output);
                              } finally {
                                setGitBusy(null);
                              }
                            }}
                            className="w-full min-h-[36px] rounded-xl border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 disabled:opacity-40 text-xs font-medium text-cyan-200"
                          >
                            Push Current Branch to GitHub
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {buildResult && (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {[buildResult.lint, buildResult.build].map((step) => (
                      <div
                        key={step.command}
                        className={`rounded-xl border p-3.5 text-xs space-y-2 ${
                          step.ok
                            ? 'border-emerald-500/30 bg-emerald-500/[0.07]'
                            : 'border-rose-500/30 bg-rose-500/[0.07]'
                        }`}
                      >
                        <div className="flex items-center justify-between font-semibold">
                          <span>{step.command}</span>
                          <span className="font-mono">
                            {step.ok ? 'PASS' : 'FAIL'} · {step.durationMs}ms
                          </span>
                        </div>
                        <pre className="whitespace-pre-wrap font-mono text-[11px] max-h-48 overflow-y-auto text-slate-200">
                          {step.output}
                        </pre>
                      </div>
                    ))}
                  </div>
                )}

                {gitOutput && (
                  <pre className="rounded-xl border border-white/[0.08] bg-[#141418] p-3.5 font-mono text-xs text-slate-200 whitespace-pre-wrap">
                    {gitOutput}
                  </pre>
                )}
              </div>
            )}

            {/* ============================================================== */}
            {/* 8. AUDIT LOGS                                                  */}
            {/* ============================================================== */}
            {activeTab === 'audit' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                  <h3 className="text-sm font-semibold text-white">
                    Account Directory Audit Logs (Firestore)
                  </h3>
                  {firestoreAudits.length === 0 ? (
                    <p className="text-xs text-slate-500 py-4">No user admin actions recorded yet.</p>
                  ) : (
                    <div className="space-y-2 max-h-[480px] overflow-y-auto">
                      {firestoreAudits.map((log) => (
                        <div
                          key={log.id}
                          className="rounded-lg border border-white/[0.06] bg-[#0d0d10] px-3 py-2 text-xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono font-semibold text-violet-300">
                              {log.action}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              {formatDateTime(log.createdAt)}
                            </span>
                          </div>
                          <p className="mt-0.5 text-slate-300">{log.details}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-4 space-y-3">
                  <h3 className="text-sm font-semibold text-white">
                    Config, Code &amp; Deployment Audit Logs (Server)
                  </h3>
                  {backendAudits.length === 0 ? (
                    <p className="text-xs text-slate-500 py-4">No server admin actions recorded yet.</p>
                  ) : (
                    <div className="space-y-2 max-h-[480px] overflow-y-auto">
                      {backendAudits.map((log) => (
                        <div
                          key={log.id}
                          className="rounded-lg border border-white/[0.06] bg-[#0d0d10] px-3 py-2 text-xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-mono font-semibold text-cyan-300">
                              {log.action}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              {formatDateTime(log.timestamp)}
                            </span>
                          </div>
                          <p className="mt-0.5 text-slate-300">{log.details}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Secure User Delete Confirmation Modal */}
      {deleteTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
          onClick={() => setDeleteTarget(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl border border-rose-500/30 bg-[#141418] p-5 space-y-4"
          >
            <h3 className="font-display text-base font-semibold text-white">
              Confirm Account Directory Deletion
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              This permanently deletes the account directory record for{' '}
              <span className="font-mono text-white">{deleteTarget.email}</span>. Type{' '}
              <span className="font-mono font-semibold text-rose-300">DELETE</span> to confirm.
            </p>
            <input
              type="text"
              value={deleteConfirmText}
              onChange={(e) => setDeleteConfirmText(e.target.value)}
              placeholder="Type DELETE"
              className="w-full min-h-[38px] rounded-xl border border-white/10 bg-[#0d0d10] px-3 font-mono text-xs text-white"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                className="min-h-[36px] rounded-xl border border-white/10 px-4 text-xs text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deleteConfirmText.trim() !== 'DELETE'}
                onClick={() => void handleConfirmDeleteUser()}
                className="min-h-[36px] rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-40 px-4 text-xs font-semibold text-white"
              >
                Delete Account Directory
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Paid Image API Billing Confirmation Modal */}
      {billingConfirmModal && configDraft && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"
          onClick={() => setBillingConfirmModal(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl border border-amber-500/35 bg-[#141418] p-5 space-y-4"
          >
            <div className="flex items-center gap-2 text-amber-300">
              <AlertTriangle className="h-5 w-5" />
              <h3 className="font-display text-base font-semibold text-white">
                Confirm Paid Image API Billing
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              You enabled AI Image Generation (`imageGeneration`) for Free or Premium users. Google Gemini Nano Banana models require a billing-enabled API key. Confirm that you understand paid charges may apply before saving.
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setBillingConfirmModal(false)}
                className="min-h-[36px] rounded-xl border border-white/10 px-4 text-xs text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setBillingConfirmModal(false);
                  const confirmed: AdminConfigDocument = {
                    ...configDraft,
                    paidImageBillingConfirmedByAdmin: true,
                  };
                  setConfigDraft(confirmed);
                  void handleSaveConfig(confirmed);
                }}
                className="min-h-[36px] rounded-xl bg-amber-600 hover:bg-amber-500 px-4 text-xs font-semibold text-white"
              >
                Confirm Billing &amp; Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
