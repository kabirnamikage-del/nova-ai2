import {
  useEffect,
  useRef,
  useState,
  type ClipboardEvent,
  type DragEvent,
  type KeyboardEvent,
} from 'react';
import {
  ArrowUp,
  ExternalLink,
  FileCode,
  FileText,
  Globe,
  ImagePlus,
  Loader2,
  Mic,
  MicOff,
  Paperclip,
  Sparkles,
  Square,
  X,
} from 'lucide-react';
import { transcribeAudioBlob } from '../lib/api.ts';
import { ASSISTANT_MODES, MODE_LIST } from '../lib/modes.ts';
import type {
  ApiErrorInfo,
  AssistantMode,
  ChatAttachment,
} from '../types/chat.ts';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface ChatComposerProps {
  mode: AssistantMode;
  onChangeMode: (mode: AssistantMode) => void;
  useWebSearch: boolean;
  onToggleWebSearch: () => void;
  searchGroundingSupported: boolean;
  imageMode?: boolean;
  onToggleImageMode?: () => void;
  isTemporaryChat: boolean;
  isStreaming: boolean;
  disabled: boolean;
  speechLang: 'auto' | 'en-US' | 'bn-BD';
  onSend: (text: string, attachments: ChatAttachment[]) => void;
  onStop: () => void;
  onVoiceError: (err: ApiErrorInfo) => void;
}

const MAX_FILE_BYTES = 8 * 1024 * 1024; // 8 MB per file

const TEXT_EXTENSIONS = [
  '.txt',
  '.md',
  '.csv',
  '.json',
  '.ts',
  '.tsx',
  '.js',
  '.jsx',
  '.py',
  '.html',
  '.css',
  '.sql',
  '.xml',
  '.yaml',
  '.yml',
];

function isTextFile(file: File): boolean {
  if (file.type.startsWith('text/')) return true;
  if (
    file.type === 'application/json' ||
    file.type === 'application/javascript'
  ) {
    return true;
  }
  const lower = file.name.toLowerCase();
  return TEXT_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

async function fileToAttachment(file: File): Promise<ChatAttachment> {
  if (file.size > MAX_FILE_BYTES) {
    throw new Error(`"${file.name}" exceeds the 8 MB file size limit.`);
  }

  const lowerName = file.name.toLowerCase();
  const isImageMime =
    file.type === 'image/jpeg' ||
    file.type === 'image/jpg' ||
    file.type === 'image/png' ||
    file.type === 'image/webp' ||
    /\.(jpg|jpeg|png|webp)$/i.test(lowerName);

  if (isImageMime || file.type.startsWith('image/')) {
    const normalizedMime =
      file.type === 'image/jpg' || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')
        ? 'image/jpeg'
        : file.type === 'image/png' || lowerName.endsWith('.png')
          ? 'image/png'
          : file.type === 'image/webp' || lowerName.endsWith('.webp')
            ? 'image/webp'
            : '';
    if (!normalizedMime) {
      throw new Error(
        `Unsupported image format "${file.name}". Please upload JPG, JPEG, PNG, or WEBP.`
      );
    }
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result ?? ''));
      reader.onerror = () => reject(new Error(`Could not read "${file.name}".`));
      reader.readAsDataURL(file);
    });
    const commaIndex = dataUrl.indexOf(',');
    const base64 = commaIndex >= 0 ? dataUrl.slice(commaIndex + 1) : dataUrl;
    return {
      id: crypto.randomUUID(),
      name: file.name || 'image.png',
      mimeType: normalizedMime,
      data: base64,
      size: file.size,
      kind: 'image',
    };
  }

  if (
    file.type === 'application/pdf' ||
    file.name.toLowerCase().endsWith('.pdf')
  ) {
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result ?? ''));
      reader.onerror = () => reject(new Error(`Could not read "${file.name}".`));
      reader.readAsDataURL(file);
    });
    const commaIndex = dataUrl.indexOf(',');
    const base64 = commaIndex >= 0 ? dataUrl.slice(commaIndex + 1) : dataUrl;
    return {
      id: crypto.randomUUID(),
      name: file.name || 'document.pdf',
      mimeType: 'application/pdf',
      data: base64,
      size: file.size,
      kind: 'pdf',
    };
  }

  if (isTextFile(file)) {
    const textContent = await file.text();
    return {
      id: crypto.randomUUID(),
      name: file.name || 'note.txt',
      mimeType: file.type || 'text/plain',
      data: textContent,
      size: file.size,
      kind: 'text',
    };
  }

  throw new Error(
    `Unsupported file "${file.name}". Attach images, PDFs, or text/code files.`
  );
}

export function ChatComposer({
  mode,
  onChangeMode,
  useWebSearch,
  onToggleWebSearch,
  searchGroundingSupported,
  imageMode = false,
  onToggleImageMode,
  isTemporaryChat,
  isStreaming,
  disabled,
  speechLang,
  onSend,
  onStop,
  onVoiceError,
}: ChatComposerProps) {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [interimText, setInterimText] = useState('');

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 168)}px`;
  }, [text]);

  useEffect(() => {
    return () => {
      try {
        recognitionRef.current?.stop();
      } catch {
        // Ignore
      }
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== 'inactive'
      ) {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const addFiles = async (files: FileList | File[]) => {
    const list = Array.from(files);
    const added: ChatAttachment[] = [];
    for (const file of list) {
      try {
        const att = await fileToAttachment(file);
        added.push(att);
      } catch (err) {
        onVoiceError({
          code: 'INVALID_ATTACHMENT',
          title: 'File Attachment Error',
          message:
            err instanceof Error ? err.message : 'Unable to attach file.',
          hint: 'Use images, PDFs, or text/code files under 8 MB.',
        });
      }
    }
    if (added.length > 0) {
      setAttachments((prev) => [...prev, ...added].slice(0, 4));
    }
  };

  const handlePaste = async (e: ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    const imageFiles: File[] = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.startsWith('image/')) {
        const f = item.getAsFile();
        if (f) imageFiles.push(f);
      }
    }
    if (imageFiles.length > 0) {
      e.preventDefault();
      await addFiles(imageFiles);
    }
  };

  const handleDrop = async (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files?.length) {
      await addFiles(e.dataTransfer.files);
    }
  };

  const handleSubmit = () => {
    if (isStreaming || disabled) return;
    const trimmed = text.trim();
    if (!trimmed && attachments.length === 0) return;
    onSend(trimmed, attachments);
    setText('');
    setAttachments([]);
    setInterimText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const stopVoiceInput = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {
        // Ignore
      }
      recognitionRef.current = null;
    }
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== 'inactive'
    ) {
      mediaRecorderRef.current.stop();
    }
    setIsListening(false);
    setInterimText('');
  };

  const startVoiceInput = async () => {
    if (isListening) {
      stopVoiceInput();
      return;
    }

    const win = window as unknown as {
      SpeechRecognition?: new () => SpeechRecognitionLike;
      webkitSpeechRecognition?: new () => SpeechRecognitionLike;
    };
    const SpeechRec = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (SpeechRec) {
      try {
        const rec = new SpeechRec();
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang =
          speechLang === 'auto'
            ? mode === 'study'
              ? 'bn-BD'
              : navigator.language || 'en-US'
            : speechLang;

        let finalBuffer = '';
        rec.onresult = (event) => {
          let interim = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const res = event.results[i];
            const transcript = res[0]?.transcript ?? '';
            if (res.isFinal) {
              finalBuffer += (finalBuffer ? ' ' : '') + transcript.trim();
            } else {
              interim += transcript;
            }
          }
          if (finalBuffer) {
            setText((prev) =>
              prev ? `${prev.trimEnd()} ${finalBuffer}` : finalBuffer
            );
            finalBuffer = '';
          }
          setInterimText(interim);
        };

        rec.onerror = (event) => {
          setIsListening(false);
          setInterimText('');
          if (
            event.error === 'not-allowed' ||
            event.error === 'service-not-allowed'
          ) {
            onVoiceError({
              code: 'MIC_PERMISSION',
              title: 'Microphone Permission Denied',
              message: 'NOVA AI does not have permission to access your microphone.',
              hint: 'Allow microphone access in your browser site settings and try again.',
            });
          } else if (event.error !== 'aborted' && event.error !== 'no-speech') {
            onVoiceError({
              code: 'SPEECH_ERROR',
              title: 'Voice Input Error',
              message: `Speech recognition stopped (${event.error ?? 'unknown'}).`,
              hint: 'Try speaking closer to the microphone or type your message.',
            });
          }
        };

        rec.onend = () => {
          setIsListening(false);
          setInterimText('');
          recognitionRef.current = null;
        };

        recognitionRef.current = rec;
        rec.start();
        setIsListening(true);
        return;
      } catch {
        // Fall through to MediaRecorder transcription fallback
      }
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      onVoiceError({
        code: 'MIC_UNSUPPORTED',
        title: 'Voice Input Unsupported',
        message: 'This browser does not support microphone recording.',
        hint: 'Try Chrome, Edge, or Android Chrome for voice input.',
      });
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) audioChunksRef.current.push(ev.data);
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, {
          type: recorder.mimeType || 'audio/webm',
        });
        if (blob.size < 500) return;

        setIsTranscribing(true);
        const result = await transcribeAudioBlob(blob, speechLang);
        setIsTranscribing(false);

        if (result.error) {
          onVoiceError(result.error);
        } else if (result.text) {
          setText((prev) =>
            prev ? `${prev.trimEnd()} ${result.text}` : result.text!
          );
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsListening(true);
    } catch {
      onVoiceError({
        code: 'MIC_PERMISSION',
        title: 'Microphone Access Unavailable',
        message: 'Could not access microphone for voice recording.',
        hint: 'Grant microphone permission in browser settings and try again.',
      });
    }
  };

  const canSend =
    !isStreaming &&
    !disabled &&
    (text.trim().length > 0 || attachments.length > 0);

  return (
    <div className="shrink-0 bg-slate-50/95 dark:bg-[#141418]/95 backdrop-blur-md px-3 sm:px-6 pt-2 pb-safe">
      <div className="mx-auto max-w-3xl space-y-2 pb-2">
        {isTemporaryChat && (
          <div className="text-center text-xs text-slate-500 dark:text-slate-400">
            Temporary chat active — messages are not saved to local history
          </div>
        )}

        {/* Mode Switcher + Search Grounding Control */}
        <div className="flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
          <div
            role="tablist"
            aria-label="Assistant mode"
            className="inline-flex items-center gap-1 rounded-xl bg-slate-200/75 dark:bg-[#1b1b20] p-1 border border-slate-200 dark:border-white/[0.06]"
          >
            {MODE_LIST.map((m) => {
              const active = m.id === mode;
              return (
                <button
                  key={m.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => onChangeMode(m.id)}
                  className={`min-h-[34px] rounded-lg px-2.5 sm:px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-white dark:bg-[#2a2a32] text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <span className="sm:hidden">{m.shortLabel}</span>
                  <span className="hidden sm:inline">{m.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onToggleImageMode && (
              <button
                type="button"
                onClick={onToggleImageMode}
                aria-pressed={imageMode}
                title="Generate or edit images inside this chat using Nano Banana (requires paid API billing confirmation)"
                className={`min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  imageMode
                    ? 'border-amber-500/60 bg-amber-500/15 text-amber-800 dark:text-amber-300'
                    : 'border-slate-200 dark:border-white/10 bg-white dark:bg-[#1b1b20] text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>{imageMode ? 'Image Mode (Paid)' : 'Image Mode'}</span>
              </button>
            )}

            {searchGroundingSupported && !imageMode && (
              <button
                type="button"
                onClick={onToggleWebSearch}
                aria-pressed={useWebSearch}
                title="Ground answers with live Google Search"
                className={`min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border px-3 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  useWebSearch
                    ? 'border-cyan-500/50 bg-cyan-500/12 dark:bg-cyan-500/20 text-cyan-700 dark:text-cyan-300'
                    : 'border-slate-200 dark:border-white/10 bg-white dark:bg-[#1b1b20] text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Globe className="h-3.5 w-3.5" />
                <span>Web Search</span>
              </button>
            )}
          </div>
        </div>

        {/* Main Input Card */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`rounded-3xl border transition-colors bg-white dark:bg-[#1b1b20] shadow-sm ${
            isDragging
              ? 'border-cyan-500 ring-2 ring-cyan-500/25'
              : 'border-slate-200 dark:border-white/10 focus-within:border-violet-500/60 dark:focus-within:border-white/25'
          }`}
        >
          {/* Attachment Previews */}
          {attachments.length > 0 && (
            <div className="px-3 pt-3 space-y-2">
              <div className="flex flex-wrap gap-2">
                {attachments.map((att) =>
                  att.kind === 'image' || att.mimeType.startsWith('image/') ? (
                    <div
                      key={att.id}
                      className="relative group h-16 w-16 rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#181c2b]"
                    >
                      <img
                        src={`data:${att.mimeType};base64,${att.data}`}
                        alt={att.name}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setAttachments((prev) =>
                            prev.filter((item) => item.id !== att.id)
                          )
                        }
                        aria-label={`Remove ${att.name}`}
                        className="absolute top-1 right-1 h-6 w-6 rounded-full bg-black/70 text-white flex items-center justify-center hover:bg-black"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div
                      key={att.id}
                      className="flex items-center gap-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-[#181c2b] pl-2.5 pr-1.5 py-1.5 text-xs"
                    >
                      {att.kind === 'pdf' ? (
                        <FileText className="h-4 w-4 text-rose-500 shrink-0" />
                      ) : (
                        <FileCode className="h-4 w-4 text-cyan-500 shrink-0" />
                      )}
                      <span className="truncate max-w-[140px] font-medium text-slate-800 dark:text-slate-200">
                        {att.name}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setAttachments((prev) =>
                            prev.filter((item) => item.id !== att.id)
                          )
                        }
                        aria-label={`Remove ${att.name}`}
                        className="h-6 w-6 rounded-lg flex items-center justify-center text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/10"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  )
                )}
              </div>

              {attachments.some(
                (a) => a.kind === 'image' || a.mimeType.startsWith('image/')
              ) && (
                <div className="flex flex-wrap items-center gap-1.5">
                  {[
                    {
                      label: 'Describe image',
                      prompt: 'Describe this image in detail.',
                    },
                    {
                      label: 'Bengali + English OCR',
                      prompt:
                        'Extract all Bengali (বাংলা) and English text from this image accurately, keeping exact spelling.',
                    },
                    {
                      label: 'Extract English text',
                      prompt:
                        'Extract all visible English text from this image cleanly.',
                    },
                  ].map((chip) => (
                    <button
                      key={chip.label}
                      type="button"
                      onClick={() => {
                        setText(chip.prompt);
                        textareaRef.current?.focus();
                      }}
                      className="rounded-lg border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-white/[0.05] hover:bg-slate-200/70 dark:hover:bg-white/[0.1] px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:text-slate-300 transition-colors"
                    >
                      {chip.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Voice interim feedback */}
          {(isListening || isTranscribing) && (
            <div className="px-3.5 pt-2.5 flex items-center gap-2 text-xs text-cyan-700 dark:text-cyan-300">
              {isTranscribing ? (
                <>
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  <span>Transcribing audio...</span>
                </>
              ) : (
                <>
                  <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" />
                  <span className="truncate">
                    {interimText
                      ? `Listening: "${interimText}"`
                      : 'Listening... tap mic again to stop'}
                  </span>
                </>
              )}
            </div>
          )}

          {imageMode && (
            <div className="mx-3.5 mt-2.5 flex items-center justify-between gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-[11px] text-amber-800 dark:text-amber-300">
              <span>
                In-Chat Nano Banana Image Mode: requires paid API confirmation before sending.
              </span>
              <button
                type="button"
                onClick={onToggleImageMode}
                className="font-semibold underline shrink-0"
              >
                Exit
              </button>
            </div>
          )}

          {/* Textarea */}
          <div className="px-3.5 pt-2.5 pb-1">
            <textarea
              ref={textareaRef}
              rows={1}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              onPaste={handlePaste}
              placeholder={
                imageMode
                  ? 'Describe an image to generate or follow-up edit (e.g. "Change the background to sunset")...'
                  : ASSISTANT_MODES[mode].placeholder
              }
              aria-label="Message NOVA AI"
              className="w-full resize-none bg-transparent text-[15px] leading-relaxed text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none max-h-[168px]"
            />
          </div>

          {/* Bottom Toolbar */}
          <div className="flex items-center justify-between gap-2 px-2 pb-2">
            <div className="flex items-center gap-1">
              <input
                ref={fileInputRef}
                type="file"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp,.pdf,.txt,.md,.csv,.json,.js,.ts,.tsx,.jsx,.py,.html,.css,.sql,.xml,.yaml,.yml"
                multiple
                className="hidden"
                onChange={(e) => {
                  if (e.target.files?.length) {
                    void addFiles(e.target.files);
                  }
                  e.target.value = '';
                }}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                aria-label="Attach image, PDF, or text file"
                title="Attach image, PDF, or code/text file"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors"
              >
                <Paperclip className="h-5 w-5" />
              </button>

              <button
                type="button"
                onClick={startVoiceInput}
                aria-label={isListening ? 'Stop voice input' : 'Start voice input'}
                title={isListening ? 'Stop voice input' : 'Voice input'}
                className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl transition-colors ${
                  isListening
                    ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                }`}
              >
                {isListening ? (
                  <MicOff className="h-5 w-5" />
                ) : (
                  <Mic className="h-5 w-5" />
                )}
              </button>

              <a
                href="https://gemini.google.com/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Generate image in Gemini"
                title="Generate an image in Gemini (gemini.google.com), download it, and attach it here"
                className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.04] hover:border-violet-500/40 hover:bg-slate-100 dark:hover:bg-white/[0.08] px-2.5 sm:px-3 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
              >
                <ImagePlus className="h-4 w-4 text-violet-500 dark:text-cyan-400 shrink-0" />
                <span className="hidden xs:inline sm:inline">Generate Image</span>
                <ExternalLink className="h-3 w-3 opacity-60 shrink-0" />
              </a>
            </div>

            {isStreaming ? (
              <button
                type="button"
                onClick={onStop}
                aria-label="Stop generating"
                className="min-h-[44px] px-4 inline-flex items-center gap-2 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold hover:opacity-90 transition-opacity whitespace-nowrap shrink-0"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={!canSend}
                aria-label="Send message"
                className={`min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-xl transition-all ${
                  canSend
                    ? 'bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white shadow-sm active:scale-95'
                    : 'bg-slate-200 dark:bg-white/[0.06] text-slate-400 dark:text-slate-600 cursor-not-allowed'
                }`}
              >
                <ArrowUp className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
