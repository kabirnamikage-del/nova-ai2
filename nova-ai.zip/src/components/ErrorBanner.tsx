import { AlertTriangle, KeyRound, RefreshCw, WifiOff, X } from 'lucide-react';
import type { ApiErrorInfo } from '../types/chat.ts';

interface ErrorBannerProps {
  error: ApiErrorInfo;
  onRetry?: () => void;
  onDismiss?: () => void;
  onOpenSettings?: () => void;
}

export function ErrorBanner({
  error,
  onRetry,
  onDismiss,
  onOpenSettings,
}: ErrorBannerProps) {
  const isAuth =
    error.code === 'MISSING_API_KEY' || error.code === 'AUTH_ERROR';
  const isNetwork = error.code === 'NETWORK_ERROR';

  const Icon = isAuth ? KeyRound : isNetwork ? WifiOff : AlertTriangle;

  return (
    <div
      role="alert"
      className="rounded-xl border border-rose-500/30 bg-rose-50 dark:bg-rose-950/30 p-3.5 text-slate-900 dark:text-slate-100"
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5 shrink-0 rounded-lg bg-rose-500/15 p-2 text-rose-600 dark:text-rose-400">
          <Icon className="h-4 w-4" aria-hidden="true" />
        </div>
        <div className="min-w-0 flex-1 space-y-1">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-semibold text-rose-700 dark:text-rose-300">
              {error.title}
            </p>
            {onDismiss && (
              <button
                type="button"
                onClick={onDismiss}
                aria-label="Dismiss error"
                className="min-h-[36px] min-w-[36px] -mr-1.5 -mt-1.5 flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <p className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
            {error.message}
          </p>
          {error.hint && (
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {error.hint}
            </p>
          )}
          {(onRetry || (isAuth && onOpenSettings)) && (
            <div className="flex flex-wrap items-center gap-2 pt-1.5">
              {onRetry && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Retry
                </button>
              )}
              {isAuth && onOpenSettings && (
                <button
                  type="button"
                  onClick={onOpenSettings}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap shrink-0"
                >
                  Check Connection Status
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
