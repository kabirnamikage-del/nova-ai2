import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  ArrowUp,
  ChevronDown,
  Download,
  ExternalLink,
  Heart,
  Image as ImageIcon,
  Loader2,
  Palette,
  Plus,
  Sparkles,
  Wand2,
  X,
} from 'lucide-react';
import {
  downloadSvgAsPng,
  svgToObjectUrl,
  type VisualCreation,
} from '../lib/creations.ts';
import type { ChatAttachment } from '../types/chat.ts';
import { NovaLogo } from './NovaLogo.tsx';

interface CreateVisualViewProps {
  creations: VisualCreation[];
  isGenerating: boolean;
  initialPrompt?: string;
  onGenerateVisual: (opts: {
    prompt: string;
    style: string;
    aspectRatio: string;
    mood: string;
    attachments: ChatAttachment[];
  }) => Promise<void>;
  onOpenLibrary: () => void;
}

const STYLE_OPTIONS = [
  'Illustration',
  'Anime',
  'Diagram',
  'Minimalist',
  'Cyberpunk',
  'Watercolor',
];

const ASPECT_OPTIONS = ['1:1', '16:9', '4:3', '3:4'];

const MOOD_OPTIONS = ['Vibrant', 'Calm', 'Dramatic', 'Editorial'];

const QUICK_IDEA_POOL = [
  {
    label: 'Anime style portrait',
    prompt: 'An anime style portrait under a glowing twilight sky with soft cyan rim lighting',
  },
  {
    label: 'Beautiful nature',
    prompt: 'A tranquil mountain lake at golden sunset with warm amber reflections',
  },
  {
    label: 'Anime city at night',
    prompt: 'A neon-lit futuristic city skyline at night with glowing purple clouds',
  },
  {
    label: 'Cute cat in a hoodie',
    prompt: 'A cozy illustrated cat wearing a violet hoodie sipping warm tea',
  },
  {
    label: 'System architecture diagram',
    prompt: 'A clean technical diagram showing React frontend, Node API, and Gemini AI flow',
  },
  {
    label: 'Solar system poster',
    prompt: 'A sleek minimalist space poster of planets orbiting a glowing sun',
  },
];

function CreationCard({
  item,
  liked,
  onToggleLike,
  onSelect,
}: {
  item: VisualCreation;
  liked: boolean;
  onToggleLike: () => void;
  onSelect: () => void;
}) {
  const url = useMemo(() => svgToObjectUrl(item.svgCode), [item.svgCode]);

  useEffect(() => {
    return () => URL.revokeObjectURL(url);
  }, [url]);

  return (
    <div className="group relative aspect-square overflow-hidden rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-100 dark:bg-[#17171b]">
      <button
        type="button"
        onClick={onSelect}
        className="h-full w-full block focus:outline-none"
        aria-label={`Preview ${item.title}`}
      >
        <img
          src={url}
          alt={item.title}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
      </button>

      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          onToggleLike();
        }}
        aria-label={liked ? `Unlike ${item.title}` : `Like ${item.title}`}
        className={`absolute top-2.5 right-2.5 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-full bg-black/45 backdrop-blur-sm transition-opacity ${
          liked
            ? 'text-rose-400 opacity-100'
            : 'text-white/90 opacity-80 sm:opacity-0 sm:group-hover:opacity-100 focus:opacity-100'
        }`}
      >
        <Heart className={`h-4 w-4 ${liked ? 'fill-current' : ''}`} />
      </button>
    </div>
  );
}

export function CreateVisualView({
  creations,
  isGenerating,
  initialPrompt,
  onGenerateVisual,
  onOpenLibrary,
}: CreateVisualViewProps) {
  const [prompt, setPrompt] = useState(initialPrompt ?? '');
  const [style, setStyle] = useState('Illustration');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [mood, setMood] = useState('Vibrant');
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [ideaOffset, setIdeaOffset] = useState(0);
  const [openMenu, setOpenMenu] = useState<'style' | 'aspect' | 'mood' | null>(
    null
  );
  const [likedIds, setLikedIds] = useState<Record<string, boolean>>({});
  const [selectedCreation, setSelectedCreation] =
    useState<VisualCreation | null>(null);

  useEffect(() => {
    if (initialPrompt) {
      setPrompt(initialPrompt);
    }
  }, [initialPrompt]);

  const fileRef = useRef<HTMLInputElement>(null);
  const menusRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const closeMenus = (e: MouseEvent) => {
      if (menusRef.current && !menusRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
      }
    };
    document.addEventListener('mousedown', closeMenus);
    return () => document.removeEventListener('mousedown', closeMenus);
  }, []);

  const visibleIdeas = useMemo(() => {
    const list: typeof QUICK_IDEA_POOL = [];
    for (let i = 0; i < 4; i++) {
      list.push(QUICK_IDEA_POOL[(ideaOffset + i) % QUICK_IDEA_POOL.length]);
    }
    return list;
  }, [ideaOffset]);

  const handlePhotoUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    const file = files[0];
    if (!file.type.startsWith('image/')) return;
    const dataUrl = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result ?? ''));
      reader.readAsDataURL(file);
    });
    const idx = dataUrl.indexOf(',');
    setAttachments([
      {
        id: crypto.randomUUID(),
        name: file.name,
        mimeType: file.type,
        data: idx >= 0 ? dataUrl.slice(idx + 1) : dataUrl,
        size: file.size,
        kind: 'image',
      },
    ]);
  };

  const handleSubmit = async () => {
    const trimmed = prompt.trim();
    if (!trimmed || isGenerating) return;
    await onGenerateVisual({
      prompt: trimmed,
      style,
      aspectRatio,
      mood,
      attachments,
    });
    setPrompt('');
    setAttachments([]);
  };

  const selectedPreviewUrl = useMemo(
    () => (selectedCreation ? svgToObjectUrl(selectedCreation.svgCode) : null),
    [selectedCreation]
  );

  useEffect(() => {
    return () => {
      if (selectedPreviewUrl) URL.revokeObjectURL(selectedPreviewUrl);
    };
  }, [selectedPreviewUrl]);

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 sm:py-10">
      <div className="mx-auto max-w-4xl space-y-8">
        {/* Hero Headline + Prompt Card */}
        <div className="flex flex-col items-center text-center pt-2 sm:pt-4">
          <div className="mb-4">
            <NovaLogo size={46} />
          </div>
          <h1 className="font-display text-2xl sm:text-4xl font-semibold tracking-tight text-slate-900 dark:text-white text-balance">
            Create something amazing
          </h1>
          <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Turn your ideas into clean vector visuals, diagrams &amp; PNG artwork
          </p>

          {/* Unified Prompt Card */}
          <div
            ref={menusRef}
            className="mt-7 w-full max-w-2xl rounded-3xl border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-[#1b1b20] p-4 shadow-sm focus-within:border-violet-500/50 dark:focus-within:border-cyan-400/50 transition-colors text-left"
          >
            {attachments.length > 0 && (
              <div className="mb-2.5 flex items-center gap-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="relative h-14 w-14 overflow-hidden rounded-xl border border-slate-200 dark:border-white/10"
                  >
                    <img
                      src={`data:${att.mimeType};base64,${att.data}`}
                      alt={att.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setAttachments([])}
                      aria-label="Remove reference photo"
                      className="absolute top-0.5 right-0.5 h-5 w-5 rounded-full bg-black/75 text-white flex items-center justify-center"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-start gap-2.5">
              <ImageIcon
                className="mt-1 h-5 w-5 shrink-0 text-slate-400 dark:text-slate-500"
                aria-hidden="true"
              />
              <textarea
                rows={2}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    void handleSubmit();
                  }
                }}
                placeholder="Describe what you want to see..."
                aria-label="Describe the visual you want to create"
                className="w-full resize-none bg-transparent text-[15px] leading-relaxed text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none"
              />
            </div>

            {/* Bottom Controls Row matching screenshot */}
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex flex-wrap items-center gap-2">
                <input
                  ref={fileRef}
                  type="file"
                  accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={(e) => {
                    void handlePhotoUpload(e.target.files);
                    e.target.value = '';
                  }}
                />
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-full border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-white/[0.05] hover:bg-slate-200/70 dark:hover:bg-white/[0.1] px-3.5 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add photo</span>
                </button>

                <span
                  aria-hidden="true"
                  className="hidden sm:inline-block h-4 w-px bg-slate-200 dark:bg-white/10"
                />

                {/* Style Selector */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() =>
                      setOpenMenu((m) => (m === 'style' ? null : 'style'))
                    }
                    className="min-h-[38px] inline-flex items-center gap-1.5 rounded-full border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-white/[0.05] hover:bg-slate-200/70 dark:hover:bg-white/[0.1] px-3.5 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
                  >
                    <span>{style}</span>
                    <ChevronDown className="h-3.5 w-3.5 opacity-70" />
                  </button>
                  {openMenu === 'style' && (
                    <div className="absolute left-0 mt-1.5 w-40 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1e1e24] p-1 shadow-xl z-30">
                      {STYLE_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => {
                            setStyle(opt);
                            setOpenMenu(null);
                          }}
                          className={`w-full text-left rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                            opt === style
                              ? 'bg-violet-500/15 text-violet-700 dark:text-cyan-300'
                              : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Aspect Ratio Selector */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() =>
                      setOpenMenu((m) => (m === 'aspect' ? null : 'aspect'))
                    }
                    className="min-h-[38px] inline-flex items-center gap-1.5 rounded-full border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-white/[0.05] hover:bg-slate-200/70 dark:hover:bg-white/[0.1] px-3.5 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
                  >
                    <span>{aspectRatio}</span>
                    <ChevronDown className="h-3.5 w-3.5 opacity-70" />
                  </button>
                  {openMenu === 'aspect' && (
                    <div className="absolute left-0 mt-1.5 w-32 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1e1e24] p-1 shadow-xl z-30">
                      {ASPECT_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => {
                            setAspectRatio(opt);
                            setOpenMenu(null);
                          }}
                          className={`w-full text-left rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                            opt === aspectRatio
                              ? 'bg-violet-500/15 text-violet-700 dark:text-cyan-300'
                              : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Mood Selector */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() =>
                      setOpenMenu((m) => (m === 'mood' ? null : 'mood'))
                    }
                    className="min-h-[38px] inline-flex items-center gap-1.5 rounded-full border border-slate-200 dark:border-white/10 bg-slate-100/80 dark:bg-white/[0.05] hover:bg-slate-200/70 dark:hover:bg-white/[0.1] px-3.5 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
                  >
                    <span>{mood}</span>
                    <ChevronDown className="h-3.5 w-3.5 opacity-70" />
                  </button>
                  {openMenu === 'mood' && (
                    <div className="absolute left-0 mt-1.5 w-36 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1e1e24] p-1 shadow-xl z-30">
                      {MOOD_OPTIONS.map((opt) => (
                        <button
                          key={opt}
                          type="button"
                          onClick={() => {
                            setMood(opt);
                            setOpenMenu(null);
                          }}
                          className={`w-full text-left rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                            opt === mood
                              ? 'bg-violet-500/15 text-violet-700 dark:text-cyan-300'
                              : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06]'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <button
                type="button"
                disabled={!prompt.trim() || isGenerating}
                onClick={() => void handleSubmit()}
                aria-label="Generate visual"
                className={`min-h-[40px] min-w-[40px] flex items-center justify-center rounded-full transition-all shrink-0 ${
                  prompt.trim() && !isGenerating
                    ? 'bg-gradient-to-r from-violet-600 to-cyan-600 text-white hover:opacity-95 active:scale-95'
                    : 'bg-slate-200 dark:bg-white/[0.12] text-slate-400 dark:text-slate-500 cursor-not-allowed'
                }`}
              >
                {isGenerating ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ArrowUp className="h-4 w-4" />
                )}
              </button>
            </div>
          </div>

          {/* Quick Idea Prompts Row */}
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2 max-w-3xl">
            {visibleIdeas.map((idea, index) => {
              const Icons = [Wand2, ImageIcon, Palette, Sparkles];
              const Icon = Icons[index % Icons.length];
              return (
                <button
                  key={idea.label}
                  type="button"
                  onClick={() => setPrompt(idea.prompt)}
                  className="min-h-[44px] inline-flex items-center gap-2 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#17171b] hover:bg-slate-50 dark:hover:bg-[#1f1f25] px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors"
                >
                  <Icon className="h-4 w-4 text-violet-500 dark:text-cyan-400 shrink-0" />
                  <span className="whitespace-nowrap">{idea.label}</span>
                </button>
              );
            })}
            <button
              type="button"
              onClick={() =>
                setIdeaOffset((o) => (o + 2) % QUICK_IDEA_POOL.length)
              }
              className="min-h-[44px] inline-flex items-center gap-1.5 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#17171b] hover:bg-slate-50 dark:hover:bg-[#1f1f25] px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap"
            >
              <span>More ideas</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
            <a
              href="https://gemini.google.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="min-h-[44px] inline-flex items-center gap-1.5 rounded-2xl border border-violet-500/35 bg-violet-500/10 hover:bg-violet-500/20 px-4 py-2 text-xs font-semibold text-violet-700 dark:text-cyan-300 transition-colors whitespace-nowrap"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Generate Image in Gemini</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        </div>

        {/* Your creations Grid */}
        <section className="space-y-3.5 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Your creations
            </h2>
            <button
              type="button"
              onClick={onOpenLibrary}
              className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              <span>See all</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {creations.slice(0, 6).map((item) => (
              <CreationCard
                key={item.id}
                item={item}
                liked={Boolean(likedIds[item.id])}
                onToggleLike={() =>
                  setLikedIds((prev) => ({
                    ...prev,
                    [item.id]: !prev[item.id],
                  }))
                }
                onSelect={() => setSelectedCreation(item)}
              />
            ))}
          </div>
        </section>
      </div>

      {/* Creation Preview Lightbox */}
      {selectedCreation && selectedPreviewUrl && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setSelectedCreation(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl rounded-2xl border border-white/10 bg-[#141418] text-slate-100 overflow-hidden shadow-2xl"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
              <div className="min-w-0">
                <h3 className="text-sm font-semibold truncate">
                  {selectedCreation.title}
                </h3>
                <p className="text-xs text-slate-400 truncate">
                  {selectedCreation.style} · {selectedCreation.aspectRatio} ·{' '}
                  {selectedCreation.mood}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedCreation(null)}
                aria-label="Close preview"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-4 bg-[#0b0b0e] flex items-center justify-center">
              <img
                src={selectedPreviewUrl}
                alt={selectedCreation.title}
                referrerPolicy="no-referrer"
                className="max-h-[55vh] rounded-xl object-contain"
              />
            </div>
            <div className="p-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  setPrompt(selectedCreation.prompt);
                  setStyle(selectedCreation.style);
                  setSelectedCreation(null);
                }}
                className="min-h-[38px] rounded-xl border border-white/15 px-3.5 py-1.5 text-xs font-medium hover:bg-white/10 transition-colors"
              >
                Remix Prompt
              </button>
              <button
                type="button"
                onClick={() =>
                  downloadSvgAsPng(
                    selectedCreation.svgCode,
                    `${selectedCreation.id}.png`
                  )
                }
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:opacity-95"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download PNG</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
