import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Code2,
  Eye,
  FileCode2,
  History,
  ImagePlus,
  Loader2,
  MessageSquareText,
  RotateCcw,
  Sparkles,
  Trash2,
  Upload,
  X,
  XCircle,
} from 'lucide-react';
import {
  applyBuilderChangesRemote,
  fetchBuilderProposalsRemote,
  generateBuilderChangesRemote,
  rejectBuilderChangesRemote,
  rollbackBuilderChangesRemote,
} from '../lib/adminApi.ts';
import type {
  BuilderImageAttachment,
  BuilderInputMode,
  BuilderProposalRecord,
} from '../types/admin.ts';

interface SuperPowerBuilderProps {
  availableModels: Array<{ id: string; displayName: string; tier: 'free' | 'paid' }>;
  onAuditRefresh?: () => Promise<void> | void;
  onWorkspaceMutated?: () => Promise<void> | void;
  onToast: (type: 'ok' | 'err', text: string) => void;
}

const CODE_LANGUAGES = [
  'typescript',
  'tsx',
  'javascript',
  'jsx',
  'css',
  'html',
  'json',
  'markdown',
  'xml',
];

const FALLBACK_BUILDER_MODELS = [
  { id: 'gemini-4-hydrogen', label: 'Gemini 4 Hydrogen (Free · Recommended)' },
  { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash (Free)' },
  { id: 'gemini-3.5-flash', label: 'Gemini 3.5 Flash (Free)' },
  { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash Lite (Free)' },
];

const ALLOWED_MIME_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_IMAGES = 5;

function formatTimestamp(ms: number): string {
  try {
    return new Date(ms).toLocaleString();
  } catch {
    return String(ms);
  }
}

function formatBytes(bytes?: number): string {
  if (!bytes || bytes <= 0) return '0 KB';
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function statusMeta(status: BuilderProposalRecord['status']): {
  label: string;
  textClass: string;
} {
  switch (status) {
    case 'applied':
      return { label: 'Applied & Validated', textClass: 'text-emerald-400' };
    case 'rejected':
      return { label: 'Rejected', textClass: 'text-slate-400' };
    case 'rolled-back':
      return { label: 'Rolled Back', textClass: 'text-amber-300' };
    case 'failed':
      return { label: 'Validation Failed (Reverted)', textClass: 'text-rose-400' };
    default:
      return { label: 'Pending Review', textClass: 'text-cyan-300' };
  }
}

function readFileAsImageAttachment(file: File): Promise<BuilderImageAttachment> {
  return new Promise((resolve, reject) => {
    const mime =
      file.type === 'image/jpg' ? 'image/jpeg' : file.type.toLowerCase();
    if (!ALLOWED_MIME_TYPES.has(mime)) {
      reject(new Error(`"${file.name}" is unsupported. Use PNG, JPG, JPEG, or WEBP.`));
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      reject(new Error(`"${file.name}" exceeds the 5 MB image upload limit.`));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error(`Failed to read "${file.name}".`));
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) {
        reject(new Error(`Empty image data for "${file.name}".`));
        return;
      }
      resolve({
        id: `img_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        name: file.name,
        mimeType: mime as 'image/png' | 'image/jpeg' | 'image/webp',
        dataUrl,
        sizeBytes: file.size,
      });
    };
    reader.readAsDataURL(file);
  });
}

export function SuperPowerBuilder({
  availableModels,
  onAuditRefresh,
  onWorkspaceMutated,
  onToast,
}: SuperPowerBuilderProps) {
  const [activeMode, setActiveMode] = useState<BuilderInputMode>('prompt');

  // Input editors state (can be combined across all 3 modes simultaneously)
  const [promptText, setPromptText] = useState('');
  const [revisionNote, setRevisionNote] = useState('');
  const [preferredModel, setPreferredModel] = useState('gemini-4-hydrogen');

  const [codeSnippet, setCodeSnippet] = useState('');
  const [codeLanguage, setCodeLanguage] = useState('typescript');
  const [targetFile, setTargetFile] = useState('');
  const [targetCustomMode, setTargetCustomMode] = useState(false);

  const [images, setImages] = useState<BuilderImageAttachment[]>([]);
  const [isDraggingImages, setIsDraggingImages] = useState(false);

  // Server proposals & workspace inventory
  const [workspaceFiles, setWorkspaceFiles] = useState<string[]>([]);
  const [proposals, setProposals] = useState<BuilderProposalRecord[]>([]);
  const [loadingProposals, setLoadingProposals] = useState(true);
  const [activeProposalId, setActiveProposalId] = useState<string | null>(null);
  const [previewVisible, setPreviewVisible] = useState(true);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [fileViewMode, setFileViewMode] = useState<'diff' | 'full'>('diff');

  // Async action flags
  const [generating, setGenerating] = useState(false);
  const [applying, setApplying] = useState(false);
  const [rejecting, setRejecting] = useState(false);
  const [rollingBack, setRollingBack] = useState(false);
  const [builderError, setBuilderError] = useState<string | null>(null);

  const imageInputRef = useRef<HTMLInputElement>(null);
  const previewSectionRef = useRef<HTMLDivElement>(null);

  const loadBuilderState = useCallback(async () => {
    setLoadingProposals(true);
    try {
      const data = await fetchBuilderProposalsRemote();
      setProposals(data.proposals);
      setWorkspaceFiles(data.workspaceFiles);
      setActiveProposalId((prev) => {
        if (prev && data.proposals.some((p) => p.id === prev)) return prev;
        return data.proposals[0]?.id ?? null;
      });
    } catch (err) {
      console.warn('[SuperPowerBuilder] Load state warning:', err);
    } finally {
      setLoadingProposals(false);
    }
  }, []);

  useEffect(() => {
    void loadBuilderState();
  }, [loadBuilderState]);

  const modelChoices = useMemo(() => {
    const map = new Map<string, string>();
    for (const def of FALLBACK_BUILDER_MODELS) {
      map.set(def.id, def.label);
    }
    for (const m of availableModels) {
      if (!map.has(m.id)) {
        map.set(
          m.id,
          `${m.displayName || m.id} (${m.tier === 'paid' ? 'Paid' : 'Free'})`
        );
      }
    }
    return Array.from(map.entries()).map(([id, label]) => ({ id, label }));
  }, [availableModels]);

  const activeProposal = useMemo(() => {
    if (!activeProposalId) return proposals[0] ?? null;
    return proposals.find((p) => p.id === activeProposalId) ?? proposals[0] ?? null;
  }, [proposals, activeProposalId]);

  const latestAppliedProposal = useMemo(
    () => proposals.find((p) => p.status === 'applied' && p.backupId) ?? null,
    [proposals]
  );

  const rollbackTargetProposal = useMemo(() => {
    if (activeProposal && activeProposal.status === 'applied' && activeProposal.backupId) {
      return activeProposal;
    }
    return latestAppliedProposal;
  }, [activeProposal, latestAppliedProposal]);

  const activeChange = useMemo(() => {
    if (!activeProposal || activeProposal.changes.length === 0) return null;
    return (
      activeProposal.changes[selectedFileIndex] ?? activeProposal.changes[0] ?? null
    );
  }, [activeProposal, selectedFileIndex]);

  const totalStats = useMemo(() => {
    if (!activeProposal) return { added: 0, removed: 0 };
    return activeProposal.changes.reduce(
      (acc, ch) => ({
        added: acc.added + ch.stats.added,
        removed: acc.removed + ch.stats.removed,
      }),
      { added: 0, removed: 0 }
    );
  }, [activeProposal]);

  const hasAnyInput = Boolean(
    promptText.trim() || codeSnippet.trim() || images.length > 0
  );

  const activeInputSummary = useMemo(() => {
    const parts: string[] = [];
    if (promptText.trim()) parts.push('Prompt');
    if (codeSnippet.trim()) parts.push('Code');
    if (images.length > 0) {
      parts.push(`${images.length} Image${images.length > 1 ? 's' : ''}`);
    }
    return parts;
  }, [promptText, codeSnippet, images.length]);

  const handleAddImageFiles = async (fileList: FileList | File[]) => {
    const incoming = Array.from(fileList);
    if (incoming.length === 0) return;

    const remainingSlots = MAX_IMAGES - images.length;
    if (remainingSlots <= 0) {
      onToast('err', `Maximum ${MAX_IMAGES} reference images allowed per request.`);
      return;
    }

    const toProcess = incoming.slice(0, remainingSlots);
    const loaded: BuilderImageAttachment[] = [];
    for (const file of toProcess) {
      try {
        const attachment = await readFileAsImageAttachment(file);
        loaded.push(attachment);
      } catch (err) {
        onToast(
          'err',
          err instanceof Error ? err.message : 'Unable to attach image.'
        );
      }
    }
    if (loaded.length > 0) {
      setImages((prev) => [...prev, ...loaded]);
      setBuilderError(null);
    }
  };

  const handleGenerate = async () => {
    if (!hasAnyInput) {
      setBuilderError(
        'Enter a prompt, paste code, or upload at least one reference image before generating.'
      );
      return;
    }

    setGenerating(true);
    setBuilderError(null);
    try {
      const inputModes: BuilderInputMode[] = [];
      if (promptText.trim()) inputModes.push('prompt');
      if (codeSnippet.trim()) inputModes.push('code');
      if (images.length > 0) inputModes.push('image');

      const res = await generateBuilderChangesRemote({
        inputModes,
        prompt: promptText.trim(),
        revisionNote: revisionNote.trim() || undefined,
        codeSnippet: codeSnippet.trim() || undefined,
        codeLanguage: codeSnippet.trim() ? codeLanguage : undefined,
        targetFile: targetFile.trim() || undefined,
        images:
          images.length > 0
            ? images.map((im) => ({
                name: im.name,
                mimeType: im.mimeType,
                base64: im.dataUrl.split(',').pop() || '',
              }))
            : undefined,
        preferredModel,
      });

      setProposals(res.proposals);
      setActiveProposalId(res.proposal.id);
      setSelectedFileIndex(0);
      setFileViewMode('diff');
      setPreviewVisible(true);
      await onAuditRefresh?.();
      onToast(
        'ok',
        `Generated ${res.proposal.changes.length} file change(s) via ${res.proposal.modelUsed}. Review the diff before applying.`
      );
      setTimeout(() => {
        previewSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 80);
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Failed to generate AI application modifications.';
      setBuilderError(msg);
      onToast('err', msg);
    } finally {
      setGenerating(false);
    }
  };

  const handleTogglePreview = () => {
    if (!activeProposal) {
      onToast('err', 'Generate changes first to preview file diffs.');
      return;
    }
    setPreviewVisible((prev) => !prev);
    if (!previewVisible) {
      setTimeout(() => {
        previewSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }, 60);
    }
  };

  const handleApproveAndApply = async () => {
    if (!activeProposal) return;
    if (activeProposal.status === 'applied') return;

    setApplying(true);
    setBuilderError(null);
    try {
      const res = await applyBuilderChangesRemote(activeProposal.id);
      setProposals(res.proposals);
      setActiveProposalId(res.proposal.id);
      setPreviewVisible(true);
      await Promise.all([onAuditRefresh?.(), onWorkspaceMutated?.()]);

      if (res.ok) {
        onToast(
          'ok',
          `Changes applied, verified with TypeScript & Vite build, and backed up (${res.backup.id}).`
        );
      } else {
        const msg =
          res.proposal.errorMessage ||
          'Validation failed; changes were automatically reverted using backup.';
        setBuilderError(msg);
        onToast('err', 'Validation failed — changes automatically reverted.');
      }
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Unable to apply generated changes.';
      setBuilderError(msg);
      onToast('err', msg);
    } finally {
      setApplying(false);
    }
  };

  const handleReject = async () => {
    if (!activeProposal || activeProposal.status === 'applied') return;
    setRejecting(true);
    setBuilderError(null);
    try {
      const res = await rejectBuilderChangesRemote(activeProposal.id);
      setProposals(res.proposals);
      setActiveProposalId(res.proposal.id);
      await onAuditRefresh?.();
      onToast('ok', 'Change proposal rejected. No project files were modified.');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to reject proposal.';
      onToast('err', msg);
    } finally {
      setRejecting(false);
    }
  };

  const handleRollback = async (targetId?: string) => {
    const id = targetId || rollbackTargetProposal?.id;
    if (!id) {
      onToast('err', 'No applied change with a backup snapshot is available to roll back.');
      return;
    }

    setRollingBack(true);
    setBuilderError(null);
    try {
      const res = await rollbackBuilderChangesRemote(id);
      setProposals(res.proposals);
      setActiveProposalId(res.proposal.id);
      setPreviewVisible(true);
      await Promise.all([onAuditRefresh?.(), onWorkspaceMutated?.()]);
      onToast(
        'ok',
        `Rolled back ${res.restoredPaths.length} file(s). TypeScript validation ${res.validation.ok ? 'passed' : 'reported warnings'}.`
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Rollback failed.';
      setBuilderError(msg);
      onToast('err', msg);
    } finally {
      setRollingBack(false);
    }
  };

  const handleClearEditor = () => {
    setPromptText('');
    setRevisionNote('');
    setCodeSnippet('');
    setTargetFile('');
    setTargetCustomMode(false);
    setImages([]);
    setBuilderError(null);
  };

  const busy = generating || applying || rejecting || rollingBack;

  return (
    <section
      aria-label="Super Power AI App Builder and Modification Center"
      className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-5"
    >
      {/* Section Header */}
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-white/[0.06] pb-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <Sparkles className="h-5 w-5 text-violet-400 shrink-0" />
            <h2 className="font-display text-lg font-semibold text-white tracking-tight">
              AI App Builder &amp; Modification Center
            </h2>
          </div>
          <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
            Upgrade, redesign, fix, or extend NOVA AI directly from this console using natural
            language (English or বাংলা), code snippets, or visual UI screenshots. Every change
            is inspected against real project files, previewed line-by-line, backed up before
            writing, and verified with TypeScript and Vite production builds.
          </p>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 pt-1 tabular-nums">
            <span>{workspaceFiles.length} editable project files</span>
            <span aria-hidden="true">·</span>
            <span>{proposals.length} recorded builder revision{proposals.length === 1 ? '' : 's'}</span>
            {activeInputSummary.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-violet-300 font-medium">
                  Attached inputs: {activeInputSummary.join(' + ')}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Model Override Selector */}
        <div className="flex items-center gap-2 shrink-0">
          <label
            htmlFor="sp-builder-model"
            className="text-xs font-medium text-slate-400 whitespace-nowrap"
          >
            Builder Model
          </label>
          <select
            id="sp-builder-model"
            value={preferredModel}
            disabled={busy}
            onChange={(e) => setPreferredModel(e.target.value)}
            className="min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
          >
            {modelChoices.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Mode Switcher Tabs + Combined Input Indicator */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div
          role="tablist"
          aria-label="Builder Input Methods"
          className="inline-flex items-center gap-1 rounded-lg bg-[#0d0d10] p-1 border border-white/[0.08]"
        >
          <button
            type="button"
            role="tab"
            aria-selected={activeMode === 'prompt'}
            onClick={() => setActiveMode('prompt')}
            className={`min-h-[36px] inline-flex items-center gap-2 rounded-md px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeMode === 'prompt'
                ? 'bg-violet-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <MessageSquareText className="h-3.5 w-3.5" />
            <span>Prompt Mode</span>
            {promptText.trim() && (
              <span className="font-mono text-[10px] opacity-80">({promptText.trim().length})</span>
            )}
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeMode === 'code'}
            onClick={() => setActiveMode('code')}
            className={`min-h-[36px] inline-flex items-center gap-2 rounded-md px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeMode === 'code'
                ? 'bg-violet-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <Code2 className="h-3.5 w-3.5" />
            <span>Code Mode</span>
            {codeSnippet.trim() && (
              <span className="font-mono text-[10px] opacity-80">
                ({codeSnippet.split('\n').length}L)
              </span>
            )}
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={activeMode === 'image'}
            onClick={() => setActiveMode('image')}
            className={`min-h-[36px] inline-flex items-center gap-2 rounded-md px-3.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              activeMode === 'image'
                ? 'bg-violet-600 text-white'
                : 'text-slate-300 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <ImagePlus className="h-3.5 w-3.5" />
            <span>Image Upload Mode</span>
            {images.length > 0 && (
              <span className="font-mono text-[10px] opacity-80">({images.length})</span>
            )}
          </button>
        </div>

        <span className="text-[11px] text-slate-400">
          Switch tabs freely to combine prompt, code, and images in a single update
        </span>
      </div>

      {/* Mode A: Prompt Mode */}
      {activeMode === 'prompt' && (
        <div className="space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label htmlFor="sp-builder-prompt" className="font-medium text-slate-200">
                Describe What You Want to Build, Modify, or Fix (English or বাংলা)
              </label>
              <span className="font-mono tabular-nums text-[11px] text-slate-500">
                {promptText.length} / 8000
              </span>
            </div>
            <textarea
              id="sp-builder-prompt"
              rows={7}
              maxLength={8000}
              disabled={busy}
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder={
                'Examples:\n' +
                '• Add a keyboard shortcut (Ctrl+K) to open quick conversation search in the sidebar.\n' +
                '• চ্যাট হেডারে একটি compact Word Count নির্দেশক যোগ করুন এবং মোবাইলে লেআউট ঠিক রাখুন।\n' +
                '• Fix spacing in LibraryView cards and add a filter by creation date.'
              }
              className="w-full rounded-lg border border-white/10 bg-[#0d0d10] p-3.5 text-xs text-slate-100 leading-relaxed placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
            />
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
            <label
              htmlFor="sp-builder-revision"
              className="text-xs font-medium text-slate-400 whitespace-nowrap"
            >
              Revision Note (Optional)
            </label>
            <input
              id="sp-builder-revision"
              type="text"
              maxLength={180}
              disabled={busy}
              value={revisionNote}
              onChange={(e) => setRevisionNote(e.target.value)}
              placeholder="e.g., Added keyboard shortcut & sidebar search polish"
              className="flex-1 min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
            />
          </div>
        </div>
      )}

      {/* Mode B: Code Mode */}
      {activeMode === 'code' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label htmlFor="sp-builder-lang" className="block text-xs font-medium text-slate-300">
                Code Language
              </label>
              <select
                id="sp-builder-lang"
                disabled={busy}
                value={codeLanguage}
                onChange={(e) => setCodeLanguage(e.target.value)}
                className="w-full min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
              >
                {CODE_LANGUAGES.map((lang) => (
                  <option key={lang} value={lang}>
                    {lang.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label htmlFor="sp-builder-target" className="font-medium text-slate-300">
                  Target File Path
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setTargetCustomMode((v) => !v);
                    setTargetFile('');
                  }}
                  className="text-[11px] text-violet-300 hover:text-violet-200 underline"
                >
                  {targetCustomMode ? 'Choose Existing File' : 'Enter New / Custom Path'}
                </button>
              </div>
              {targetCustomMode ? (
                <input
                  id="sp-builder-target"
                  type="text"
                  disabled={busy}
                  value={targetFile}
                  onChange={(e) => setTargetFile(e.target.value)}
                  placeholder="e.g., src/components/QuickShortcutsModal.tsx"
                  className="w-full min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 font-mono text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
                />
              ) : (
                <select
                  id="sp-builder-target"
                  disabled={busy}
                  value={targetFile}
                  onChange={(e) => setTargetFile(e.target.value)}
                  className="w-full min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 font-mono text-xs text-white focus:outline-none focus:border-violet-500/60"
                >
                  <option value="">Auto-detect target file from project structure</option>
                  {workspaceFiles.map((filePath) => (
                    <option key={filePath} value={filePath}>
                      {filePath}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <label htmlFor="sp-builder-code" className="font-medium text-slate-200">
                Paste Complete Code or Code Snippet to Integrate Safely
              </label>
              <span className="font-mono tabular-nums text-[11px] text-slate-500">
                {codeSnippet.split('\n').length} line{codeSnippet.split('\n').length === 1 ? '' : 's'}
              </span>
            </div>
            <textarea
              id="sp-builder-code"
              rows={12}
              disabled={busy}
              spellCheck={false}
              value={codeSnippet}
              onChange={(e) => setCodeSnippet(e.target.value)}
              placeholder="// Paste TypeScript, TSX, JavaScript, CSS, HTML, or JSON here..."
              className="w-full rounded-lg border border-white/10 bg-[#0d0d10] p-3.5 font-mono text-xs text-emerald-100 leading-5 placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
            />
          </div>

          <div className="space-y-1.5">
            <label htmlFor="sp-builder-code-note" className="block text-xs font-medium text-slate-300">
              Integration Instructions (Optional — syncs with Prompt Mode)
            </label>
            <input
              id="sp-builder-code-note"
              type="text"
              disabled={busy}
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder="Tell the AI how to wire this snippet in without breaking existing exports..."
              className="w-full min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
            />
          </div>
        </div>
      )}

      {/* Mode C: Image Upload Mode */}
      {activeMode === 'image' && (
        <div className="space-y-4">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDraggingImages(true);
            }}
            onDragLeave={() => setIsDraggingImages(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDraggingImages(false);
              if (e.dataTransfer.files?.length) {
                void handleAddImageFiles(e.dataTransfer.files);
              }
            }}
            className={`rounded-lg border border-dashed p-5 text-center transition-colors ${
              isDraggingImages
                ? 'border-violet-400 bg-violet-500/10'
                : 'border-white/15 bg-[#0d0d10] hover:border-white/25'
            }`}
          >
            <input
              ref={imageInputRef}
              type="file"
              accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.length) {
                  void handleAddImageFiles(e.target.files);
                }
                e.target.value = '';
              }}
            />
            <Upload className="mx-auto h-6 w-6 text-violet-400" />
            <div className="mt-2 text-xs font-medium text-white">
              Upload Screenshots, UI Designs, Diagrams, or Visual References
            </div>
            <p className="mt-1 text-[11px] text-slate-400">
              Supports PNG, JPG, JPEG, WEBP · Up to {MAX_IMAGES} images (max 5 MB each)
            </p>
            <button
              type="button"
              disabled={busy || images.length >= MAX_IMAGES}
              onClick={() => imageInputRef.current?.click()}
              className="mt-3 min-h-[36px] inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.06] hover:bg-white/[0.12] disabled:opacity-40 px-4 text-xs font-medium text-white whitespace-nowrap"
            >
              <ImagePlus className="h-3.5 w-3.5" />
              <span>Select Reference Images</span>
            </button>
          </div>

          {images.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {images.map((img) => (
                <div
                  key={img.id}
                  className="rounded-lg border border-white/[0.08] bg-[#0d0d10] overflow-hidden flex flex-col"
                >
                  <div className="relative aspect-video bg-black/50 flex items-center justify-center overflow-hidden">
                    <img
                      src={img.dataUrl}
                      alt={`Uploaded visual reference ${img.name}`}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-contain"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setImages((prev) => prev.filter((item) => item.id !== img.id))
                      }
                      aria-label={`Remove ${img.name}`}
                      className="absolute top-2 right-2 h-7 w-7 rounded-md bg-black/75 hover:bg-rose-600 text-white flex items-center justify-center transition-colors"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="px-3 py-2 flex items-center justify-between gap-2 text-[11px] text-slate-300 border-t border-white/[0.06]">
                    <span className="truncate font-mono">{img.name}</span>
                    <span className="font-mono tabular-nums text-slate-500 shrink-0">
                      {formatBytes(img.sizeBytes)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-1.5">
            <label htmlFor="sp-builder-image-prompt" className="block text-xs font-medium text-slate-200">
              Visual Implementation Instructions (Syncs with Prompt Mode)
            </label>
            <textarea
              id="sp-builder-image-prompt"
              rows={4}
              disabled={busy}
              value={promptText}
              onChange={(e) => setPromptText(e.target.value)}
              placeholder="Explain what part of NOVA AI should match these uploaded images (e.g., redesign the sidebar cards like screenshot 1, or implement this dashboard widget)..."
              className="w-full rounded-lg border border-white/10 bg-[#0d0d10] p-3 text-xs text-slate-100 leading-relaxed placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
            />
          </div>
        </div>
      )}

      {/* Error Alert Banner */}
      {builderError && (
        <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-3 flex items-start gap-2.5 text-xs text-rose-200">
          <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1 whitespace-pre-wrap break-words leading-relaxed">
            {builderError}
          </div>
          <button
            type="button"
            onClick={() => setBuilderError(null)}
            aria-label="Dismiss error"
            className="text-rose-300 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Primary Action Bar (All 6 Core Controls) */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-white/[0.06]">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={busy || !hasAnyInput}
            onClick={() => void handleGenerate()}
            className="min-h-[40px] inline-flex items-center gap-2 rounded-lg bg-violet-600 hover:bg-violet-500 disabled:opacity-45 px-4 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition-colors"
          >
            {generating ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4" />
            )}
            <span>{generating ? 'Inspecting & Generating...' : 'Generate Changes'}</span>
          </button>

          <button
            type="button"
            disabled={!activeProposal}
            onClick={handleTogglePreview}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-white/10 hover:bg-white/[0.07] disabled:opacity-40 px-3.5 text-xs font-medium text-slate-200 whitespace-nowrap shrink-0"
          >
            <Eye className="h-3.5 w-3.5" />
            <span>{previewVisible && activeProposal ? 'Hide Preview' : 'Preview Changes'}</span>
          </button>

          <button
            type="button"
            disabled={
              busy ||
              !activeProposal ||
              activeProposal.status === 'applied' ||
              activeProposal.status === 'rolled-back'
            }
            onClick={() => void handleApproveAndApply()}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 px-4 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition-colors"
          >
            {applying ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <CheckCircle2 className="h-4 w-4" />
            )}
            <span>{applying ? 'Applying & Validating...' : 'Approve & Apply'}</span>
          </button>

          <button
            type="button"
            disabled={
              busy ||
              !activeProposal ||
              activeProposal.status === 'applied' ||
              activeProposal.status === 'rejected'
            }
            onClick={() => void handleReject()}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 disabled:opacity-40 px-3.5 text-xs font-medium text-rose-200 whitespace-nowrap shrink-0"
          >
            {rejecting ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <XCircle className="h-3.5 w-3.5" />
            )}
            <span>Reject Changes</span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={busy || !rollbackTargetProposal}
            onClick={() => void handleRollback()}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-amber-500/35 bg-amber-500/10 hover:bg-amber-500/20 disabled:opacity-40 px-3.5 text-xs font-medium text-amber-200 whitespace-nowrap shrink-0"
          >
            {rollingBack ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <RotateCcw className="h-3.5 w-3.5" />
            )}
            <span>Undo / Rollback</span>
          </button>

          <button
            type="button"
            disabled={busy || !hasAnyInput}
            onClick={handleClearEditor}
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-white/10 hover:bg-white/[0.07] disabled:opacity-40 px-3.5 text-xs font-medium text-slate-300 whitespace-nowrap shrink-0"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear Editor</span>
          </button>
        </div>
      </div>

      {/* Modification Summary & File-by-File Diff Preview */}
      {activeProposal && previewVisible && (
        <div
          ref={previewSectionRef}
          className="pt-4 border-t border-white/[0.08] space-y-4"
        >
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="font-display text-sm font-semibold text-white">
                  Modification Preview
                </span>
                <span aria-hidden="true" className="text-slate-500">·</span>
                <span className={`font-semibold ${statusMeta(activeProposal.status).textClass}`}>
                  {statusMeta(activeProposal.status).label}
                </span>
                <span aria-hidden="true" className="text-slate-500">·</span>
                <span className="font-mono text-slate-400">
                  {activeProposal.modelUsed}
                  {activeProposal.fallbackUsed ? ' (auto-fallback)' : ''}
                </span>
                <span aria-hidden="true" className="text-slate-500">·</span>
                <span className="font-mono tabular-nums text-emerald-400">
                  +{totalStats.added}
                </span>
                <span className="font-mono tabular-nums text-rose-400">
                  -{totalStats.removed}
                </span>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed max-w-4xl">
                {activeProposal.summary}
              </p>
              <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-1.5">
                <span>Inspected files:</span>
                <span className="font-mono text-slate-300">
                  {activeProposal.inspectedFiles.join(', ')}
                </span>
              </div>
            </div>

            {activeProposal.backupId && (
              <div className="text-right text-[11px] font-mono text-slate-400 tabular-nums shrink-0">
                <div>Backup: {activeProposal.backupId}</div>
                {activeProposal.appliedAt && (
                  <div>Applied: {formatTimestamp(activeProposal.appliedAt)}</div>
                )}
              </div>
            )}
          </div>

          {activeProposal.notes.length > 0 && (
            <ul className="space-y-1 text-[11px] text-slate-300 bg-[#0d0d10] border border-white/[0.06] rounded-lg px-3.5 py-2.5 list-disc list-inside">
              {activeProposal.notes.map((n, i) => (
                <li key={i}>{n}</li>
              ))}
            </ul>
          )}

          {/* Validation & Build Report */}
          {(activeProposal.validation || activeProposal.buildValidation) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              {activeProposal.validation && (
                <div
                  className={`rounded-lg border px-3.5 py-2.5 space-y-1 ${
                    activeProposal.validation.ok
                      ? 'border-emerald-500/25 bg-emerald-500/[0.05]'
                      : 'border-rose-500/30 bg-rose-500/[0.06]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 font-medium">
                    <span
                      className={
                        activeProposal.validation.ok ? 'text-emerald-300' : 'text-rose-300'
                      }
                    >
                      TypeScript Check ({activeProposal.validation.command})
                    </span>
                    <span className="font-mono tabular-nums text-[11px] text-slate-400">
                      {activeProposal.validation.ok ? 'Passed' : 'Failed'} ·{' '}
                      {activeProposal.validation.durationMs} ms
                    </span>
                  </div>
                  <pre className="font-mono text-[11px] text-slate-300 whitespace-pre-wrap break-words max-h-28 overflow-y-auto">
                    {activeProposal.validation.output}
                  </pre>
                </div>
              )}

              {activeProposal.buildValidation && (
                <div
                  className={`rounded-lg border px-3.5 py-2.5 space-y-1 ${
                    activeProposal.buildValidation.ok
                      ? 'border-emerald-500/25 bg-emerald-500/[0.05]'
                      : 'border-rose-500/30 bg-rose-500/[0.06]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 font-medium">
                    <span
                      className={
                        activeProposal.buildValidation.ok
                          ? 'text-emerald-300'
                          : 'text-rose-300'
                      }
                    >
                      Production Bundle ({activeProposal.buildValidation.command})
                    </span>
                    <span className="font-mono tabular-nums text-[11px] text-slate-400">
                      {activeProposal.buildValidation.ok ? 'Passed' : 'Failed'} ·{' '}
                      {activeProposal.buildValidation.durationMs} ms
                    </span>
                  </div>
                  <pre className="font-mono text-[11px] text-slate-300 whitespace-pre-wrap break-words max-h-28 overflow-y-auto">
                    {activeProposal.buildValidation.output}
                  </pre>
                </div>
              )}
            </div>
          )}

          {/* File-by-File Tabs & Diff Viewer */}
          <div className="rounded-lg border border-white/[0.08] bg-[#0d0d10] overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.08] px-3 py-2 bg-white/[0.02]">
              <div className="flex flex-wrap items-center gap-1.5">
                {activeProposal.changes.map((ch, idx) => {
                  const selected = idx === selectedFileIndex;
                  return (
                    <button
                      key={ch.path}
                      type="button"
                      onClick={() => setSelectedFileIndex(idx)}
                      className={`min-h-[32px] inline-flex items-center gap-1.5 rounded-md px-2.5 font-mono text-[11px] transition-colors whitespace-nowrap ${
                        selected
                          ? 'bg-violet-600/25 text-white border border-violet-500/50'
                          : 'text-slate-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
                      }`}
                    >
                      <FileCode2 className="h-3.5 w-3.5 shrink-0" />
                      <span>{ch.path}</span>
                      <span className="text-[10px] opacity-80">
                        {ch.action === 'create' ? '(NEW)' : `+${ch.stats.added}/-${ch.stats.removed}`}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="inline-flex items-center gap-1 rounded-md bg-[#141418] p-0.5 border border-white/[0.08]">
                <button
                  type="button"
                  onClick={() => setFileViewMode('diff')}
                  className={`px-2.5 py-1 rounded text-[11px] font-medium ${
                    fileViewMode === 'diff'
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Diff View
                </button>
                <button
                  type="button"
                  onClick={() => setFileViewMode('full')}
                  className={`px-2.5 py-1 rounded text-[11px] font-medium ${
                    fileViewMode === 'full'
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Full Proposed File
                </button>
              </div>
            </div>

            {activeChange && (
              <div>
                <div className="px-3.5 py-2 border-b border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-300">
                  <span>{activeChange.rationale}</span>
                  <span className="font-mono text-slate-400">
                    {activeChange.action === 'create' ? 'Create New File' : 'Modify Existing File'} ·{' '}
                    {activeChange.language}
                  </span>
                </div>

                {fileViewMode === 'diff' ? (
                  <div className="max-h-[420px] overflow-y-auto font-mono text-[11px] leading-5 divide-y divide-white/[0.02]">
                    {activeChange.diffLines.length === 0 ? (
                      <div className="p-4 text-slate-500">
                        No diff hunks to display for this file.
                      </div>
                    ) : (
                      activeChange.diffLines.map((line, i) => (
                        <div
                          key={i}
                          className={`flex items-start gap-2 px-3 py-0.5 whitespace-pre-wrap break-all ${
                            line.type === 'add'
                              ? 'bg-emerald-500/12 text-emerald-200'
                              : line.type === 'remove'
                                ? 'bg-rose-500/12 text-rose-200'
                                : 'text-slate-400'
                          }`}
                        >
                          <span className="w-10 shrink-0 text-right tabular-nums text-[10px] opacity-55 select-none">
                            {line.newLine ?? line.oldLine ?? ''}
                          </span>
                          <span className="w-3 shrink-0 select-none">
                            {line.type === 'add' ? '+' : line.type === 'remove' ? '-' : ' '}
                          </span>
                          <span className="flex-1 min-w-0">{line.text}</span>
                        </div>
                      ))
                    )}
                  </div>
                ) : (
                  <pre className="max-h-[420px] overflow-auto p-3.5 font-mono text-[11px] leading-5 text-slate-200 whitespace-pre">
                    {activeChange.newContent}
                  </pre>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Recent Builder Revisions List */}
      <div className="pt-4 border-t border-white/[0.06] space-y-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-white">
            <History className="h-4 w-4 text-violet-400" />
            <span>Recent App Builder Revisions</span>
          </div>
          {loadingProposals && <Loader2 className="h-3.5 w-3.5 animate-spin text-slate-400" />}
        </div>

        {proposals.length === 0 ? (
          <p className="text-xs text-slate-500">
            No generated modifications yet. Submit a prompt, code snippet, or UI screenshot above
            to generate your first verified preview.
          </p>
        ) : (
          <div className="divide-y divide-white/[0.06] rounded-lg border border-white/[0.06] bg-[#0d0d10]">
            {proposals.slice(0, 8).map((p) => {
              const sm = statusMeta(p.status);
              const selected = activeProposal?.id === p.id;
              return (
                <div
                  key={p.id}
                  className={`px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs ${
                    selected ? 'bg-violet-500/[0.08]' : ''
                  }`}
                >
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`font-semibold ${sm.textClass}`}>{sm.label}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-white font-medium truncate max-w-md">
                        {p.revisionNote || p.summary}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono tabular-nums truncate">
                      {formatTimestamp(p.createdAt)} · {p.inputModes.join('+')} ·{' '}
                      {p.changes.map((c) => c.path).join(', ')}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveProposalId(p.id);
                        setSelectedFileIndex(0);
                        setPreviewVisible(true);
                      }}
                      className="min-h-[30px] rounded-md border border-white/10 hover:bg-white/[0.08] px-2.5 text-[11px] font-medium text-slate-200 whitespace-nowrap"
                    >
                      Inspect
                    </button>
                    {p.status === 'applied' && p.backupId && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handleRollback(p.id)}
                        className="min-h-[30px] inline-flex items-center gap-1 rounded-md border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 disabled:opacity-40 px-2.5 text-[11px] font-medium text-amber-200 whitespace-nowrap"
                      >
                        <RotateCcw className="h-3 w-3" />
                        <span>Rollback</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
