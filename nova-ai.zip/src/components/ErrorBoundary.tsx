import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  state: ErrorBoundaryState = {
    hasError: false,
    message: '',
  };

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      message: error.message || 'An unexpected application error occurred.',
    };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('NOVA AI ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      let friendly = this.state.message;
      if (friendly.startsWith('{')) {
        try {
          const parsed = JSON.parse(friendly) as { error?: string; path?: string };
          friendly = parsed.error
            ? `Database access error (${parsed.path || 'cloud sync'}): ${parsed.error}`
            : friendly;
        } catch {
          // Keep original
        }
      }

      return (
        <div className="min-h-[100dvh] flex items-center justify-center bg-slate-50 dark:bg-[#0d0d10] text-slate-900 dark:text-slate-100 p-6">
          <div className="max-w-md w-full rounded-2xl border border-rose-500/30 bg-white dark:bg-[#17171c] p-6 space-y-4 shadow-xl">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 text-rose-500 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h1 className="font-display text-lg font-semibold">
                  NOVA AI encountered a problem
                </h1>
                <p className="text-xs text-slate-600 dark:text-slate-400 break-words leading-relaxed">
                  {friendly}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full min-h-[42px] inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-sm font-semibold hover:opacity-95"
            >
              <RefreshCw className="h-4 w-4" />
              <span>Reload NOVA AI</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
