import { useEffect, useMemo, useState, type ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import { Check, Code2, Copy, Download, Eye } from 'lucide-react';

interface CodeBlockProps {
  language: string;
  rawText: string;
  children: ReactNode;
}

function isRenderableSvg(raw: string): boolean {
  const trimmed = raw.trim();
  return (
    trimmed.startsWith('<svg') &&
    trimmed.includes('</svg>') &&
    trimmed.includes('xmlns=')
  );
}

function SvgPreviewCard({ rawText }: { rawText: string }) {
  const svgUrl = useMemo(() => {
    const blob = new Blob([rawText], { type: 'image/svg+xml;charset=utf-8' });
    return URL.createObjectURL(blob);
  }, [rawText]);

  useEffect(() => {
    return () => URL.revokeObjectURL(svgUrl);
  }, [svgUrl]);

  const handleDownloadSvg = () => {
    const a = document.createElement('a');
    a.href = svgUrl;
    a.download = `nova-visual-${Date.now()}.svg`;
    a.click();
  };

  const handleDownloadPng = () => {
    const img = new Image();
    img.onload = () => {
      const w = Math.max(img.naturalWidth || 800, 800);
      const h = Math.max(img.naturalHeight || 600, 600);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0, w, h);
      canvas.toBlob((pngBlob) => {
        if (!pngBlob) return;
        const url = URL.createObjectURL(pngBlob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `nova-visual-${Date.now()}.png`;
        a.click();
        URL.revokeObjectURL(url);
      }, 'image/png');
    };
    img.src = svgUrl;
  };

  return (
    <div className="p-4 flex flex-col items-center gap-3 bg-white dark:bg-[#090b12]">
      <img
        src={svgUrl}
        alt="Generated SVG visual"
        referrerPolicy="no-referrer"
        className="max-w-full max-h-[420px] rounded-xl object-contain"
      />
      <div className="flex flex-wrap items-center justify-end w-full gap-2 pt-1 border-t border-slate-100 dark:border-white/[0.06]">
        <button
          type="button"
          onClick={handleDownloadSvg}
          className="min-h-[34px] inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-white/10 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06] transition-colors whitespace-nowrap"
        >
          <Download className="h-3.5 w-3.5" />
          <span>SVG</span>
        </button>
        <button
          type="button"
          onClick={handleDownloadPng}
          className="min-h-[34px] inline-flex items-center gap-1.5 rounded-lg bg-violet-600 hover:bg-violet-500 text-white px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap"
        >
          <Download className="h-3.5 w-3.5" />
          <span>PNG</span>
        </button>
      </div>
    </div>
  );
}

function CodeBlock({ language, rawText, children }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);
  const canPreviewSvg =
    language.toLowerCase() === 'svg' && isRenderableSvg(rawText);
  const [viewMode, setViewMode] = useState<'preview' | 'code'>(
    canPreviewSvg ? 'preview' : 'code'
  );

  useEffect(() => {
    if (canPreviewSvg) {
      setViewMode('preview');
    }
  }, [canPreviewSvg]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(rawText);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored
    }
  };

  return (
    <div className="my-3 overflow-hidden rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100/90 dark:bg-[#0d101b]">
      <div className="flex items-center justify-between gap-2 px-3.5 py-2 border-b border-slate-200 dark:border-white/10 bg-slate-200/60 dark:bg-white/[0.03]">
        <span className="font-mono text-xs font-medium text-slate-600 dark:text-slate-400">
          {language || 'code'}
        </span>
        <div className="flex items-center gap-1.5">
          {canPreviewSvg && (
            <button
              type="button"
              onClick={() =>
                setViewMode((m) => (m === 'preview' ? 'code' : 'preview'))
              }
              className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-300/60 dark:hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
            >
              {viewMode === 'preview' ? (
                <>
                  <Code2 className="h-3.5 w-3.5" />
                  <span>Code</span>
                </>
              ) : (
                <>
                  <Eye className="h-3.5 w-3.5" />
                  <span>Preview</span>
                </>
              )}
            </button>
          )}
          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-300/60 dark:hover:bg-white/10 transition-colors whitespace-nowrap shrink-0"
            aria-label="Copy code block"
          >
            {copied ? (
              <>
                <Check className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-400" />
                <span className="text-cyan-700 dark:text-cyan-300">Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {canPreviewSvg && viewMode === 'preview' ? (
        <SvgPreviewCard rawText={rawText} />
      ) : (
        <div className="overflow-x-auto p-3.5 text-[13px] leading-relaxed font-mono">
          {children}
        </div>
      )}
    </div>
  );
}

function extractText(node: ReactNode): string {
  if (typeof node === 'string' || typeof node === 'number') {
    return String(node);
  }
  if (Array.isArray(node)) {
    return node.map(extractText).join('');
  }
  if (node && typeof node === 'object' && 'props' in node) {
    const element = node as { props?: { children?: ReactNode } };
    return extractText(element.props?.children);
  }
  return '';
}

interface MarkdownRendererProps {
  content: string;
}

export function MarkdownRenderer({ content }: MarkdownRendererProps) {
  return (
    <div className="text-[15px] leading-[1.7] text-slate-800 dark:text-slate-100 break-words space-y-3">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeHighlight]}
        components={{
          h1: ({ children }) => (
            <h1 className="font-display text-xl font-semibold tracking-tight text-slate-900 dark:text-white pt-2 pb-1">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="font-display text-lg font-semibold tracking-tight text-slate-900 dark:text-white pt-2 pb-0.5">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="font-display text-base font-semibold text-slate-900 dark:text-white pt-1.5">
              {children}
            </h3>
          ),
          p: ({ children }) => <p className="leading-[1.7]">{children}</p>,
          ul: ({ children }) => (
            <ul className="list-disc pl-5 space-y-1.5">{children}</ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal pl-5 space-y-1.5">{children}</ol>
          ),
          li: ({ children }) => <li className="leading-relaxed">{children}</li>,
          a: ({ href, children }) => (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-violet-600 dark:text-cyan-400 underline decoration-violet-500/40 dark:decoration-cyan-400/40 underline-offset-2 hover:decoration-violet-600 dark:hover:decoration-cyan-300 transition-colors"
            >
              {children}
            </a>
          ),
          blockquote: ({ children }) => (
            <blockquote className="my-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100/70 dark:bg-white/[0.03] px-4 py-3 text-slate-700 dark:text-slate-300">
              {children}
            </blockquote>
          ),
          hr: () => (
            <hr className="my-4 border-slate-200 dark:border-white/10" />
          ),
          table: ({ children }) => (
            <div className="my-3 overflow-x-auto rounded-xl border border-slate-200 dark:border-white/10">
              <table className="w-full border-collapse text-left text-sm">
                {children}
              </table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-slate-100 dark:bg-white/[0.04] text-slate-900 dark:text-slate-100 font-medium">
              {children}
            </thead>
          ),
          th: ({ children }) => (
            <th className="border-b border-slate-200 dark:border-white/10 px-3.5 py-2.5 text-xs font-semibold">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="border-b border-slate-200/70 dark:border-white/[0.06] px-3.5 py-2.5 align-top">
              {children}
            </td>
          ),
          pre: ({ children }) => {
            const child = Array.isArray(children) ? children[0] : children;
            let language = '';
            if (child && typeof child === 'object' && 'props' in child) {
              const cls = String(
                (child as { props?: { className?: string } }).props?.className ?? ''
              );
              const match = cls.match(/language-([\w-]+)/);
              if (match) language = match[1];
            }
            const rawText = extractText(children).replace(/\n$/, '');
            return (
              <CodeBlock language={language} rawText={rawText}>
                <pre className="m-0 bg-transparent p-0">{children}</pre>
              </CodeBlock>
            );
          },
          code: ({ className, children, ...props }) => {
            const isBlock = Boolean(className && className.includes('language-'));
            if (isBlock) {
              return (
                <code className={className} {...props}>
                  {children}
                </code>
              );
            }
            return (
              <code
                className="rounded-md bg-slate-200/80 dark:bg-white/10 px-1.5 py-0.5 font-mono text-[13px] text-violet-700 dark:text-cyan-300"
                {...props}
              >
                {children}
              </code>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
