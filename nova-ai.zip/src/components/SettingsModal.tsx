import { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Loader2,
  LogOut,
  Moon,
  RefreshCw,
  ShieldCheck,
  Sun,
  Trash2,
  Volume2,
  X,
  XCircle,
} from 'lucide-react';
import { MODE_LIST, STUDY_LANGUAGE_OPTIONS } from '../lib/modes.ts';
import type {
  AppSettings,
  Conversation,
  GeminiModelInfo,
  HealthStatus,
} from '../types/chat.ts';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  health: HealthStatus | null;
  verifyingHealth: boolean;
  onVerifyConnection: () => void;
  models: GeminiModelInfo[];
  selectedModelId: string;
  onSelectModel: (modelId: string) => void;
  modelsLoading: boolean;
  onRefreshModels: () => void;
  conversations: Conversation[];
  onClearAllConversations: () => Promise<void>;
  currentUser?: {
    displayName: string | null;
    email: string | null;
    emailVerified?: boolean;
  } | null;
  onSignOut?: () => void;
}

export function SettingsModal({
  open,
  onClose,
  settings,
  onUpdateSettings,
  health,
  verifyingHealth,
  onVerifyConnection,
  models,
  selectedModelId,
  onSelectModel,
  modelsLoading,
  onRefreshModels,
  conversations,
  onClearAllConversations,
  currentUser,
  onSignOut,
}: SettingsModalProps) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => {
    if (!open || typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    const loadVoices = () => {
      const list = window.speechSynthesis.getVoices();
      setVoices(list);
    };

    loadVoices();
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
    };
  }, [open]);

  if (!open) return null;

  const handleExport = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      app: 'NOVA AI',
      conversations,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nova-ai-chats-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleTestVoice = () => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const sample =
      settings.speechRecognitionLang === 'bn-BD'
        ? 'নমস্কার, আমি নোভা এআই। আপনার পড়াশোনা ও কাজে সাহায্য করতে প্রস্তুত।'
        : 'Hello, I am NOVA AI, ready to help you learn, build, and write.';
    const utterance = new SpeechSynthesisUtterance(sample);
    utterance.rate = settings.ttsRate;
    if (settings.ttsVoiceURI) {
      const found = voices.find((v) => v.voiceURI === settings.ttsVoiceURI);
      if (found) utterance.voice = found;
    }
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm sm:p-4"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-title"
        onClick={(e) => e.stopPropagation()}
        className="w-full sm:max-w-xl max-h-[90vh] flex flex-col rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#121521] text-slate-900 dark:text-slate-100 shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/[0.08]">
          <div>
            <h2
              id="settings-title"
              className="font-display text-lg font-semibold text-slate-900 dark:text-white"
            >
              Settings
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Preferences, voice, study language, and server status
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            className="min-h-[44px] min-w-[44px] -mr-2 flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/[0.06]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* Account & Security */}
          {currentUser && (
            <section className="space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Account &amp; Security
              </h3>
              <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#171b2b] p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold truncate">
                      {currentUser.displayName ||
                        currentUser.email?.split('@')[0] ||
                        'Private User'}
                    </span>
                    {currentUser.emailVerified && (
                      <span className="inline-flex items-center gap-1 rounded-md bg-emerald-500/15 px-2 py-0.5 text-[11px] font-medium text-emerald-700 dark:text-emerald-300">
                        <CheckCircle2 className="h-3 w-3" />
                        Verified
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {currentUser.email} · Private cloud sync active
                  </div>
                </div>

                {onSignOut && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onSignOut();
                    }}
                    className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 px-3 py-1.5 text-xs font-medium text-rose-700 dark:text-rose-300 transition-colors whitespace-nowrap shrink-0"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                    <span>Sign Out</span>
                  </button>
                )}
              </div>
            </section>
          )}

          {/* Server-Side Gemini Connection */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Server-Side Gemini Connection
            </h3>
            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#171b2b] p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  {health?.ok ? (
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-cyan-600 dark:text-cyan-400 mt-0.5" />
                  ) : (
                    <XCircle className="h-5 w-5 shrink-0 text-rose-600 dark:text-rose-400 mt-0.5" />
                  )}
                  <div className="space-y-1">
                    <div className="text-sm font-medium">
                      {health?.verified
                        ? 'Connected and verified with Gemini API'
                        : health?.configured
                          ? 'Configured on server environment'
                          : 'Server key not detected'}
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      All Gemini requests execute securely on the Node.js backend.
                      The server credential is managed via AI Studio{' '}
                      <span className="font-medium text-slate-800 dark:text-slate-200">
                        Settings &gt; Secrets
                      </span>
                      .
                    </p>
                    {health?.error && (
                      <p className="text-xs text-rose-600 dark:text-rose-400">
                        {health.error.message}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 pt-1">
                <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                  <ShieldCheck className="h-4 w-4 text-violet-600 dark:text-violet-400" />
                  <span>Zero client-side key exposure</span>
                </div>
                <button
                  type="button"
                  onClick={onVerifyConnection}
                  disabled={verifyingHealth}
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#121521] hover:bg-slate-100 dark:hover:bg-[#1f2438] px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                >
                  {verifyingHealth ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="h-3.5 w-3.5" />
                  )}
                  <span>Verify Connection</span>
                </button>
              </div>
            </div>
          </section>

          {/* Appearance */}
          <section className="space-y-2.5">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Appearance
            </h3>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'dark' })}
                className={`min-h-[46px] flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium transition-colors ${
                  settings.theme === 'dark'
                    ? 'border-violet-500 bg-violet-500/12 text-violet-700 dark:text-white'
                    : 'border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.04]'
                }`}
              >
                <Moon className="h-4 w-4" />
                <span>Dark Theme</span>
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'light' })}
                className={`min-h-[46px] flex items-center justify-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-medium transition-colors ${
                  settings.theme === 'light'
                    ? 'border-violet-600 bg-violet-500/10 text-violet-800 dark:text-white'
                    : 'border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.04]'
                }`}
              >
                <Sun className="h-4 w-4" />
                <span>Light Theme</span>
              </button>
            </div>
          </section>

          {/* Study & Assistant Defaults */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Assistant &amp; Study Preferences
            </h3>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label
                  htmlFor="active-model-select"
                  className="block text-xs font-medium text-slate-600 dark:text-slate-400"
                >
                  Active Gemini Chat Model
                </label>
                <button
                  type="button"
                  onClick={onRefreshModels}
                  disabled={modelsLoading}
                  className="inline-flex items-center gap-1 text-xs font-medium text-violet-600 dark:text-cyan-400 hover:underline disabled:opacity-50"
                >
                  <RefreshCw
                    className={`h-3 w-3 ${modelsLoading ? 'animate-spin' : ''}`}
                  />
                  <span>Refresh Models</span>
                </button>
              </div>
              <select
                id="active-model-select"
                value={selectedModelId}
                onChange={(e) => onSelectModel(e.target.value)}
                disabled={models.length === 0}
                className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#171b2b] px-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
              >
                {models.length === 0 ? (
                  <option value="">
                    {modelsLoading ? 'Loading active models...' : 'No active models available'}
                  </option>
                ) : (
                  models.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.displayName} ({m.id}) · {m.tier === 'paid' ? 'Paid Tier' : 'Free Tier'}
                    </option>
                  ))
                )}
              </select>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="default-mode-select"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400"
              >
                Default Mode for New Chats
              </label>
              <select
                id="default-mode-select"
                value={settings.defaultMode}
                onChange={(e) =>
                  onUpdateSettings({
                    defaultMode: e.target.value as AppSettings['defaultMode'],
                  })
                }
                className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#171b2b] px-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
              >
                {MODE_LIST.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Study Mode Explanation Language
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {STUDY_LANGUAGE_OPTIONS.map((opt) => {
                  const active = settings.studyLanguage === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => onUpdateSettings({ studyLanguage: opt.id })}
                      className={`text-left rounded-xl border p-3 transition-colors ${
                        active
                          ? 'border-cyan-500/60 bg-cyan-500/10 text-slate-900 dark:text-white'
                          : 'border-slate-200 dark:border-white/10 hover:bg-slate-50 dark:hover:bg-white/[0.04]'
                      }`}
                    >
                      <div className="text-xs font-semibold">{opt.label}</div>
                      <div className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                        {opt.description}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {health?.searchGroundingAvailable && (
              <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 p-3 cursor-pointer">
                <div>
                  <div className="text-sm font-medium">
                    Enable Web Search by default
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    Ground responses with Google Search when supported by the model
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.defaultWebSearch}
                  onChange={(e) =>
                    onUpdateSettings({ defaultWebSearch: e.target.checked })
                  }
                  className="h-5 w-5 accent-violet-600 rounded"
                />
              </label>
            )}
          </section>

          {/* Voice & Speech */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Voice Input &amp; Text-to-Speech
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label
                  htmlFor="speech-lang"
                  className="block text-xs font-medium text-slate-600 dark:text-slate-400"
                >
                  Voice Input Language
                </label>
                <select
                  id="speech-lang"
                  value={settings.speechRecognitionLang}
                  onChange={(e) =>
                    onUpdateSettings({
                      speechRecognitionLang: e.target
                        .value as AppSettings['speechRecognitionLang'],
                    })
                  }
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#171b2b] px-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                >
                  <option value="auto">Auto (Mode &amp; Browser)</option>
                  <option value="en-US">English (US)</option>
                  <option value="bn-BD">Bengali (বাংলা)</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label
                  htmlFor="tts-voice"
                  className="block text-xs font-medium text-slate-600 dark:text-slate-400"
                >
                  Preferred Read-Aloud Voice
                </label>
                <select
                  id="tts-voice"
                  value={settings.ttsVoiceURI}
                  onChange={(e) =>
                    onUpdateSettings({ ttsVoiceURI: e.target.value })
                  }
                  className="w-full min-h-[44px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#171b2b] px-3 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/50"
                >
                  <option value="">Automatic (Bengali / English)</option>
                  {voices.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between gap-4 rounded-xl border border-slate-200 dark:border-white/10 p-3">
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between text-xs font-medium">
                  <span>Speech Speed</span>
                  <span className="font-mono tabular-nums text-cyan-600 dark:text-cyan-400">
                    {settings.ttsRate.toFixed(2)}x
                  </span>
                </div>
                <input
                  type="range"
                  min={0.75}
                  max={1.5}
                  step={0.05}
                  value={settings.ttsRate}
                  onChange={(e) =>
                    onUpdateSettings({ ttsRate: Number(e.target.value) })
                  }
                  aria-label="Text to speech speed"
                  className="w-full accent-violet-600"
                />
              </div>

              <button
                type="button"
                onClick={handleTestVoice}
                className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/[0.06] whitespace-nowrap shrink-0"
              >
                <Volume2 className="h-3.5 w-3.5" />
                <span>Test</span>
              </button>
            </div>

            <label className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 p-3 cursor-pointer">
              <div>
                <div className="text-sm font-medium">
                  Auto-read assistant responses
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Automatically speak replies aloud once generation finishes
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.autoSpeak}
                onChange={(e) =>
                  onUpdateSettings({ autoSpeak: e.target.checked })
                }
                className="h-5 w-5 accent-violet-600 rounded"
              />
            </label>
          </section>

          {/* Local Data Management */}
          <section className="space-y-2.5">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Local Chat History
            </h3>
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 dark:border-white/10 p-3.5">
              <div className="text-xs text-slate-600 dark:text-slate-400 tabular-nums">
                {conversations.length}{' '}
                {conversations.length === 1 ? 'conversation' : 'conversations'}{' '}
                saved locally in this browser
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleExport}
                  disabled={conversations.length === 0}
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/[0.06] disabled:opacity-40 whitespace-nowrap"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Export JSON</span>
                </button>

                {confirmClear ? (
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={async () => {
                        await onClearAllConversations();
                        setConfirmClear(false);
                      }}
                      className="min-h-[38px] rounded-xl bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 text-xs font-medium whitespace-nowrap"
                    >
                      Confirm Clear
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmClear(false)}
                      className="min-h-[38px] rounded-xl border border-slate-200 dark:border-white/10 px-3 py-1.5 text-xs font-medium whitespace-nowrap"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setConfirmClear(true)}
                    disabled={conversations.length === 0}
                    className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-rose-500/30 text-rose-600 dark:text-rose-400 hover:bg-rose-500/10 px-3 py-1.5 text-xs font-medium disabled:opacity-40 whitespace-nowrap"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Clear All</span>
                  </button>
                )}
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
