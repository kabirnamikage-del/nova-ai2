import { useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Check,
  Copy,
  Download,
  ExternalLink,
  ImagePlus,
  Languages,
  Loader2,
  MessageSquare,
  RotateCcw,
  ScanEye,
  Send,
  ShieldAlert,
  Sliders,
  Sparkles,
  Upload,
  Wand2,
  X,
} from 'lucide-react';
import {
  analyzeImageWithGemini,
  fetchImageProviderStatus,
  runNanoBananaImage,
  type NanoBananaTurnPayload,
} from '../lib/api.ts';
import type {
  ApiErrorInfo,
  ChatAttachment,
  GeneratedChatImage,
  ImageAnalysisTask,
  ImageProviderStatus,
} from '../types/chat.ts';
import {
  CanvasPhotoEditor,
  type EditorImageAsset,
} from './CanvasPhotoEditor.tsx';
import { ErrorBanner } from './ErrorBanner.tsx';
import { MarkdownRenderer } from './MarkdownRenderer.tsx';

export type ImageAssistantTab =
  | 'analyze'
  | 'editor'
  | 'ai-generate'
  | 'ai-edit';

interface ImageAssistantViewProps {
  initialTab?: ImageAssistantTab;
  initialEditImage?: GeneratedChatImage | null;
  onClearInitialEditImage?: () => void;
  onContinueInChat: (prompt: string, attachment: ChatAttachment) => void;
  onSendGeneratedToChat?: (image: GeneratedChatImage, caption?: string) => void;
  onOpenSvgStudio: () => void;
  onOpenSettings: () => void;
}

const ACCEPTED_TYPES = '.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp';
const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;

function readImageFile(file: File): Promise<EditorImageAsset> {
  return new Promise((resolve, reject) => {
    const lower = file.name.toLowerCase();
    let mimeType = file.type.toLowerCase();
    if (
      mimeType === 'image/jpg' ||
      lower.endsWith('.jpg') ||
      lower.endsWith('.jpeg')
    ) {
      mimeType = 'image/jpeg';
    } else if (mimeType === 'image/png' || lower.endsWith('.png')) {
      mimeType = 'image/png';
    } else if (mimeType === 'image/webp' || lower.endsWith('.webp')) {
      mimeType = 'image/webp';
    } else {
      reject(
        new Error(
          `Unsupported image format "${file.name}". Please upload JPG, JPEG, PNG, or WEBP.`
        )
      );
      return;
    }

    if (file.size > MAX_UPLOAD_BYTES) {
      reject(new Error(`"${file.name}" exceeds the 8 MB upload limit.`));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = String(reader.result ?? '');
      const comma = dataUrl.indexOf(',');
      resolve({
        name: file.name || 'image.png',
        mimeType,
        base64: comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl,
      });
    };
    reader.onerror = () => reject(new Error(`Failed to read "${file.name}".`));
    reader.readAsDataURL(file);
  });
}

function HybridGeminiBanner({
  onUploadToAnalyze,
}: {
  onUploadToAnalyze: () => void;
}) {
  return (
    <div className="rounded-2xl border border-violet-500/30 bg-gradient-to-br from-violet-500/10 via-transparent to-cyan-500/10 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="space-y-1">
        <div className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-violet-500 dark:text-cyan-400 shrink-0" />
          <span>Hybrid AI Image Workflow (Free via Gemini Web)</span>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
          Generate images free on{' '}
          <span className="font-mono font-medium">gemini.google.com</span>,
          download your image, then upload it back into NOVA AI for free vision
          Q&amp;A, Bengali/English OCR, or Canvas photo editing.
        </p>
      </div>
      <div className="flex flex-wrap items-center gap-2 shrink-0">
        <a
          href="https://gemini.google.com/"
          target="_blank"
          rel="noopener noreferrer"
          className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white px-4 text-xs font-semibold shadow-sm whitespace-nowrap"
        >
          <span>Generate Image in Gemini</span>
          <ExternalLink className="h-3.5 w-3.5" />
        </a>
        <button
          type="button"
          onClick={onUploadToAnalyze}
          className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-[#1b1b20] hover:bg-slate-50 dark:hover:bg-white/[0.06] px-3.5 text-xs font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap"
        >
          <Upload className="h-3.5 w-3.5" />
          <span>Upload Back to NOVA</span>
        </button>
      </div>
    </div>
  );
}

export function ImageAssistantView({
  initialTab = 'analyze',
  initialEditImage,
  onClearInitialEditImage,
  onContinueInChat,
  onSendGeneratedToChat,
  onOpenSvgStudio,
  onOpenSettings,
}: ImageAssistantViewProps) {
  const [activeTab, setActiveTab] = useState<ImageAssistantTab>(initialTab);

  // Vision & OCR state
  const [visionImage, setVisionImage] = useState<EditorImageAsset | null>(null);
  const [question, setQuestion] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisText, setAnalysisText] = useState('');
  const [analysisModel, setAnalysisModel] = useState<string | null>(null);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);
  const [visionError, setVisionError] = useState<ApiErrorInfo | null>(null);
  const [copiedVision, setCopiedVision] = useState(false);

  // Editor handoff asset
  const [editorAsset, setEditorAsset] = useState<EditorImageAsset | null>(null);

  // Provider status + Nano Banana generation & multi-turn editing states
  const [providerStatus, setProviderStatus] =
    useState<ImageProviderStatus | null>(null);
  const [loadingProvider, setLoadingProvider] = useState(true);

  const [nanoModel, setNanoModel] = useState<
    'gemini-3.1-flash-lite-image' | 'gemini-nano-banana-2.1'
  >('gemini-3.1-flash-lite-image');
  const [paidConfirmed, setPaidConfirmed] = useState(false);

  const [genPrompt, setGenPrompt] = useState('');
  const [genAspect, setGenAspect] = useState('1:1');
  const [genSize, setGenSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [generatingAi, setGeneratingAi] = useState(false);
  const [genError, setGenError] = useState<ApiErrorInfo | null>(null);
  const [genHistory, setGenHistory] = useState<NanoBananaTurnPayload[]>([]);
  const [genFollowUp, setGenFollowUp] = useState('');
  const [genResult, setGenResult] = useState<{
    base64: string;
    mimeType: string;
    dataUrl: string;
    prompt: string;
    caption?: string;
    modelUsed?: string;
  } | null>(null);

  const [aiEditImage, setAiEditImage] = useState<EditorImageAsset | null>(null);
  const [aiEditPrompt, setAiEditPrompt] = useState('');
  const [editingAi, setEditingAi] = useState(false);
  const [aiEditError, setAiEditError] = useState<ApiErrorInfo | null>(null);
  const [aiEditHistory, setAiEditHistory] = useState<NanoBananaTurnPayload[]>([]);
  const [aiEditResult, setAiEditResult] = useState<{
    base64: string;
    mimeType: string;
    dataUrl: string;
    prompt: string;
    caption?: string;
    modelUsed?: string;
  } | null>(null);

  const visionFileRef = useRef<HTMLInputElement>(null);
  const aiEditFileRef = useRef<HTMLInputElement>(null);
  const analyzeAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (initialEditImage) {
      setAiEditImage({
        name: `generated-${initialEditImage.id.slice(0, 6)}.png`,
        mimeType: initialEditImage.mimeType,
        base64: initialEditImage.data,
      });
      setAiEditResult(null);
      setAiEditHistory([]);
      setActiveTab('ai-edit');
      onClearInitialEditImage?.();
    }
  }, [initialEditImage, onClearInitialEditImage]);

  useEffect(() => {
    let mounted = true;
    setLoadingProvider(true);
    fetchImageProviderStatus().then((status) => {
      if (!mounted) return;
      setProviderStatus(status);
      setLoadingProvider(false);
    });
    return () => {
      mounted = false;
      analyzeAbortRef.current?.abort();
    };
  }, []);

  const handleVisionFileSelect = async (files: FileList | null) => {
    if (!files?.length) return;
    setVisionError(null);
    try {
      const asset = await readImageFile(files[0]);
      setVisionImage(asset);
      setAnalysisText('');
      setAnalysisModel(null);
      setFallbackNotice(null);
    } catch (err) {
      setVisionError({
        code: 'INVALID_IMAGE',
        title: 'Image Upload Error',
        message: err instanceof Error ? err.message : 'Unable to load image.',
        hint: 'Upload a JPG, JPEG, PNG, or WEBP file under 8 MB.',
      });
    }
  };

  const runVisionTask = async (task: ImageAnalysisTask) => {
    if (!visionImage || analyzing) return;
    if (task === 'qa' && !question.trim()) {
      setVisionError({
        code: 'QUESTION_REQUIRED',
        title: 'Enter a Question',
        message: 'Type a question about the image before asking.',
        hint: 'You can ask in English or Bengali.',
      });
      return;
    }

    analyzeAbortRef.current?.abort();
    const ctrl = new AbortController();
    analyzeAbortRef.current = ctrl;

    setAnalyzing(true);
    setVisionError(null);
    setFallbackNotice(null);

    try {
      const result = await analyzeImageWithGemini({
        imageBase64: visionImage.base64,
        mimeType: visionImage.mimeType,
        task,
        question: question.trim(),
        signal: ctrl.signal,
      });

      if (result.error) {
        if (result.error.code !== 'ABORTED') {
          setVisionError(result.error);
        }
      } else if (result.text) {
        setAnalysisText(result.text);
        setAnalysisModel(result.modelUsed ?? 'gemini-3.1-flash-lite');
        setFallbackNotice(result.fallbackNotice ?? null);
      }
    } finally {
      analyzeAbortRef.current = null;
      setAnalyzing(false);
    }
  };

  const handleNanoGenerate = async (
    promptToRun: string,
    isFollowUp: boolean
  ) => {
    if (!promptToRun.trim() || generatingAi) return;
    setGeneratingAi(true);
    setGenError(null);

    const priorHistory = isFollowUp ? genHistory : [];
    try {
      const res = await runNanoBananaImage({
        prompt: promptToRun.trim(),
        model: nanoModel,
        aspectRatio: genAspect,
        imageSize: nanoModel === 'gemini-nano-banana-2.1' ? genSize : undefined,
        history: priorHistory,
        confirmPaidRequest: paidConfirmed,
      });

      if (res.error) {
        setGenError(res.error);
      } else if (res.imageBase64) {
        const mime = res.mimeType || 'image/png';
        setGenResult({
          base64: res.imageBase64,
          mimeType: mime,
          dataUrl: `data:${mime};base64,${res.imageBase64}`,
          prompt: promptToRun.trim(),
          caption: res.text,
          modelUsed: res.modelUsed,
        });
        setGenHistory([
          ...priorHistory,
          { role: 'user', text: promptToRun.trim() },
          { role: 'model', imageBase64: res.imageBase64, mimeType: mime },
        ]);
        if (isFollowUp) setGenFollowUp('');
      }
    } finally {
      setGeneratingAi(false);
    }
  };

  const handleAiEditFileSelect = async (files: FileList | null) => {
    if (!files?.length) return;
    setAiEditError(null);
    try {
      const asset = await readImageFile(files[0]);
      setAiEditImage(asset);
      setAiEditResult(null);
      setAiEditHistory([]);
    } catch (err) {
      setAiEditError({
        code: 'INVALID_IMAGE',
        title: 'Image Upload Error',
        message: err instanceof Error ? err.message : 'Unable to load image.',
        hint: 'Upload a JPG, JPEG, PNG, or WEBP file under 8 MB.',
      });
    }
  };

  const handleNanoEditSubmit = async (instruction?: string) => {
    const promptToRun = (instruction ?? aiEditPrompt).trim();
    if (!aiEditImage || !promptToRun || editingAi) return;
    setEditingAi(true);
    setAiEditError(null);

    try {
      const isContinuation = aiEditHistory.length > 0;
      const res = await runNanoBananaImage({
        prompt: promptToRun,
        model: nanoModel,
        aspectRatio: genAspect,
        imageSize: nanoModel === 'gemini-nano-banana-2.1' ? genSize : undefined,
        imageBase64: isContinuation ? undefined : aiEditImage.base64,
        mimeType: isContinuation ? undefined : aiEditImage.mimeType,
        history: isContinuation ? aiEditHistory : undefined,
        confirmPaidRequest: paidConfirmed,
      });

      if (res.error) {
        setAiEditError(res.error);
      } else if (res.imageBase64) {
        const mime = res.mimeType || 'image/png';
        setAiEditResult({
          base64: res.imageBase64,
          mimeType: mime,
          dataUrl: `data:${mime};base64,${res.imageBase64}`,
          prompt: promptToRun,
          caption: res.text,
          modelUsed: res.modelUsed,
        });
        const baseTurn: NanoBananaTurnPayload[] = isContinuation
          ? aiEditHistory
          : [
              {
                role: 'user',
                text: promptToRun,
                imageBase64: aiEditImage.base64,
                mimeType: aiEditImage.mimeType,
              },
              { role: 'model', imageBase64: res.imageBase64, mimeType: mime },
            ];
        if (isContinuation) {
          setAiEditHistory([
            ...baseTurn,
            { role: 'user', text: promptToRun },
            { role: 'model', imageBase64: res.imageBase64, mimeType: mime },
          ]);
        } else {
          setAiEditHistory(baseTurn);
        }
        setAiEditPrompt('');
      }
    } finally {
      setEditingAi(false);
    }
  };

  const tabs: Array<{
    id: ImageAssistantTab;
    label: string;
    badge?: string;
    icon: typeof ScanEye;
  }> = [
    { id: 'analyze', label: 'Analyze & OCR', badge: 'Free', icon: ScanEye },
    { id: 'editor', label: 'Photo Editor', badge: 'Non-AI', icon: Sliders },
    { id: 'ai-generate', label: 'AI Generate', icon: Sparkles },
    { id: 'ai-edit', label: 'AI Edit', icon: Wand2 },
  ];

  const aspectChoices =
    nanoModel === 'gemini-nano-banana-2.1'
      ? ['1:1', '16:9', '4:3', '3:4', '9:16', '1:4', '4:1']
      : ['1:1', '16:9', '4:3', '3:4', '9:16'];

  const PaidConfirmationControl = (
    <div className="rounded-xl border border-amber-500/35 bg-amber-500/10 p-3.5 space-y-2.5">
      <div className="flex items-start gap-2.5">
        <ShieldAlert className="h-4 w-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-950 dark:text-amber-200 leading-relaxed">
          <span className="font-semibold">Cost Control Warning:</span>{' '}
          Nano Banana models (<span className="font-mono">gemini-3.1-flash-lite-image</span> &amp;{' '}
          <span className="font-mono">gemini-nano-banana-2.1</span>) require a paid billing-enabled Gemini API account. NOVA will never submit a paid request without your explicit confirmation.
        </div>
      </div>
      <label className="flex items-center gap-2.5 cursor-pointer text-xs font-medium text-slate-800 dark:text-slate-100">
        <input
          type="checkbox"
          checked={paidConfirmed}
          onChange={(e) => setPaidConfirmed(e.target.checked)}
          className="h-4 w-4 accent-amber-600 rounded"
        />
        <span>
          I confirm this Nano Banana request uses a paid billing-enabled API key
        </span>
      </label>
    </div>
  );

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-6 sm:py-8">
      <div className="mx-auto max-w-5xl space-y-6">
        {/* Header & Segmented Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-semibold tracking-tight text-slate-900 dark:text-white">
              Image Assistant
            </h1>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              Free Gemini vision analysis &amp; Bengali/English OCR, browser Canvas photo editor, Hybrid Gemini Web link, and Nano Banana Studio
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Image assistant tools"
            className="inline-flex flex-wrap items-center gap-1 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-100/90 dark:bg-[#1b1b20] p-1"
          >
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setActiveTab(tab.id)}
                  className={`min-h-[38px] inline-flex items-center gap-1.5 rounded-xl px-3 text-xs font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-[#2a2a32] text-slate-900 dark:text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5 text-violet-500 dark:text-cyan-400" />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span className="text-[10px] font-semibold text-cyan-700 dark:text-cyan-300 opacity-85">
                      · {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* TAB 1: FREE IMAGE UNDERSTANDING & BENGALI/ENGLISH OCR */}
        {activeTab === 'analyze' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            <div className="lg:col-span-5 space-y-4 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
                    Upload Image (JPG, PNG, WEBP)
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Free Gemini Vision &amp; Bengali/English OCR
                  </p>
                </div>
                {visionImage && (
                  <button
                    type="button"
                    onClick={() => {
                      setVisionImage(null);
                      setAnalysisText('');
                      setVisionError(null);
                      setFallbackNotice(null);
                    }}
                    aria-label="Remove image"
                    className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>

              <input
                ref={visionFileRef}
                type="file"
                accept={ACCEPTED_TYPES}
                className="hidden"
                onChange={(e) => {
                  void handleVisionFileSelect(e.target.files);
                  e.target.value = '';
                }}
              />

              {!visionImage ? (
                <button
                  type="button"
                  onClick={() => visionFileRef.current?.click()}
                  className="w-full rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/15 hover:border-violet-500/50 dark:hover:border-cyan-400/50 bg-slate-50 dark:bg-[#141418] py-12 px-4 text-center transition-colors"
                >
                  <Upload className="mx-auto h-8 w-8 text-slate-400 dark:text-slate-500 mb-2.5" />
                  <div className="text-sm font-medium text-slate-900 dark:text-white">
                    Click to select an image
                  </div>
                  <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    JPG, JPEG, PNG, or WEBP up to 8 MB
                  </div>
                </button>
              ) : (
                <div className="space-y-3">
                  <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#0d0d10] flex items-center justify-center">
                    <img
                      src={`data:${visionImage.mimeType};base64,${visionImage.base64}`}
                      alt={visionImage.name}
                      referrerPolicy="no-referrer"
                      className="max-h-64 w-full object-contain"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span className="truncate font-medium text-slate-700 dark:text-slate-200">
                      {visionImage.name}
                    </span>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => visionFileRef.current?.click()}
                        className="text-violet-600 dark:text-cyan-400 hover:underline font-medium"
                      >
                        Change
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setEditorAsset(visionImage);
                          setActiveTab('editor');
                        }}
                        className="text-slate-600 dark:text-slate-300 hover:underline font-medium"
                      >
                        Edit Photo
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  disabled={!visionImage || analyzing}
                  onClick={() => void runVisionTask('describe')}
                  className="min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] hover:border-violet-500/40 px-3 text-xs font-medium text-slate-800 dark:text-slate-100 disabled:opacity-45 transition-colors"
                >
                  <ScanEye className="h-3.5 w-3.5 text-violet-500 dark:text-cyan-400 shrink-0" />
                  <span>Describe</span>
                </button>
                <button
                  type="button"
                  disabled={!visionImage || analyzing}
                  onClick={() => void runVisionTask('ocr_bilingual')}
                  className="min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] hover:border-violet-500/40 px-3 text-xs font-medium text-slate-800 dark:text-slate-100 disabled:opacity-45 transition-colors"
                >
                  <Languages className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-400 shrink-0" />
                  <span>বাংলা + EN OCR</span>
                </button>
                <button
                  type="button"
                  disabled={!visionImage || analyzing}
                  onClick={() => void runVisionTask('ocr_english')}
                  className="min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] hover:border-violet-500/40 px-3 text-xs font-medium text-slate-800 dark:text-slate-100 disabled:opacity-45 transition-colors"
                >
                  <span>English OCR</span>
                </button>
              </div>

              <div className="space-y-2 pt-1">
                <label
                  htmlFor="vision-question-input"
                  className="block text-xs font-medium text-slate-600 dark:text-slate-300"
                >
                  Ask a question about this image (English or বাংলা)
                </label>
                <div className="flex gap-2">
                  <input
                    id="vision-question-input"
                    type="text"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        void runVisionTask('qa');
                      }
                    }}
                    placeholder="e.g., Summarize this Bengali note..."
                    className="min-w-0 flex-1 min-h-[40px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-3 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
                  />
                  <button
                    type="button"
                    disabled={!visionImage || !question.trim() || analyzing}
                    onClick={() => void runVisionTask('qa')}
                    aria-label="Ask Gemini about image"
                    className="min-h-[40px] min-w-[44px] flex items-center justify-center rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white disabled:opacity-40"
                  >
                    {analyzing ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              {visionImage && (
                <button
                  type="button"
                  onClick={() => {
                    onContinueInChat(
                      question.trim() || 'Describe and analyze this image.',
                      {
                        id: crypto.randomUUID(),
                        name: visionImage.name,
                        mimeType: visionImage.mimeType,
                        data: visionImage.base64,
                        size: Math.round((visionImage.base64.length * 3) / 4),
                        kind: 'image',
                      }
                    );
                  }}
                  className="w-full min-h-[38px] inline-flex items-center justify-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/10 hover:bg-slate-100 dark:hover:bg-white/[0.06] text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors"
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Send Image &amp; Question to Chat</span>
                </button>
              )}
            </div>

            <div className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] p-5 min-h-[360px] flex flex-col">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200 dark:border-white/[0.08]">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-slate-900 dark:text-white">
                    Vision &amp; OCR Result
                  </span>
                  {analysisModel && (
                    <span className="font-mono text-[11px] text-cyan-600 dark:text-cyan-400">
                      · {analysisModel}
                    </span>
                  )}
                </div>

                {analysisText && (
                  <button
                    type="button"
                    onClick={async () => {
                      await navigator.clipboard.writeText(analysisText);
                      setCopiedVision(true);
                      setTimeout(() => setCopiedVision(false), 1800);
                    }}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-white/10 px-2.5 py-1 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                  >
                    {copiedVision ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-cyan-500" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              <div className="flex-1 pt-4 space-y-4">
                {fallbackNotice && (
                  <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-800 dark:text-amber-200">
                    {fallbackNotice}
                  </div>
                )}

                {visionError && (
                  <ErrorBanner
                    error={visionError}
                    onDismiss={() => setVisionError(null)}
                    onOpenSettings={onOpenSettings}
                  />
                )}

                {analyzing ? (
                  <div className="py-16 flex flex-col items-center justify-center gap-3 text-sm text-slate-500 dark:text-slate-400">
                    <Loader2 className="h-6 w-6 animate-spin text-violet-500 dark:text-cyan-400" />
                    <span>Analyzing image with Gemini Vision...</span>
                  </div>
                ) : analysisText ? (
                  <MarkdownRenderer content={analysisText} />
                ) : (
                  <div className="py-16 text-center space-y-2">
                    <ScanEye className="mx-auto h-8 w-8 text-slate-400 dark:text-slate-500" />
                    <div className="text-sm font-medium text-slate-700 dark:text-slate-200">
                      Upload an image and choose Describe, OCR, or Ask a Question
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                      Extract printed or handwritten Bengali (বাংলা) and English text, summarize documents, or inspect diagrams and photos.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: CLIENT-SIDE CANVAS PHOTO EDITOR (NON-AI) */}
        {activeTab === 'editor' && (
          <CanvasPhotoEditor
            initialImage={editorAsset}
            onSendToAnalyze={(asset) => {
              setVisionImage(asset);
              setAnalysisText('');
              setActiveTab('analyze');
            }}
          />
        )}

        {/* TAB 3: HYBRID GEMINI LINK + NANO BANANA IMAGE GENERATION */}
        {activeTab === 'ai-generate' && (
          <div className="space-y-5">
            <HybridGeminiBanner
              onUploadToAnalyze={() => setActiveTab('analyze')}
            />

            {!loadingProvider && providerStatus && !providerStatus.available && (
              <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#18181d] p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    Need free vector graphics or diagrams inside NOVA without a paid billing key? Open{' '}
                    <span className="font-semibold">SVG Visual Studio</span>.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onOpenSvgStudio}
                  className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-3 text-xs font-semibold hover:opacity-90 shrink-0"
                >
                  <span>Open SVG Studio</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                    <ImagePlus className="h-4 w-4 text-violet-500 dark:text-cyan-400" />
                    <span>Nano Banana Image Generation</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Official Google Gemini Nano Banana text-to-image &amp; multi-turn refinement
                  </p>
                </div>
                <span className="text-xs font-medium px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-white/[0.06] text-slate-600 dark:text-slate-300">
                  {loadingProvider
                    ? 'Checking...'
                    : providerStatus?.available
                      ? providerStatus.providerName
                      : 'Paid API Key Required'}
                </span>
              </div>

              {PaidConfirmationControl}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label
                    htmlFor="nb-gen-model"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400"
                  >
                    Nano Banana Model
                  </label>
                  <select
                    id="nb-gen-model"
                    value={nanoModel}
                    onChange={(e) =>
                      setNanoModel(
                        e.target.value as
                          | 'gemini-3.1-flash-lite-image'
                          | 'gemini-nano-banana-2.1'
                      )
                    }
                    className="w-full min-h-[38px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-3 text-xs font-medium"
                  >
                    <option value="gemini-3.1-flash-lite-image">
                      gemini-3.1-flash-lite-image (Default)
                    </option>
                    <option value="gemini-nano-banana-2.1">
                      gemini-nano-banana-2.1 (HD 1K/2K/4K)
                    </option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="ai-gen-aspect"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400"
                  >
                    Aspect Ratio
                  </label>
                  <select
                    id="ai-gen-aspect"
                    value={genAspect}
                    onChange={(e) => setGenAspect(e.target.value)}
                    className="w-full min-h-[38px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-3 text-xs font-medium"
                  >
                    {aspectChoices.map((ratio) => (
                      <option key={ratio} value={ratio}>
                        {ratio}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label
                    htmlFor="ai-gen-size"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400"
                  >
                    Resolution {nanoModel !== 'gemini-nano-banana-2.1' && '(2.1 only)'}
                  </label>
                  <select
                    id="ai-gen-size"
                    value={genSize}
                    disabled={nanoModel !== 'gemini-nano-banana-2.1'}
                    onChange={(e) =>
                      setGenSize(e.target.value as '1K' | '2K' | '4K')
                    }
                    className="w-full min-h-[38px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-3 text-xs font-medium disabled:opacity-45"
                  >
                    <option value="1K">1K Standard</option>
                    <option value="2K">2K High</option>
                    <option value="4K">4K Ultra</option>
                  </select>
                </div>
              </div>

              <textarea
                rows={3}
                value={genPrompt}
                onChange={(e) => setGenPrompt(e.target.value)}
                placeholder="Describe the image you want to generate with Nano Banana..."
                className="w-full rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] p-3.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              />

              <div className="flex flex-wrap items-center justify-end gap-2">
                <button
                  type="button"
                  disabled={!genPrompt.trim() || generatingAi || !paidConfirmed}
                  onClick={() => void handleNanoGenerate(genPrompt, false)}
                  className="min-h-[40px] inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 px-4 text-xs font-semibold text-white disabled:opacity-45"
                >
                  {generatingAi ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Generating with Nano Banana...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      <span>Generate Image</span>
                    </>
                  )}
                </button>
              </div>

              {genError && (
                <ErrorBanner
                  error={genError}
                  onDismiss={() => setGenError(null)}
                  onOpenSettings={onOpenSettings}
                />
              )}

              {genResult && (
                <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] p-4 space-y-4">
                  <img
                    src={genResult.dataUrl}
                    alt={genResult.prompt}
                    referrerPolicy="no-referrer"
                    className="max-h-[420px] rounded-xl mx-auto object-contain"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                      {genResult.modelUsed}
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      <a
                        href={genResult.dataUrl}
                        download="nova-nano-banana.png"
                        className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-3 text-xs font-semibold"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Download</span>
                      </a>
                      <button
                        type="button"
                        disabled={generatingAi || !paidConfirmed}
                        onClick={() =>
                          void handleNanoGenerate(genResult.prompt, false)
                        }
                        className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/15 px-3 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-45"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        <span>Regenerate</span>
                      </button>
                      {onSendGeneratedToChat && (
                        <button
                          type="button"
                          onClick={() =>
                            onSendGeneratedToChat(
                              {
                                id: crypto.randomUUID(),
                                mimeType: genResult.mimeType,
                                data: genResult.base64,
                                prompt: genResult.prompt,
                                model: genResult.modelUsed,
                              },
                              genResult.caption
                            )
                          }
                          className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl bg-violet-500/15 text-violet-700 dark:text-cyan-300 px-3 text-xs font-medium hover:bg-violet-500/25"
                        >
                          <MessageSquare className="h-3.5 w-3.5" />
                          <span>Add to Chat</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Multi-turn follow-up image edit inside Nano Banana */}
                  <div className="pt-3 border-t border-slate-200 dark:border-white/10 space-y-2">
                    <div className="text-xs font-medium text-slate-600 dark:text-slate-300">
                      Multi-turn Follow-up Edit
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {[
                        'Change the background',
                        'Make it brighter',
                        'Add warm golden hour lighting',
                      ].map((chip) => (
                        <button
                          key={chip}
                          type="button"
                          onClick={() => setGenFollowUp(chip)}
                          className="rounded-lg border border-slate-200 dark:border-white/10 px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-white/[0.06]"
                        >
                          {chip}
                        </button>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={genFollowUp}
                        onChange={(e) => setGenFollowUp(e.target.value)}
                        placeholder='Follow-up edit (e.g., "change the background to a night sky")...'
                        className="min-w-0 flex-1 min-h-[38px] rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1b1b20] px-3 text-xs"
                      />
                      <button
                        type="button"
                        disabled={
                          !genFollowUp.trim() || generatingAi || !paidConfirmed
                        }
                        onClick={() =>
                          void handleNanoGenerate(genFollowUp, true)
                        }
                        className="min-h-[38px] px-3.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold disabled:opacity-45"
                      >
                        Apply Follow-up
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: HYBRID LINK + NANO BANANA IMAGE-TO-IMAGE & MULTI-TURN EDITING */}
        {activeTab === 'ai-edit' && (
          <div className="space-y-5">
            <HybridGeminiBanner
              onUploadToAnalyze={() => setActiveTab('analyze')}
            />

            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#18181d] p-4 flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Want free offline crop, rotate, resize, brightness, contrast, saturation &amp; filters? Use the non-AI Canvas Photo Editor.
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('editor')}
                className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-3 text-xs font-semibold hover:opacity-90 shrink-0"
              >
                <Sliders className="h-3.5 w-3.5" />
                <span>Open Basic Canvas Photo Editor</span>
              </button>
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                    <Wand2 className="h-4 w-4 text-violet-500 dark:text-cyan-400" />
                    <span>Nano Banana Image-to-Image Editing</span>
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Upload an image and apply multi-turn AI edits via Google Gemini Nano Banana
                  </p>
                </div>
                <select
                  aria-label="Nano Banana edit model"
                  value={nanoModel}
                  onChange={(e) =>
                    setNanoModel(
                      e.target.value as
                        | 'gemini-3.1-flash-lite-image'
                        | 'gemini-nano-banana-2.1'
                    )
                  }
                  className="min-h-[34px] rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] px-2.5 text-xs font-medium"
                >
                  <option value="gemini-3.1-flash-lite-image">
                    gemini-3.1-flash-lite-image
                  </option>
                  <option value="gemini-nano-banana-2.1">
                    gemini-nano-banana-2.1
                  </option>
                </select>
              </div>

              {PaidConfirmationControl}

              <input
                ref={aiEditFileRef}
                type="file"
                accept={ACCEPTED_TYPES}
                className="hidden"
                onChange={(e) => {
                  void handleAiEditFileSelect(e.target.files);
                  e.target.value = '';
                }}
              />

              {!aiEditImage ? (
                <button
                  type="button"
                  onClick={() => aiEditFileRef.current?.click()}
                  className="w-full rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/15 hover:border-violet-500/50 bg-slate-50 dark:bg-[#141418] py-10 px-4 text-center transition-colors"
                >
                  <Upload className="mx-auto h-7 w-7 text-slate-400 mb-2" />
                  <div className="text-sm font-medium text-slate-900 dark:text-white">
                    Upload image for AI editing (JPG, PNG, WEBP)
                  </div>
                </button>
              ) : (
                <div className="flex flex-col sm:flex-row items-start gap-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] p-3">
                  <img
                    src={`data:${aiEditImage.mimeType};base64,${aiEditImage.base64}`}
                    alt={aiEditImage.name}
                    referrerPolicy="no-referrer"
                    className="h-28 w-28 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="text-sm font-medium truncate">
                      {aiEditImage.name}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => aiEditFileRef.current?.click()}
                        className="rounded-lg border border-slate-200 dark:border-white/10 px-2.5 py-1 text-xs font-medium"
                      >
                        Change Image
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setAiEditImage(null);
                          setAiEditResult(null);
                          setAiEditHistory([]);
                        }}
                        className="rounded-lg border border-slate-200 dark:border-white/10 px-2.5 py-1 text-xs font-medium text-rose-500"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-1.5">
                {[
                  'Change the background to a sunset beach',
                  'Make it brighter and sharper',
                  'Convert lighting to cinematic neon blue',
                ].map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => setAiEditPrompt(chip)}
                    className="rounded-lg border border-slate-200 dark:border-white/10 px-2.5 py-1 text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              <textarea
                rows={2}
                value={aiEditPrompt}
                onChange={(e) => setAiEditPrompt(e.target.value)}
                placeholder='Describe the edit (e.g., "change the background", "make it brighter")...'
                className="w-full rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] p-3.5 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/40"
              />

              <div className="flex justify-end">
                <button
                  type="button"
                  disabled={
                    !aiEditImage ||
                    !aiEditPrompt.trim() ||
                    editingAi ||
                    !paidConfirmed
                  }
                  onClick={() => void handleNanoEditSubmit()}
                  className="min-h-[40px] inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 px-4 text-xs font-semibold text-white disabled:opacity-45"
                >
                  {editingAi ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>Applying Nano Banana Edit...</span>
                    </>
                  ) : (
                    <>
                      <Wand2 className="h-4 w-4" />
                      <span>
                        {aiEditHistory.length > 0
                          ? 'Apply Follow-up Edit'
                          : 'Apply AI Edit'}
                      </span>
                    </>
                  )}
                </button>
              </div>

              {aiEditError && (
                <ErrorBanner
                  error={aiEditError}
                  onDismiss={() => setAiEditError(null)}
                  onOpenSettings={onOpenSettings}
                />
              )}

              {aiEditResult && (
                <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#141418] p-4 space-y-3">
                  <img
                    src={aiEditResult.dataUrl}
                    alt="Nano Banana edited output"
                    referrerPolicy="no-referrer"
                    className="max-h-[420px] rounded-xl mx-auto object-contain"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-slate-500 font-mono">
                      {aiEditResult.modelUsed}
                    </span>
                    <div className="flex flex-wrap items-center gap-2">
                      <a
                        href={aiEditResult.dataUrl}
                        download="nova-nano-banana-edited.png"
                        className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-3 text-xs font-semibold"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Download</span>
                      </a>
                      <button
                        type="button"
                        disabled={editingAi || !paidConfirmed}
                        onClick={() =>
                          void handleNanoEditSubmit(aiEditResult.prompt)
                        }
                        className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-white/15 px-3 text-xs font-medium hover:bg-slate-100 dark:hover:bg-white/10 disabled:opacity-45"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        <span>Regenerate</span>
                      </button>
                      {onSendGeneratedToChat && (
                        <button
                          type="button"
                          onClick={() =>
                            onSendGeneratedToChat(
                              {
                                id: crypto.randomUUID(),
                                mimeType: aiEditResult.mimeType,
                                data: aiEditResult.base64,
                                prompt: aiEditResult.prompt,
                                model: aiEditResult.modelUsed,
                              },
                              aiEditResult.caption
                            )
                          }
                          className="min-h-[34px] inline-flex items-center gap-1.5 rounded-xl bg-violet-500/15 text-violet-700 dark:text-cyan-300 px-3 text-xs font-medium hover:bg-violet-500/25"
                        >
                          <MessageSquare className="h-3.5 w-3.5" />
                          <span>Add to Chat</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
