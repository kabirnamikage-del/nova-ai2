import { ArrowUpRight } from 'lucide-react';
import { ASSISTANT_MODES } from '../lib/modes.ts';
import type { AssistantMode } from '../types/chat.ts';
import { NovaLogo } from './NovaLogo.tsx';

interface EmptyStateProps {
  mode: AssistantMode;
  onSelectPrompt: (prompt: string) => void;
  welcomeMessage?: string;
  appDescription?: string;
  customLogoUrl?: string;
}

export function EmptyState({
  mode,
  onSelectPrompt,
  welcomeMessage,
  appDescription,
  customLogoUrl,
}: EmptyStateProps) {
  const modeDef = ASSISTANT_MODES[mode];

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col items-center justify-center px-4 py-10 sm:py-16">
      <div className="mb-4">
        <NovaLogo size={46} customLogoUrl={customLogoUrl} />
      </div>

      <h1 className="font-display text-2xl sm:text-4xl font-semibold tracking-tight text-slate-900 dark:text-white text-center text-balance">
        {welcomeMessage || 'What can I help with?'}
      </h1>
      <p className="mt-2 max-w-xl text-center text-sm sm:text-[15px] text-slate-600 dark:text-slate-400 leading-relaxed">
        {mode === 'general' && appDescription ? appDescription : modeDef.description}
      </p>

      <div className="mt-8 grid w-full grid-cols-1 sm:grid-cols-2 gap-3">
        {modeDef.starters.map((item) => (
          <button
            key={item.title}
            type="button"
            onClick={() => onSelectPrompt(item.prompt)}
            className="group text-left rounded-2xl border border-slate-200 dark:border-white/[0.08] bg-white dark:bg-[#1b1b20] hover:border-violet-500/40 dark:hover:border-white/20 hover:bg-slate-50 dark:hover:bg-[#222228] p-4 transition-all"
          >
            <div className="flex items-start justify-between gap-2">
              <span className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                {item.title}
              </span>
              <ArrowUpRight className="h-4 w-4 shrink-0 text-slate-400 group-hover:text-violet-600 dark:group-hover:text-cyan-400 transition-colors" />
            </div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
              {item.subtitle}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
