interface NovaLogoProps {
  size?: number;
  className?: string;
  customLogoUrl?: string;
}

export function NovaLogo({ size = 28, className = '', customLogoUrl }: NovaLogoProps) {
  if (customLogoUrl) {
    return (
      <img
        src={customLogoUrl}
        alt="App logo"
        style={{ width: size, height: size }}
        className={`rounded-lg object-cover shrink-0 ${className}`}
      />
    );
  }

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="nova-grad" x1="4" y1="4" x2="28" y2="28" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#8B5CF6" />
          <stop offset="100%" stopColor="#06B6D4" />
        </linearGradient>
      </defs>
      <rect
        x="2"
        y="2"
        width="28"
        height="28"
        rx="8"
        stroke="url(#nova-grad)"
        strokeWidth="1.75"
        fill="url(#nova-grad)"
        fillOpacity="0.12"
      />
      <path
        d="M16 7.5L18.6 13.4L24.5 16L18.6 18.6L16 24.5L13.4 18.6L7.5 16L13.4 13.4L16 7.5Z"
        stroke="url(#nova-grad)"
        strokeWidth="1.75"
        strokeLinejoin="round"
        fill="url(#nova-grad)"
        fillOpacity="0.22"
      />
    </svg>
  );
}
