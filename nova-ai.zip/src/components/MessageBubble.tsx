import { useState } from 'react';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Copy,
  Download,
  ExternalLink,
  FileCode,
  FileText,
  Globe,
  Languages,
  Pencil,
  RotateCcw,
  Share2,
  Sparkles,
  Square,
  Volume2,
  Wand2,
  X,
} from 'lucide-react';
import { sanitizeAssistantMarkdown } from '../lib/sanitize.ts';
import type { ChatMessage, GeneratedChatImage } from '../types/chat.ts';
import { ErrorBanner } from './ErrorBanner.tsx';
import { MarkdownRenderer } from './MarkdownRenderer.tsx';
import { NovaLogo } from './NovaLogo.tsx';

interface MessageBubbleProps {
  message: ChatMessage;
  isStreaming: boolean;
  isSpeaking: boolean;
  canEditOrRegenerate: boolean;
  onCopy: (content: string) => void;
  onRegenerate: (messageId: string) => void;
  onSelectVersion: (messageId: string, versionIndex: number) => void;
  onEditUserMessage: (messageId: string, newContent: string) => void;
  onSpeakToggle: (messageId: string, content: string) => void;
  onRefineResponse: (
    type: 'shorter' | 'detailed' | 'bengali',
    content: string
  ) => void;
  onEditGeneratedImage?: (image: GeneratedChatImage) => void;
  onRegenerateGeneratedImage?: (
    messageId: string,
    prompt: string,
    model?: string
  ) => void;
  onOpenSettings: () => void;
}

function getHostname(uri: string): string {
  try {
    return new URL(uri).hostname.replace(/^www\./, '');
  } catch {
    return uri;
  }
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function MessageBubble({
  message,
  isStreaming,
  isSpeaking,
  canEditOrRegenerate,
  onCopy,
  onRegenerate,
  onSelectVersion,
  onEditUserMessage,
  onSpeakToggle,
  onRefineResponse,
  onEditGeneratedImage,
  onRegenerateGeneratedImage,
  onOpenSettings,
}: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [draftText, setDraftText] = useState(message.content);

  const isUser = message.role === 'user';
  const safeAssistantContent = isUser
    ? message.content
    : sanitizeAssistantMarkdown(message.content);

  const handleCopyClick = async () => {
    await onCopy(safeAssistantContent);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const handleShareClick = async () => {
    const shareText = safeAssistantContent;
    if (!shareText) return;
    try {
      if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
        await navigator.share({
          title: 'NOVA AI Response',
          text: shareText,
        });
      } else {
        await onCopy(shareText);
      }
      setShared(true);
      window.setTimeout(() => setShared(false), 1800);
    } catch {
      // User dismissed share sheet or clipboard unsupported; fallback copy quietly
      try {
        await onCopy(shareText);
      } catch {
        // Ignore
      }
    }
  };

  if (isUser) {
    const imageAtts =
      message.attachments?.filter(
        (a) => a.kind === 'image' || a.mimeType.startsWith('image/')
      ) ?? [];
    const fileAtts =
      message.attachments?.filter(
        (a) => a.kind !== 'image' && !a.mimeType.startsWith('image/')
      ) ?? [];

    return (
      <div className="group flex justify-end">
        <div className="max-w-[88%] sm:max-w-[78%] space-y-2">
          {imageAtts.length > 0 && (
            <div className="flex flex-wrap justify-end gap-2">
              {imageAtts.map((att) => {
                const src = `data:${att.mimeType};base64,${att.data}`;
                return (
                  <button
                    key={att.id}
                    type="button"
                    onClick={() => setPreviewImage(src)}
                    className="overflow-hidden rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#141724] transition-transform hover:scale-[1.02]"
                  >
                    <img
                      src={src}
                      alt={att.name}
                      referrerPolicy="no-referrer"
                      className="h-32 w-32 sm:h-40 sm:w-40 object-cover"
                    />
                  </button>
                );
              })}
            </div>
          )}

          {fileAtts.length > 0 && (
            <div className="flex flex-wrap justify-end gap-2">
              {fileAtts.map((att) => {
                const isPdf =
                  att.kind === 'pdf' || att.mimeType === 'application/pdf';
                return (
                  <div
                    key={att.id}
                    className="flex items-center gap-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#141724] px-3 py-2 text-xs"
                  >
                    {isPdf ? (
                      <FileText className="h-4 w-4 text-rose-500 shrink-0" />
                    ) : (
                      <FileCode className="h-4 w-4 text-cyan-500 shrink-0" />
                    )}
                    <div className="min-w-0">
                      <div className="truncate max-w-[160px] font-medium text-slate-800 dark:text-slate-100">
                        {att.name}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
                        {formatBytes(att.size)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {isEditing ? (
            <div className="w-full min-w-[260px] sm:min-w-[380px] rounded-2xl border border-violet-500/40 bg-white dark:bg-[#141724] p-3 space-y-2.5 shadow-sm">
              <textarea
                rows={3}
                value={draftText}
                onChange={(e) => setDraftText(e.target.value)}
                aria-label="Edit message"
                className="w-full resize-y bg-transparent text-[15px] leading-relaxed text-slate-900 dark:text-slate-100 focus:outline-none"
                autoFocus
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setDraftText(message.content);
                    setIsEditing(false);
                  }}
                  className="min-h-[36px] rounded-lg border border-slate-200 dark:border-white/10 px-3 py-1 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={!draftText.trim()}
                  onClick={() => {
                    const trimmed = draftText.trim();
                    if (!trimmed) return;
                    setIsEditing(false);
                    onEditUserMessage(message.id, trimmed);
                  }}
                  className="min-h-[36px] rounded-lg bg-gradient-to-r from-violet-600 to-cyan-600 text-white px-3.5 py-1 text-xs font-semibold hover:opacity-95 disabled:opacity-40"
                >
                  Save &amp; Send
                </button>
              </div>
            </div>
          ) : (
            message.content.trim() && (
              <div className="flex items-start justify-end gap-1.5">
                {canEditOrRegenerate && (
                  <button
                    type="button"
                    onClick={() => {
                      setDraftText(message.content);
                      setIsEditing(true);
                    }}
                    aria-label="Edit message"
                    title="Edit & resend"
                    className="mt-1.5 min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-white/[0.06] opacity-100 lg:opacity-0 lg:group-hover:opacity-100 lg:focus-within:opacity-100 transition-opacity shrink-0"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                )}
                <div className="rounded-2xl rounded-tr-sm bg-gradient-to-br from-violet-600/95 to-indigo-600/95 dark:from-violet-600/30 dark:to-cyan-600/20 border border-violet-500/20 dark:border-violet-400/25 px-4 py-3 text-[15px] leading-relaxed text-white dark:text-slate-100 whitespace-pre-wrap break-words shadow-sm">
                  {message.content}
                </div>
              </div>
            )
          )}
        </div>

        {previewImage && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
            onClick={() => setPreviewImage(null)}
          >
            <button
              type="button"
              onClick={() => setPreviewImage(null)}
              aria-label="Close image preview"
              className="absolute top-4 right-4 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <X className="h-5 w-5" />
            </button>
            <img
              src={previewImage}
              alt="Full size upload"
              referrerPolicy="no-referrer"
              className="max-h-[85vh] max-w-[92vw] rounded-2xl object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        )}
      </div>
    );
  }

  const versionCount = message.versions?.length ?? 0;
  const activeVersionIdx = message.activeVersionIndex ?? Math.max(0, versionCount - 1);

  return (
    <div className="flex items-start gap-3 sm:gap-4">
      <div className="mt-0.5 shrink-0">
        <NovaLogo size={28} />
      </div>

      <div className="min-w-0 flex-1 space-y-3">
        {/* Subtle unboxed metadata line */}
        {(message.modelUsed || message.modeUsed) && (
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
            <span className="font-medium text-slate-700 dark:text-slate-300">
              NOVA AI
            </span>
            {message.modelUsed && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono text-[11px] truncate max-w-[180px]">
                  {message.modelUsed}
                </span>
              </>
            )}
            {message.modeUsed === 'study' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-cyan-600 dark:text-cyan-400">
                  Study Mode
                </span>
              </>
            )}
          </div>
        )}

        {/* Message content or streaming loader */}
        {safeAssistantContent ? (
          <MarkdownRenderer content={safeAssistantContent} />
        ) : isStreaming ? (
          <div
            className="flex items-center gap-2 py-2 text-sm text-slate-500 dark:text-slate-400"
            aria-live="polite"
          >
            <span className="inline-flex gap-1">
              <span className="h-2 w-2 rounded-full bg-violet-500 animate-bounce [animation-delay:-0.2s]" />
              <span className="h-2 w-2 rounded-full bg-indigo-400 animate-bounce [animation-delay:-0.1s]" />
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-bounce" />
            </span>
            <span>Thinking...</span>
          </div>
        ) : null}

        {/* Generated Images rendered cleanly inside chat */}
        {message.generatedImages && message.generatedImages.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {message.generatedImages.map((img) => {
              const src = `data:${img.mimeType};base64,${img.data}`;
              return (
                <div
                  key={img.id}
                  className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#171b2b] shadow-sm"
                >
                  <button
                    type="button"
                    onClick={() => setPreviewImage(src)}
                    className="block w-full bg-slate-100 dark:bg-[#0d0d10]"
                    aria-label="Preview generated image"
                  >
                    <img
                      src={src}
                      alt={img.prompt || 'Generated AI image'}
                      referrerPolicy="no-referrer"
                      className="max-h-80 w-full object-contain"
                    />
                  </button>
                  <div className="p-2.5 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200/80 dark:border-white/[0.06]">
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate max-w-[160px]">
                      <Sparkles className="h-3 w-3 text-violet-500 dark:text-cyan-400 shrink-0" />
                      {img.model || 'Nano Banana'}
                    </span>
                    <div className="flex items-center gap-1.5">
                      <a
                        href={src}
                        download={`nova-${img.id.slice(0, 8)}.png`}
                        className="min-h-[32px] inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-white/10 px-2.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                      >
                        <Download className="h-3 w-3" />
                        <span>Download</span>
                      </a>
                      {onRegenerateGeneratedImage && img.prompt && (
                        <button
                          type="button"
                          onClick={() =>
                            onRegenerateGeneratedImage(
                              message.id,
                              img.prompt!,
                              img.model
                            )
                          }
                          className="min-h-[32px] inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-white/10 px-2.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/[0.06]"
                        >
                          <RotateCcw className="h-3 w-3" />
                          <span>Regenerate</span>
                        </button>
                      )}
                      {onEditGeneratedImage && (
                        <button
                          type="button"
                          onClick={() => onEditGeneratedImage(img)}
                          className="min-h-[32px] inline-flex items-center gap-1 rounded-lg bg-violet-500/12 text-violet-700 dark:text-cyan-300 px-2.5 text-xs font-medium hover:bg-violet-500/20"
                        >
                          <Wand2 className="h-3 w-3" />
                          <span>Edit</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Error state */}
        {message.error && (
          <ErrorBanner
            error={message.error}
            onRetry={() => onRegenerate(message.id)}
            onOpenSettings={onOpenSettings}
          />
        )}

        {/* Grounded Web Search Sources */}
        {message.sources && message.sources.length > 0 && (
          <div className="rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-100/70 dark:bg-[#121521] p-3 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300">
              <Globe className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-400" />
              <span>Grounded Web Sources</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {message.sources.map((src, idx) => (
                <a
                  key={`${src.uri}-${idx}`}
                  href={src.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between gap-2 rounded-lg border border-slate-200/80 dark:border-white/[0.06] bg-white dark:bg-[#171b2b] hover:border-cyan-500/40 px-2.5 py-2 text-xs transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium text-slate-800 dark:text-slate-200">
                      {src.title}
                    </div>
                    <div className="truncate text-[11px] text-slate-500 dark:text-slate-400">
                      {getHostname(src.uri)}
                    </div>
                  </div>
                  <ExternalLink className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Action Bar (visible once streaming completes or content exists) */}
        {!isStreaming && safeAssistantContent && (
          <div className="flex flex-wrap items-center gap-1 pt-0.5">
            {versionCount > 1 && (
              <div className="mr-1 inline-flex items-center gap-0.5 rounded-lg border border-slate-200 dark:border-white/10 px-1 py-0.5 text-xs text-slate-600 dark:text-slate-300 tabular-nums">
                <button
                  type="button"
                  disabled={activeVersionIdx <= 0}
                  onClick={() => onSelectVersion(message.id, activeVersionIdx - 1)}
                  aria-label="Previous response version"
                  className="min-h-[30px] min-w-[28px] flex items-center justify-center rounded hover:bg-slate-200/60 dark:hover:bg-white/10 disabled:opacity-30"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                <span className="px-1 font-mono text-[11px]">
                  {activeVersionIdx + 1}/{versionCount}
                </span>
                <button
                  type="button"
                  disabled={activeVersionIdx >= versionCount - 1}
                  onClick={() => onSelectVersion(message.id, activeVersionIdx + 1)}
                  aria-label="Next response version"
                  className="min-h-[30px] min-w-[28px] flex items-center justify-center rounded hover:bg-slate-200/60 dark:hover:bg-white/10 disabled:opacity-30"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={handleCopyClick}
              aria-label="Copy response"
              className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-white/[0.06] transition-colors whitespace-nowrap"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span className="text-cyan-700 dark:text-cyan-300">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => onSpeakToggle(message.id, safeAssistantContent)}
              aria-label={isSpeaking ? 'Stop speaking' : 'Read response aloud'}
              className={`min-h-[38px] inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
                isSpeaking
                  ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-300'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-white/[0.06]'
              }`}
            >
              {isSpeaking ? (
                <>
                  <Square className="h-3.5 w-3.5 fill-current" />
                  <span>Stop Audio</span>
                </>
              ) : (
                <>
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>Listen</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => void handleShareClick()}
              aria-label="Share response"
              className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-white/[0.06] transition-colors whitespace-nowrap"
            >
              {shared ? (
                <>
                  <Check className="h-3.5 w-3.5 text-cyan-600 dark:text-cyan-400" />
                  <span className="text-cyan-700 dark:text-cyan-300">Shared</span>
                </>
              ) : (
                <>
                  <Share2 className="h-3.5 w-3.5" />
                  <span>Share</span>
                </>
              )}
            </button>

            {canEditOrRegenerate && (
              <>
                <button
                  type="button"
                  onClick={() => onRegenerate(message.id)}
                  aria-label="Regenerate response"
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-white/[0.06] transition-colors whitespace-nowrap"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Regenerate</span>
                </button>

                <button
                  type="button"
                  onClick={() => onRefineResponse('shorter', safeAssistantContent)}
                  className="min-h-[38px] inline-flex items-center rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-white/[0.06] transition-colors whitespace-nowrap"
                >
                  Shorter
                </button>

                <button
                  type="button"
                  onClick={() => onRefineResponse('detailed', safeAssistantContent)}
                  className="min-h-[38px] inline-flex items-center rounded-lg px-2.5 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-white/[0.06] transition-colors whitespace-nowrap"
                >
                  More detail
                </button>

                <button
                  type="button"
                  onClick={() => onRefineResponse('bengali', safeAssistantContent)}
                  aria-label="Explain in Bengali"
                  className="min-h-[38px] inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium text-violet-700 dark:text-violet-300 hover:bg-violet-500/10 dark:hover:bg-violet-500/15 transition-colors whitespace-nowrap"
                >
                  <Languages className="h-3.5 w-3.5" />
                  <span>বাংলায় বুঝিয়ে দাও</span>
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {previewImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setPreviewImage(null)}
        >
          <button
            type="button"
            onClick={() => setPreviewImage(null)}
            aria-label="Close image preview"
            className="absolute top-4 right-4 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
          >
            <X className="h-5 w-5" />
          </button>
          <img
            src={previewImage}
            alt="Full size generated image"
            referrerPolicy="no-referrer"
            className="max-h-[85vh] max-w-[92vw] rounded-2xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
