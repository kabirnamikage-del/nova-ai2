import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  CheckCircle2,
  Cpu,
  History,
  Loader2,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  ShieldCheck,
  Sliders,
  Terminal,
  Zap,
} from 'lucide-react';
import {
  fetchSuperPowerRemote,
  restoreSuperPowerRemote,
  saveSuperPowerRemote,
  testSuperPowerRemote,
  type SuperPowerPayload,
} from '../lib/adminApi.ts';
import { SuperPowerBuilder } from './SuperPowerBuilder.tsx';
import type {
  PublicAppConfig,
  SuperPowerConfig,
  SuperPowerHistoryEntry,
  SuperPowerLanguagePriority,
  SuperPowerPersonalityPreset,
  SuperPowerTestResponse,
  SuperPowerThinkingLevel,
  SuperPowerTone,
  SuperPowerVerbosity,
} from '../types/admin.ts';

interface SuperPowerSectionProps {
  onPublicConfigUpdated: (cfg: PublicAppConfig) => void;
  onAuditRefresh?: () => Promise<void> | void;
  onWorkspaceMutated?: () => Promise<void> | void;
  onToast: (type: 'ok' | 'err', text: string) => void;
}

const DEFAULT_SYSTEM_PROMPT =
  'You are NOVA AI, a thoughtful, accurate, and clear personal AI assistant.';

const PERSONALITY_PRESETS: Array<{
  id: SuperPowerPersonalityPreset;
  label: string;
  description: string;
}> = [
  {
    id: 'nova-balanced',
    label: 'NOVA Balanced',
    description: 'Clear, structured, general-purpose personal AI assistant.',
  },
  {
    id: 'friendly-mentor',
    label: 'Friendly Mentor',
    description: 'Supportive step-by-step guidance that builds confidence.',
  },
  {
    id: 'concise-executive',
    label: 'Concise Executive',
    description: 'Lead with bottom-line answers and crisp bullet takeaways.',
  },
  {
    id: 'technical-architect',
    label: 'Technical Architect',
    description: 'Rigorous engineering specs, edge cases, and trade-offs.',
  },
  {
    id: 'creative-storyteller',
    label: 'Creative Writer',
    description: 'Expressive, vivid, well-paced prose across styles.',
  },
  {
    id: 'bilingual-tutor',
    label: 'Bilingual Tutor',
    description: 'Seamless English & Bengali (বাংলা) concept teaching.',
  },
];

const FALLBACK_CHAT_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash-lite',
  'gemini-4-hydrogen',
  'gemini-3.8-flash',
  'gemini-3.5-flash',
  'gemini-4-neon',
  'gemini-4-carbon',
];

const VISION_MODEL_OPTIONS = [
  'gemini-2.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash-lite',
  'gemini-4-hydrogen',
];

function formatTimestamp(ms: number): string {
  try {
    return new Date(ms).toLocaleString();
  } catch {
    return String(ms);
  }
}

export function SuperPowerSection({
  onPublicConfigUpdated,
  onAuditRefresh,
  onWorkspaceMutated,
  onToast,
}: SuperPowerSectionProps) {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [payload, setPayload] = useState<SuperPowerPayload | null>(null);
  const [savedConfig, setSavedConfig] = useState<SuperPowerConfig | null>(null);
  const [draft, setDraft] = useState<SuperPowerConfig | null>(null);
  const [history, setHistory] = useState<SuperPowerHistoryEntry[]>([]);
  const [revisionNote, setRevisionNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [restoringId, setRestoringId] = useState<string | null>(null);

  // Live Test AI Configuration state
  const [testPrompt, setTestPrompt] = useState(
    'Introduce yourself in two sentences and summarize how you will assist me.'
  );
  const [testMode, setTestMode] = useState<'general' | 'study' | 'coding' | 'writing'>('general');
  const [testUseDraft, setTestUseDraft] = useState(true);
  const [testWebSearch, setTestWebSearch] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testError, setTestError] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<SuperPowerTestResponse | null>(null);
  const [showPromptPreview, setShowPromptPreview] = useState(false);

  const loadSuperPower = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await fetchSuperPowerRemote();
      setPayload(data);
      setSavedConfig(data.config);
      setDraft(data.config);
      setHistory(data.history);
    } catch (err) {
      const msg =
        err instanceof Error ? err.message : 'Unable to load Super Power configuration.';
      setLoadError(msg);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSuperPower();
  }, [loadSuperPower]);

  const hasUnsavedChanges = useMemo(() => {
    if (!savedConfig || !draft) return false;
    return JSON.stringify(savedConfig) !== JSON.stringify(draft);
  }, [savedConfig, draft]);

  const chatModelOptions = useMemo(() => {
    const map = new Map<string, { id: string; label: string }>();
    for (const m of payload?.availableModels ?? []) {
      map.set(m.id, {
        id: m.id,
        label: `${m.displayName || m.id} (${m.tier === 'paid' ? 'Paid' : 'Free'})`,
      });
    }
    for (const id of FALLBACK_CHAT_MODELS) {
      if (!map.has(id)) {
        map.set(id, { id, label: id });
      }
    }
    if (draft?.models.defaultChatModel && !map.has(draft.models.defaultChatModel)) {
      map.set(draft.models.defaultChatModel, {
        id: draft.models.defaultChatModel,
        label: draft.models.defaultChatModel,
      });
    }
    return Array.from(map.values());
  }, [payload?.availableModels, draft?.models.defaultChatModel]);

  const visionModelOptions = useMemo(() => {
    const set = new Set<string>(VISION_MODEL_OPTIONS);
    for (const m of payload?.availableModels ?? []) {
      set.add(m.id);
    }
    if (draft?.models.visionModel) set.add(draft.models.visionModel);
    return Array.from(set);
  }, [payload?.availableModels, draft?.models.visionModel]);

  const handleSaveAndApply = async () => {
    if (!draft) return;
    setSaving(true);
    try {
      const res = await saveSuperPowerRemote({
        config: draft,
        note: revisionNote.trim() || undefined,
      });
      setSavedConfig(res.config);
      setDraft(res.config);
      setHistory(res.history);
      setRevisionNote('');
      onPublicConfigUpdated(res.publicConfig);
      await onAuditRefresh?.();
      onToast(
        'ok',
        `Super Power v${res.config.version} saved and applied to live NOVA AI endpoints.`
      );
    } catch (err) {
      onToast(
        'err',
        err instanceof Error ? err.message : 'Failed to save Super Power configuration.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleRestoreRevision = async (entry: SuperPowerHistoryEntry) => {
    setRestoringId(entry.id);
    try {
      const res = await restoreSuperPowerRemote(entry.id);
      setSavedConfig(res.config);
      setDraft(res.config);
      setHistory(res.history);
      onPublicConfigUpdated(res.publicConfig);
      await onAuditRefresh?.();
      onToast(
        'ok',
        `Restored settings from v${res.restoredFromVersion} (now active v${res.config.version}).`
      );
    } catch (err) {
      onToast(
        'err',
        err instanceof Error ? err.message : 'Failed to restore previous configuration.'
      );
    } finally {
      setRestoringId(null);
    }
  };

  const handleRunTest = async () => {
    if (!draft || !testPrompt.trim()) return;
    setTesting(true);
    setTestError(null);
    try {
      const res = await testSuperPowerRemote({
        prompt: testPrompt.trim(),
        mode: testMode,
        studyLanguage: 'bilingual',
        useWebSearch: testWebSearch,
        draftConfig: testUseDraft ? draft : undefined,
      });
      setTestResult(res);
    } catch (err) {
      setTestError(
        err instanceof Error ? err.message : 'Failed to execute live AI configuration test.'
      );
    } finally {
      setTesting(false);
    }
  };

  if (loading && !draft) {
    return (
      <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-10 flex items-center justify-center gap-3 text-sm text-slate-400">
        <Loader2 className="h-5 w-5 animate-spin text-violet-400" />
        <span>Loading Super Power engine configuration...</span>
      </div>
    );
  }

  if (loadError && !draft) {
    return (
      <div className="rounded-xl border border-rose-500/30 bg-[#141418] p-6 space-y-3">
        <h2 className="font-display text-base font-semibold text-white">
          Unable to Load Super Power
        </h2>
        <p className="text-xs text-rose-200">{loadError}</p>
        <button
          type="button"
          onClick={() => void loadSuperPower()}
          className="min-h-[38px] inline-flex items-center gap-2 rounded-lg bg-white/10 hover:bg-white/15 px-4 text-xs font-medium text-white"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span>Retry</span>
        </button>
      </div>
    );
  }

  if (!draft) return null;

  return (
    <div className="space-y-6">
      {/* Sticky/Top Action Header */}
      <div className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <Zap className="h-5 w-5 text-violet-400 shrink-0" />
              <h2 className="font-display text-lg font-semibold text-white tracking-tight">
                Super Power — Central AI Control
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              Configure NOVA AI&apos;s active personality, system prompt, model routing, API
              provider behavior, feature permissions, and response tuning. Saved changes persist
              on the server and govern every live AI request immediately.
            </p>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 pt-1 tabular-nums">
              <span>Active Version v{savedConfig?.version ?? draft.version}</span>
              <span aria-hidden="true">·</span>
              <span>Updated {formatTimestamp(savedConfig?.updatedAt ?? draft.updatedAt)}</span>
              <span aria-hidden="true">·</span>
              <span>By {savedConfig?.updatedBy || 'system'}</span>
              {hasUnsavedChanges && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-300 font-medium">Unsaved draft edits</span>
                </>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => void loadSuperPower()}
              disabled={loading || saving}
              className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-white/10 hover:bg-white/[0.07] disabled:opacity-50 px-3.5 text-xs font-medium text-slate-200 whitespace-nowrap"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Reload</span>
            </button>
            <button
              type="button"
              disabled={!hasUnsavedChanges || saving}
              onClick={() => savedConfig && setDraft(savedConfig)}
              className="min-h-[40px] inline-flex items-center gap-1.5 rounded-lg border border-white/10 hover:bg-white/[0.07] disabled:opacity-40 px-3.5 text-xs font-medium text-slate-200 whitespace-nowrap"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Discard Draft</span>
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => void handleSaveAndApply()}
              className="min-h-[40px] inline-flex items-center gap-2 rounded-lg bg-violet-600 hover:bg-violet-500 disabled:opacity-50 px-4 text-xs font-semibold text-white whitespace-nowrap transition-colors"
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              <span>Save &amp; Apply Changes</span>
            </button>
          </div>
        </div>

        <div className="pt-2 border-t border-white/[0.06] flex flex-col sm:flex-row sm:items-center gap-3">
          <label
            htmlFor="sp-revision-note"
            className="text-xs font-medium text-slate-400 whitespace-nowrap"
          >
            Revision Note
          </label>
          <input
            id="sp-revision-note"
            type="text"
            value={revisionNote}
            onChange={(e) => setRevisionNote(e.target.value)}
            maxLength={180}
            placeholder="Optional description for Configuration History (e.g., Switched to concise executive tone)"
            className="flex-1 min-h-[38px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
          />
        </div>
      </div>

      {/* 0. Super Power AI App Builder & Modification Center (Prominent Top Section) */}
      <SuperPowerBuilder
        availableModels={payload?.availableModels ?? []}
        onAuditRefresh={onAuditRefresh}
        onWorkspaceMutated={onWorkspaceMutated}
        onToast={onToast}
      />

      {/* 1. AI Personality Control */}
      <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
          <div>
            <h3 className="font-display text-base font-semibold text-white">
              AI Personality Control
            </h3>
            <p className="text-xs text-slate-400">
              Select the persona archetype, conversational tone, and bilingual priority enforced
              in every reply.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {PERSONALITY_PRESETS.map((preset) => {
            const active = draft.personality.preset === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          personality: { ...prev.personality, preset: preset.id },
                        }
                      : prev
                  )
                }
                className={`text-left rounded-lg border p-3.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
                  active
                    ? 'border-violet-500/70 bg-violet-500/12 text-white'
                    : 'border-white/[0.08] bg-[#0d0d10] text-slate-300 hover:border-white/20'
                }`}
              >
                <div className="text-xs font-semibold text-white">{preset.label}</div>
                <div className="mt-1 text-[11px] text-slate-400 leading-relaxed">
                  {preset.description}
                </div>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="space-y-1.5">
            <label htmlFor="sp-tone" className="block text-xs font-medium text-slate-300">
              Conversational Tone
            </label>
            <select
              id="sp-tone"
              value={draft.personality.tone}
              onChange={(e) =>
                setDraft((prev) =>
                  prev
                    ? {
                        ...prev,
                        personality: {
                          ...prev.personality,
                          tone: e.target.value as SuperPowerTone,
                        },
                      }
                    : prev
                )
              }
              className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
            >
              <option value="warm">Warm &amp; Supportive</option>
              <option value="neutral">Neutral &amp; Objective</option>
              <option value="direct">Direct &amp; Matter-of-Fact</option>
              <option value="academic">Academic &amp; Scholarly</option>
              <option value="playful">Engaging &amp; Conversational</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label htmlFor="sp-lang" className="block text-xs font-medium text-slate-300">
              Language Priority (English / Bengali)
            </label>
            <select
              id="sp-lang"
              value={draft.personality.languagePriority}
              onChange={(e) =>
                setDraft((prev) =>
                  prev
                    ? {
                        ...prev,
                        personality: {
                          ...prev.personality,
                          languagePriority: e.target.value as SuperPowerLanguagePriority,
                        },
                      }
                    : prev
                )
              }
              className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
            >
              <option value="match-user">Match User Language Automatically</option>
              <option value="english-first">English First (Default)</option>
              <option value="bengali-first">Bengali (বাংলা) First</option>
              <option value="bilingual-bn-en">Bilingual (English + বাংলা Pair)</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <label className="flex items-start justify-between gap-3 rounded-lg border border-white/[0.07] bg-[#0d0d10] px-3.5 py-3 cursor-pointer">
            <div>
              <div className="text-xs font-medium text-white">Adaptive Empathy</div>
              <div className="text-[11px] text-slate-400">
                Adjust pacing smoothly when users ask follow-up or troubleshooting questions.
              </div>
            </div>
            <input
              type="checkbox"
              checked={draft.personality.empathyBoost}
              onChange={(e) =>
                setDraft((prev) =>
                  prev
                    ? {
                        ...prev,
                        personality: {
                          ...prev.personality,
                          empathyBoost: e.target.checked,
                        },
                      }
                    : prev
                )
              }
              className="mt-0.5 h-4 w-4 accent-violet-500"
            />
          </label>

          <label className="flex items-start justify-between gap-3 rounded-lg border border-white/[0.07] bg-[#0d0d10] px-3.5 py-3 cursor-pointer">
            <div>
              <div className="text-xs font-medium text-white">Strict Grounding &amp; Facts</div>
              <div className="text-[11px] text-slate-400">
                Enforce strict separation between verified facts, search results, and assumptions.
              </div>
            </div>
            <input
              type="checkbox"
              checked={draft.personality.citationsStrictness}
              onChange={(e) =>
                setDraft((prev) =>
                  prev
                    ? {
                        ...prev,
                        personality: {
                          ...prev.personality,
                          citationsStrictness: e.target.checked,
                        },
                      }
                    : prev
                )
              }
              className="mt-0.5 h-4 w-4 accent-violet-500"
            />
          </label>
        </div>
      </section>

      {/* 2. System Prompt Editor & Custom Instructions */}
      <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
          <div>
            <h3 className="font-display text-base font-semibold text-white">
              System Prompt Editor &amp; Custom Instructions
            </h3>
            <p className="text-xs text-slate-400">
              Define NOVA AI&apos;s core system instruction and global custom rules injected across
              all chat turns.
            </p>
          </div>
          <button
            type="button"
            onClick={() =>
              setDraft((prev) =>
                prev ? { ...prev, systemPrompt: DEFAULT_SYSTEM_PROMPT } : prev
              )
            }
            className="min-h-[34px] inline-flex items-center gap-1.5 rounded-lg border border-white/10 hover:bg-white/[0.06] px-3 text-xs font-medium text-slate-300"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Default Prompt</span>
          </button>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="sp-system-prompt" className="font-medium text-slate-200">
              Core System Prompt
            </label>
            <span className="text-slate-400 font-mono tabular-nums">
              {draft.systemPrompt.length} / 8000 chars
            </span>
          </div>
          <textarea
            id="sp-system-prompt"
            rows={4}
            maxLength={8000}
            value={draft.systemPrompt}
            onChange={(e) =>
              setDraft((prev) =>
                prev ? { ...prev, systemPrompt: e.target.value } : prev
              )
            }
            placeholder="Define NOVA AI's core identity, expertise, and baseline rules..."
            className="w-full rounded-lg border border-white/10 bg-[#0d0d10] p-3 font-mono text-xs text-slate-100 leading-relaxed placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <label htmlFor="sp-custom-instructions" className="font-medium text-slate-200">
              Global Custom Instructions
            </label>
            <div className="flex items-center gap-3">
              {draft.customInstructions.trim() && (
                <button
                  type="button"
                  onClick={() =>
                    setDraft((prev) =>
                      prev ? { ...prev, customInstructions: '' } : prev
                    )
                  }
                  className="text-xs text-slate-400 hover:text-white underline"
                >
                  Clear
                </button>
              )}
              <span className="text-slate-400 font-mono tabular-nums">
                {draft.customInstructions.length} / 6000 chars
              </span>
            </div>
          </div>
          <textarea
            id="sp-custom-instructions"
            rows={4}
            maxLength={6000}
            value={draft.customInstructions}
            onChange={(e) =>
              setDraft((prev) =>
                prev ? { ...prev, customInstructions: e.target.value } : prev
              )
            }
            placeholder="Optional global directives appended to every conversation (e.g., preferred formatting rules, domain focus, sign-offs, or safety reminders)..."
            className="w-full rounded-lg border border-white/10 bg-[#0d0d10] p-3 text-xs text-slate-100 leading-relaxed placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
          />
        </div>
      </section>

      {/* 3. AI Model Selection & API Provider Configuration */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/[0.06] pb-3">
            <Cpu className="h-4 w-4 text-cyan-400 shrink-0" />
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                AI Model Selection &amp; Routing
              </h3>
              <p className="text-xs text-slate-400">
                Choose active default models and automatic busy/quota fallback routing.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="space-y-1.5">
              <label htmlFor="sp-default-model" className="block text-xs font-medium text-slate-300">
                Default Chat Model
              </label>
              <select
                id="sp-default-model"
                value={draft.models.defaultChatModel}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          models: { ...prev.models, defaultChatModel: e.target.value },
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
              >
                {chatModelOptions.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="sp-fallback-model"
                className="block text-xs font-medium text-slate-300"
              >
                Fallback Chat Model
              </label>
              <select
                id="sp-fallback-model"
                value={draft.models.fallbackChatModel}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          models: { ...prev.models, fallbackChatModel: e.target.value },
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
              >
                {chatModelOptions.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label
                  htmlFor="sp-vision-model"
                  className="block text-xs font-medium text-slate-300"
                >
                  Vision &amp; OCR Model
                </label>
                <select
                  id="sp-vision-model"
                  value={draft.models.visionModel}
                  onChange={(e) =>
                    setDraft((prev) =>
                      prev
                        ? {
                            ...prev,
                            models: { ...prev.models, visionModel: e.target.value },
                          }
                        : prev
                    )
                  }
                  className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
                >
                  {visionModelOptions.map((id) => (
                    <option key={id} value={id}>
                      {id}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="sp-title-model" className="block text-xs font-medium text-slate-300">
                  Auto-Title Model
                </label>
                <select
                  id="sp-title-model"
                  value={draft.models.titleModel}
                  onChange={(e) =>
                    setDraft((prev) =>
                      prev
                        ? {
                            ...prev,
                            models: { ...prev.models, titleModel: e.target.value },
                          }
                        : prev
                    )
                  }
                  className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
                >
                  {chatModelOptions.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <label className="flex items-start justify-between gap-3 rounded-lg border border-white/[0.07] bg-[#0d0d10] px-3.5 py-3 cursor-pointer">
              <div>
                <div className="text-xs font-medium text-white">
                  Automatic Model Fallback on Quota or Busy
                </div>
                <div className="text-[11px] text-slate-400">
                  Switch automatically to Fallback Chat Model if the primary model returns 429, 404,
                  or 503.
                </div>
              </div>
              <input
                type="checkbox"
                checked={draft.models.autoFallbackEnabled}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          models: { ...prev.models, autoFallbackEnabled: e.target.checked },
                        }
                      : prev
                  )
                }
                className="mt-0.5 h-4 w-4 accent-violet-500"
              />
            </label>
          </div>
        </section>

        {/* 4. API Provider Configuration */}
        <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/[0.06] pb-3">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                API Provider Configuration
              </h3>
              <p className="text-xs text-slate-400">
                Server-managed Gemini API runtime policies, grounding, and timeout behavior.
              </p>
            </div>
          </div>

          {/* Read-only connection status (no client API keys ever rendered or requested) */}
          <div className="rounded-lg border border-white/[0.07] bg-[#0d0d10] px-3.5 py-3 space-y-1.5 text-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400">Primary LLM Provider</span>
              <span className="font-medium text-white">Google Gen AI SDK (Server-Side)</span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400">Server Secret Status</span>
              <span
                className={
                  payload?.geminiConfigured
                    ? 'font-medium text-emerald-400'
                    : 'font-medium text-amber-300'
                }
              >
                {payload?.geminiConfigured
                  ? 'Configured via Environment Secrets'
                  : 'Not Configured in Server Secrets'}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400">Image API Provider</span>
              <span className="text-slate-200">
                {payload?.imageProvider.providerName || 'Hybrid Gemini Web + Nano Banana'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label
                htmlFor="sp-search-provider"
                className="block text-xs font-medium text-slate-300"
              >
                Search Grounding Provider
              </label>
              <select
                id="sp-search-provider"
                value={draft.provider.searchGroundingProvider}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          provider: {
                            ...prev.provider,
                            searchGroundingProvider: e.target.value as 'google-search' | 'disabled',
                          },
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
              >
                <option value="google-search">Google Search Grounding</option>
                <option value="disabled">Disabled</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="sp-image-mode" className="block text-xs font-medium text-slate-300">
                Image Generation Routing
              </label>
              <select
                id="sp-image-mode"
                value={draft.provider.imageProviderMode}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          provider: {
                            ...prev.provider,
                            imageProviderMode: e.target
                              .value as SuperPowerConfig['provider']['imageProviderMode'],
                          },
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 text-xs text-white focus:outline-none focus:border-violet-500/60"
              >
                <option value="hybrid">Hybrid (Gemini Web + Nano Banana API)</option>
                <option value="web-only">Gemini Web Only (Free Tab Handoff)</option>
                <option value="nano-banana-enabled">Nano Banana Studio Enabled</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label htmlFor="sp-timeout" className="block text-xs font-medium text-slate-300">
                Request Timeout (ms)
              </label>
              <input
                id="sp-timeout"
                type="number"
                min={8000}
                max={60000}
                step={1000}
                value={draft.provider.requestTimeoutMs}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          provider: {
                            ...prev.provider,
                            requestTimeoutMs: Math.min(
                              60000,
                              Math.max(8000, Number(e.target.value) || 25000)
                            ),
                          },
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 font-mono tabular-nums text-xs text-white focus:outline-none focus:border-violet-500/60"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="sp-retries" className="block text-xs font-medium text-slate-300">
                Busy Model Retries (0–3)
              </label>
              <input
                id="sp-retries"
                type="number"
                min={0}
                max={3}
                value={draft.provider.maxBusyRetries}
                onChange={(e) =>
                  setDraft((prev) =>
                    prev
                      ? {
                          ...prev,
                          provider: {
                            ...prev.provider,
                            maxBusyRetries: Math.min(3, Math.max(0, Number(e.target.value) || 0)),
                          },
                        }
                      : prev
                  )
                }
                className="w-full min-h-[40px] rounded-lg border border-white/10 bg-[#0d0d10] px-3 font-mono tabular-nums text-xs text-white focus:outline-none focus:border-violet-500/60"
              />
            </div>
          </div>

          <label className="flex items-start justify-between gap-3 rounded-lg border border-white/[0.07] bg-[#0d0d10] px-3.5 py-3 cursor-pointer">
            <div>
              <div className="text-xs font-medium text-white">Retry Automatically on 503 Busy</div>
              <div className="text-[11px] text-slate-400">
                Wait briefly and retry transient upstream busy responses before failing over.
              </div>
            </div>
            <input
              type="checkbox"
              checked={draft.provider.retryOnBusy}
              onChange={(e) =>
                setDraft((prev) =>
                  prev
                    ? {
                        ...prev,
                        provider: { ...prev.provider, retryOnBusy: e.target.checked },
                      }
                    : prev
                )
              }
              className="mt-0.5 h-4 w-4 accent-violet-500"
            />
          </label>
        </section>
      </div>

      {/* 5. AI Feature Enable/Disable & Response Behavior Settings */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-white/[0.06] pb-3">
            <Sliders className="h-4 w-4 text-violet-400 shrink-0" />
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                AI Feature Enable / Disable
              </h3>
              <p className="text-xs text-slate-400">
                Server-enforced switches controlling which AI capabilities run across NOVA AI.
              </p>
            </div>
          </div>

          <div className="divide-y divide-white/[0.06]">
            {(
              [
                {
                  key: 'chatEnabled',
                  title: 'Chat AI Assistant',
                  hint: 'Master switch for /api/chat/stream text completions.',
                },
                {
                  key: 'streamingEnabled',
                  title: 'Progressive Streaming Responses',
                  hint: 'Stream tokens live via SSE instead of waiting for full completion.',
                },
                {
                  key: 'webSearchEnabled',
                  title: 'Web Search Grounding',
                  hint: 'Allow Google Search grounding and source citations in chat.',
                },
                {
                  key: 'visionEnabled',
                  title: 'Vision Analysis & Bilingual OCR',
                  hint: 'Enable /api/image/analyze image understanding and OCR.',
                },
                {
                  key: 'voiceEnabled',
                  title: 'Voice Transcription',
                  hint: 'Enable Gemini audio-to-text transcription endpoint.',
                },
                {
                  key: 'autoTitleEnabled',
                  title: 'Automatic Conversation Titles',
                  hint: 'Generate short chat titles automatically via Gemini.',
                },
                {
                  key: 'svgDiagramsEnabled',
                  title: 'Interactive Vector SVG Diagrams',
                  hint: 'Instruct NOVA to produce interactive visual SVG diagrams when requested.',
                },
              ] as const
            ).map((item) => (
              <label
                key={item.key}
                className="flex items-center justify-between gap-4 py-3 first:pt-1 last:pb-1 cursor-pointer"
              >
                <div>
                  <div className="text-xs font-medium text-white">{item.title}</div>
                  <div className="text-[11px] text-slate-400">{item.hint}</div>
                </div>
                <input
                  type="checkbox"
                  checked={draft.features[item.key]}
                  onChange={(e) =>
                    setDraft((prev) =>
                      prev
                        ? {
                            ...prev,
                            features: { ...prev.features, [item.key]: e.target.checked },
                          }
                        : prev
                    )
                  }
                  className="h-4 w-4 accent-violet-500 shrink-0"
                />
              </label>
            ))}
          </div>
        </section>

        <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
          <div className="border-b border-white/[0.06] pb-3">
            <h3 className="font-display text-base font-semibold text-white">
              Response Behavior Settings
            </h3>
            <p className="text-xs text-slate-400">
              Control reasoning depth, response length, Markdown structure, and uncertainty ethics.
            </p>
          </div>

          <div className="space-y-1.5">
            <div className="text-xs font-medium text-slate-300">
              Reasoning Depth (Thinking Level)
            </div>
            <div className="grid grid-cols-4 gap-1.5 p-1 rounded-lg bg-[#0d0d10] border border-white/[0.06]">
              {(['auto', 'low', 'medium', 'high'] as SuperPowerThinkingLevel[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() =>
                    setDraft((prev) =>
                      prev
                        ? {
                            ...prev,
                            responseBehavior: {
                              ...prev.responseBehavior,
                              thinkingLevel: lvl,
                            },
                          }
                        : prev
                    )
                  }
                  className={`min-h-[34px] rounded-md text-xs font-medium capitalize transition-colors ${
                    draft.responseBehavior.thinkingLevel === lvl
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="text-xs font-medium text-slate-300">Response Verbosity</div>
            <div className="grid grid-cols-3 gap-1.5 p-1 rounded-lg bg-[#0d0d10] border border-white/[0.06]">
              {(['concise', 'balanced', 'detailed'] as SuperPowerVerbosity[]).map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() =>
                    setDraft((prev) =>
                      prev
                        ? {
                            ...prev,
                            responseBehavior: { ...prev.responseBehavior, verbosity: v },
                          }
                        : prev
                    )
                  }
                  className={`min-h-[34px] rounded-md text-xs font-medium capitalize transition-colors ${
                    draft.responseBehavior.verbosity === v
                      ? 'bg-violet-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-white/[0.06] pt-1">
            {(
              [
                {
                  key: 'markdownFormatting',
                  title: 'Structured Markdown & Code Fences',
                  hint: 'Use clean headings, lists, and syntax-highlighted code blocks.',
                },
                {
                  key: 'includeFollowUpSuggestions',
                  title: 'Proactive Next-Step Suggestions',
                  hint: 'Offer 1–2 concise follow-up questions or steps after complex answers.',
                },
                {
                  key: 'admitUncertainty',
                  title: 'Explicit Uncertainty Honesty',
                  hint: 'State clearly when data is missing or uncertain rather than guessing.',
                },
              ] as const
            ).map((opt) => (
              <label
                key={opt.key}
                className="flex items-center justify-between gap-4 py-3 last:pb-1 cursor-pointer"
              >
                <div>
                  <div className="text-xs font-medium text-white">{opt.title}</div>
                  <div className="text-[11px] text-slate-400">{opt.hint}</div>
                </div>
                <input
                  type="checkbox"
                  checked={draft.responseBehavior[opt.key]}
                  onChange={(e) =>
                    setDraft((prev) =>
                      prev
                        ? {
                            ...prev,
                            responseBehavior: {
                              ...prev.responseBehavior,
                              [opt.key]: e.target.checked,
                            },
                          }
                        : prev
                    )
                  }
                  className="h-4 w-4 accent-violet-500 shrink-0"
                />
              </label>
            ))}
          </div>
        </section>
      </div>

      {/* 6. Test AI Configuration */}
      <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.06] pb-3">
          <div className="flex items-center gap-2">
            <Terminal className="h-4 w-4 text-emerald-400 shrink-0" />
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                Test AI Configuration
              </h3>
              <p className="text-xs text-slate-400">
                Execute a real server-side Gemini call using either your unsaved draft or the live
                saved settings.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs">
            <label className="inline-flex items-center gap-1.5 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={testUseDraft}
                onChange={(e) => setTestUseDraft(e.target.checked)}
                className="h-3.5 w-3.5 accent-violet-500"
              />
              <span>Evaluate Unsaved Draft</span>
            </label>
            <label className="inline-flex items-center gap-1.5 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={testWebSearch}
                onChange={(e) => setTestWebSearch(e.target.checked)}
                className="h-3.5 w-3.5 accent-violet-500"
              />
              <span>Enable Web Search</span>
            </label>
            <select
              aria-label="Test Mode"
              value={testMode}
              onChange={(e) =>
                setTestMode(e.target.value as 'general' | 'study' | 'coding' | 'writing')
              }
              className="min-h-[34px] rounded-lg border border-white/10 bg-[#0d0d10] px-2.5 text-xs text-white"
            >
              <option value="general">General Mode</option>
              <option value="study">Study Mode</option>
              <option value="coding">Coding Mode</option>
              <option value="writing">Writing Mode</option>
            </select>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <textarea
            rows={2}
            value={testPrompt}
            onChange={(e) => setTestPrompt(e.target.value)}
            placeholder="Enter a prompt to test NOVA AI with these settings..."
            className="flex-1 rounded-lg border border-white/10 bg-[#0d0d10] p-3 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500/60"
          />
          <button
            type="button"
            disabled={testing || !testPrompt.trim()}
            onClick={() => void handleRunTest()}
            className="min-h-[44px] sm:self-end inline-flex items-center justify-center gap-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 px-5 text-xs font-semibold text-white whitespace-nowrap shrink-0 transition-colors"
          >
            {testing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            <span>Run AI Test</span>
          </button>
        </div>

        {testError && (
          <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-200">
            {testError}
          </div>
        )}

        {testResult && (
          <div className="space-y-3 pt-1">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 tabular-nums">
              <div className="flex flex-wrap items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
                <span className="font-medium text-emerald-300">Live Response Verified</span>
                <span aria-hidden="true">·</span>
                <span>Model: {testResult.modelUsed}</span>
                {testResult.fallbackUsed && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="text-amber-300">Fallback Triggered</span>
                  </>
                )}
                <span aria-hidden="true">·</span>
                <span>Thinking: {testResult.appliedThinkingLevel}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">{testResult.latencyMs} ms</span>
              </div>
              <button
                type="button"
                onClick={() => setShowPromptPreview((v) => !v)}
                className="text-xs text-violet-300 hover:text-violet-200 underline"
              >
                {showPromptPreview ? 'Hide Effective Prompt' : 'Inspect Effective Prompt'}
              </button>
            </div>

            {showPromptPreview && (
              <pre className="max-h-48 overflow-y-auto rounded-lg border border-white/[0.07] bg-[#0d0d10] p-3 font-mono text-[11px] text-slate-300 whitespace-pre-wrap">
                {testResult.systemInstructionPreview}
              </pre>
            )}

            <div className="rounded-lg border border-white/[0.08] bg-[#0d0d10] p-4 text-sm text-slate-100 whitespace-pre-wrap leading-relaxed">
              {testResult.text}
            </div>
          </div>
        )}
      </section>

      {/* 7. Configuration History & Restore Previous Settings */}
      <section className="rounded-xl border border-white/[0.08] bg-[#141418] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
          <div className="flex items-center gap-2">
            <History className="h-4 w-4 text-cyan-400 shrink-0" />
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                Configuration History &amp; Restore
              </h3>
              <p className="text-xs text-slate-400">
                Every saved or restored Super Power snapshot is stored on disk for instant
                one-click rollback.
              </p>
            </div>
          </div>
          <span className="text-xs text-slate-400 tabular-nums">
            {history.length} revision{history.length === 1 ? '' : 's'} stored
          </span>
        </div>

        {history.length === 0 ? (
          <div className="rounded-lg border border-dashed border-white/10 p-6 text-center text-xs text-slate-500">
            No saved revisions yet. Click Save &amp; Apply Changes above to create the first
            snapshot.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/[0.08] text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">Version</th>
                  <th className="py-2.5 pr-4 font-medium">Timestamp</th>
                  <th className="py-2.5 pr-4 font-medium">Summary &amp; Settings</th>
                  <th className="py-2.5 pr-4 font-medium">Actor</th>
                  <th className="py-2.5 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {history.map((entry) => {
                  const isCurrent = savedConfig?.version === entry.version;
                  return (
                    <tr key={entry.id} className="hover:bg-white/[0.02]">
                      <td className="py-3 pr-4 font-mono tabular-nums text-white whitespace-nowrap">
                        v{entry.version}
                        {isCurrent && (
                          <span className="ml-2 text-emerald-400 font-sans font-medium">
                            Active
                          </span>
                        )}
                      </td>
                      <td className="py-3 pr-4 tabular-nums text-slate-400 whitespace-nowrap">
                        {formatTimestamp(entry.savedAt)}
                      </td>
                      <td className="py-3 pr-4">
                        <div className="font-medium text-slate-100">{entry.note}</div>
                        <div className="mt-0.5 text-[11px] text-slate-400">
                          {entry.config.personality.preset} ·{' '}
                          {entry.config.models.defaultChatModel} · thinking:{' '}
                          {entry.config.responseBehavior.thinkingLevel}
                        </div>
                      </td>
                      <td className="py-3 pr-4 text-slate-400 whitespace-nowrap">
                        {entry.actorEmail}
                      </td>
                      <td className="py-3 text-right whitespace-nowrap">
                        <button
                          type="button"
                          disabled={isCurrent || restoringId === entry.id}
                          onClick={() => void handleRestoreRevision(entry)}
                          className="min-h-[34px] inline-flex items-center gap-1.5 rounded-lg border border-white/10 hover:bg-white/[0.08] disabled:opacity-40 px-3 text-xs font-medium text-slate-200"
                        >
                          {restoringId === entry.id ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          ) : (
                            <RotateCcw className="h-3.5 w-3.5" />
                          )}
                          <span>{isCurrent ? 'Current' : 'Restore'}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
