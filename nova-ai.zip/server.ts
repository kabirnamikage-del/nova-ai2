import 'dotenv/config';
import express, { type Request, type Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  ThinkingLevel,
  type GenerateContentResponse,
} from '@google/genai';
import {
  buildGeminiHistory,
  buildSystemInstruction,
  classifyGeminiError,
  getGeminiClient,
  isApiKeyConfigured,
  listAvailableModels,
  markModelQuotaExhausted,
  markModelUnavailable,
  resolveSuperPowerThinkingLevel,
  toGeminiParts,
  type IncomingMessage,
} from './server/gemini.ts';
import {
  classifyImageProviderError,
  editImageWithProvider,
  generateImageWithProvider,
  getImageProviderStatus,
  runNanoBananaRequest,
  type NanoBananaTurn,
} from './server/imageProvider.ts';
import {
  isStepUpPinRequired,
  requireStepUpPin,
  requireSuperAdmin,
  verifySuperAdminToken,
} from './server/adminAuth.ts';
import {
  appendBackendAuditLog,
  getAdminConfig,
  getBackendAuditLogs,
  getPublicAppConfig,
  getSuperPowerConfig,
  getSuperPowerHistory,
  getTelemetrySnapshot,
  recordApiEvent,
  restoreSuperPowerConfig,
  sanitizeSuperPowerConfig,
  saveAdminConfig,
  saveSuperPowerConfig,
} from './server/adminStore.ts';
import {
  applyEditsWithBackup,
  computeLineDiff,
  listBackupSnapshots,
  listWorkspaceTree,
  readWorkspaceFile,
  rollbackBackupSnapshot,
  runTypeScriptValidation,
  syncAndroidCustomizationFiles,
} from './server/adminFiles.ts';
import {
  commitApprovedGitChanges,
  createGitUpdateBranch,
  getGitStatusReport,
  pushToGitHubIfConfigured,
  runBuildValidationSuite,
} from './server/adminGit.ts';
import {
  applyBuilderProposal,
  generateBuilderProposal,
  getBuilderProposals,
  listEditableWorkspaceFiles,
  rejectBuilderProposal,
  rollbackBuilderProposal,
} from './server/superPowerBuilder.ts';
import type {
  AdminConfigDocument,
  BuilderGenerateRequest,
  SuperPowerConfig,
  SuperPowerTestRequest,
} from './src/types/admin.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: '25mb' }));

// Block any direct probing of internal store or secret files
app.use((req, res, next) => {
  if (req.path.startsWith('/.nova-admin') || req.path.startsWith('/.env')) {
    res.status(404).end();
    return;
  }
  next();
});

// Public sanitized live app configuration (branding, maintenance mode, feature matrix — zero secrets)
app.get('/api/app-config', (_req: Request, res: Response) => {
  res.json(getPublicAppConfig());
});

// Health and secure server-side API configuration verification
app.get('/api/health', async (req: Request, res: Response) => {
  const configured = isApiKeyConfigured();
  const verify = req.query.verify === 'true';

  if (!configured) {
    const errInfo = classifyGeminiError(
      Object.assign(new Error('GEMINI_API_KEY not configured'), {
        customCode: 'MISSING_API_KEY',
      })
    );
    res.json({
      ok: false,
      configured: false,
      verified: false,
      searchGroundingAvailable: false,
      timestamp: Date.now(),
      error: errInfo,
    });
    return;
  }

  const sp = getSuperPowerConfig();

  if (!verify) {
    res.json({
      ok: true,
      configured: true,
      verified: undefined,
      searchGroundingAvailable:
        sp.features.webSearchEnabled && sp.provider.searchGroundingProvider !== 'disabled',
      timestamp: Date.now(),
    });
    return;
  }

  try {
    const ai = getGeminiClient();
    const pager = await ai.models.list({ config: { pageSize: 1 } });
    // Consume one page item to confirm live API authentication
    for await (const _model of pager) {
      break;
    }
    res.json({
      ok: true,
      configured: true,
      verified: true,
      searchGroundingAvailable:
        sp.features.webSearchEnabled && sp.provider.searchGroundingProvider !== 'disabled',
      timestamp: Date.now(),
    });
  } catch (err) {
    const classified = classifyGeminiError(err);
    res.status(classified.status).json({
      ok: false,
      configured: true,
      verified: false,
      searchGroundingAvailable: false,
      timestamp: Date.now(),
      error: classified,
    });
  }
});

// List only models actually available from the Gemini API
app.get('/api/models', async (_req: Request, res: Response) => {
  try {
    const models = await listAvailableModels();
    res.json({ models });
  } catch (err) {
    const classified = classifyGeminiError(err);
    res.status(classified.status).json({
      models: [],
      error: classified,
    });
  }
});

// Streaming multi-turn Gemini chat with Super Power runtime control
app.post('/api/chat/stream', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();

  if (!superPower.features.chatEnabled) {
    res.status(403).json({
      error: {
        code: 'FEATURE_DISABLED',
        title: 'Chat Temporarily Disabled',
        message: 'Text chat has been disabled in Super Power settings by the administrator.',
        hint: 'Contact the administrator or re-enable Chat AI in Super Power.',
      },
    });
    return;
  }

  const {
    model: requestedModel,
    messages,
    mode = 'general',
    studyLanguage = 'bilingual',
    useWebSearch = false,
  } = req.body as {
    model?: string;
    messages?: IncomingMessage[];
    mode?: string;
    studyLanguage?: string;
    useWebSearch?: boolean;
  };

  const model =
    typeof requestedModel === 'string' && requestedModel.trim()
      ? requestedModel.trim()
      : superPower.models.defaultChatModel;

  if (!model) {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Model Required',
        message: 'No Gemini model was selected.',
        hint: 'Choose an available model from the model selector.',
      },
    });
    return;
  }

  if (!Array.isArray(messages) || messages.length === 0) {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Message Required',
        message: 'Conversation messages cannot be empty.',
        hint: 'Enter a prompt or attach an image to send.',
      },
    });
    return;
  }

  const lastMessage = messages[messages.length - 1];
  if (!lastMessage || lastMessage.role !== 'user') {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Invalid Turn',
        message: 'The latest message in the conversation must be from the user.',
        hint: 'Try sending your message again.',
      },
    });
    return;
  }

  let closed = false;
  res.on('close', () => {
    if (!res.writableEnded) {
      closed = true;
    }
  });

  const sendEvent = (event: string, data: unknown) => {
    if (closed || res.writableEnded) return;
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  };

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  const upstreamAbort = new AbortController();
  const heartbeatTimer = setInterval(() => {
    if (!closed && !res.writableEnded) {
      res.write(': ping\n\n');
    }
  }, 4000);

  const onClientClose = () => {
    if (!res.writableEnded) {
      closed = true;
      upstreamAbort.abort();
    }
  };
  res.on('close', onClientClose);

  const withTimeout = <T>(promise: Promise<T>, ms: number, label: string): Promise<T> => {
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        upstreamAbort.abort();
        reject(new Error(`${label} timed out after ${Math.round(ms / 1000)}s`));
      }, ms);
      promise.then(
        (val) => {
          clearTimeout(timer);
          resolve(val);
        },
        (err) => {
          clearTimeout(timer);
          reject(err);
        }
      );
    });
  };

  const requestTimeoutMs = Math.min(
    60_000,
    Math.max(8_000, superPower.provider.requestTimeoutMs || 25_000)
  );
  const effectiveSearchEnabled =
    Boolean(useWebSearch) &&
    superPower.features.webSearchEnabled &&
    superPower.provider.searchGroundingProvider !== 'disabled';

  let activeModel = model;

  try {
    const ai = getGeminiClient();
    const systemInstruction = buildSystemInstruction(mode, studyLanguage, superPower);
    const history = buildGeminiHistory(messages.slice(0, -1));
    const latestParts = toGeminiParts(lastMessage);

    const buildChatConfig = (targetModel: string) => {
      const thinkingLevel = resolveSuperPowerThinkingLevel(
        targetModel,
        superPower.responseBehavior.thinkingLevel,
        mode
      );
      const cfg: {
        systemInstruction: string;
        abortSignal: AbortSignal;
        tools?: Array<{ googleSearch: Record<string, never> }>;
        thinkingConfig?: { thinkingLevel: ThinkingLevel };
      } = {
        systemInstruction,
        abortSignal: upstreamAbort.signal,
      };
      if (effectiveSearchEnabled) {
        cfg.tools = [{ googleSearch: {} }];
      }
      if (thinkingLevel) {
        cfg.thinkingConfig = { thinkingLevel };
      }
      return cfg;
    };

    const maxBusyRetries = superPower.provider.retryOnBusy
      ? Math.max(0, Math.min(3, superPower.provider.maxBusyRetries))
      : 0;

    const executeStart = async (targetModel: string) => {
      let attempt = 0;
      while (true) {
        try {
          const chat = ai.chats.create({
            model: targetModel,
            history,
            config: buildChatConfig(targetModel),
          });
          if (!superPower.features.streamingEnabled) {
            const fullResponse = await withTimeout(
              chat.sendMessage({ message: latestParts }),
              requestTimeoutMs,
              'Gemini response'
            );
            return { streaming: false as const, fullResponse };
          }
          const stream = await withTimeout(
            chat.sendMessageStream({ message: latestParts }),
            Math.min(requestTimeoutMs, 20_000),
            'Gemini stream start'
          );
          return { streaming: true as const, stream };
        } catch (err) {
          const classified = classifyGeminiError(err);
          if (classified.code === 'MODEL_BUSY' && attempt < maxBusyRetries && !closed) {
            attempt++;
            await new Promise((r) => setTimeout(r, 750 * attempt));
            continue;
          }
          throw err;
        }
      }
    };

    let startedRun;
    try {
      startedRun = await executeStart(activeModel);
    } catch (primaryErr) {
      const classified = classifyGeminiError(primaryErr);
      const fallbackModel = superPower.models.fallbackChatModel?.trim();
      const canFallback =
        superPower.models.autoFallbackEnabled &&
        Boolean(fallbackModel) &&
        fallbackModel !== activeModel &&
        !closed &&
        (classified.code === 'MODEL_NOT_FOUND' ||
          classified.code === 'MODEL_BUSY' ||
          classified.code === 'QUOTA_EXCEEDED');

      if (!canFallback) {
        throw primaryErr;
      }

      if (classified.code === 'MODEL_NOT_FOUND') {
        markModelUnavailable(activeModel);
      } else if (classified.code === 'QUOTA_EXCEEDED') {
        markModelQuotaExhausted(activeModel);
      }

      activeModel = fallbackModel!;
      startedRun = await executeStart(activeModel);
    }

    const seenUris = new Set<string>();
    const collectedSources: Array<{ title: string; uri: string }> = [];
    const collectedQueries = new Set<string>();
    let finishReason = 'STOP';
    let emittedText = false;

    const processCandidate = (responseChunk: GenerateContentResponse) => {
      const candidate = responseChunk.candidates?.[0];
      const parts = candidate?.content?.parts ?? [];
      let visibleDelta =
        parts.length > 0
          ? parts
              .filter(
                (p) =>
                  !(p as { thought?: boolean }).thought &&
                  typeof p.text === 'string'
              )
              .map((p) => p.text ?? '')
              .join('')
          : responseChunk.text ?? '';

      if (visibleDelta) {
        visibleDelta = visibleDelta.replace(/<\/?thought>/gi, '');
      }

      if (visibleDelta) {
        emittedText = true;
        sendEvent('chunk', { text: visibleDelta });
      }

      if (candidate?.finishReason) {
        finishReason = candidate.finishReason;
      }

      const grounding = candidate?.groundingMetadata;
      if (grounding?.webSearchQueries) {
        for (const q of grounding.webSearchQueries) {
          if (q) collectedQueries.add(q);
        }
      }

      if (grounding?.groundingChunks) {
        let addedSource = false;
        for (const gChunk of grounding.groundingChunks) {
          const web = gChunk.web;
          if (web?.uri && !seenUris.has(web.uri)) {
            seenUris.add(web.uri);
            collectedSources.push({
              title: web.title?.trim() || web.uri,
              uri: web.uri,
            });
            addedSource = true;
          }
        }
        if (addedSource || collectedQueries.size > 0) {
          sendEvent('grounding', {
            sources: collectedSources,
            searchQueries: Array.from(collectedQueries),
          });
        }
      }
    };

    if (!startedRun.streaming) {
      processCandidate(startedRun.fullResponse);
    } else {
      const iterator = startedRun.stream[Symbol.asyncIterator]();
      while (!closed) {
        const nextStep = await withTimeout(
          iterator.next(),
          requestTimeoutMs,
          'Gemini response chunk'
        );
        if (nextStep.done) break;
        processCandidate(nextStep.value as GenerateContentResponse);
      }
    }

    if (!closed) {
      if (!emittedText) {
        recordApiEvent({
          category: 'chat',
          route: '/api/chat/stream',
          model: activeModel,
          ok: false,
          status: 502,
          errorCode: 'EMPTY_RESPONSE',
          errorMessage: 'The model completed without returning any text.',
        });
        sendEvent('error', {
          status: 502,
          code: 'EMPTY_RESPONSE',
          title: 'Empty Response',
          message: 'The model completed without returning any text.',
          hint: 'Click Retry or select Gemini 3.1 Flash Lite in the model selector.',
        });
      } else {
        recordApiEvent({
          category: 'chat',
          route: '/api/chat/stream',
          model: activeModel,
          ok: true,
          status: 200,
        });
        sendEvent('done', { finishReason, modelUsed: activeModel });
      }
      res.end();
    }
  } catch (err) {
    const classified = classifyGeminiError(err);
    recordApiEvent({
      category: 'chat',
      route: '/api/chat/stream',
      model: activeModel,
      ok: false,
      status: classified.status,
      errorCode: classified.code,
      errorMessage: classified.message,
    });
    if (classified.code === 'MODEL_NOT_FOUND' && activeModel) {
      markModelUnavailable(activeModel);
    }
    if (!closed) {
      sendEvent('error', classified);
      res.end();
    }
  } finally {
    clearInterval(heartbeatTimer);
    res.off('close', onClientClose);
  }
});

// Generate a concise conversation title from the initial prompt
app.post('/api/chat/title', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();
  const { prompt, model } = req.body as {
    prompt?: string;
    model?: string;
  };

  if (!prompt || typeof prompt !== 'string') {
    res.status(400).json({ error: 'Prompt is required' });
    return;
  }

  if (!superPower.features.autoTitleEnabled) {
    res.json({ title: prompt.trim().slice(0, 44), disabled: true });
    return;
  }

  const targetModel =
    superPower.models.titleModel?.trim() ||
    (typeof model === 'string' && model.trim()) ||
    'gemini-3.1-flash-lite';

  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: targetModel,
      contents: `Create a concise 3 to 5 word title summarizing this user message. Return ONLY the plain title with no quotes, punctuation, or markdown:\n\n${prompt.slice(0, 500)}`,
    });

    const cleanTitle = (response.text ?? '')
      .replace(/^["'`#*\s]+|["'`#*\s.]+$/g, '')
      .split('\n')[0]
      .trim()
      .slice(0, 60);

    res.json({ title: cleanTitle || prompt.trim().slice(0, 40) });
  } catch (err) {
    const classified = classifyGeminiError(err);
    res.status(classified.status).json({ error: classified });
  }
});

// Server-side audio transcription fallback via Gemini when browser SpeechRecognition is unavailable
app.post('/api/transcribe', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();
  if (!superPower.features.voiceEnabled) {
    res.status(403).json({
      error: {
        code: 'FEATURE_DISABLED',
        title: 'Voice Transcription Disabled',
        message: 'Server voice transcription is currently disabled by Super Power settings.',
        hint: 'Ask your administrator to enable Voice Transcription in Super Power.',
      },
    });
    return;
  }

  const { audioBase64, mimeType = 'audio/webm', language = 'auto' } = req.body as {
    audioBase64?: string;
    mimeType?: string;
    language?: string;
  };

  if (!audioBase64 || typeof audioBase64 !== 'string') {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Audio Required',
        message: 'No audio data was provided for transcription.',
        hint: 'Record a voice message and try again.',
      },
    });
    return;
  }

  try {
    const ai = getGeminiClient();
    const langHint =
      language === 'bn-BD'
        ? 'The speaker is likely speaking Bengali (বাংলা) or English. Transcribe accurately in the spoken script.'
        : language === 'en-US'
          ? 'The speaker is speaking English. Return only the clean transcription text.'
          : 'Transcribe the spoken audio accurately in its original language (English, Bengali, etc.). Return only the transcribed text.';

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType,
              data: audioBase64,
            },
          },
          { text: langHint },
        ],
      },
    });

    recordApiEvent({
      category: 'voice',
      route: '/api/transcribe',
      model: 'gemini-3.5-transcribe',
      ok: true,
      status: 200,
    });
    res.json({ text: (response.text ?? '').trim() });
  } catch (err) {
    const classified = classifyGeminiError(err);
    recordApiEvent({
      category: 'voice',
      route: '/api/transcribe',
      model: 'gemini-3.5-transcribe',
      ok: false,
      status: classified.status,
      errorCode: classified.code,
      errorMessage: classified.message,
    });
    res.status(classified.status).json({ error: classified });
  }
});

let unavailable25LiteUntil = 0;

// Free Image Understanding: description, Q&A, and Bengali/English OCR
// Uses gemini-2.5-flash-lite first (subject to project availability), falling back to gemini-3.1-flash-lite on 404 MODEL_NOT_FOUND
app.post('/api/image/analyze', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();
  if (!superPower.features.visionEnabled) {
    res.status(403).json({
      error: {
        code: 'FEATURE_DISABLED',
        title: 'Vision Analysis Disabled',
        message: 'Image understanding & OCR is currently disabled by Super Power settings.',
        hint: 'Enable Vision Analysis & OCR in Super Power to restore this feature.',
      },
    });
    return;
  }

  const {
    imageBase64,
    mimeType,
    task = 'describe',
    question = '',
    model,
  } = req.body as {
    imageBase64?: string;
    mimeType?: string;
    task?: 'describe' | 'qa' | 'ocr_bilingual' | 'ocr_english';
    question?: string;
    model?: string;
  };

  if (!imageBase64 || typeof imageBase64 !== 'string') {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Image Required',
        message: 'No image data was provided for analysis.',
        hint: 'Upload a JPG, JPEG, PNG, or WEBP image and try again.',
      },
    });
    return;
  }

  const normalizedMime =
    mimeType?.toLowerCase() === 'image/jpg'
      ? 'image/jpeg'
      : mimeType?.toLowerCase() || '';
  const allowedMimes = new Set(['image/jpeg', 'image/png', 'image/webp']);
  if (!allowedMimes.has(normalizedMime)) {
    res.status(400).json({
      error: {
        code: 'UNSUPPORTED_IMAGE_FORMAT',
        title: 'Unsupported Image Format',
        message: `Format "${mimeType || 'unknown'}" is not supported.`,
        hint: 'Please upload a JPG, JPEG, PNG, or WEBP image.',
      },
    });
    return;
  }

  let promptText = '';
  if (task === 'ocr_bilingual') {
    promptText = [
      'Perform accurate Optical Character Recognition (OCR) on this image.',
      'Extract ALL visible Bengali (বাংলা) and English text verbatim, preserving lines, headings, numbers, and tables cleanly.',
      'If there is Bengali text, keep every Bengali character and diacritic exact (do not romanize).',
      question.trim()
        ? `Additional user instruction: ${question.trim()}`
        : 'Format output cleanly with an "Extracted Text" section, followed by a brief summary only if helpful.',
    ].join('\n');
  } else if (task === 'ocr_english') {
    promptText = [
      'Extract all visible English text from this image accurately and verbatim, preserving headings, lists, and formatting.',
      'If no readable English text is present, state that clearly.',
    ].join('\n');
  } else if (task === 'qa') {
    if (!question.trim()) {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Question Required',
          message: 'Please enter a question about the uploaded image.',
          hint: 'Ask anything about objects, text, code, or details in the image.',
        },
      });
      return;
    }
    promptText = `Answer the user's question accurately based strictly on the attached image. Respond in the same language as the question (English or Bengali) when appropriate.\n\nQuestion: ${question.trim()}`;
  } else {
    const customExtra = superPower.customInstructions?.trim()
      ? `\n\nAdmin Instructions: ${superPower.customInstructions.trim()}`
      : '';
    promptText =
      'Provide a clear, well-structured description of this image. Cover the main subjects, setting, colors/lighting, any visible text (English or Bengali), and key details.' +
      customExtra;
  }

  const runVisionRequest = async (targetModel: string) => {
    const ai = getGeminiClient();
    const abortCtrl = new AbortController();
    const timer = setTimeout(
      () => abortCtrl.abort(),
      Math.min(60_000, Math.max(10_000, superPower.provider.requestTimeoutMs || 25_000))
    );
    try {
      const response = await ai.models.generateContent({
        model: targetModel,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: normalizedMime,
                data: imageBase64,
              },
            },
            { text: promptText },
          ],
        },
        config: {
          abortSignal: abortCtrl.signal,
        },
      });
      return (response.text ?? '').trim();
    } finally {
      clearTimeout(timer);
    }
  };

  const requestedModel =
    typeof model === 'string' && model.trim() && model.trim() !== 'gemini-2.5-flash-lite'
      ? model.trim()
      : superPower.models.visionModel?.trim() || 'gemini-2.5-flash-lite';

  try {
    let usedModel = requestedModel;
    let fallbackNotice: string | undefined;
    let text = '';

    const runWithBusyRetry = async (targetModel: string) => {
      try {
        return await runVisionRequest(targetModel);
      } catch (err) {
        const classified = classifyGeminiError(err);
        if (classified.code === 'MODEL_BUSY') {
          await new Promise((r) => setTimeout(r, 800));
          return await runVisionRequest(targetModel);
        }
        throw err;
      }
    };

    const skipPrimary25 =
      requestedModel === 'gemini-2.5-flash-lite' &&
      Date.now() < unavailable25LiteUntil;

    if (skipPrimary25) {
      usedModel = 'gemini-3.1-flash-lite';
      fallbackNotice =
        'gemini-2.5-flash-lite is not enabled on this project; automatically used gemini-3.1-flash-lite for free-tier vision.';
      text = await runWithBusyRetry(usedModel);
    } else {
      try {
        text = await runWithBusyRetry(requestedModel);
      } catch (primaryErr) {
        const classifiedPrimary = classifyGeminiError(primaryErr);
        if (
          classifiedPrimary.code === 'MODEL_NOT_FOUND' &&
          requestedModel !== 'gemini-3.1-flash-lite'
        ) {
          if (requestedModel === 'gemini-2.5-flash-lite') {
            unavailable25LiteUntil = Date.now() + 5 * 60_000;
          }
          usedModel = 'gemini-3.1-flash-lite';
          fallbackNotice = `${requestedModel} is not enabled on this project; automatically used ${usedModel} for free-tier vision.`;
          text = await runWithBusyRetry(usedModel);
        } else {
          throw primaryErr;
        }
      }
    }

    if (!text) {
      res.status(502).json({
        error: {
          code: 'EMPTY_RESPONSE',
          title: 'Empty Vision Response',
          message: 'The vision model completed without returning text.',
          hint: 'Try again with a clearer image or a different prompt.',
        },
      });
      return;
    }

    recordApiEvent({
      category: 'image_analyze',
      route: '/api/image/analyze',
      model: usedModel,
      ok: true,
      status: 200,
    });
    res.json({
      text,
      modelUsed: usedModel,
      requestedModel,
      fallbackNotice,
    });
  } catch (err) {
    const classified = classifyGeminiError(err);
    recordApiEvent({
      category: 'image_analyze',
      route: '/api/image/analyze',
      model: requestedModel,
      ok: false,
      status: classified.status,
      errorCode: classified.code,
      errorMessage: classified.message,
    });
    res.status(classified.status).json({ error: classified });
  }
});

// Separate AI Image Generation & Editing provider capability status
app.get('/api/image/provider', (_req: Request, res: Response) => {
  res.json(getImageProviderStatus());
});

app.post('/api/image/generate', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();
  if (superPower.provider.imageProviderMode === 'web-only') {
    res.status(403).json({
      error: {
        code: 'FEATURE_DISABLED',
        title: 'API Image Generation Restricted',
        message: 'Image generation is currently set to Gemini Web mode in Super Power.',
        hint: 'Use the Generate Image button (gemini.google.com) or enable Hybrid / Nano Banana mode in Super Power.',
      },
    });
    return;
  }

  const {
    prompt,
    aspectRatio = '1:1',
    model,
    imageSize,
    confirmPaidRequest,
  } = req.body as {
    prompt?: string;
    aspectRatio?: string;
    model?: string;
    imageSize?: '1K' | '2K' | '4K';
    confirmPaidRequest?: boolean;
  };

  if (!prompt || !prompt.trim()) {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Prompt Required',
        message: 'Describe the image you want to generate.',
        hint: 'Enter a descriptive prompt and try again.',
      },
    });
    return;
  }

  try {
    const result = await generateImageWithProvider({
      prompt: prompt.trim(),
      aspectRatio,
      model,
      imageSize,
      confirmPaidRequest,
    });
    recordApiEvent({
      category: 'image_gen',
      route: '/api/image/generate',
      model: result.modelUsed,
      ok: true,
      status: 200,
    });
    res.json(result);
  } catch (err) {
    const classified = classifyImageProviderError(err);
    recordApiEvent({
      category: 'image_gen',
      route: '/api/image/generate',
      model,
      ok: false,
      status: classified.status,
      errorCode: classified.code,
      errorMessage: classified.message,
    });
    res.status(classified.status).json({ error: classified });
  }
});

app.post('/api/image/edit', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();
  if (superPower.provider.imageProviderMode === 'web-only') {
    res.status(403).json({
      error: {
        code: 'FEATURE_DISABLED',
        title: 'API Image Editing Restricted',
        message: 'Server AI image editing is currently set to Gemini Web mode in Super Power.',
        hint: 'Enable Hybrid or Nano Banana mode in Super Power, or use the offline Image Studio.',
      },
    });
    return;
  }
  const {
    prompt,
    imageBase64,
    mimeType,
    model,
    aspectRatio,
    imageSize,
    history,
    confirmPaidRequest,
  } = req.body as {
    prompt?: string;
    imageBase64?: string;
    mimeType?: string;
    model?: string;
    aspectRatio?: string;
    imageSize?: '1K' | '2K' | '4K';
    history?: NanoBananaTurn[];
    confirmPaidRequest?: boolean;
  };

  if (!prompt || !prompt.trim() || !imageBase64 || !mimeType) {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Image and Edit Prompt Required',
        message: 'Upload an image and describe the edit you want to apply.',
        hint: 'Select an image file and enter an editing instruction.',
      },
    });
    return;
  }

  try {
    const result = await editImageWithProvider({
      prompt: prompt.trim(),
      imageBase64,
      mimeType,
      model,
      aspectRatio,
      imageSize,
      history,
      confirmPaidRequest,
    });
    recordApiEvent({
      category: 'image_gen',
      route: '/api/image/edit',
      model: result.modelUsed,
      ok: true,
      status: 200,
    });
    res.json(result);
  } catch (err) {
    const classified = classifyImageProviderError(err);
    recordApiEvent({
      category: 'image_gen',
      route: '/api/image/edit',
      model,
      ok: false,
      status: classified.status,
      errorCode: classified.code,
      errorMessage: classified.message,
    });
    res.status(classified.status).json({ error: classified });
  }
});

// Dedicated Google Gemini Nano Banana endpoint (text-to-image, image-to-image, & multi-turn image editing)
app.post('/api/image/nano-banana', async (req: Request, res: Response) => {
  const superPower = getSuperPowerConfig();
  if (superPower.provider.imageProviderMode === 'web-only') {
    res.status(403).json({
      error: {
        code: 'FEATURE_DISABLED',
        title: 'Nano Banana Studio Restricted',
        message: 'Image provider mode is set to Gemini Web Only in Super Power.',
        hint: 'Enable Hybrid or Nano Banana Studio in Super Power to use paid Gemini image models.',
      },
    });
    return;
  }
  const {
    prompt,
    model = 'gemini-3.1-flash-lite-image',
    aspectRatio = '1:1',
    imageSize,
    imageBase64,
    mimeType,
    history,
    confirmPaidRequest,
  } = req.body as {
    prompt?: string;
    model?: string;
    aspectRatio?: string;
    imageSize?: '1K' | '2K' | '4K';
    imageBase64?: string;
    mimeType?: string;
    history?: NanoBananaTurn[];
    confirmPaidRequest?: boolean;
  };

  if (!prompt || !prompt.trim()) {
    res.status(400).json({
      error: {
        code: 'INVALID_REQUEST',
        title: 'Prompt Required',
        message: 'Enter a description or edit instruction for Nano Banana.',
        hint: 'For example: "A glowing mountain lake at dusk" or "Make it brighter".',
      },
    });
    return;
  }

  try {
    const result = await runNanoBananaRequest({
      prompt: prompt.trim(),
      model,
      aspectRatio,
      imageSize,
      imageBase64,
      mimeType,
      history,
      confirmPaidRequest,
    });
    recordApiEvent({
      category: 'image_gen',
      route: '/api/image/nano-banana',
      model: result.modelUsed,
      ok: true,
      status: 200,
    });
    res.json(result);
  } catch (err) {
    const classified = classifyImageProviderError(err);
    recordApiEvent({
      category: 'image_gen',
      route: '/api/image/nano-banana',
      model,
      ok: false,
      status: classified.status,
      errorCode: classified.code,
      errorMessage: classified.message,
    });
    res.status(classified.status).json({ error: classified });
  }
});

// ============================================================================
// SUPER ADMIN CONTROL PANEL API (Strictly verified Google OAuth backend RBAC)
// ============================================================================

app.get('/api/admin/session', async (req: Request, res: Response) => {
  const check = await verifySuperAdminToken(req.headers.authorization);
  if (!check.ok) {
    res.status(check.status).json({
      authorized: false,
      stepUpPinRequired: isStepUpPinRequired(),
      error: {
        code: check.code,
        title: check.title,
        message: check.message,
      },
    });
    return;
  }
  res.json({
    authorized: true,
    principal: check.principal,
    stepUpPinRequired: isStepUpPinRequired(),
  });
});

app.get('/api/admin/overview', requireSuperAdmin, async (_req: Request, res: Response) => {
  const telemetry = getTelemetrySnapshot();
  const config = getAdminConfig();
  const git = await getGitStatusReport();
  res.json({
    telemetry,
    config,
    geminiConfigured: isApiKeyConfigured(),
    imageProvider: getImageProviderStatus(),
    git,
    stepUpPinRequired: isStepUpPinRequired(),
  });
});

app.put(
  '/api/admin/config',
  requireSuperAdmin,
  requireStepUpPin,
  (req: Request, res: Response) => {
    const incoming = req.body as Partial<AdminConfigDocument>;
    const current = getAdminConfig();
    const merged: AdminConfigDocument = {
      ...current,
      paidImageBillingConfirmedByAdmin:
        typeof incoming.paidImageBillingConfirmedByAdmin === 'boolean'
          ? incoming.paidImageBillingConfirmedByAdmin
          : current.paidImageBillingConfirmedByAdmin,
      customization: {
        ...current.customization,
        ...(incoming.customization || {}),
        announcement: {
          ...current.customization.announcement,
          ...(incoming.customization?.announcement || {}),
        },
        sidebarItems: {
          ...current.customization.sidebarItems,
          ...(incoming.customization?.sidebarItems || {}),
        },
        android: {
          ...current.customization.android,
          ...(incoming.customization?.android || {}),
        },
      },
      features: {
        free: { ...current.features.free, ...(incoming.features?.free || {}) },
        premium: { ...current.features.premium, ...(incoming.features?.premium || {}) },
        admin: { ...current.features.admin, ...(incoming.features?.admin || {}) },
      },
    };
    const saved = saveAdminConfig(merged);
    appendBackendAuditLog({
      actorEmail: req.superAdmin!.email,
      action: 'UPDATE_APP_CONFIG',
      target: 'config.json',
      details: `Updated app customization & feature controls (v${saved.version}, maintenanceMode=${saved.customization.maintenanceMode})`,
    });
    res.json({ config: saved });
  }
);

app.post(
  '/api/admin/android-sync',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    try {
      const current = getAdminConfig();
      const { appName, launcherColor, splashBackground } = (req.body || {}) as {
        appName?: string;
        launcherColor?: string;
        splashBackground?: string;
      };
      const targetAndroid = {
        appName: appName?.trim() || current.customization.android.appName,
        launcherColor: launcherColor?.trim() || current.customization.android.launcherColor,
        splashBackground:
          splashBackground?.trim() || current.customization.android.splashBackground,
      };
      const syncRes = await syncAndroidCustomizationFiles(targetAndroid);
      const saved = saveAdminConfig({
        ...current,
        customization: {
          ...current.customization,
          android: {
            ...targetAndroid,
            lastSyncedAt: Date.now(),
          },
        },
      });
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'SYNC_ANDROID_SOURCE',
        target: syncRes.updatedFiles.join(', '),
        details: `Synced Android branding files (backup ${syncRes.backupId}). Requires new APK build to ship to devices.`,
      });
      res.json({ ...syncRes, config: saved });
    } catch (err) {
      res.status(400).json({
        error: {
          code: 'ANDROID_SYNC_FAILED',
          title: 'Android Sync Failed',
          message: err instanceof Error ? err.message : 'Unable to sync Android files.',
        },
      });
    }
  }
);

app.get('/api/admin/files', requireSuperAdmin, (_req: Request, res: Response) => {
  res.json({ tree: listWorkspaceTree(5) });
});

app.get('/api/admin/file', requireSuperAdmin, (req: Request, res: Response) => {
  const filePath = typeof req.query.path === 'string' ? req.query.path : '';
  try {
    const file = readWorkspaceFile(filePath);
    res.json(file);
  } catch (err) {
    res.status(400).json({
      error: {
        code: 'FILE_READ_ERROR',
        title: 'Cannot Open File',
        message: err instanceof Error ? err.message : 'Unable to read requested file.',
      },
    });
  }
});

app.post('/api/admin/file/diff', requireSuperAdmin, (req: Request, res: Response) => {
  const { path: filePath, content } = (req.body || {}) as {
    path?: string;
    content?: string;
  };
  if (!filePath || typeof content !== 'string') {
    res.status(400).json({ error: { message: 'path and content are required' } });
    return;
  }
  try {
    const current = readWorkspaceFile(filePath);
    const diff = computeLineDiff(current.content, content);
    res.json(diff);
  } catch (err) {
    res.status(400).json({
      error: {
        code: 'DIFF_ERROR',
        title: 'Diff Preview Failed',
        message: err instanceof Error ? err.message : 'Unable to compute diff.',
      },
    });
  }
});

app.put(
  '/api/admin/file',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { path: filePath, content, reason } = (req.body || {}) as {
      path?: string;
      content?: string;
      reason?: string;
    };
    if (!filePath || typeof content !== 'string') {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Missing Parameters',
          message: 'File path and content are required.',
        },
      });
      return;
    }
    try {
      const result = await applyEditsWithBackup(
        [{ path: filePath, content }],
        reason?.trim() || `Direct Code Editor save: ${filePath}`
      );
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'EDIT_FILE',
        target: filePath,
        details: `Saved file with backup ${result.backup.id} (tsc ok=${result.validation.ok})`,
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: {
          code: 'FILE_WRITE_ERROR',
          title: 'Save Failed',
          message: err instanceof Error ? err.message : 'Unable to save file.',
        },
      });
    }
  }
);

app.post('/api/admin/validate', requireSuperAdmin, async (_req: Request, res: Response) => {
  const validation = await runTypeScriptValidation();
  res.json({ validation });
});

app.get('/api/admin/backups', requireSuperAdmin, (_req: Request, res: Response) => {
  res.json({ backups: listBackupSnapshots() });
});

app.post(
  '/api/admin/rollback',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { backupId } = (req.body || {}) as { backupId?: string };
    if (!backupId) {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Rollback Failed',
          message: 'Unable to Apply Changes. Please Retry.',
        },
      });
      return;
    }
    try {
      const result = await rollbackBackupSnapshot(backupId);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'ROLLBACK_BACKUP',
        target: backupId,
        details: `Restored ${result.restoredPaths.length} file(s): ${result.restoredPaths.join(', ')} (tsc ok=${result.validation.ok})`,
      });
      res.json({
        ...result,
        message: 'Changes Rolled Back Successfully!',
      });
    } catch (err) {
      console.error('[NOVA Rollback Error]', backupId, err);
      res.status(400).json({
        error: {
          code: 'ROLLBACK_FAILED',
          title: 'Rollback Failed',
          message: 'Unable to Apply Changes. Please Retry.',
        },
      });
    }
  }
);

// ============================================================================
// SUPER POWER — Central NOVA AI Brain & Runtime Configuration
// ============================================================================

app.get('/api/admin/super-power', requireSuperAdmin, async (_req: Request, res: Response) => {
  const config = getSuperPowerConfig();
  const history = getSuperPowerHistory();
  let availableModels: Array<{ id: string; displayName: string; tier: 'free' | 'paid' }> = [];
  if (isApiKeyConfigured()) {
    try {
      const listed = await listAvailableModels();
      availableModels = listed.map((m) => ({
        id: m.id,
        displayName: m.displayName,
        tier: m.tier,
      }));
    } catch {
      availableModels = [];
    }
  }
  res.json({
    config,
    history,
    availableModels,
    geminiConfigured: isApiKeyConfigured(),
    imageProvider: getImageProviderStatus(),
  });
});

app.put(
  '/api/admin/super-power',
  requireSuperAdmin,
  requireStepUpPin,
  (req: Request, res: Response) => {
    const body = (req.body || {}) as {
      config?: Partial<SuperPowerConfig>;
      note?: string;
    };
    const incomingConfig = body.config ?? (req.body as Partial<SuperPowerConfig>);
    if (!incomingConfig || typeof incomingConfig !== 'object') {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Invalid Configuration',
          message: 'Super Power configuration payload is required.',
        },
      });
      return;
    }

    const result = saveSuperPowerConfig(
      incomingConfig,
      req.superAdmin!.email,
      body.note
    );

    appendBackendAuditLog({
      actorEmail: req.superAdmin!.email,
      action: 'UPDATE_SUPER_POWER',
      target: 'super-power.json',
      details: `Saved Super Power v${result.config.version} (preset=${result.config.personality.preset}, model=${result.config.models.defaultChatModel}, thinking=${result.config.responseBehavior.thinkingLevel})`,
    });

    res.json({
      config: result.config,
      history: result.history,
      publicConfig: getPublicAppConfig(),
    });
  }
);

app.post(
  '/api/admin/super-power/restore',
  requireSuperAdmin,
  requireStepUpPin,
  (req: Request, res: Response) => {
    const { historyId } = (req.body || {}) as { historyId?: string };
    if (!historyId || typeof historyId !== 'string') {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Revision Required',
          message: 'Select a configuration revision to restore.',
        },
      });
      return;
    }

    try {
      const result = restoreSuperPowerConfig(historyId, req.superAdmin!.email);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'RESTORE_SUPER_POWER',
        target: 'super-power.json',
        details: `Restored Super Power settings from v${result.restoredFromVersion} -> active v${result.config.version}`,
      });
      res.json({
        ...result,
        publicConfig: getPublicAppConfig(),
      });
    } catch (err) {
      res.status(404).json({
        error: {
          code: 'REVISION_NOT_FOUND',
          title: 'Restore Failed',
          message:
            err instanceof Error
              ? err.message
              : 'Selected configuration revision could not be restored.',
        },
      });
    }
  }
);

app.post(
  '/api/admin/super-power/test',
  requireSuperAdmin,
  async (req: Request, res: Response) => {
    const body = (req.body || {}) as SuperPowerTestRequest;
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    if (!prompt) {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Test Prompt Required',
          message: 'Enter a test prompt to evaluate the AI configuration.',
        },
      });
      return;
    }

    const baseSaved = getSuperPowerConfig();
    const effectiveConfig = body.draftConfig
      ? sanitizeSuperPowerConfig(body.draftConfig, baseSaved)
      : baseSaved;

    const mode = body.mode || 'general';
    const studyLanguage = body.studyLanguage || 'bilingual';
    const systemInstruction = buildSystemInstruction(
      mode,
      studyLanguage,
      effectiveConfig
    );

    const primaryModel = effectiveConfig.models.defaultChatModel;
    const fallbackModel = effectiveConfig.models.fallbackChatModel?.trim();
    const timeoutMs = Math.min(
      45_000,
      Math.max(8_000, effectiveConfig.provider.requestTimeoutMs || 25_000)
    );

    const runTestWithModel = async (targetModel: string) => {
      const ai = getGeminiClient();
      const abortCtrl = new AbortController();
      const timer = setTimeout(() => abortCtrl.abort(), timeoutMs);
      const thinkingLevel = resolveSuperPowerThinkingLevel(
        targetModel,
        effectiveConfig.responseBehavior.thinkingLevel,
        mode
      );
      const useSearch =
        Boolean(body.useWebSearch) &&
        effectiveConfig.features.webSearchEnabled &&
        effectiveConfig.provider.searchGroundingProvider !== 'disabled';

      try {
        const response = await ai.models.generateContent({
          model: targetModel,
          contents: prompt.slice(0, 4000),
          config: {
            systemInstruction,
            ...(thinkingLevel ? { thinkingConfig: { thinkingLevel } } : {}),
            ...(useSearch ? { tools: [{ googleSearch: {} }] } : {}),
            abortSignal: abortCtrl.signal,
          },
        });
        return {
          text: (response.text ?? '').replace(/<\/?thought>/gi, '').trim(),
          thinkingUsed: thinkingLevel ? String(thinkingLevel) : 'AUTO',
        };
      } finally {
        clearTimeout(timer);
      }
    };

    const started = Date.now();
    let usedModel = primaryModel;
    let fallbackUsed = false;

    try {
      let result: { text: string; thinkingUsed: string };
      try {
        result = await runTestWithModel(primaryModel);
      } catch (primaryErr) {
        const classified = classifyGeminiError(primaryErr);
        const canFallback =
          effectiveConfig.models.autoFallbackEnabled &&
          Boolean(fallbackModel) &&
          fallbackModel !== primaryModel &&
          (classified.code === 'MODEL_NOT_FOUND' ||
            classified.code === 'MODEL_BUSY' ||
            classified.code === 'QUOTA_EXCEEDED');

        if (!canFallback) {
          throw primaryErr;
        }
        usedModel = fallbackModel!;
        fallbackUsed = true;
        result = await runTestWithModel(usedModel);
      }

      res.json({
        ok: true,
        text: result.text || '(Model returned an empty response.)',
        modelUsed: usedModel,
        fallbackUsed,
        latencyMs: Date.now() - started,
        appliedThinkingLevel: result.thinkingUsed,
        systemInstructionPreview: systemInstruction,
      });
    } catch (err) {
      const classified = classifyGeminiError(err);
      res.status(classified.status).json({ error: classified });
    }
  }
);

app.get(
  '/api/admin/super-power/builder/proposals',
  requireSuperAdmin,
  (_req: Request, res: Response) => {
    res.json({
      proposals: getBuilderProposals(),
      workspaceFiles: listEditableWorkspaceFiles(),
    });
  }
);

app.post(
  '/api/admin/super-power/builder/generate',
  requireSuperAdmin,
  async (req: Request, res: Response) => {
    const body = (req.body || {}) as BuilderGenerateRequest;
    try {
      const proposal = await generateBuilderProposal(body, req.superAdmin!.email);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'SUPER_POWER_BUILDER_GENERATE',
        target: proposal.changes.map((c) => c.path).join(', '),
        details: `Generated ${proposal.changes.length} file change(s) via ${proposal.modelUsed} [${proposal.inputModes.join('+')}]`,
      });
      res.json({
        proposal,
        proposals: getBuilderProposals(),
      });
    } catch (err) {
      console.error('[SuperPowerBuilder] Generate error:', err);
      const classified = classifyGeminiError(err);
      const isGeminiFailure =
        classified.code !== 'INTERNAL_ERROR' ||
        (err instanceof Error && /gemini|api key|quota|model/i.test(err.message));

      res.status(isGeminiFailure ? classified.status : 400).json({
        error: isGeminiFailure
          ? classified
          : {
              code: 'BUILDER_GENERATE_FAILED',
              title: 'Could Not Generate Changes',
              message:
                err instanceof Error
                  ? err.message
                  : 'Unable to generate code modifications for this request.',
            },
      });
    }
  }
);

app.post(
  '/api/admin/super-power/builder/apply',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { proposalId } = (req.body || {}) as { proposalId?: string };
    if (!proposalId || typeof proposalId !== 'string') {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Proposal Required',
          message: 'proposalId is required to apply generated changes.',
        },
      });
      return;
    }

    try {
      const result = await applyBuilderProposal(proposalId);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: result.ok ? 'SUPER_POWER_BUILDER_APPLY' : 'SUPER_POWER_BUILDER_APPLY_FAILED',
        target: result.proposal.changes.map((c) => c.path).join(', '),
        details: result.ok
          ? `Applied ${result.proposal.changes.length} file(s), backup=${result.backup.id}, tsc+build passed`
          : `Validation failed & auto-reverted backup=${result.backup.id}`,
      });
      res.status(result.ok ? 200 : 422).json({
        ...result,
        proposals: getBuilderProposals(),
        backups: listBackupSnapshots(),
      });
    } catch (err) {
      console.error('[SuperPowerBuilder] Apply error:', err);
      res.status(400).json({
        error: {
          code: 'BUILDER_APPLY_FAILED',
          title: 'Apply Failed',
          message:
            err instanceof Error
              ? err.message
              : 'Unable to apply generated code changes.',
        },
      });
    }
  }
);

app.post(
  '/api/admin/super-power/builder/reject',
  requireSuperAdmin,
  (req: Request, res: Response) => {
    const { proposalId } = (req.body || {}) as { proposalId?: string };
    if (!proposalId || typeof proposalId !== 'string') {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Proposal Required',
          message: 'proposalId is required.',
        },
      });
      return;
    }

    try {
      const proposal = rejectBuilderProposal(proposalId);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'SUPER_POWER_BUILDER_REJECT',
        target: proposal.id,
        details: `Rejected builder proposal (${proposal.changes.length} file(s))`,
      });
      res.json({
        proposal,
        proposals: getBuilderProposals(),
      });
    } catch (err) {
      res.status(400).json({
        error: {
          code: 'BUILDER_REJECT_FAILED',
          title: 'Reject Failed',
          message: err instanceof Error ? err.message : 'Unable to reject proposal.',
        },
      });
    }
  }
);

app.post(
  '/api/admin/super-power/builder/rollback',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { proposalId } = (req.body || {}) as { proposalId?: string };
    if (!proposalId || typeof proposalId !== 'string') {
      res.status(400).json({
        error: {
          code: 'INVALID_REQUEST',
          title: 'Proposal Required',
          message: 'proposalId is required to roll back applied changes.',
        },
      });
      return;
    }

    try {
      const result = await rollbackBuilderProposal(proposalId);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'SUPER_POWER_BUILDER_ROLLBACK',
        target: result.restoredPaths.join(', '),
        details: `Rolled back proposal ${result.proposal.id} (backup ${result.proposal.backupId}), tsc=${result.validation.ok}`,
      });
      res.json({
        ...result,
        proposals: getBuilderProposals(),
        backups: listBackupSnapshots(),
      });
    } catch (err) {
      console.error('[SuperPowerBuilder] Rollback error:', err);
      res.status(400).json({
        error: {
          code: 'BUILDER_ROLLBACK_FAILED',
          title: 'Rollback Failed',
          message: err instanceof Error ? err.message : 'Unable to roll back changes.',
        },
      });
    }
  }
);

app.get('/api/admin/git/status', requireSuperAdmin, async (_req: Request, res: Response) => {
  const git = await getGitStatusReport();
  res.json({ git });
});

app.post(
  '/api/admin/git/branch',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { branchName } = (req.body || {}) as { branchName?: string };
    if (!branchName) {
      res.status(400).json({ error: { message: 'branchName is required' } });
      return;
    }
    try {
      const result = await createGitUpdateBranch(branchName);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'GIT_CREATE_BRANCH',
        target: result.branch,
        details: result.output.slice(0, 200),
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: {
          code: 'GIT_BRANCH_ERROR',
          title: 'Branch Creation Failed',
          message: err instanceof Error ? err.message : 'Unable to create branch.',
        },
      });
    }
  }
);

app.post(
  '/api/admin/git/commit',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { message } = (req.body || {}) as { message?: string };
    if (!message) {
      res.status(400).json({ error: { message: 'Commit message is required' } });
      return;
    }
    try {
      const result = await commitApprovedGitChanges(message);
      appendBackendAuditLog({
        actorEmail: req.superAdmin!.email,
        action: 'GIT_COMMIT',
        target: 'repository',
        details: `${message} (ok=${result.ok})`,
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: {
          code: 'GIT_COMMIT_ERROR',
          title: 'Commit Failed',
          message: err instanceof Error ? err.message : 'Unable to commit changes.',
        },
      });
    }
  }
);

app.post('/api/admin/git/build', requireSuperAdmin, async (req: Request, res: Response) => {
  const suite = await runBuildValidationSuite();
  appendBackendAuditLog({
    actorEmail: req.superAdmin!.email,
    action: 'RUN_BUILD_SUITE',
    target: 'npm run lint && npm run build',
    details: `lint=${suite.lint.ok}, build=${suite.build.ok}`,
  });
  res.json(suite);
});

app.post(
  '/api/admin/git/push',
  requireSuperAdmin,
  requireStepUpPin,
  async (req: Request, res: Response) => {
    const { branchName } = (req.body || {}) as { branchName?: string };
    const result = await pushToGitHubIfConfigured(branchName);
    appendBackendAuditLog({
      actorEmail: req.superAdmin!.email,
      action: 'GITHUB_PUSH',
      target: branchName || 'current-branch',
      details: `Push ok=${result.ok}: ${result.output.slice(0, 200)}`,
    });
    res.json(result);
  }
);

app.get('/api/admin/audit-logs', requireSuperAdmin, (_req: Request, res: Response) => {
  res.json({ logs: getBackendAuditLogs() });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexPath = path.join(distDir, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NOVA AI server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start NOVA AI server:', err);
  process.exit(1);
});
