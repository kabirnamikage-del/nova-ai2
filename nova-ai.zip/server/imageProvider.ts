import type { Content, Part } from '@google/genai';
import { classifyGeminiError, getGeminiClient, isApiKeyConfigured } from './gemini.ts';

export const NANO_BANANA_MODELS = [
  'gemini-3.1-flash-lite-image',
  'gemini-nano-banana-2.1',
] as const;

export type NanoBananaModelId = (typeof NANO_BANANA_MODELS)[number];

export interface ImageProviderStatus {
  available: boolean;
  providerName: string;
  supportsGeneration: boolean;
  supportsEditing: boolean;
  reasonCode: 'READY' | 'PAID_KEY_REQUIRED' | 'PROVIDER_NOT_CONFIGURED';
  title: string;
  message: string;
  hint: string;
  nanoBananaModels: Array<{
    id: NanoBananaModelId;
    label: string;
    description: string;
    supportsImageSize: boolean;
    paidRequired: boolean;
  }>;
  supportedProviders: Array<{
    id: string;
    label: string;
    envHint: string;
  }>;
}

export interface GeneratedImageResult {
  imageBase64: string;
  mimeType: string;
  text?: string;
  providerName: string;
  modelUsed: string;
}

export interface NanoBananaTurn {
  role: 'user' | 'model';
  text?: string;
  imageBase64?: string;
  mimeType?: string;
}

const NANO_BANANA_META: ImageProviderStatus['nanoBananaModels'] = [
  {
    id: 'gemini-3.1-flash-lite-image',
    label: 'Nano Banana Flash Lite (gemini-3.1-flash-lite-image)',
    description: 'Default Gemini Nano Banana model for fast text-to-image & image editing.',
    supportsImageSize: false,
    paidRequired: true,
  },
  {
    id: 'gemini-nano-banana-2.1',
    label: 'Nano Banana 2.1 (gemini-nano-banana-2.1)',
    description: 'High-resolution 1K/2K/4K output, ultra-wide aspect ratios, and web search grounding.',
    supportsImageSize: true,
    paidRequired: true,
  },
];

const SUPPORTED_PROVIDERS = [
  {
    id: 'gemini-nano-banana',
    label: 'Google Gemini Nano Banana (gemini-3.1-flash-lite-image / gemini-nano-banana-2.1)',
    envHint: 'Requires billing-enabled GEMINI_API_KEY + explicit user paid confirmation (or ENABLE_PAID_GEMINI_IMAGE_MODELS=true)',
  },
  {
    id: 'openai-compatible',
    label: 'OpenAI-Compatible Image API',
    envHint: 'Requires server secrets IMAGE_GEN_PROVIDER=openai-compatible + IMAGE_GEN_API_KEY',
  },
];

export function getImageProviderStatus(): ImageProviderStatus {
  const paidGeminiEnabled =
    process.env.ENABLE_PAID_GEMINI_IMAGE_MODELS?.trim().toLowerCase() === 'true' &&
    isApiKeyConfigured();

  if (paidGeminiEnabled) {
    return {
      available: true,
      providerName: 'Gemini Nano Banana API',
      supportsGeneration: true,
      supportsEditing: true,
      reasonCode: 'READY',
      title: 'Gemini Nano Banana Image Generation Ready',
      message: 'Connected to Google Gemini Nano Banana server-side image generation and multi-turn editing.',
      hint: 'Paid Gemini image models are active on the backend.',
      nanoBananaModels: NANO_BANANA_META,
      supportedProviders: SUPPORTED_PROVIDERS,
    };
  }

  const provider = process.env.IMAGE_GEN_PROVIDER?.trim().toLowerCase();
  const providerKey = process.env.IMAGE_GEN_API_KEY?.trim();
  if (provider === 'openai-compatible' && providerKey) {
    return {
      available: true,
      providerName: 'External Image API',
      supportsGeneration: true,
      supportsEditing: false,
      reasonCode: 'READY',
      title: 'External Image Provider Connected',
      message: 'Server-side image generation provider is configured and ready.',
      hint: 'Generation runs through your configured backend IMAGE_GEN_PROVIDER.',
      nanoBananaModels: NANO_BANANA_META,
      supportedProviders: SUPPORTED_PROVIDERS,
    };
  }

  return {
    available: false,
    providerName: 'Paid Billing / Gemini Web Hybrid',
    supportsGeneration: false,
    supportsEditing: false,
    reasonCode: 'PAID_KEY_REQUIRED',
    title: 'Nano Banana Requires a Billing-Enabled Gemini API Key',
    message:
      'Google Gemini Nano Banana image models (gemini-3.1-flash-lite-image & gemini-nano-banana-2.1) require a paid billing-enabled API key. Use the free Hybrid Gemini Web button (gemini.google.com) or explicitly confirm a paid request if your server key has billing active.',
    hint: 'Click "Generate Image in Gemini" to generate images free at gemini.google.com and upload them back into NOVA, or confirm paid API usage if your GEMINI_API_KEY has billing enabled.',
    nanoBananaModels: NANO_BANANA_META,
    supportedProviders: SUPPORTED_PROVIDERS,
  };
}

function buildNanoBananaContents(params: {
  prompt: string;
  imageBase64?: string;
  mimeType?: string;
  history?: NanoBananaTurn[];
}): Content[] {
  const contents: Content[] = [];

  if (Array.isArray(params.history)) {
    for (const turn of params.history) {
      const parts: Part[] = [];
      if (turn.imageBase64 && turn.mimeType) {
        parts.push({
          inlineData: {
            mimeType: turn.mimeType,
            data: turn.imageBase64,
          },
        });
      }
      if (turn.text && turn.text.trim()) {
        parts.push({ text: turn.text.trim() });
      }
      if (parts.length > 0) {
        contents.push({
          role: turn.role === 'model' ? 'model' : 'user',
          parts,
        });
      }
    }
  }

  const latestParts: Part[] = [];
  if (params.imageBase64 && params.mimeType) {
    latestParts.push({
      inlineData: {
        mimeType: params.mimeType,
        data: params.imageBase64,
      },
    });
  }
  latestParts.push({ text: params.prompt.trim() });

  contents.push({
    role: 'user',
    parts: latestParts,
  });

  return contents;
}

export async function runNanoBananaRequest(params: {
  prompt: string;
  model?: string;
  aspectRatio?: string;
  imageSize?: '1K' | '2K' | '4K';
  imageBase64?: string;
  mimeType?: string;
  history?: NanoBananaTurn[];
  confirmPaidRequest?: boolean;
}): Promise<GeneratedImageResult> {
  const serverOptedIn =
    process.env.ENABLE_PAID_GEMINI_IMAGE_MODELS?.trim().toLowerCase() === 'true';

  if (!serverOptedIn && params.confirmPaidRequest !== true) {
    const err = new Error(
      'Nano Banana image generation uses a paid-tier Gemini API model and requires explicit user confirmation before sending.'
    );
    (err as Error & { customCode?: string; status?: number }).customCode =
      'PAID_BILLING_CONFIRMATION_REQUIRED';
    (err as Error & { status?: number }).status = 402;
    throw err;
  }

  const ai = getGeminiClient();
  const chosenModel: NanoBananaModelId =
    params.model === 'gemini-nano-banana-2.1'
      ? 'gemini-nano-banana-2.1'
      : 'gemini-3.1-flash-lite-image';

  const contents = buildNanoBananaContents({
    prompt: params.prompt,
    imageBase64: params.imageBase64,
    mimeType: params.mimeType,
    history: params.history,
  });

  const imageConfig: {
    aspectRatio?: string;
    imageSize?: '1K' | '2K' | '4K';
  } = {
    aspectRatio: params.aspectRatio || '1:1',
  };

  // imageSize is only supported on gemini-nano-banana-2.1 (not 3.1-flash-lite-image)
  if (chosenModel === 'gemini-nano-banana-2.1' && params.imageSize) {
    imageConfig.imageSize = params.imageSize;
  }

  const abortCtrl = new AbortController();
  const timer = setTimeout(() => abortCtrl.abort(), 45_000);

  try {
    // Do NOT set responseMimeType or responseSchema for Nano Banana models
    const response = await ai.models.generateContent({
      model: chosenModel,
      contents,
      config: {
        imageConfig,
        abortSignal: abortCtrl.signal,
      },
    });

    let imageBase64 = '';
    let mimeType = 'image/png';
    let text = '';

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if ((part as { thought?: boolean }).thought) continue;
      if (part.inlineData?.data && !imageBase64) {
        imageBase64 = part.inlineData.data;
        mimeType = part.inlineData.mimeType || 'image/png';
      } else if (part.text) {
        text += part.text;
      }
    }

    if (!imageBase64) {
      throw new Error(
        text.trim()
          ? `The Nano Banana model replied without an image: ${text.trim()}`
          : 'The Nano Banana model completed without returning image data.'
      );
    }

    return {
      imageBase64,
      mimeType,
      text: text.trim() || undefined,
      providerName: 'Gemini Nano Banana API',
      modelUsed: chosenModel,
    };
  } finally {
    clearTimeout(timer);
  }
}

export async function generateImageWithProvider(params: {
  prompt: string;
  aspectRatio?: string;
  model?: string;
  imageSize?: '1K' | '2K' | '4K';
  confirmPaidRequest?: boolean;
}): Promise<GeneratedImageResult> {
  const status = getImageProviderStatus();
  const paidGeminiEnabled =
    process.env.ENABLE_PAID_GEMINI_IMAGE_MODELS?.trim().toLowerCase() === 'true';

  if (paidGeminiEnabled || params.confirmPaidRequest === true) {
    return runNanoBananaRequest({
      prompt: params.prompt,
      model: params.model,
      aspectRatio: params.aspectRatio,
      imageSize: params.imageSize,
      confirmPaidRequest: params.confirmPaidRequest ?? paidGeminiEnabled,
    });
  }

  if (!status.available) {
    const err = new Error(status.message);
    (err as Error & { customCode?: string; status?: number }).customCode =
      'IMAGE_PROVIDER_UNAVAILABLE';
    (err as Error & { status?: number }).status = 503;
    throw err;
  }

  // OpenAI-compatible server-side provider adapter
  const endpoint =
    process.env.IMAGE_GEN_ENDPOINT?.trim() ||
    'https://api.openai.com/v1/images/generations';
  const apiKey = process.env.IMAGE_GEN_API_KEY?.trim() || '';
  const model = process.env.IMAGE_GEN_MODEL?.trim() || 'gpt-image-1';
  const size =
    params.aspectRatio === '16:9'
      ? '1536x1024'
      : params.aspectRatio === '3:4'
        ? '1024x1536'
        : '1024x1024';

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      prompt: params.prompt,
      size,
      response_format: 'b64_json',
    }),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    const err = new Error(errText || `Provider returned HTTP ${res.status}`);
    (err as Error & { status?: number }).status = res.status;
    throw err;
  }

  const data = (await res.json()) as {
    data?: Array<{ b64_json?: string; revised_prompt?: string }>;
  };
  const b64 = data.data?.[0]?.b64_json;
  if (!b64) {
    throw new Error('Image provider response did not contain base64 image data.');
  }

  return {
    imageBase64: b64,
    mimeType: 'image/png',
    text: data.data?.[0]?.revised_prompt,
    providerName: 'External Image API',
    modelUsed: model,
  };
}

export async function editImageWithProvider(params: {
  prompt: string;
  imageBase64: string;
  mimeType: string;
  model?: string;
  aspectRatio?: string;
  imageSize?: '1K' | '2K' | '4K';
  history?: NanoBananaTurn[];
  confirmPaidRequest?: boolean;
}): Promise<GeneratedImageResult> {
  const paidGeminiEnabled =
    process.env.ENABLE_PAID_GEMINI_IMAGE_MODELS?.trim().toLowerCase() === 'true';

  if (paidGeminiEnabled || params.confirmPaidRequest === true) {
    return runNanoBananaRequest({
      prompt: params.prompt,
      model: params.model,
      aspectRatio: params.aspectRatio,
      imageSize: params.imageSize,
      imageBase64: params.imageBase64,
      mimeType: params.mimeType,
      history: params.history,
      confirmPaidRequest: params.confirmPaidRequest ?? paidGeminiEnabled,
    });
  }

  const status = getImageProviderStatus();
  const err = new Error(
    status.available
      ? 'The configured external provider does not support AI image editing. Use the Canvas Photo Editor or confirm a Nano Banana paid request.'
      : status.message
  );
  (err as Error & { customCode?: string; status?: number }).customCode =
    'IMAGE_PROVIDER_UNAVAILABLE';
  (err as Error & { status?: number }).status = 503;
  throw err;
}

export function classifyImageProviderError(err: unknown) {
  const customCode = (err as { customCode?: string } | null)?.customCode;
  if (customCode === 'PAID_BILLING_CONFIRMATION_REQUIRED') {
    return {
      status: 402,
      code: 'PAID_BILLING_CONFIRMATION_REQUIRED',
      title: 'Paid API Confirmation Required',
      message:
        'Nano Banana image models (gemini-3.1-flash-lite-image and gemini-nano-banana-2.1) require a billing-enabled Gemini API key and explicit user confirmation.',
      hint: 'Check the paid-billing confirmation box before submitting, or click "Generate Image in Gemini" to generate images free at gemini.google.com and upload them back into NOVA.',
    };
  }
  if (customCode === 'IMAGE_PROVIDER_UNAVAILABLE') {
    const status = getImageProviderStatus();
    return {
      status: 503,
      code: 'IMAGE_PROVIDER_UNAVAILABLE',
      title: status.title,
      message: status.message,
      hint: status.hint,
    };
  }
  const classified = classifyGeminiError(err);
  if (classified.code === 'QUOTA_EXCEEDED' || classified.code === 'AUTH_ERROR') {
    return {
      ...classified,
      title: 'Paid Billing Required for Nano Banana',
      message:
        'Your current GEMINI_API_KEY does not have active paid quota/billing for Nano Banana image generation.',
      hint: 'Use the free Hybrid Gemini Web button (gemini.google.com) to generate images and upload them back into NOVA, or enable billing on your Gemini API project.',
    };
  }
  return classified;
}
