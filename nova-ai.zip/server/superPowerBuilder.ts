import { execFile } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { ThinkingLevel, Type } from '@google/genai';
import {
  WORKSPACE_ROOT,
  applyEditsWithBackup,
  computeLineDiff,
  isProtectedFile,
  listWorkspaceTree,
  normalizeRelPath,
  readWorkspaceFile,
  resolveSafeWorkspacePath,
  rollbackBackupSnapshot,
  runTypeScriptValidation,
} from './adminFiles.ts';
import {
  classifyGeminiError,
  getGeminiClient,
  isModelInQuotaCooldown,
  markModelQuotaExhausted,
  markModelUnavailable,
} from './gemini.ts';
import type {
  BackupSnapshotMeta,
  BuilderGenerateRequest,
  BuilderInputMode,
  BuilderProposalRecord,
  BuilderProposedFileChange,
  ValidationResult,
  WorkspaceFileNode,
} from '../src/types/admin.ts';

const ADMIN_DIR = path.join(WORKSPACE_ROOT, '.nova-admin');
const BUILDER_PROPOSALS_PATH = path.join(ADMIN_DIR, 'builder-proposals.json');

const EDITABLE_EXTENSIONS = new Set([
  '.ts',
  '.tsx',
  '.js',
  '.jsx',
  '.css',
  '.html',
  '.json',
  '.md',
  '.svg',
  '.xml',
  '.yml',
  '.yaml',
]);

const ALLOWED_IMAGE_MIMES = new Set(['image/png', 'image/jpeg', 'image/webp']);

const CORE_ANCHOR_FILES = [
  'src/App.tsx',
  'src/components/HeaderBar.tsx',
  'src/components/Sidebar.tsx',
  'src/components/ChatComposer.tsx',
  'src/components/AdminPanel.tsx',
  'src/components/SuperPowerSection.tsx',
  'src/types/admin.ts',
  'src/types/chat.ts',
  'src/index.css',
  'server.ts',
];

const BENGALI_TECH_SYNONYMS: Array<[RegExp, string[]]> = [
  [/সাইডবার|sidebar/i, ['Sidebar', 'sidebar', 'App.tsx']],
  [/হেডার|header/i, ['HeaderBar', 'header', 'App.tsx']],
  [/বাটন|button/i, ['button', 'HeaderBar', 'ChatComposer', 'Sidebar', 'App.tsx']],
  [/থিম|কালার|রং|theme|color|dark|light/i, ['index.css', 'theme', 'ThemeToggle', 'App.tsx']],
  [/চ্যাট|মেসেজ|chat|message/i, ['ChatComposer', 'MessageBubble', 'App.tsx', 'server.ts']],
  [/ইমেজ|ছবি|image|photo|screenshot/i, ['ImageAssistantView', 'imageProvider', 'server.ts']],
  [/অ্যাডমিন|সুপার|admin|super/i, ['AdminPanel', 'SuperPowerSection', 'adminStore', 'server.ts']],
  [/লগইন|সাইন|অ্যাকাউন্ট|login|auth|signup/i, ['AuthModal', 'firebase', 'App.tsx']],
  [/ভয়েস|মাইক|voice|audio|mic/i, ['ChatComposer', 'transcribe', 'server.ts']],
  [/সেটিংস|settings/i, ['SettingsModal', 'settings', 'App.tsx']],
  [/লাইব্রেরি|library|svg|visual/i, ['CreateVisualView', 'LibraryView']],
];

interface GeminiPatchSpec {
  search: string;
  replace: string;
}

interface GeminiEditSpec {
  path: string;
  action: 'modify' | 'create';
  rationale: string;
  updatedContent?: string;
  patches?: GeminiPatchSpec[];
}

interface GeminiBuilderResponse {
  summary: string;
  notes?: string[];
  edits: GeminiEditSpec[];
}

function ensureAdminDir(): void {
  if (!fs.existsSync(ADMIN_DIR)) {
    fs.mkdirSync(ADMIN_DIR, { recursive: true });
  }
}

function writeJsonAtomic(filePath: string, data: unknown): void {
  ensureAdminDir();
  const tmp = `${filePath}.tmp.${process.pid}`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, filePath);
}

export function getBuilderProposals(): BuilderProposalRecord[] {
  if (!fs.existsSync(BUILDER_PROPOSALS_PATH)) return [];
  try {
    const parsed = JSON.parse(
      fs.readFileSync(BUILDER_PROPOSALS_PATH, 'utf8')
    ) as unknown;
    return Array.isArray(parsed) ? (parsed as BuilderProposalRecord[]) : [];
  } catch {
    return [];
  }
}

function saveBuilderProposals(list: BuilderProposalRecord[]): void {
  writeJsonAtomic(BUILDER_PROPOSALS_PATH, list.slice(0, 25));
}

export function upsertBuilderProposal(record: BuilderProposalRecord): void {
  const existing = getBuilderProposals().filter((p) => p.id !== record.id);
  saveBuilderProposals([record, ...existing]);
}

export function getBuilderProposalById(id: string): BuilderProposalRecord | null {
  return getBuilderProposals().find((p) => p.id === id) ?? null;
}

function sha256(text: string): string {
  return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
}

function inferLanguageFromPath(relPath: string): string {
  const ext = path.posix.extname(relPath).toLowerCase();
  switch (ext) {
    case '.ts':
      return 'typescript';
    case '.tsx':
      return 'tsx';
    case '.js':
      return 'javascript';
    case '.jsx':
      return 'jsx';
    case '.css':
      return 'css';
    case '.html':
      return 'html';
    case '.json':
      return 'json';
    case '.md':
      return 'markdown';
    case '.svg':
    case '.xml':
      return 'xml';
    default:
      return 'text';
  }
}

function isAllowedEditablePath(relPath: string): boolean {
  const norm = normalizeRelPath(relPath);
  if (!norm || norm === '.' || isProtectedFile(norm)) return false;
  if (norm.startsWith('dist/') || norm.startsWith('build/') || norm.startsWith('.')) {
    return false;
  }
  const ext = path.posix.extname(norm).toLowerCase();
  if (!EDITABLE_EXTENSIONS.has(ext)) return false;
  return true;
}

export function listEditableWorkspaceFiles(): string[] {
  const tree = listWorkspaceTree(5);
  const paths: string[] = [];

  const walk = (nodes: WorkspaceFileNode[]) => {
    for (const node of nodes) {
      if (node.type === 'directory' && node.children) {
        walk(node.children);
      } else if (node.type === 'file' && !node.protected && isAllowedEditablePath(node.path)) {
        paths.push(node.path);
      }
    }
  };

  walk(tree);
  return paths;
}

function extractKeywords(text: string): string[] {
  const tokens = new Set<string>();
  const matches = text.match(/[A-Za-z_][A-Za-z0-9_.-]{2,}/g) ?? [];
  for (const m of matches) {
    tokens.add(m.toLowerCase());
  }
  for (const [pattern, extras] of BENGALI_TECH_SYNONYMS) {
    if (pattern.test(text)) {
      for (const ex of extras) {
        tokens.add(ex.toLowerCase());
      }
    }
  }
  return Array.from(tokens).slice(0, 45);
}

function inspectRelevantFiles(params: {
  prompt: string;
  codeSnippet: string;
  targetFile?: string;
}): {
  allFiles: string[];
  inspected: Array<{ path: string; content: string; lines: number }>;
} {
  const allFiles = listEditableWorkspaceFiles();
  const combinedInput = `${params.prompt}\n${params.codeSnippet}\n${params.targetFile || ''}`;
  const keywords = extractKeywords(combinedInput);

  const scored = allFiles.map((filePath) => {
    let score = 0;
    const lowerPath = filePath.toLowerCase();

    if (params.targetFile && normalizeRelPath(params.targetFile) === filePath) {
      score += 500;
    }
    if (CORE_ANCHOR_FILES.includes(filePath)) {
      score += 18;
    }
    if (lowerPath.startsWith('src/components/')) score += 6;
    if (lowerPath.startsWith('server/')) score += 5;

    for (const kw of keywords) {
      if (lowerPath.includes(kw)) {
        score += 25;
      }
    }

    let content = '';
    try {
      const read = readWorkspaceFile(filePath);
      if (read.size <= 160_000) {
        content = read.content;
        const sample = content.slice(0, 6000).toLowerCase();
        for (const kw of keywords) {
          if (sample.includes(kw)) score += 4;
        }
      }
    } catch {
      score -= 100;
    }

    return {
      path: filePath,
      score,
      content,
      lines: content ? content.split(/\r?\n/).length : 0,
    };
  });

  scored.sort((a, b) => b.score - a.score);

  const inspected: Array<{ path: string; content: string; lines: number }> = [];
  let charBudget = 88_000;

  for (const item of scored) {
    if (!item.content) continue;
    const isTarget =
      Boolean(params.targetFile) && normalizeRelPath(params.targetFile!) === item.path;
    if (!isTarget && item.content.length > 52_000 && inspected.length >= 2) {
      // Include a representative slice for oversized files only if already enough context, or include full up to budget
      continue;
    }
    if (item.content.length > charBudget && inspected.length >= 1) {
      continue;
    }
    inspected.push({
      path: item.path,
      content: item.content,
      lines: item.lines,
    });
    charBudget -= item.content.length;
    if (charBudget <= 6_000 || inspected.length >= 10) break;
  }

  return { allFiles, inspected };
}

function applyPatchesToContent(
  original: string,
  patches: GeminiPatchSpec[],
  filePath: string
): string {
  const normOriginal = original.replace(/\r\n/g, '\n');
  let working = normOriginal;

  for (let i = 0; i < patches.length; i++) {
    const p = patches[i];
    const search = (p.search ?? '').replace(/\r\n/g, '\n');
    const replace = (p.replace ?? '').replace(/\r\n/g, '\n');

    if (!search) {
      throw new Error(`Patch #${i + 1} for "${filePath}" has an empty search block.`);
    }

    const exactIdx = working.indexOf(search);
    if (exactIdx !== -1) {
      const secondIdx = working.indexOf(search, exactIdx + search.length);
      if (secondIdx !== -1) {
        throw new Error(
          `Patch #${i + 1} for "${filePath}" matched multiple locations. Include more surrounding lines to make it unique.`
        );
      }
      working =
        working.slice(0, exactIdx) + replace + working.slice(exactIdx + search.length);
      continue;
    }

    // Fallback: line-trimmed block match (preserves surrounding structure safely)
    const workingLines = working.split('\n');
    const searchLines = search.split('\n').map((l) => l.trim());
    // Remove leading/trailing empty lines if AI padded them
    while (searchLines.length > 1 && searchLines[0] === '') searchLines.shift();
    while (searchLines.length > 1 && searchLines[searchLines.length - 1] === '') {
      searchLines.pop();
    }

    const matchStarts: number[] = [];
    for (let row = 0; row <= workingLines.length - searchLines.length; row++) {
      let matched = true;
      for (let k = 0; k < searchLines.length; k++) {
        if (workingLines[row + k].trim() !== searchLines[k]) {
          matched = false;
          break;
        }
      }
      if (matched) matchStarts.push(row);
    }

    if (matchStarts.length === 1) {
      const startRow = matchStarts[0];
      const before = workingLines.slice(0, startRow);
      const after = workingLines.slice(startRow + searchLines.length);
      working = [...before, replace, ...after].join('\n');
      continue;
    }

    if (matchStarts.length > 1) {
      throw new Error(
        `Patch #${i + 1} for "${filePath}" matched ${matchStarts.length} blocks. Include more surrounding lines.`
      );
    }

    throw new Error(
      `Patch #${i + 1} for "${filePath}" did not match the current file contents.`
    );
  }

  return working;
}

function parseJsonStrictOrExtracted(raw: string): GeminiBuilderResponse {
  const cleaned = raw
    .replace(/^\s*```(?:json)?\s*/i, '')
    .replace(/\s*```\s*$/, '')
    .trim();

  const parsed = JSON.parse(cleaned) as GeminiBuilderResponse;
  if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.edits)) {
    throw new Error('Model response did not follow the expected structured edits schema.');
  }
  return parsed;
}

function selectBuilderCandidateModels(preferredModel?: string): string[] {
  const defaultChain = [
    'gemini-4-hydrogen',
    'gemini-3.8-flash',
    'gemini-3.5-flash',
    'gemini-3.1-flash-lite',
  ];

  const ordered: string[] = [];
  if (preferredModel && preferredModel.trim()) {
    ordered.push(preferredModel.trim());
  }
  for (const m of defaultChain) {
    if (!ordered.includes(m)) ordered.push(m);
  }

  const ready = ordered.filter((m) => !isModelInQuotaCooldown(m));
  return ready.length > 0 ? ready : ordered;
}

export async function runViteBuildValidation(
  cwd: string = WORKSPACE_ROOT
): Promise<ValidationResult> {
  const started = Date.now();
  const localVite = path.join(cwd, 'node_modules', '.bin', 'vite');
  const cmd = fs.existsSync(localVite) ? localVite : 'npx';
  const args = fs.existsSync(localVite) ? ['build'] : ['vite', 'build'];

  return new Promise<ValidationResult>((resolve) => {
    execFile(
      cmd,
      args,
      { cwd, timeout: 60_000, maxBuffer: 4 * 1024 * 1024 },
      (err, stdout, stderr) => {
        const output = [stdout, stderr].filter(Boolean).join('\n').trim();
        resolve({
          ok: !err,
          command: 'npm run build',
          output:
            output ||
            (err ? err.message : 'Production Vite bundle built with 0 errors.'),
          durationMs: Date.now() - started,
        });
      }
    );
  });
}

export async function generateBuilderProposal(
  req: BuilderGenerateRequest,
  actorEmail: string
): Promise<BuilderProposalRecord> {
  const prompt = typeof req.prompt === 'string' ? req.prompt.trim() : '';
  const revisionNote =
    typeof req.revisionNote === 'string' ? req.revisionNote.trim().slice(0, 200) : '';
  const codeSnippet = typeof req.codeSnippet === 'string' ? req.codeSnippet.trim() : '';
  const codeLanguage =
    typeof req.codeLanguage === 'string' && req.codeLanguage.trim()
      ? req.codeLanguage.trim().slice(0, 40)
      : 'typescript';
  const targetFile =
    typeof req.targetFile === 'string' && req.targetFile.trim()
      ? normalizeRelPath(req.targetFile.trim())
      : undefined;

  if (targetFile && !isAllowedEditablePath(targetFile)) {
    throw new Error(
      `Target file "${targetFile}" is protected or uses an unsupported file extension.`
    );
  }

  const images = Array.isArray(req.images)
    ? req.images
        .filter(
          (img) =>
            img &&
            typeof img.base64 === 'string' &&
            img.base64.trim().length > 0 &&
            ALLOWED_IMAGE_MIMES.has(img.mimeType)
        )
        .slice(0, 5)
    : [];

  if (!prompt && !codeSnippet && images.length === 0) {
    throw new Error(
      'Provide a natural-language prompt, paste code, or upload at least one reference image.'
    );
  }

  const inputModes: BuilderInputMode[] = [];
  if (prompt) inputModes.push('prompt');
  if (codeSnippet) inputModes.push('code');
  if (images.length > 0) inputModes.push('image');

  const { allFiles, inspected } = inspectRelevantFiles({
    prompt,
    codeSnippet,
    targetFile,
  });

  const fileListBlock = allFiles.join('\n');
  const inspectedContextBlock = inspected
    .map(
      (f) =>
        `=== FILE: ${f.path} (${f.lines} lines) ===\n\`\`\`${inferLanguageFromPath(f.path)}\n${f.content}\n\`\`\``
    )
    .join('\n\n');

  const developerInstruction = [
    'You are the NOVA AI Application Architect & Code Modification Engine inside the Super Power Admin Center.',
    'Your task is to implement the Super Admin’s requested modification safely and completely on the actual NOVA AI codebase.',
    '',
    'CRITICAL RULES:',
    '1. Inspect the provided workspace file tree and source files carefully before proposing changes.',
    '2. NEVER modify protected files: package.json, package-lock.json, firebase-applet-config.json, firestore.rules, server/adminAuth.ts, eslint.config.js, .env*, or .nova-admin/*.',
    '3. NEVER call window.alert, eval(), new Function(), or expose GEMINI_API_KEY in frontend code. Never use hardcoded placeholder URLs or fake stub buttons.',
    '4. Understand both English and Bengali (বাংলা) instructions accurately.',
    '5. PRESERVE existing working features unless explicitly asked to remove or redesign something.',
    '6. HOW TO OUTPUT EDITS ACCURATELY:',
    '   - For NEW files (`action: "create"`), provide `updatedContent` with the full complete file.',
    '   - For EXISTING files (`action: "modify"`) over 180 lines (like src/App.tsx, server.ts, AdminPanel.tsx, SuperPowerSection.tsx), prefer `patches` (`[{ search, replace }]`) using EXACT verbatim lines copied from the inspected source file with 2-4 context lines so each patch matches unambiguously.',
    '   - For small existing files under 180 lines, either `patches` or complete `updatedContent` is acceptable, NEVER truncate any file with "..." or "// rest of file".',
    '7. All TypeScript types, imports, React hooks, and Tailwind v4 dark-mode classes must compile cleanly under `tsc --noEmit` and `vite build`.',
    '8. If reference images are attached, inspect their layout, colors, spacing, typography, and controls closely and translate them into authentic React + Tailwind code integrated cleanly into NOVA AI.',
    '9. If code was pasted in Code Mode, analyze where it belongs (honoring Target File if specified), adapt imports/types seamlessly, and avoid duplicating symbols or breaking existing exports.',
  ].join('\n');

  const userTaskSections: string[] = [
    `## Workspace File Inventory (${allFiles.length} editable files)\n${fileListBlock}`,
    `## Inspected Source Files (${inspected.length} files)\n${inspectedContextBlock}`,
  ];

  if (prompt) {
    userTaskSections.push(`## Admin Natural-Language Request (Prompt)\n${prompt}`);
  }
  if (revisionNote) {
    userTaskSections.push(`## Revision Note\n${revisionNote}`);
  }
  if (codeSnippet) {
    userTaskSections.push(
      `## Submitted Code (${codeLanguage}${targetFile ? `, Target File: ${targetFile}` : ', Auto-detect Target File'})\n\`\`\`${codeLanguage}\n${codeSnippet}\n\`\`\``
    );
  }
  if (images.length > 0) {
    userTaskSections.push(
      `## Uploaded Reference Images (${images.length})\n${images.map((im, idx) => `${idx + 1}. ${im.name} (${im.mimeType})`).join('\n')}\nAnalyze these uploaded images carefully and implement the requested visual layout, components, or fixes.`
    );
  }

  userTaskSections.push(
    'Return ONLY valid JSON conforming to the responseSchema. Ensure every file change is complete, type-safe, and ready for `tsc --noEmit`.'
  );

  const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];
  for (const img of images) {
    const cleanB64 = img.base64.includes(',') ? img.base64.split(',').pop()! : img.base64;
    parts.push({
      inlineData: {
        mimeType: img.mimeType,
        data: cleanB64,
      },
    });
  }
  parts.push({ text: userTaskSections.join('\n\n') });

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      summary: {
        type: Type.STRING,
        description: 'Clear 1-3 sentence explanation of the implemented changes.',
      },
      notes: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description: 'Optional technical notes, verification hints, or follow-ups.',
      },
      edits: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            path: { type: Type.STRING, description: 'Relative workspace file path.' },
            action: { type: Type.STRING, description: 'Either modify or create.' },
            rationale: { type: Type.STRING, description: 'Why this file is modified or created.' },
            updatedContent: {
              type: Type.STRING,
              description: 'Full new file content for new files or small modified files.',
            },
            patches: {
              type: Type.ARRAY,
              description: 'Exact search/replace hunks for modifying existing files safely.',
              items: {
                type: Type.OBJECT,
                properties: {
                  search: {
                    type: Type.STRING,
                    description: 'Exact verbatim lines from the existing file.',
                  },
                  replace: {
                    type: Type.STRING,
                    description: 'Replacement lines.',
                  },
                },
                required: ['search', 'replace'],
              },
            },
          },
          required: ['path', 'action', 'rationale'],
        },
      },
    },
    required: ['summary', 'edits'],
  };

  const candidates = selectBuilderCandidateModels(req.preferredModel);
  const ai = getGeminiClient();

  let parsedPayload: GeminiBuilderResponse | null = null;
  let usedModel = candidates[0];
  let fallbackUsed = false;
  let lastError: unknown = null;

  for (let idx = 0; idx < candidates.length; idx++) {
    const candidateModel = candidates[idx];
    const abortCtrl = new AbortController();
    const timer = setTimeout(() => abortCtrl.abort(), 75_000);

    try {
      const isG4 = candidateModel.startsWith('gemini-4');
      const response = await ai.models.generateContent({
        model: candidateModel,
        contents: { parts },
        config: {
          systemInstruction: developerInstruction,
          responseMimeType: 'application/json',
          responseSchema,
          ...(isG4 ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM } } : {}),
          abortSignal: abortCtrl.signal,
        },
      });

      clearTimeout(timer);
      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        throw new Error(`Model ${candidateModel} returned an empty proposal response.`);
      }

      const candidateParsed = parseJsonStrictOrExtracted(rawText);
      // Validate patches & paths immediately so if a patch missed we can try next candidate or throw cleanly
      parsedPayload = candidateParsed;
      usedModel = candidateModel;
      fallbackUsed = idx > 0;
      break;
    } catch (err) {
      clearTimeout(timer);
      lastError = err;
      const classified = classifyGeminiError(err);

      if (classified.code === 'MODEL_NOT_FOUND') {
        markModelUnavailable(candidateModel);
      } else if (classified.code === 'QUOTA_EXCEEDED') {
        markModelQuotaExhausted(candidateModel);
      }

      const canContinue =
        idx < candidates.length - 1 &&
        (classified.code === 'MODEL_NOT_FOUND' ||
          classified.code === 'QUOTA_EXCEEDED' ||
          classified.code === 'MODEL_BUSY' ||
          classified.code === 'MODEL_TIMEOUT' ||
          err instanceof SyntaxError);

      console.warn(
        `[SuperPowerBuilder] Attempt with ${candidateModel} failed (${classified.code}): ${classified.message}`
      );

      if (!canContinue) {
        throw err;
      }
    }
  }

  if (!parsedPayload) {
    throw lastError instanceof Error
      ? lastError
      : new Error('Unable to generate code changes from the AI service.');
  }

  if (!Array.isArray(parsedPayload.edits) || parsedPayload.edits.length === 0) {
    throw new Error(
      'AI analyzed your request but did not propose any file modifications. Try adding more detail or specifying a target file.'
    );
  }

  const materialChanges: BuilderProposedFileChange[] = [];

  for (const edit of parsedPayload.edits) {
    const normPath = normalizeRelPath(edit.path || '');
    if (!isAllowedEditablePath(normPath)) {
      throw new Error(
        `Proposed file "${edit.path}" is protected or not an editable workspace source file.`
      );
    }

    const absPath = resolveSafeWorkspacePath(normPath);
    const fileExists = fs.existsSync(absPath) && fs.statSync(absPath).isFile();

    let oldContent = '';
    let originalSha256: string | null = null;
    if (fileExists) {
      oldContent = readWorkspaceFile(normPath).content;
      originalSha256 = sha256(oldContent);
    }

    const action: 'modify' | 'create' =
      edit.action === 'create' && !fileExists ? 'create' : 'modify';

    if (action === 'modify' && !fileExists) {
      throw new Error(`AI tried to modify non-existent file "${normPath}".`);
    }

    let newContent = '';
    if (Array.isArray(edit.patches) && edit.patches.length > 0 && fileExists) {
      newContent = applyPatchesToContent(oldContent, edit.patches, normPath);
    } else if (typeof edit.updatedContent === 'string' && edit.updatedContent.length > 0) {
      newContent = edit.updatedContent.replace(/\r\n/g, '\n');
      if (fileExists) {
        const oldLinesCount = oldContent.split(/\r?\n/).length;
        const newLinesCount = newContent.split(/\r?\n/).length;
        if (
          oldLinesCount > 180 &&
          newLinesCount < oldLinesCount * 0.35 &&
          !/remove|delete|simplify|strip|replace entire/i.test(prompt)
        ) {
          throw new Error(
            `Proposed edit for "${normPath}" appeared truncated (${newLinesCount} vs ${oldLinesCount} lines). Please retry so patch mode is used.`
          );
        }
      }
    } else {
      throw new Error(`No patches or file content provided for "${normPath}".`);
    }

    const { diffLines, stats } = computeLineDiff(oldContent, newContent);
    if (action === 'modify' && stats.added === 0 && stats.removed === 0) {
      continue;
    }

    materialChanges.push({
      path: normPath,
      action,
      rationale:
        (typeof edit.rationale === 'string' && edit.rationale.trim()) ||
        (action === 'create' ? 'Create new file' : 'Update existing file'),
      language: inferLanguageFromPath(normPath),
      oldContent,
      newContent,
      diffLines,
      stats,
      originalSha256,
    });
  }

  if (materialChanges.length === 0) {
    throw new Error(
      'Generated proposal resulted in zero line differences compared to current files.'
    );
  }

  const record: BuilderProposalRecord = {
    id: `bld_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    createdAt: Date.now(),
    actorEmail,
    inputModes,
    prompt: prompt.slice(0, 8000),
    revisionNote: revisionNote || `AI App Builder update (${inputModes.join('+')})`,
    codeLanguage: codeSnippet ? codeLanguage : undefined,
    targetFile,
    hasCodeSnippet: Boolean(codeSnippet),
    imageNames: images.map((im) => im.name),
    modelUsed: usedModel,
    fallbackUsed,
    inspectedFiles: inspected.map((f) => f.path),
    summary:
      (typeof parsedPayload.summary === 'string' && parsedPayload.summary.trim()) ||
      'Generated project modifications.',
    notes: Array.isArray(parsedPayload.notes)
      ? parsedPayload.notes.filter((n) => typeof n === 'string' && n.trim()).slice(0, 6)
      : [],
    status: 'pending',
    changes: materialChanges,
  };

  upsertBuilderProposal(record);
  return record;
}

export async function applyBuilderProposal(proposalId: string): Promise<{
  ok: boolean;
  proposal: BuilderProposalRecord;
  backup: BackupSnapshotMeta;
  validation: ValidationResult;
  buildValidation?: ValidationResult;
}> {
  const proposal = getBuilderProposalById(proposalId);
  if (!proposal) {
    throw new Error('Selected AI App Builder change proposal was not found.');
  }
  if (proposal.status === 'applied') {
    throw new Error('This change proposal has already been applied.');
  }
  if (proposal.changes.length === 0) {
    throw new Error('Change proposal contains no file edits.');
  }

  // Verify no underlying files drifted since preview generation
  for (const ch of proposal.changes) {
    const abs = resolveSafeWorkspacePath(ch.path);
    const exists = fs.existsSync(abs) && fs.statSync(abs).isFile();
    if (ch.action === 'create' && exists) {
      throw new Error(
        `Cannot create "${ch.path}" because it already exists on disk. Regenerate changes to modify it.`
      );
    }
    if (ch.action === 'modify') {
      if (!exists) {
        throw new Error(`Target file "${ch.path}" no longer exists on disk.`);
      }
      const currentSha = sha256(readWorkspaceFile(ch.path).content);
      if (ch.originalSha256 && currentSha !== ch.originalSha256) {
        throw new Error(
          `File "${ch.path}" changed since preview was generated. Generate a fresh preview before applying.`
        );
      }
    }
  }

  const edits = proposal.changes.map((c) => ({
    path: c.path,
    content: c.newContent,
  }));

  // Write with backup snapshot, do NOT auto-revert inside applyEditsWithBackup so we can run both tsc & vite build before deciding
  const { backup, validation } = await applyEditsWithBackup(
    edits,
    `Super Power Builder: ${proposal.revisionNote || proposal.summary.slice(0, 100)}`,
    { revertOnValidationFailure: false }
  );

  let buildValidation: ValidationResult | undefined;
  if (validation.ok) {
    buildValidation = await runViteBuildValidation();
  }

  const passedAll = validation.ok && (!buildValidation || buildValidation.ok);

  if (!passedAll) {
    // Roll back immediately so workspace stays clean and compiling
    await rollbackBackupSnapshot(backup.id).catch((rbErr) => {
      console.error('[SuperPowerBuilder] Auto-rollback error:', rbErr);
    });

    const failureDetail = !validation.ok
      ? `TypeScript validation failed: ${validation.output.slice(0, 500)}`
      : `Production Vite build failed: ${(buildValidation?.output || '').slice(0, 500)}`;

    const failedRecord: BuilderProposalRecord = {
      ...proposal,
      status: 'failed',
      backupId: backup.id,
      validation,
      buildValidation,
      errorMessage: `${failureDetail} Changes were automatically reverted using backup ${backup.id}.`,
    };
    upsertBuilderProposal(failedRecord);

    return {
      ok: false,
      proposal: failedRecord,
      backup,
      validation,
      buildValidation,
    };
  }

  const appliedRecord: BuilderProposalRecord = {
    ...proposal,
    status: 'applied',
    backupId: backup.id,
    appliedAt: Date.now(),
    validation,
    buildValidation,
    errorMessage: undefined,
  };
  upsertBuilderProposal(appliedRecord);

  return {
    ok: true,
    proposal: appliedRecord,
    backup,
    validation,
    buildValidation,
  };
}

export function rejectBuilderProposal(proposalId: string): BuilderProposalRecord {
  const proposal = getBuilderProposalById(proposalId);
  if (!proposal) {
    throw new Error('Change proposal was not found.');
  }
  if (proposal.status === 'applied') {
    throw new Error('Cannot reject an already applied change. Use Undo / Rollback instead.');
  }

  const updated: BuilderProposalRecord = {
    ...proposal,
    status: 'rejected',
  };
  upsertBuilderProposal(updated);
  return updated;
}

export async function rollbackBuilderProposal(proposalId: string): Promise<{
  proposal: BuilderProposalRecord;
  restoredPaths: string[];
  validation: ValidationResult;
}> {
  const proposal = getBuilderProposalById(proposalId);
  if (!proposal) {
    throw new Error('Change proposal was not found.');
  }
  if (!proposal.backupId) {
    throw new Error('This proposal does not have an associated backup snapshot to roll back.');
  }

  const { restoredPaths, validation } = await rollbackBackupSnapshot(proposal.backupId);

  const rolledBack: BuilderProposalRecord = {
    ...proposal,
    status: 'rolled-back',
    rolledBackAt: Date.now(),
    validation,
  };
  upsertBuilderProposal(rolledBack);

  return {
    proposal: rolledBack,
    restoredPaths,
    validation,
  };
}
