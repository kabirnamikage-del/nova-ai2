import { execFile } from 'child_process';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type {
  BackupSnapshotMeta,
  DiffLine,
  ValidationResult,
  WorkspaceFileNode,
} from '../src/types/admin.ts';

export const WORKSPACE_ROOT = path.resolve(process.cwd());
const ADMIN_DIR = path.join(WORKSPACE_ROOT, '.nova-admin');
const BACKUPS_DIR = path.join(ADMIN_DIR, 'backups');

const EXCLUDED_DIRS = new Set([
  'node_modules',
  '.git',
  '.nova-admin',
  'dist',
  'build',
  '.gradle',
  '.idea',
]);

// Completely hidden from file explorer & reading (secrets/keys)
function isHiddenSecretPath(relPath: string): boolean {
  const base = path.posix.basename(relPath);
  if (base === '.env' || base.startsWith('.env.')) return true;
  if (base.endsWith('.key') || base.endsWith('.pem') || base.endsWith('.p12')) {
    return true;
  }
  const firstSegment = relPath.split('/')[0];
  if (EXCLUDED_DIRS.has(firstSegment)) return true;
  return false;
}

// Protected files: viewable in code editor as read-only locked, NEVER editable via editor or AI proposals
const READ_ONLY_PROTECTED_FILES = new Set([
  'firebase-applet-config.json',
  'firestore.rules',
  'package.json',
  'package-lock.json',
  'server/adminAuth.ts',
  'eslint.config.js',
]);

export function isProtectedFile(relPath: string): boolean {
  const norm = normalizeRelPath(relPath);
  if (isHiddenSecretPath(norm)) return true;
  if (READ_ONLY_PROTECTED_FILES.has(norm)) return true;
  if (norm.startsWith('.env')) return true;
  return false;
}

export function normalizeRelPath(relPath: string): string {
  const replaced = relPath.replace(/\\/g, '/').replace(/^\/+/, '');
  return path.posix.normalize(replaced);
}

export function resolveSafeWorkspacePath(relPath: string): string {
  if (!relPath || relPath.includes('\0')) {
    throw new Error('Invalid file path.');
  }
  const normalized = normalizeRelPath(relPath);
  if (
    normalized === '.' ||
    normalized.startsWith('..') ||
    path.isAbsolute(normalized)
  ) {
    throw new Error('Path traversal outside workspace root is prohibited.');
  }
  if (isHiddenSecretPath(normalized)) {
    throw new Error('Access to sensitive environment or internal files is blocked.');
  }
  const resolved = path.resolve(WORKSPACE_ROOT, normalized);
  if (
    resolved !== WORKSPACE_ROOT &&
    !resolved.startsWith(WORKSPACE_ROOT + path.sep)
  ) {
    throw new Error('Resolved path escapes workspace root.');
  }
  return resolved;
}

export function listWorkspaceTree(maxDepth = 5): WorkspaceFileNode[] {
  const walk = (dirAbs: string, relDir: string, depth: number): WorkspaceFileNode[] => {
    if (depth > maxDepth) return [];
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dirAbs, { withFileTypes: true });
    } catch {
      return [];
    }

    const nodes: WorkspaceFileNode[] = [];
    for (const entry of entries) {
      const name = entry.name;
      if (EXCLUDED_DIRS.has(name)) continue;
      if (name === '.env' || name.startsWith('.env.')) continue;
      if (name.endsWith('.key') || name.endsWith('.pem') || name.endsWith('.p12')) {
        continue;
      }

      const relPath = relDir ? `${relDir}/${name}` : name;
      const absPath = path.join(dirAbs, name);

      if (entry.isDirectory()) {
        nodes.push({
          name,
          path: relPath,
          type: 'directory',
          children: walk(absPath, relPath, depth + 1),
        });
      } else if (entry.isFile()) {
        let size = 0;
        try {
          size = fs.statSync(absPath).size;
        } catch {
          size = 0;
        }
        nodes.push({
          name,
          path: relPath,
          type: 'file',
          size,
          protected: isProtectedFile(relPath),
        });
      }
    }

    nodes.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    return nodes;
  };

  return walk(WORKSPACE_ROOT, '', 0);
}

export function readWorkspaceFile(relPath: string): {
  path: string;
  content: string;
  protected: boolean;
  size: number;
} {
  const norm = normalizeRelPath(relPath);
  const abs = resolveSafeWorkspacePath(norm);
  if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) {
    throw new Error(`File "${norm}" does not exist.`);
  }
  const stat = fs.statSync(abs);
  if (stat.size > 1_000_000) {
    throw new Error(`File "${norm}" exceeds the 1 MB editor limit.`);
  }
  const buf = fs.readFileSync(abs);
  if (buf.includes(0)) {
    throw new Error(`File "${norm}" appears to be binary and cannot be edited as text.`);
  }
  return {
    path: norm,
    content: buf.toString('utf8'),
    protected: isProtectedFile(norm),
    size: stat.size,
  };
}

export function computeLineDiff(oldText: string, newText: string): {
  diffLines: DiffLine[];
  stats: { added: number; removed: number };
} {
  const oldLines = oldText.split(/\r?\n/);
  const newLines = newText.split(/\r?\n/);
  const totalOld = oldLines.length;
  const totalNew = newLines.length;

  // Trim identical prefix and suffix first so large files diff cleanly with exact LCS
  let prefix = 0;
  while (
    prefix < totalOld &&
    prefix < totalNew &&
    oldLines[prefix] === newLines[prefix]
  ) {
    prefix++;
  }

  let suffix = 0;
  while (
    suffix < totalOld - prefix &&
    suffix < totalNew - prefix &&
    oldLines[totalOld - 1 - suffix] === newLines[totalNew - 1 - suffix]
  ) {
    suffix++;
  }

  const midOld = oldLines.slice(prefix, totalOld - suffix);
  const midNew = newLines.slice(prefix, totalNew - suffix);
  const m = midOld.length;
  const n = midNew.length;

  const midOps: DiffLine[] = [];
  let added = 0;
  let removed = 0;

  if (m === 0 && n === 0) {
    return { diffLines: [], stats: { added: 0, removed: 0 } };
  }

  if (m * n > 2_000_000) {
    for (let i = 0; i < m; i++) {
      removed++;
      midOps.push({ type: 'remove', oldLine: prefix + i + 1, text: midOld[i] });
    }
    for (let j = 0; j < n; j++) {
      added++;
      midOps.push({ type: 'add', newLine: prefix + j + 1, text: midNew[j] });
    }
  } else {
    const dp: Uint32Array[] = Array.from(
      { length: m + 1 },
      () => new Uint32Array(n + 1)
    );
    for (let i = m - 1; i >= 0; i--) {
      for (let j = n - 1; j >= 0; j--) {
        if (midOld[i] === midNew[j]) {
          dp[i][j] = dp[i + 1][j + 1] + 1;
        } else {
          dp[i][j] = dp[i + 1][j] >= dp[i][j + 1] ? dp[i + 1][j] : dp[i][j + 1];
        }
      }
    }

    let i = 0;
    let j = 0;
    while (i < m && j < n) {
      if (midOld[i] === midNew[j]) {
        midOps.push({
          type: 'context',
          oldLine: prefix + i + 1,
          newLine: prefix + j + 1,
          text: midOld[i],
        });
        i++;
        j++;
      } else if (dp[i + 1][j] >= dp[i][j + 1]) {
        midOps.push({ type: 'remove', oldLine: prefix + i + 1, text: midOld[i] });
        removed++;
        i++;
      } else {
        midOps.push({ type: 'add', newLine: prefix + j + 1, text: midNew[j] });
        added++;
        j++;
      }
    }
    while (i < m) {
      midOps.push({ type: 'remove', oldLine: prefix + i + 1, text: midOld[i] });
      removed++;
      i++;
    }
    while (j < n) {
      midOps.push({ type: 'add', newLine: prefix + j + 1, text: midNew[j] });
      added++;
      j++;
    }
  }

  // Reconstruct full boundary context (3 lines before prefix & 3 lines into suffix)
  const fullOps: DiffLine[] = [];
  const leadStart = Math.max(0, prefix - 3);
  for (let k = leadStart; k < prefix; k++) {
    fullOps.push({
      type: 'context',
      oldLine: k + 1,
      newLine: k + 1,
      text: oldLines[k],
    });
  }
  fullOps.push(...midOps);
  const tailCount = Math.min(3, suffix);
  for (let k = 0; k < tailCount; k++) {
    const oi = totalOld - suffix + k;
    const nj = totalNew - suffix + k;
    fullOps.push({
      type: 'context',
      oldLine: oi + 1,
      newLine: nj + 1,
      text: oldLines[oi],
    });
  }

  // Trim internal unchanged stretches to 3 lines around changes
  const keep = new Uint8Array(fullOps.length);
  for (let idx = 0; idx < fullOps.length; idx++) {
    if (fullOps[idx].type !== 'context') {
      const start = Math.max(0, idx - 3);
      const end = Math.min(fullOps.length - 1, idx + 3);
      for (let k = start; k <= end; k++) keep[k] = 1;
    }
  }

  const trimmed = fullOps.filter((_, idx) => keep[idx] === 1);
  return {
    diffLines: trimmed.slice(0, 600),
    stats: { added, removed },
  };
}

export function createBackupSnapshot(
  relPaths: string[],
  reason: string
): BackupSnapshotMeta {
  if (!fs.existsSync(BACKUPS_DIR)) {
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
  }
  const id = `bak_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
  const snapshotDir = path.join(BACKUPS_DIR, id);
  const filesDir = path.join(snapshotDir, 'files');
  fs.mkdirSync(filesDir, { recursive: true });

  const fileRecords: BackupSnapshotMeta['files'] = [];
  for (const rel of relPaths) {
    const norm = normalizeRelPath(rel);
    const abs = resolveSafeWorkspacePath(norm);
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      const content = fs.readFileSync(abs);
      const backupFileAbs = path.join(filesDir, norm);
      fs.mkdirSync(path.dirname(backupFileAbs), { recursive: true });
      fs.writeFileSync(backupFileAbs, content);
      fileRecords.push({ path: norm, existed: true, size: content.length });
    } else {
      fileRecords.push({ path: norm, existed: false, size: 0 });
    }
  }

  const meta: BackupSnapshotMeta = {
    id,
    createdAt: Date.now(),
    reason: reason.slice(0, 200),
    files: fileRecords,
  };
  fs.writeFileSync(
    path.join(snapshotDir, 'meta.json'),
    JSON.stringify(meta, null, 2),
    'utf8'
  );
  return meta;
}

export function listBackupSnapshots(): BackupSnapshotMeta[] {
  if (!fs.existsSync(BACKUPS_DIR)) return [];
  const entries = fs.readdirSync(BACKUPS_DIR, { withFileTypes: true });
  const metas: BackupSnapshotMeta[] = [];
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    const metaPath = path.join(BACKUPS_DIR, e.name, 'meta.json');
    if (!fs.existsSync(metaPath)) continue;
    try {
      const parsed = JSON.parse(fs.readFileSync(metaPath, 'utf8')) as BackupSnapshotMeta;
      metas.push(parsed);
    } catch {
      // Ignore corrupt backup metadata
    }
  }
  return metas.sort((a, b) => b.createdAt - a.createdAt).slice(0, 40);
}

export async function runTypeScriptValidation(
  cwd: string = WORKSPACE_ROOT
): Promise<ValidationResult> {
  const started = Date.now();
  const localTsc = path.join(cwd, 'node_modules', '.bin', 'tsc');
  const cmd = fs.existsSync(localTsc) ? localTsc : 'npx';
  const args = fs.existsSync(localTsc) ? ['--noEmit'] : ['tsc', '--noEmit'];

  return new Promise<ValidationResult>((resolve) => {
    execFile(
      cmd,
      args,
      { cwd, timeout: 45_000, maxBuffer: 2 * 1024 * 1024 },
      (err, stdout, stderr) => {
        const output = [stdout, stderr].filter(Boolean).join('\n').trim();
        resolve({
          ok: !err,
          command: 'npx tsc --noEmit',
          output:
            output ||
            (err ? err.message : 'TypeScript validation passed with 0 errors.'),
          durationMs: Date.now() - started,
        });
      }
    );
  });
}

function restoreBackupFilesOnDisk(backupId: string): string[] {
  if (!/^bak_[0-9]+_[a-f0-9]+$/.test(backupId)) {
    throw new Error('Invalid backup snapshot ID.');
  }
  const snapshotDir = path.join(BACKUPS_DIR, backupId);
  const metaPath = path.join(snapshotDir, 'meta.json');
  if (!fs.existsSync(metaPath)) {
    throw new Error(`Backup snapshot "${backupId}" was not found.`);
  }
  const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8')) as BackupSnapshotMeta;
  const filesDir = path.join(snapshotDir, 'files');

  const restoredPaths: string[] = [];
  for (const f of meta.files) {
    const norm = normalizeRelPath(f.path);
    if (isProtectedFile(norm)) continue;
    const abs = resolveSafeWorkspacePath(norm);
    if (f.existed) {
      const backupFileAbs = path.join(filesDir, norm);
      if (fs.existsSync(backupFileAbs)) {
        fs.mkdirSync(path.dirname(abs), { recursive: true });
        fs.copyFileSync(backupFileAbs, abs);
        restoredPaths.push(norm);
      }
    } else if (fs.existsSync(abs)) {
      fs.unlinkSync(abs);
      restoredPaths.push(norm);
    }
  }
  return restoredPaths;
}

export async function applyEditsWithBackup(
  edits: Array<{ path: string; content: string }>,
  reason: string,
  opts: { revertOnValidationFailure?: boolean } = {}
): Promise<{
  backup: BackupSnapshotMeta;
  appliedPaths: string[];
  validation: ValidationResult;
}> {
  if (!Array.isArray(edits) || edits.length === 0) {
    throw new Error('No file edits provided.');
  }

  const normalizedEdits = edits.map((e) => {
    const norm = normalizeRelPath(e.path);
    if (isProtectedFile(norm)) {
      throw new Error(`Protected file "${norm}" cannot be modified.`);
    }
    const abs = resolveSafeWorkspacePath(norm);
    return { norm, abs, content: e.content };
  });

  const backup = createBackupSnapshot(
    normalizedEdits.map((e) => e.norm),
    reason
  );

  for (const item of normalizedEdits) {
    fs.mkdirSync(path.dirname(item.abs), { recursive: true });
    fs.writeFileSync(item.abs, item.content, 'utf8');
  }

  const validation = await runTypeScriptValidation();
  if (!validation.ok && opts.revertOnValidationFailure) {
    const reverted = restoreBackupFilesOnDisk(backup.id);
    console.error(
      '[AdminFiles] Validation failed; reverted edits:',
      reverted.join(', ')
    );
  }

  return {
    backup,
    appliedPaths: normalizedEdits.map((e) => e.norm),
    validation,
  };
}

export async function rollbackBackupSnapshot(backupId: string): Promise<{
  restoredPaths: string[];
  validation: ValidationResult;
}> {
  const restoredPaths = restoreBackupFilesOnDisk(backupId);
  const validation = await runTypeScriptValidation();
  return { restoredPaths, validation };
}

export async function syncAndroidCustomizationFiles(params: {
  appName: string;
  launcherColor: string;
  splashBackground: string;
}): Promise<{ backupId: string; updatedFiles: string[] }> {
  const safeName =
    params.appName
      .replace(/[<>&"']/g, '')
      .trim()
      .slice(0, 40) || 'NOVA AI';
  const safeLauncherColor = /^#[0-9a-fA-F]{6}$/.test(params.launcherColor)
    ? params.launcherColor.toUpperCase()
    : '#7C3AED';
  const safeSplash = /^#[0-9a-fA-F]{6}$/.test(params.splashBackground)
    ? params.splashBackground.toUpperCase()
    : '#0D0D10';

  const stringsRel = 'android/app/src/main/res/values/strings.xml';
  const themesRel = 'android/app/src/main/res/values/themes.xml';
  const launcherRel = 'android/app/src/main/res/drawable/ic_launcher_background.xml';

  const candidates = [stringsRel, themesRel, launcherRel].filter((rel) =>
    fs.existsSync(resolveSafeWorkspacePath(rel))
  );
  if (candidates.length === 0) {
    throw new Error('Android source files were not found in this workspace.');
  }

  const backup = createBackupSnapshot(candidates, 'Sync Android branding & theme');
  const updatedFiles: string[] = [];

  if (candidates.includes(stringsRel)) {
    const abs = resolveSafeWorkspacePath(stringsRel);
    const content = `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="app_name">${safeName}</string>\n</resources>\n`;
    fs.writeFileSync(abs, content, 'utf8');
    updatedFiles.push(stringsRel);
  }

  if (candidates.includes(themesRel)) {
    const abs = resolveSafeWorkspacePath(themesRel);
    const current = fs.readFileSync(abs, 'utf8');
    const next = current.replace(
      /(<item name="windowSplashScreenBackground">)[^<]*(<\/item>)/,
      `$1${safeSplash}$2`
    );
    fs.writeFileSync(abs, next, 'utf8');
    updatedFiles.push(themesRel);
  }

  if (candidates.includes(launcherRel)) {
    const abs = resolveSafeWorkspacePath(launcherRel);
    const content = `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#0D0D14"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="${safeLauncherColor}"
        android:fillAlpha="0.28"
        android:pathData="M54,14A40,40 0 1,1 54,94A40,40 0 1,1 54,14z" />
</vector>
`;
    fs.writeFileSync(abs, content, 'utf8');
    updatedFiles.push(launcherRel);
  }

  return { backupId: backup.id, updatedFiles };
}
