import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { getApps, initializeApp, type App } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import firebaseConfig from '../firebase-applet-config.json' with { type: 'json' };

export const SUPER_ADMIN_EMAIL = 'kabirnamikage@gmail.com';

export interface VerifiedAdminPrincipal {
  uid: string;
  email: string;
  name: string;
  provider: string;
}

declare global {
  namespace Express {
    interface Request {
      superAdmin?: VerifiedAdminPrincipal;
    }
  }
}

let cachedAdminApp: App | null = null;

function getFirebaseAdminApp(): App {
  if (cachedAdminApp) return cachedAdminApp;
  const existing = getApps();
  if (existing.length > 0) {
    cachedAdminApp = existing[0];
    return cachedAdminApp;
  }
  // Initialize with projectId ONLY so verifyIdToken works on Starter Tier without IAM permissions
  cachedAdminApp = initializeApp({
    projectId: firebaseConfig.projectId,
  });
  return cachedAdminApp;
}

export function isStepUpPinRequired(): boolean {
  return Boolean(process.env.ADMIN_STEPUP_PIN?.trim());
}

export function verifyStepUpPinHeader(req: Request): boolean {
  const configuredPin = process.env.ADMIN_STEPUP_PIN?.trim();
  if (!configuredPin) return true;
  const supplied = String(req.headers['x-admin-pin'] ?? '').trim();
  if (!supplied) return false;

  const a = Buffer.from(configuredPin, 'utf8');
  const b = Buffer.from(supplied, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export async function verifySuperAdminToken(
  authHeader?: string
): Promise<
  | { ok: true; principal: VerifiedAdminPrincipal }
  | { ok: false; status: number; code: string; title: string; message: string }
> {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return {
      ok: false,
      status: 401,
      code: 'AUTH_REQUIRED',
      title: 'Authentication Required',
      message: 'A valid Firebase Google OAuth ID token is required.',
    };
  }

  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    return {
      ok: false,
      status: 401,
      code: 'AUTH_REQUIRED',
      title: 'Authentication Required',
      message: 'Bearer authentication token is empty.',
    };
  }

  try {
    const adminApp = getFirebaseAdminApp();
    const decoded = await getAuth(adminApp).verifyIdToken(token);
    const email = (decoded.email || '').trim().toLowerCase();
    const emailVerified = decoded.email_verified === true;
    const provider = decoded.firebase?.sign_in_provider || '';

    if (!emailVerified || email !== SUPER_ADMIN_EMAIL) {
      return {
        ok: false,
        status: 403,
        code: 'ACCESS_DENIED',
        title: 'Access Denied',
        message:
          'Only the authorized Super Admin account is permitted to access this endpoint.',
      };
    }

    if (provider !== 'google.com') {
      return {
        ok: false,
        status: 403,
        code: 'GOOGLE_OAUTH_REQUIRED',
        title: 'Google OAuth Required',
        message:
          'Super Admin authentication must use verified Google OAuth sign-in.',
      };
    }

    return {
      ok: true,
      principal: {
        uid: decoded.uid,
        email,
        name: typeof decoded.name === 'string' && decoded.name ? decoded.name : 'Super Admin',
        provider,
      },
    };
  } catch (err) {
    return {
      ok: false,
      status: 401,
      code: 'INVALID_TOKEN',
      title: 'Invalid or Expired Session',
      message:
        err instanceof Error
          ? `Session verification failed: ${err.message}`
          : 'Unable to verify Firebase ID token.',
    };
  }
}

export async function requireSuperAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  const result = await verifySuperAdminToken(req.headers.authorization);
  if (!result.ok) {
    res.status(result.status).json({
      error: {
        code: result.code,
        title: result.title,
        message: result.message,
      },
    });
    return;
  }
  req.superAdmin = result.principal;
  next();
}

export function requireStepUpPin(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  if (!verifyStepUpPinHeader(req)) {
    res.status(403).json({
      error: {
        code: 'STEPUP_PIN_REQUIRED',
        title: 'Additional PIN Verification Required',
        message:
          'Enter the configured ADMIN_STEPUP_PIN to confirm this sensitive administrative change.',
      },
    });
    return;
  }
  next();
}
