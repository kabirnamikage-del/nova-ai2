import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type {
  AdminConfigDocument,
  BackendAuditLogEntry,
  PublicAppConfig,
  SuperPowerConfig,
  SuperPowerHistoryEntry,
  SuperPowerImageProviderMode,
  SuperPowerLanguagePriority,
  SuperPowerPersonalityPreset,
  SuperPowerThinkingLevel,
  SuperPowerTone,
  SuperPowerVerbosity,
  TelemetrySnapshot,
} from '../src/types/admin.ts';

const ADMIN_STORE_DIR = path.resolve(process.cwd(), '.nova-admin');
const CONFIG_PATH = path.join(ADMIN_STORE_DIR, 'config.json');
const TELEMETRY_PATH = path.join(ADMIN_STORE_DIR, 'telemetry.json');
const AUDIT_PATH = path.join(ADMIN_STORE_DIR, 'audit.json');
const SUPER_POWER_PATH = path.join(ADMIN_STORE_DIR, 'super-power.json');
const SUPER_POWER_HISTORY_PATH = path.join(ADMIN_STORE_DIR, 'super-power-history.json');

function ensureStoreDir(): void {
  if (!fs.existsSync(ADMIN_STORE_DIR)) {
    fs.mkdirSync(ADMIN_STORE_DIR, { recursive: true });
  }
}

function defaultAdminConfig(): AdminConfigDocument {
  return {
    version: 1,
    updatedAt: Date.now(),
    paidImageBillingConfirmedByAdmin: false,
    customization: {
      appName: 'NOVA AI',
      appDescription:
        'A ChatGPT-style personal AI workspace powered by Google Gemini with Bengali & English study support, vision analysis, and offline browser photo editing.',
      welcomeMessage: 'What can I help with?',
      logoMode: 'nova',
      customLogoDataUrl: '',
      defaultTheme: 'dark',
      primaryColor: '#8B5CF6',
      accentColor: '#06B6D4',
      chatBubbleStyle: 'rounded',
      maintenanceMode: false,
      maintenanceMessage:
        'NOVA AI is undergoing scheduled maintenance. Please check back shortly.',
      announcement: {
        enabled: false,
        text: '',
        severity: 'info',
      },
      sidebarItems: {
        createVisual: true,
        imageAssistant: true,
        library: true,
        studyMode: true,
        codingMode: true,
        writingMode: true,
      },
      android: {
        appName: 'NOVA AI',
        launcherColor: '#7C3AED',
        splashBackground: '#0D0D10',
        lastSyncedAt: null,
      },
    },
    features: {
      free: {
        advancedModes: true,
        premiumChatModels: false,
        imageGeneration: false,
        imageEditing: true,
        advancedFileUploads: true,
        voiceFeatures: true,
        customBrandingThemes: true,
        dailyRequestLimit: 60,
        maxUploadMb: 8,
      },
      premium: {
        advancedModes: true,
        premiumChatModels: true,
        imageGeneration: true,
        imageEditing: true,
        advancedFileUploads: true,
        voiceFeatures: true,
        customBrandingThemes: true,
        dailyRequestLimit: 500,
        maxUploadMb: 20,
      },
      admin: {
        advancedModes: true,
        premiumChatModels: true,
        imageGeneration: true,
        imageEditing: true,
        advancedFileUploads: true,
        voiceFeatures: true,
        customBrandingThemes: true,
        dailyRequestLimit: 10000,
        maxUploadMb: 25,
      },
    },
  };
}

function defaultTelemetry(): TelemetrySnapshot {
  return {
    totalRequests: 0,
    totalSuccess: 0,
    totalErrors: 0,
    quotaErrors429: 0,
    chatRequests: 0,
    imageAnalysisRequests: 0,
    imageGenRequests: 0,
    voiceRequests: 0,
    byDay: [],
    byModel: {},
    recentErrors: [],
  };
}

function readJsonSafe<T>(filePath: string, fallback: () => T): T {
  try {
    if (!fs.existsSync(filePath)) return fallback();
    const raw = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(raw) as T;
  } catch {
    return fallback();
  }
}

function writeJsonSafe(filePath: string, data: unknown): void {
  ensureStoreDir();
  const tmpPath = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpPath, filePath);
}

export function getAdminConfig(): AdminConfigDocument {
  const defaults = defaultAdminConfig();
  const loaded = readJsonSafe<Partial<AdminConfigDocument>>(CONFIG_PATH, () => defaults);
  return {
    version: loaded.version ?? defaults.version,
    updatedAt: loaded.updatedAt ?? defaults.updatedAt,
    paidImageBillingConfirmedByAdmin: Boolean(loaded.paidImageBillingConfirmedByAdmin),
    customization: {
      ...defaults.customization,
      ...(loaded.customization || {}),
      announcement: {
        ...defaults.customization.announcement,
        ...(loaded.customization?.announcement || {}),
      },
      sidebarItems: {
        ...defaults.customization.sidebarItems,
        ...(loaded.customization?.sidebarItems || {}),
      },
      android: {
        ...defaults.customization.android,
        ...(loaded.customization?.android || {}),
      },
    },
    features: {
      free: { ...defaults.features.free, ...(loaded.features?.free || {}) },
      premium: { ...defaults.features.premium, ...(loaded.features?.premium || {}) },
      admin: { ...defaults.features.admin, ...(loaded.features?.admin || {}) },
    },
  };
}

export function saveAdminConfig(next: AdminConfigDocument): AdminConfigDocument {
  const current = getAdminConfig();
  const saved: AdminConfigDocument = {
    ...next,
    version: current.version + 1,
    updatedAt: Date.now(),
  };
  writeJsonSafe(CONFIG_PATH, saved);
  return saved;
}

export function getPublicAppConfig(): PublicAppConfig {
  const cfg = getAdminConfig();
  const sp = getSuperPowerConfig();
  return {
    version: cfg.version,
    updatedAt: cfg.updatedAt,
    customization: cfg.customization,
    features: cfg.features,
    paidImageBillingConfirmedByAdmin: cfg.paidImageBillingConfirmedByAdmin,
    superPower: {
      defaultChatModel: sp.models.defaultChatModel,
      visionModel: sp.models.visionModel,
      imageProviderMode: sp.provider.imageProviderMode,
      features: { ...sp.features },
    },
  };
}

export function getTelemetrySnapshot(): TelemetrySnapshot {
  return readJsonSafe<TelemetrySnapshot>(TELEMETRY_PATH, defaultTelemetry);
}

export function recordApiEvent(params: {
  category: 'chat' | 'image_analyze' | 'image_gen' | 'voice';
  route: string;
  model?: string;
  ok: boolean;
  status?: number;
  errorCode?: string;
  errorMessage?: string;
}): void {
  const snap = getTelemetrySnapshot();
  const today = new Date().toISOString().slice(0, 10);
  const status = params.status ?? (params.ok ? 200 : 500);
  const isQuota =
    status === 429 ||
    params.errorCode === 'QUOTA_EXCEEDED' ||
    params.errorCode === 'MODEL_BUSY';

  snap.totalRequests += 1;
  if (params.ok) {
    snap.totalSuccess += 1;
  } else {
    snap.totalErrors += 1;
    if (status === 429 || params.errorCode === 'QUOTA_EXCEEDED') {
      snap.quotaErrors429 += 1;
    }
  }

  if (params.category === 'chat') snap.chatRequests += 1;
  if (params.category === 'image_analyze') snap.imageAnalysisRequests += 1;
  if (params.category === 'image_gen') snap.imageGenRequests += 1;
  if (params.category === 'voice') snap.voiceRequests += 1;

  let dayEntry = snap.byDay.find((d) => d.date === today);
  if (!dayEntry) {
    dayEntry = {
      date: today,
      requests: 0,
      errors: 0,
      quotaErrors: 0,
      chat: 0,
      image: 0,
    };
    snap.byDay.push(dayEntry);
    snap.byDay.sort((a, b) => a.date.localeCompare(b.date));
    if (snap.byDay.length > 30) {
      snap.byDay = snap.byDay.slice(-30);
    }
  }

  dayEntry.requests += 1;
  if (!params.ok) dayEntry.errors += 1;
  if (isQuota) dayEntry.quotaErrors += 1;
  if (params.category === 'chat') dayEntry.chat += 1;
  if (params.category === 'image_analyze' || params.category === 'image_gen') {
    dayEntry.image += 1;
  }

  if (params.model) {
    const entry = snap.byModel[params.model] || {
      requests: 0,
      errors: 0,
      quotaErrors: 0,
      lastUsedAt: 0,
    };
    entry.requests += 1;
    if (!params.ok) entry.errors += 1;
    if (status === 429 || params.errorCode === 'QUOTA_EXCEEDED') {
      entry.quotaErrors += 1;
    }
    entry.lastUsedAt = Date.now();
    snap.byModel[params.model] = entry;
  }

  if (!params.ok) {
    snap.recentErrors.unshift({
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      route: params.route,
      model: params.model,
      code: params.errorCode || 'ERROR',
      status,
      message: (params.errorMessage || 'API request failed').slice(0, 320),
    });
    if (snap.recentErrors.length > 40) {
      snap.recentErrors = snap.recentErrors.slice(0, 40);
    }
  }

  writeJsonSafe(TELEMETRY_PATH, snap);
}

export function getBackendAuditLogs(): BackendAuditLogEntry[] {
  return readJsonSafe<BackendAuditLogEntry[]>(AUDIT_PATH, () => []);
}

export function appendBackendAuditLog(entry: {
  actorEmail: string;
  action: string;
  target: string;
  details: string;
}): BackendAuditLogEntry {
  const logs = getBackendAuditLogs();
  const next: BackendAuditLogEntry = {
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    actorEmail: entry.actorEmail,
    action: entry.action,
    target: entry.target,
    details: entry.details.slice(0, 500),
  };
  logs.unshift(next);
  if (logs.length > 200) {
    logs.length = 200;
  }
  writeJsonSafe(AUDIT_PATH, logs);
  return next;
}

export const DEFAULT_SUPER_POWER_SYSTEM_PROMPT =
  'You are NOVA AI, a thoughtful, accurate, and clear personal AI assistant.';

export function defaultSuperPowerConfig(): SuperPowerConfig {
  return {
    version: 1,
    updatedAt: Date.now(),
    updatedBy: 'system',
    personality: {
      preset: 'nova-balanced',
      tone: 'warm',
      languagePriority: 'match-user',
      empathyBoost: true,
      citationsStrictness: true,
    },
    systemPrompt: DEFAULT_SUPER_POWER_SYSTEM_PROMPT,
    customInstructions: '',
    models: {
      defaultChatModel: 'gemini-3.1-flash-lite',
      fallbackChatModel: 'gemini-4-hydrogen',
      visionModel: 'gemini-2.5-flash-lite',
      titleModel: 'gemini-3.1-flash-lite',
      autoFallbackEnabled: true,
    },
    provider: {
      activeProvider: 'google-gemini',
      searchGroundingProvider: 'google-search',
      imageProviderMode: 'hybrid',
      requestTimeoutMs: 25000,
      retryOnBusy: true,
      maxBusyRetries: 1,
    },
    features: {
      chatEnabled: true,
      streamingEnabled: true,
      webSearchEnabled: true,
      visionEnabled: true,
      voiceEnabled: true,
      autoTitleEnabled: true,
      svgDiagramsEnabled: true,
    },
    responseBehavior: {
      thinkingLevel: 'auto',
      verbosity: 'balanced',
      markdownFormatting: true,
      includeFollowUpSuggestions: false,
      admitUncertainty: true,
    },
  };
}

const VALID_PRESETS = new Set<SuperPowerPersonalityPreset>([
  'nova-balanced',
  'friendly-mentor',
  'concise-executive',
  'technical-architect',
  'creative-storyteller',
  'bilingual-tutor',
]);
const VALID_TONES = new Set<SuperPowerTone>([
  'neutral',
  'warm',
  'direct',
  'academic',
  'playful',
]);
const VALID_LANG_PRIORITIES = new Set<SuperPowerLanguagePriority>([
  'match-user',
  'english-first',
  'bengali-first',
  'bilingual-bn-en',
]);
const VALID_VERBOSITIES = new Set<SuperPowerVerbosity>([
  'concise',
  'balanced',
  'detailed',
]);
const VALID_THINKING = new Set<SuperPowerThinkingLevel>([
  'auto',
  'low',
  'medium',
  'high',
]);
const VALID_IMAGE_MODES = new Set<SuperPowerImageProviderMode>([
  'hybrid',
  'web-only',
  'nano-banana-enabled',
]);

export function sanitizeSuperPowerConfig(
  incoming: Partial<SuperPowerConfig> | undefined,
  base?: SuperPowerConfig
): SuperPowerConfig {
  const defaults = base ?? defaultSuperPowerConfig();
  const p = incoming?.personality;
  const m = incoming?.models;
  const pr = incoming?.provider;
  const f = incoming?.features;
  const rb = incoming?.responseBehavior;

  const clampNum = (val: unknown, min: number, max: number, fallback: number) =>
    typeof val === 'number' && Number.isFinite(val)
      ? Math.min(max, Math.max(min, Math.round(val)))
      : fallback;

  const cleanStr = (val: unknown, maxLen: number, fallback: string) =>
    typeof val === 'string' ? val.slice(0, maxLen) : fallback;

  return {
    version:
      typeof incoming?.version === 'number' && Number.isFinite(incoming.version)
        ? Math.max(1, Math.round(incoming.version))
        : defaults.version,
    updatedAt:
      typeof incoming?.updatedAt === 'number' && Number.isFinite(incoming.updatedAt)
        ? incoming.updatedAt
        : defaults.updatedAt,
    updatedBy: cleanStr(incoming?.updatedBy, 120, defaults.updatedBy),
    personality: {
      preset:
        p?.preset && VALID_PRESETS.has(p.preset) ? p.preset : defaults.personality.preset,
      tone: p?.tone && VALID_TONES.has(p.tone) ? p.tone : defaults.personality.tone,
      languagePriority:
        p?.languagePriority && VALID_LANG_PRIORITIES.has(p.languagePriority)
          ? p.languagePriority
          : defaults.personality.languagePriority,
      empathyBoost:
        typeof p?.empathyBoost === 'boolean'
          ? p.empathyBoost
          : defaults.personality.empathyBoost,
      citationsStrictness:
        typeof p?.citationsStrictness === 'boolean'
          ? p.citationsStrictness
          : defaults.personality.citationsStrictness,
    },
    systemPrompt:
      cleanStr(incoming?.systemPrompt, 8000, defaults.systemPrompt).trim() ||
      DEFAULT_SUPER_POWER_SYSTEM_PROMPT,
    customInstructions: cleanStr(
      incoming?.customInstructions,
      6000,
      defaults.customInstructions
    ).trim(),
    models: {
      defaultChatModel:
        cleanStr(m?.defaultChatModel, 100, defaults.models.defaultChatModel).trim() ||
        defaults.models.defaultChatModel,
      fallbackChatModel:
        cleanStr(m?.fallbackChatModel, 100, defaults.models.fallbackChatModel).trim() ||
        defaults.models.fallbackChatModel,
      visionModel:
        cleanStr(m?.visionModel, 100, defaults.models.visionModel).trim() ||
        defaults.models.visionModel,
      titleModel:
        cleanStr(m?.titleModel, 100, defaults.models.titleModel).trim() ||
        defaults.models.titleModel,
      autoFallbackEnabled:
        typeof m?.autoFallbackEnabled === 'boolean'
          ? m.autoFallbackEnabled
          : defaults.models.autoFallbackEnabled,
    },
    provider: {
      activeProvider: 'google-gemini',
      searchGroundingProvider:
        pr?.searchGroundingProvider === 'disabled' ? 'disabled' : 'google-search',
      imageProviderMode:
        pr?.imageProviderMode && VALID_IMAGE_MODES.has(pr.imageProviderMode)
          ? pr.imageProviderMode
          : defaults.provider.imageProviderMode,
      requestTimeoutMs: clampNum(
        pr?.requestTimeoutMs,
        8000,
        60000,
        defaults.provider.requestTimeoutMs
      ),
      retryOnBusy:
        typeof pr?.retryOnBusy === 'boolean'
          ? pr.retryOnBusy
          : defaults.provider.retryOnBusy,
      maxBusyRetries: clampNum(pr?.maxBusyRetries, 0, 3, defaults.provider.maxBusyRetries),
    },
    features: {
      chatEnabled:
        typeof f?.chatEnabled === 'boolean' ? f.chatEnabled : defaults.features.chatEnabled,
      streamingEnabled:
        typeof f?.streamingEnabled === 'boolean'
          ? f.streamingEnabled
          : defaults.features.streamingEnabled,
      webSearchEnabled:
        typeof f?.webSearchEnabled === 'boolean'
          ? f.webSearchEnabled
          : defaults.features.webSearchEnabled,
      visionEnabled:
        typeof f?.visionEnabled === 'boolean'
          ? f.visionEnabled
          : defaults.features.visionEnabled,
      voiceEnabled:
        typeof f?.voiceEnabled === 'boolean'
          ? f.voiceEnabled
          : defaults.features.voiceEnabled,
      autoTitleEnabled:
        typeof f?.autoTitleEnabled === 'boolean'
          ? f.autoTitleEnabled
          : defaults.features.autoTitleEnabled,
      svgDiagramsEnabled:
        typeof f?.svgDiagramsEnabled === 'boolean'
          ? f.svgDiagramsEnabled
          : defaults.features.svgDiagramsEnabled,
    },
    responseBehavior: {
      thinkingLevel:
        rb?.thinkingLevel && VALID_THINKING.has(rb.thinkingLevel)
          ? rb.thinkingLevel
          : defaults.responseBehavior.thinkingLevel,
      verbosity:
        rb?.verbosity && VALID_VERBOSITIES.has(rb.verbosity)
          ? rb.verbosity
          : defaults.responseBehavior.verbosity,
      markdownFormatting:
        typeof rb?.markdownFormatting === 'boolean'
          ? rb.markdownFormatting
          : defaults.responseBehavior.markdownFormatting,
      includeFollowUpSuggestions:
        typeof rb?.includeFollowUpSuggestions === 'boolean'
          ? rb.includeFollowUpSuggestions
          : defaults.responseBehavior.includeFollowUpSuggestions,
      admitUncertainty:
        typeof rb?.admitUncertainty === 'boolean'
          ? rb.admitUncertainty
          : defaults.responseBehavior.admitUncertainty,
    },
  };
}

export function getSuperPowerConfig(): SuperPowerConfig {
  const defaults = defaultSuperPowerConfig();
  const loaded = readJsonSafe<Partial<SuperPowerConfig>>(SUPER_POWER_PATH, () => defaults);
  return sanitizeSuperPowerConfig(loaded, defaults);
}

export function getSuperPowerHistory(): SuperPowerHistoryEntry[] {
  const list = readJsonSafe<SuperPowerHistoryEntry[]>(SUPER_POWER_HISTORY_PATH, () => []);
  return Array.isArray(list) ? list : [];
}

export function saveSuperPowerConfig(
  incoming: Partial<SuperPowerConfig>,
  actorEmail: string,
  note?: string
): { config: SuperPowerConfig; history: SuperPowerHistoryEntry[] } {
  const current = getSuperPowerConfig();
  const history = getSuperPowerHistory();

  // Seed initial baseline revision before applying first custom edit so user can always restore v1
  if (history.length === 0) {
    history.unshift({
      id: `sp_${current.version}_${crypto.randomBytes(3).toString('hex')}`,
      version: current.version,
      savedAt: current.updatedAt || Date.now(),
      actorEmail: current.updatedBy || 'system',
      note: 'Initial baseline configuration',
      action: 'save',
      config: current,
    });
  }

  const sanitized = sanitizeSuperPowerConfig(incoming, current);
  const now = Date.now();
  const saved: SuperPowerConfig = {
    ...sanitized,
    version: current.version + 1,
    updatedAt: now,
    updatedBy: actorEmail,
  };

  writeJsonSafe(SUPER_POWER_PATH, saved);

  const entry: SuperPowerHistoryEntry = {
    id: `sp_${saved.version}_${crypto.randomBytes(3).toString('hex')}`,
    version: saved.version,
    savedAt: now,
    actorEmail,
    note:
      note?.trim().slice(0, 200) ||
      `Updated Super Power (${saved.personality.preset} · ${saved.models.defaultChatModel})`,
    action: 'save',
    config: saved,
  };

  history.unshift(entry);
  if (history.length > 50) {
    history.length = 50;
  }
  writeJsonSafe(SUPER_POWER_HISTORY_PATH, history);

  return { config: saved, history };
}

export function restoreSuperPowerConfig(
  historyId: string,
  actorEmail: string
): {
  config: SuperPowerConfig;
  history: SuperPowerHistoryEntry[];
  restoredFromVersion: number;
} {
  const history = getSuperPowerHistory();
  const target = history.find((item) => item.id === historyId);
  if (!target) {
    throw new Error('Selected Super Power configuration revision was not found.');
  }

  const current = getSuperPowerConfig();
  const now = Date.now();
  const baseRestored = sanitizeSuperPowerConfig(target.config, defaultSuperPowerConfig());
  const nextConfig: SuperPowerConfig = {
    ...baseRestored,
    version: current.version + 1,
    updatedAt: now,
    updatedBy: actorEmail,
  };

  writeJsonSafe(SUPER_POWER_PATH, nextConfig);

  const restoreEntry: SuperPowerHistoryEntry = {
    id: `sp_${nextConfig.version}_${crypto.randomBytes(3).toString('hex')}`,
    version: nextConfig.version,
    savedAt: now,
    actorEmail,
    note: `Restored settings from v${target.version}`,
    action: 'restore',
    restoredFromVersion: target.version,
    config: nextConfig,
  };

  history.unshift(restoreEntry);
  if (history.length > 50) {
    history.length = 50;
  }
  writeJsonSafe(SUPER_POWER_HISTORY_PATH, history);

  return {
    config: nextConfig,
    history,
    restoredFromVersion: target.version,
  };
}
