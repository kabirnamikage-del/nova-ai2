import { GoogleGenAI, ThinkingLevel, type Content, type Part } from '@google/genai';
import type { SuperPowerConfig, SuperPowerThinkingLevel } from '../src/types/admin.ts';

export interface ClassifiedApiError {
  status: number;
  code: string;
  title: string;
  message: string;
  hint: string;
}

export interface ModelMetadata {
  id: string;
  name: string;
  displayName: string;
  description: string;
  inputTokenLimit?: number;
  outputTokenLimit?: number;
  supportsSearchGrounding: boolean;
  supportsVision: boolean;
  tier: 'free' | 'paid';
}

export interface IncomingAttachment {
  name?: string;
  mimeType: string;
  data: string;
  kind?: 'image' | 'pdf' | 'text';
}

export interface IncomingMessage {
  role: 'user' | 'assistant';
  content: string;
  attachments?: IncomingAttachment[];
  error?: unknown;
}

const DEPRECATED_OR_NON_CHAT_PATTERNS = [
  'gemini-1.0',
  'gemini-1.5',
  'gemini-2.0',
  'text-bison',
  'chat-bison',
  'embedding',
  'imagen',
  'veo',
  'lyria',
  'aqa',
  'tts',
  'transcribe',
  'live',
  'genie',
  'decision',
  'robotics',
  'computer-use',
  'bisect',
  '-image',
  'nano-banana',
  'omni',
];

const PAID_CHAT_MODEL_IDS = new Set([
  'gemini-4-neon',
  'gemini-4-carbon',
  'gemini-4-argon',
]);

const PREFERRED_MODEL_ORDER = [
  'gemini-3.1-flash-lite',
  'gemini-3.5-flash-lite',
  'gemini-4-hydrogen',
  'gemini-3.8-flash',
  'gemini-3.7-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash',
  'gemini-4-neon',
  'gemini-4-carbon',
  'gemini-4-argon',
];

const MODEL_AVAILABILITY_TTL_MS = 10 * 60_000;
const modelAvailabilityCache = new Map<
  string,
  { available: boolean; expiresAt: number }
>();
const modelQuotaCooldownCache = new Map<string, number>();

export function isApiKeyConfigured(): boolean {
  const key = process.env.GEMINI_API_KEY;
  return Boolean(key && key.trim() && key.trim() !== 'MY_GEMINI_API_KEY');
}

export function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    const err = new Error('GEMINI_API_KEY is not configured on the server.');
    (err as Error & { customCode?: string }).customCode = 'MISSING_API_KEY';
    throw err;
  }

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractReadableMessage(raw: string): string {
  let current = raw.trim();
  for (let i = 0; i < 3; i++) {
    if (!current.startsWith('{')) break;
    try {
      const parsed = JSON.parse(current) as {
        error?: { message?: string } | string;
        message?: string;
      };
      if (typeof parsed.error === 'object' && parsed.error?.message) {
        current = parsed.error.message.trim();
      } else if (typeof parsed.message === 'string') {
        current = parsed.message.trim();
      } else {
        break;
      }
    } catch {
      break;
    }
  }
  return current;
}

export function classifyGeminiError(err: unknown): ClassifiedApiError {
  const rawMessage = err instanceof Error ? err.message : String(err ?? 'Unknown error');
  const readableMessage = extractReadableMessage(rawMessage);
  const lower = `${rawMessage} ${readableMessage}`.toLowerCase();
  const customCode = (err as { customCode?: string } | null)?.customCode;
  const statusProp = (err as { status?: number } | null)?.status;

  if (customCode === 'MISSING_API_KEY' || lower.includes('not configured')) {
    return {
      status: 503,
      code: 'MISSING_API_KEY',
      title: 'Gemini API Key Not Configured',
      message: 'The backend does not have an active GEMINI_API_KEY configured.',
      hint: 'Open Settings > Secrets in AI Studio and configure GEMINI_API_KEY, then reload or verify the connection.',
    };
  }

  if (
    statusProp === 401 ||
    statusProp === 403 ||
    lower.includes('api_key_invalid') ||
    lower.includes('api key not valid') ||
    lower.includes('permission_denied') ||
    lower.includes('unauthorized') ||
    lower.includes('forbidden')
  ) {
    return {
      status: 401,
      code: 'AUTH_ERROR',
      title: 'Authentication Failed',
      message: 'The configured Gemini API key was rejected or lacks permission for this model.',
      hint: 'Verify your GEMINI_API_KEY in AI Studio Settings > Secrets, or choose a free-tier model like Gemini 4 Hydrogen.',
    };
  }

  if (
    statusProp === 429 ||
    lower.includes('resource_exhausted') ||
    lower.includes('quota') ||
    lower.includes('rate limit') ||
    lower.includes('"code": 429')
  ) {
    return {
      status: 429,
      code: 'QUOTA_EXCEEDED',
      title: 'Quota or Rate Limit Reached',
      message: 'API request limit or quota has been reached for this key or model.',
      hint: 'Wait a few seconds and retry, switch to a lighter model, or upgrade your API key billing tier in Settings > Secrets.',
    };
  }

  if (
    statusProp === 504 ||
    (err instanceof Error && err.name === 'AbortError') ||
    lower.includes('timeout') ||
    lower.includes('timed out') ||
    lower.includes('aborted') ||
    lower.includes('deadline_exceeded')
  ) {
    return {
      status: 504,
      code: 'MODEL_TIMEOUT',
      title: 'Response Timed Out',
      message: 'The Gemini model took too long to respond.',
      hint: 'Click Retry, or switch to Gemini 3.1 Flash Lite in the model selector for faster responses.',
    };
  }

  if (
    statusProp === 503 ||
    lower.includes('unavailable') ||
    lower.includes('high demand') ||
    lower.includes('overloaded') ||
    lower.includes('"code": 503')
  ) {
    return {
      status: 503,
      code: 'MODEL_BUSY',
      title: 'Model Temporarily Busy',
      message: readableMessage || 'This model is temporarily experiencing high demand.',
      hint: 'Click Retry in a moment, or switch to another available model (such as Gemini 3.1 Flash Lite) in the model selector.',
    };
  }

  if (
    statusProp === 404 ||
    lower.includes('not_found') ||
    lower.includes('is not found for api version')
  ) {
    return {
      status: 404,
      code: 'MODEL_NOT_FOUND',
      title: 'Model Unavailable',
      message: 'The selected Gemini model is unavailable or unsupported for this request.',
      hint: 'Refresh the model selector and pick an active model from the list.',
    };
  }

  if (
    lower.includes('enotfound') ||
    lower.includes('etimedout') ||
    lower.includes('econnreset') ||
    lower.includes('econnrefused') ||
    lower.includes('fetch failed') ||
    lower.includes('network')
  ) {
    return {
      status: 502,
      code: 'NETWORK_ERROR',
      title: 'Network Connection Issue',
      message: 'Unable to reach the Gemini API service from the server.',
      hint: 'Check internet connectivity and try again.',
    };
  }

  if (statusProp === 400 || lower.includes('invalid_argument')) {
    return {
      status: 400,
      code: 'INVALID_REQUEST',
      title: 'Invalid Request',
      message: readableMessage || 'The request parameters were rejected by the model.',
      hint: 'Try disabling Web Search for this model or removing unsupported attachments.',
    };
  }

  return {
    status: 500,
    code: 'INTERNAL_ERROR',
    title: 'Assistant Error',
    message: readableMessage || 'An unexpected error occurred while generating a response.',
    hint: 'Try regenerating the response or switching models.',
  };
}

function isSupportedChatModel(id: string, supportedActions?: string[]): boolean {
  const lower = id.toLowerCase();

  if (!lower.includes('gemini')) {
    return false;
  }

  if (lower === 'gemini-pro') {
    return false;
  }

  if (DEPRECATED_OR_NON_CHAT_PATTERNS.some((pattern) => lower.includes(pattern))) {
    return false;
  }

  if (Array.isArray(supportedActions) && supportedActions.length > 0) {
    if (!supportedActions.includes('generateContent')) {
      return false;
    }
  }

  return true;
}

function supportsSearchGroundingForModel(id: string): boolean {
  const lower = id.toLowerCase();
  return (
    lower.includes('gemini-4') ||
    lower.includes('gemini-3') ||
    lower.includes('gemini-2.5')
  );
}

export function markModelUnavailable(modelId: string): void {
  modelAvailabilityCache.set(modelId, {
    available: false,
    expiresAt: Date.now() + MODEL_AVAILABILITY_TTL_MS,
  });
}

export function markModelQuotaExhausted(
  modelId: string,
  cooldownMs = 15 * 60_000
): void {
  modelQuotaCooldownCache.set(modelId, Date.now() + cooldownMs);
}

export function isModelInQuotaCooldown(modelId: string): boolean {
  const expiresAt = modelQuotaCooldownCache.get(modelId);
  if (!expiresAt) return false;
  if (expiresAt <= Date.now()) {
    modelQuotaCooldownCache.delete(modelId);
    return false;
  }
  return true;
}

async function isModelCallable(
  ai: GoogleGenAI,
  modelId: string
): Promise<boolean> {
  const cached = modelAvailabilityCache.get(modelId);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.available;
  }

  const abortCtrl = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;

  const probePromise = ai.models
    .generateContent({
      model: modelId,
      contents: 'hi',
      config: {
        maxOutputTokens: 1,
        abortSignal: abortCtrl.signal,
      },
    })
    .then(() => true)
    .catch((err) => {
      const classified = classifyGeminiError(err);
      return !(
        classified.code === 'MODEL_NOT_FOUND' ||
        classified.code === 'AUTH_ERROR'
      );
    });

  const timeoutPromise = new Promise<boolean>((resolve) => {
    timer = setTimeout(() => {
      abortCtrl.abort();
      resolve(true);
    }, 1500);
  });

  const available = await Promise.race([probePromise, timeoutPromise]);
  if (timer) clearTimeout(timer);

  modelAvailabilityCache.set(modelId, {
    available,
    expiresAt: Date.now() + MODEL_AVAILABILITY_TTL_MS,
  });
  return available;
}

export async function listAvailableModels(): Promise<ModelMetadata[]> {
  const ai = getGeminiClient();
  const pager = await ai.models.list();
  const candidates: ModelMetadata[] = [];

  for await (const raw of pager) {
    const fullName = raw.name ?? '';
    const id = fullName.replace(/^models\//, '');
    if (!id) continue;

    if (!isSupportedChatModel(id, raw.supportedActions)) {
      continue;
    }

    candidates.push({
      id,
      name: fullName,
      displayName: raw.displayName?.trim() || id,
      description: raw.description?.trim() || '',
      inputTokenLimit: raw.inputTokenLimit,
      outputTokenLimit: raw.outputTokenLimit,
      supportsSearchGrounding: supportsSearchGroundingForModel(id),
      supportsVision: true,
      tier: PAID_CHAT_MODEL_IDS.has(id) ? 'paid' : 'free',
    });
  }

  const probeResults = await Promise.all(
    candidates.map(async (m) => ({
      model: m,
      callable: await isModelCallable(ai, m.id),
    }))
  );

  const models = probeResults.filter((r) => r.callable).map((r) => r.model);

  models.sort((a, b) => {
    // Sort free models ahead of paid-only models while keeping preferred order
    if (a.tier !== b.tier) {
      return a.tier === 'free' ? -1 : 1;
    }
    const idxA = PREFERRED_MODEL_ORDER.indexOf(a.id);
    const idxB = PREFERRED_MODEL_ORDER.indexOf(b.id);
    if (idxA !== -1 && idxB !== -1) return idxA - idxB;
    if (idxA !== -1) return -1;
    if (idxB !== -1) return 1;
    return a.displayName.localeCompare(b.displayName);
  });

  return models;
}

const PERSONALITY_DIRECTIVES: Record<SuperPowerConfig['personality']['preset'], string> = {
  'nova-balanced': 'Balanced, helpful, well-structured general intelligence assistant.',
  'friendly-mentor':
    'Approachable, encouraging mentor who explains steps patiently and builds user confidence.',
  'concise-executive':
    'Sharp executive briefer: prioritize key takeaways first, bullet actionable points, zero filler.',
  'technical-architect':
    'Principal systems architect: precise terminology, trade-offs, edge cases, and structured specs.',
  'creative-storyteller':
    'Expressive, vivid writer who balances narrative clarity with imaginative phrasing.',
  'bilingual-tutor':
    'Seamless English + Bengali (বাংলা) educator who bridges terminology clearly across both languages.',
};

const TONE_DIRECTIVES: Record<SuperPowerConfig['personality']['tone'], string> = {
  neutral: 'Maintain a calm, objective, neutral tone.',
  warm: 'Use a warm, approachable, supportive tone.',
  direct: 'Be direct, crisp, and matter-of-fact without conversational fluff.',
  academic: 'Adopt a rigorous, scholarly tone with precise definitions and logical flow.',
  playful: 'Keep the tone lightly conversational and engaging while staying strictly accurate.',
};

const LANGUAGE_DIRECTIVES: Record<SuperPowerConfig['personality']['languagePriority'], string> = {
  'match-user': 'Respond in the same language the user writes in (English, Bengali, etc.).',
  'english-first':
    'Default to clear English unless the user explicitly asks for Bengali or another language.',
  'bengali-first':
    'Prioritize natural, clear Bengali (বাংলা) explanations while keeping technical identifiers in English.',
  'bilingual-bn-en':
    'Provide clear English paired seamlessly with natural Bengali (বাংলা) explanations when teaching or clarifying.',
};

export function resolveSuperPowerThinkingLevel(
  modelId: string,
  setting: SuperPowerThinkingLevel,
  mode: string
): ThinkingLevel | undefined {
  const lower = modelId.toLowerCase();
  const isGemini4 = lower.startsWith('gemini-4');
  const isGemini3 = lower.startsWith('gemini-3');
  if (!isGemini4 && !isGemini3) {
    return undefined;
  }

  if (setting === 'low') return ThinkingLevel.LOW;
  if (setting === 'medium') return ThinkingLevel.MEDIUM;
  if (setting === 'high') return ThinkingLevel.HIGH;

  // 'auto': keep Gemini 4 general/writing snappy at LOW while letting coding/study/Gemini 3 decide naturally
  if (isGemini4 && (mode === 'general' || mode === 'writing')) {
    return ThinkingLevel.LOW;
  }
  return undefined;
}

export function buildSystemInstruction(
  mode: string,
  studyLanguage: string,
  superPower?: SuperPowerConfig
): string {
  const coreIdentity =
    superPower?.systemPrompt?.trim() ||
    'You are NOVA AI, a thoughtful, accurate, and clear personal AI assistant.';

  const p = superPower?.personality;
  const rb = superPower?.responseBehavior;
  const feats = superPower?.features;

  const personalityBlock = p
    ? [
        `AI PERSONALITY PROFILE (${p.preset}):`,
        `- ${PERSONALITY_DIRECTIVES[p.preset] || PERSONALITY_DIRECTIVES['nova-balanced']}`,
        `- ${TONE_DIRECTIVES[p.tone] || TONE_DIRECTIVES.warm}`,
        `- ${LANGUAGE_DIRECTIVES[p.languagePriority] || LANGUAGE_DIRECTIVES['match-user']}`,
        p.empathyBoost
          ? '- Acknowledge user intent smoothly and adapt explanations when the user seems stuck.'
          : '- Focus strictly on task execution without empathetic preamble.',
        p.citationsStrictness
          ? '- Never fabricate facts, URLs, or citations; distinguish verified knowledge from inference.'
          : '',
      ]
        .filter(Boolean)
        .join('\n')
    : '';

  const behaviorBlock = rb
    ? [
        'RESPONSE BEHAVIOR CONTROLS:',
        rb.verbosity === 'concise'
          ? '- Keep responses brief, dense with signal, and under 3 short paragraphs unless the user explicitly asks for deep detail.'
          : rb.verbosity === 'detailed'
            ? '- Provide thorough, comprehensive explanations covering edge cases, context, and step-by-step reasoning.'
            : '- Maintain balanced detail: clear structure without unnecessary padding.',
        rb.markdownFormatting
          ? '- Format responses cleanly with Markdown headings, lists, and fenced code blocks where helpful.'
          : '- Prefer clean plain paragraphs and minimal Markdown formatting.',
        rb.includeFollowUpSuggestions
          ? '- When helpful, end with 1–2 brief next-step follow-up suggestions.'
          : '',
        rb.admitUncertainty
          ? '- If information is uncertain, missing, or unverified, state that honestly rather than guessing.'
          : '',
      ]
        .filter(Boolean)
        .join('\n')
    : '- Format responses cleanly with Markdown where helpful, keep explanations well-structured, and never fabricate facts or citations.';

  const strictRules = [
    'STRICT OUTPUT RULES:',
    '- NEVER output raw JSON tool calls, `action`, `action_input`, `dalle.text2im`, `<thought>` tags, or internal reasoning traces.',
    '- NEVER pretend that a raster image was generated when you only output text.',
    '- When the user asks for an AI-generated photo or raster artwork in text chat, politely explain that raster image generation is handled separately via the **Generate Image** button (which opens Gemini at gemini.google.com so they can generate and upload back) or **Image Assistant → Nano Banana Studio** (when paid API billing is enabled).',
    feats?.svgDiagramsEnabled === false
      ? '- Do NOT output raw inline SVG diagrams unless the user explicitly asks for raw XML/SVG code.'
      : '- When the user specifically asks for a diagram, flowchart, chart, icon, or vector SVG graphic, output a clean, self-contained fenced `svg` code block (` ```svg `) with an explicit `viewBox`, rich gradients/shapes, and legible typography—the app automatically renders it as an interactive visual preview with PNG/SVG export.',
  ].join('\n');

  const sections = [coreIdentity, personalityBlock, behaviorBlock, strictRules].filter(
    Boolean
  );

  if (mode === 'study') {
    const langGuidance =
      studyLanguage === 'bengali'
        ? 'Deliver your explanations primarily in clear, natural, student-friendly Bengali (বাংলা), while keeping essential scientific, mathematical, or technical terms in English alongside the Bengali explanation so students learn standard terminology.'
        : studyLanguage === 'english'
          ? 'Deliver clear, accessible explanations in English, unless the student specifically asks in Bengali.'
          : 'For every concept, provide a structured dual-layer explanation: clear academic explanation in English paired with a friendly, easy-to-understand Bengali explanation (বাংলায় সহজ ব্যাখ্যা) so students deeply understand both exam terminology and core intuition.';

    sections.push(
      [
        'ACTIVE MODE: Study Mode for Students.',
        '- Break complex topics down step by step from first principles.',
        '- Use relatable analogies and worked examples before formulas or abstractions.',
        `- ${langGuidance}`,
        '- End major concept explanations with 1–2 quick self-check questions or a concise summary takeaway to help the student test their understanding.',
      ].join('\n')
    );
  } else if (mode === 'coding') {
    sections.push(
      [
        'ACTIVE MODE: Coding & Engineering Assistant.',
        '- Write clean, modern, idiomatic, production-grade code with proper types and edge-case handling.',
        '- Explain architectural trade-offs, time/space complexity, and debugging steps concisely.',
        '- Always specify the language in fenced code blocks for accurate syntax highlighting.',
      ].join('\n')
    );
  } else if (mode === 'writing') {
    sections.push(
      [
        'ACTIVE MODE: Writing & Editorial Assistant.',
        '- Help craft clear, persuasive, well-paced prose for essays, emails, reports, and creative writing.',
        '- Offer structured improvements for clarity, grammar, tone, and readability without unnecessary fluff.',
        '- Support both English and Bengali writing gracefully when requested.',
      ].join('\n')
    );
  }

  const customInstructions = superPower?.customInstructions?.trim();
  if (customInstructions) {
    sections.push(`GLOBAL CUSTOM INSTRUCTIONS (ADMIN):\n${customInstructions}`);
  }

  return sections.join('\n\n');
}

export function toGeminiParts(msg: IncomingMessage): Part[] {
  const parts: Part[] = [];

  if (Array.isArray(msg.attachments)) {
    for (const att of msg.attachments) {
      if (!att?.data || !att?.mimeType) continue;
      if (att.kind === 'text' || att.mimeType.startsWith('text/')) {
        const label = att.name ? `Attached file (${att.name})` : 'Attached file';
        parts.push({
          text: `${label}:\n\`\`\`\n${att.data.slice(0, 60000)}\n\`\`\``,
        });
      } else {
        parts.push({
          inlineData: {
            mimeType: att.mimeType,
            data: att.data,
          },
        });
      }
    }
  }

  if (msg.content && msg.content.trim().length > 0) {
    parts.push({ text: msg.content });
  } else if (parts.length > 0) {
    parts.push({ text: 'Please analyze the attached file.' });
  }

  return parts;
}

export function buildGeminiHistory(priorMessages: IncomingMessage[]): Content[] {
  const history: Content[] = [];

  for (const msg of priorMessages) {
    if (msg.error) continue;
    const parts = toGeminiParts(msg);
    if (parts.length === 0) continue;

    const role = msg.role === 'assistant' ? 'model' : 'user';
    const prev = history[history.length - 1];
    if (prev && prev.role === role) {
      prev.parts = [...(prev.parts ?? []), ...parts];
    } else {
      history.push({ role, parts });
    }
  }

  // Ensure history ends with a model turn if possible so the new user message alternates cleanly
  while (history.length > 0 && history[history.length - 1].role === 'user') {
    history.pop();
  }

  return history;
}
