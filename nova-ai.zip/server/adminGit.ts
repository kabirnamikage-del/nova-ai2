import { execFile } from 'child_process';
import fs from 'fs';
import path from 'path';
import type { GitStatusReport, ValidationResult } from '../src/types/admin.ts';
import { WORKSPACE_ROOT } from './adminFiles.ts';

function runExecFile(
  cmd: string,
  args: string[],
  timeout = 30_000,
  extraEnv?: Record<string, string>
): Promise<{ ok: boolean; stdout: string; stderr: string }> {
  return new Promise((resolve) => {
    execFile(
      cmd,
      args,
      {
        cwd: WORKSPACE_ROOT,
        timeout,
        maxBuffer: 2 * 1024 * 1024,
        env: extraEnv ? { ...process.env, ...extraEnv } : process.env,
      },
      (err, stdout, stderr) => {
        resolve({
          ok: !err,
          stdout: (stdout || '').trim(),
          stderr: (stderr || '').trim(),
        });
      }
    );
  });
}

export async function getGitStatusReport(): Promise<GitStatusReport> {
  const githubTokenConfigured = Boolean(process.env.GITHUB_TOKEN?.trim());
  const githubRepo = process.env.GITHUB_REPO?.trim() || '';
  const githubBranch = process.env.GITHUB_BRANCH?.trim() || 'main';
  const notes: string[] = [];

  const gitVer = await runExecFile('git', ['--version'], 5000);
  if (!gitVer.ok) {
    notes.push('Git CLI is not installed in this container.');
    return {
      gitAvailable: false,
      isGitRepo: false,
      branch: 'none',
      clean: true,
      changedFiles: [],
      recentCommits: [],
      githubConfigured: githubTokenConfigured,
      githubRepo,
      githubBranch,
      notes,
    };
  }

  const isRepo = fs.existsSync(path.join(WORKSPACE_ROOT, '.git'));
  if (!isRepo) {
    notes.push(
      'This workspace directory is not currently initialized as a Git repository. You can initialize Git or export changes via backups.'
    );
    return {
      gitAvailable: true,
      isGitRepo: false,
      branch: 'uninitialized',
      clean: true,
      changedFiles: [],
      recentCommits: [],
      githubConfigured: githubTokenConfigured,
      githubRepo,
      githubBranch,
      notes,
    };
  }

  const [branchRes, statusRes, logRes] = await Promise.all([
    runExecFile('git', ['rev-parse', '--abbrev-ref', 'HEAD'], 5000),
    runExecFile('git', ['status', '--porcelain'], 5000),
    runExecFile('git', ['log', '-n', '8', '--format=%h|%ad|%an|%s', '--date=short'], 5000),
  ]);

  const changedFiles = statusRes.stdout
    ? statusRes.stdout
        .split('\n')
        .filter(Boolean)
        .map((line) => ({
          status: line.slice(0, 2).trim() || 'M',
          path: line.slice(3).trim(),
        }))
    : [];

  const recentCommits = logRes.stdout
    ? logRes.stdout
        .split('\n')
        .filter(Boolean)
        .map((line) => {
          const [hash, date, author, ...msgParts] = line.split('|');
          return {
            hash: hash || '',
            date: date || '',
            author: author || '',
            message: msgParts.join('|'),
          };
        })
    : [];

  if (!githubTokenConfigured) {
    notes.push(
      'GITHUB_TOKEN is not configured in server secrets; remote GitHub push/PR creation is disabled.'
    );
  }

  return {
    gitAvailable: true,
    isGitRepo: true,
    branch: branchRes.stdout || 'HEAD',
    clean: changedFiles.length === 0,
    changedFiles,
    recentCommits,
    githubConfigured: githubTokenConfigured,
    githubRepo,
    githubBranch,
    notes,
  };
}

export async function createGitUpdateBranch(
  branchName: string
): Promise<{ ok: boolean; branch: string; output: string }> {
  const cleanName = branchName.trim();
  if (!/^[a-zA-Z0-9._/-]{2,64}$/.test(cleanName)) {
    throw new Error('Invalid branch name. Use letters, numbers, -, _, ., or /.');
  }
  const res = await runExecFile('git', ['checkout', '-B', cleanName], 10_000);
  return {
    ok: res.ok,
    branch: cleanName,
    output: [res.stdout, res.stderr].filter(Boolean).join('\n') || `Switched to branch ${cleanName}`,
  };
}

export async function commitApprovedGitChanges(
  message: string
): Promise<{ ok: boolean; output: string }> {
  const cleanMessage = message.replace(/[\r\n]+/g, ' ').trim().slice(0, 140);
  if (!cleanMessage) {
    throw new Error('Commit message is required.');
  }

  const addRes = await runExecFile(
    'git',
    ['add', '-A', '--', '.', ':!.env*', ':!.nova-admin', ':!node_modules', ':!dist'],
    15_000
  );
  if (!addRes.ok) {
    return {
      ok: false,
      output: [addRes.stdout, addRes.stderr].filter(Boolean).join('\n'),
    };
  }

  const commitRes = await runExecFile('git', ['commit', '-m', cleanMessage], 15_000);
  return {
    ok: commitRes.ok,
    output: [commitRes.stdout, commitRes.stderr].filter(Boolean).join('\n'),
  };
}

export async function runBuildValidationSuite(): Promise<{
  lint: ValidationResult;
  build: ValidationResult;
}> {
  const lintStart = Date.now();
  const lintRes = await runExecFile('npm', ['run', 'lint'], 60_000);
  const lint: ValidationResult = {
    ok: lintRes.ok,
    command: 'npm run lint',
    output: [lintRes.stdout, lintRes.stderr].filter(Boolean).join('\n') || 'Lint passed.',
    durationMs: Date.now() - lintStart,
  };

  const buildStart = Date.now();
  const buildRes = await runExecFile('npm', ['run', 'build'], 90_000);
  const build: ValidationResult = {
    ok: buildRes.ok,
    command: 'npm run build',
    output: [buildRes.stdout, buildRes.stderr].filter(Boolean).join('\n') || 'Build completed.',
    durationMs: Date.now() - buildStart,
  };

  return { lint, build };
}

export async function pushToGitHubIfConfigured(
  branchName?: string
): Promise<{ ok: boolean; output: string }> {
  const token = process.env.GITHUB_TOKEN?.trim();
  const repoSlug = process.env.GITHUB_REPO?.trim();
  if (!token) {
    return {
      ok: false,
      output:
        'GITHUB_TOKEN is not set in server environment secrets. Add GITHUB_TOKEN (and optionally GITHUB_REPO) in Settings > Secrets to push branches.',
    };
  }

  const status = await getGitStatusReport();
  if (!status.isGitRepo) {
    return {
      ok: false,
      output: 'No local .git repository exists in the workspace.',
    };
  }

  const targetBranch =
    branchName?.trim() && /^[a-zA-Z0-9._/-]{2,64}$/.test(branchName.trim())
      ? branchName.trim()
      : status.branch;

  // Determine remote URL safely without printing token
  let remoteUrl = '';
  if (repoSlug && /^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+$/.test(repoSlug)) {
    remoteUrl = `https://x-access-token:${token}@github.com/${repoSlug}.git`;
  } else {
    const originRes = await runExecFile('git', ['remote', 'get-url', 'origin'], 5000);
    if (!originRes.ok || !originRes.stdout.includes('github.com')) {
      return {
        ok: false,
        output:
          'No GitHub origin remote found and GITHUB_REPO is not configured.',
      };
    }
    const cleanOrigin = originRes.stdout
      .replace(/^git@github\.com:/, 'https://github.com/')
      .replace(/^https:\/\/([^@]+@)?github\.com\//, 'https://github.com/');
    remoteUrl = cleanOrigin.replace(
      'https://github.com/',
      `https://x-access-token:${token}@github.com/`
    );
  }

  const pushRes = await runExecFile(
    'git',
    ['push', remoteUrl, `HEAD:${targetBranch}`],
    45_000
  );

  // Redact token from any git output just in case
  const safeOutput = [pushRes.stdout, pushRes.stderr]
    .filter(Boolean)
    .join('\n')
    .replaceAll(token, '[REDACTED]');

  return {
    ok: pushRes.ok,
    output: safeOutput || (pushRes.ok ? `Pushed HEAD to ${targetBranch}` : 'Push failed.'),
  };
}
